// db.js
// Data access layer for the Mosaic Health intake portal.
// Uses Node's built-in `node:sqlite` module (no npm install required).
// Requires Node.js 22.5+. Node will print an "experimental" warning — that's expected.

const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'intakes.db');
const db = new DatabaseSync(DB_PATH);

// ---- Production pragmas --------------------------------------------------
// WAL = readers don't block the writer and crashes can't corrupt the file.
// busy_timeout = wait up to 5s on a lock instead of failing instantly.
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA synchronous = NORMAL;');
db.exec('PRAGMA busy_timeout = 5000;');

// ---- Base schema (fresh installs) --------------------------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS intake_requests (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    title                 TEXT NOT NULL,
    request_type          TEXT,
    application_name      TEXT,
    requested_date        TEXT,
    requestor_name        TEXT,
    requestor_email       TEXT,
    liaison_po            TEXT,
    business_owner        TEXT,
    business_impact       TEXT,
    priority              TEXT,
    severity              TEXT,
    epmo_approved         TEXT,
    description           TEXT,
    effort_hours          INTEGER,
    estimation_status     TEXT,
    environment           TEXT,
    planned_release_date  TEXT,
    current_status        TEXT,
    uat_approver          TEXT,
    close_date            TEXT,
    remarks               TEXT,
    created_at            TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

// (indexes are created after all migrations below)

// ---- Migration: add Kanban/SDLC columns to pre-existing databases ------
// SQLite has no "ADD COLUMN IF NOT EXISTS", so check PRAGMA table_info first.
function ensureColumn(name, declaration) {
  const existing = db.prepare('PRAGMA table_info(intake_requests)').all().map(c => c.name);
  if (!existing.includes(name)) {
    db.exec(`ALTER TABLE intake_requests ADD COLUMN ${name} ${declaration}`);
  }
}

ensureColumn('ticket_track', `TEXT DEFAULT 'Project / Enhancement'`);
ensureColumn('t_shirt_size', 'TEXT');
ensureColumn('assigned_to', 'TEXT');
ensureColumn('stage_updated_at', 'TEXT');

// ---- Migration: draft workflow (Intake ID + Draft/Submitted status) -----
const hadDraftStatusColumn = db.prepare('PRAGMA table_info(intake_requests)').all()
  .map(c => c.name).includes('draft_status');
ensureColumn('draft_status', `TEXT DEFAULT 'Draft'`);
ensureColumn('intake_code', 'TEXT');
if (!hadDraftStatusColumn) {
  // The column didn't exist before this run, so every row that already
  // exists is, by definition, a previously-submitted real ticket — not a
  // fresh draft. Mark them all Submitted so they don't vanish from views.
  db.exec(`UPDATE intake_requests SET draft_status = 'Submitted' WHERE draft_status = 'Draft' OR draft_status IS NULL`);
}
// Backfill a human-readable Intake ID for any row that doesn't have one yet.
// Format: CM-001, CM-002, ... — a plain sequential counter (NOT the raw
// database id), so discarding a draft frees its number back up instead of
// leaving a permanent gap. Computed as "highest existing number + 1".
const CODE_PREFIX = 'CM-';
const CODE_PATTERN = /^CM-(\d+)$/;

function generateIntakeCode(number) {
  return `${CODE_PREFIX}${String(number).padStart(3, '0')}`;
}

function nextIntakeNumber() {
  const rows = db.prepare(`SELECT intake_code FROM intake_requests WHERE intake_code IS NOT NULL`).all();
  let max = 0;
  rows.forEach(r => {
    const m = CODE_PATTERN.exec(r.intake_code || '');
    if (m) max = Math.max(max, parseInt(m[1], 10));
  });
  return max + 1;
}

// If any row is missing a code, or still has the old "INT-YYYYMMDD-###"
// format from a previous version of this app, renumber every row from
// scratch in chronological order (oldest = CM-001) so the whole table uses
// one consistent, gap-free sequence.
const needsCodeMigration = db.prepare(`SELECT COUNT(*) AS c FROM intake_requests WHERE intake_code IS NULL OR intake_code = '' OR intake_code NOT LIKE 'CM-%'`).get().c > 0;
if (needsCodeMigration) {
  const rows = db.prepare(`SELECT id FROM intake_requests ORDER BY created_at ASC, id ASC`).all();
  const stmt = db.prepare('UPDATE intake_requests SET intake_code = ? WHERE id = ?');
  rows.forEach((row, idx) => {
    stmt.run(generateIntakeCode(idx + 1), row.id);
  });
}

// One-time-ish normalization: fold old generic stage names into the new
// canonical Project-track vocabulary. Safe to re-run (no-op once applied).
try {
  db.exec(`UPDATE intake_requests SET current_status = 'UAT In Progress'
           WHERE ticket_track = 'Project / Enhancement' AND current_status = 'Testing'`);
  db.exec(`UPDATE intake_requests SET current_status = 'Deployed'
           WHERE ticket_track = 'Project / Enhancement' AND current_status = 'Released'`);
} catch (e) { /* non-fatal */ }

// ---- Indexes (list views, My Drafts, Kanban and dedupe all filter on these) ----
db.exec(`
  CREATE INDEX IF NOT EXISTS idx_intake_draft_status ON intake_requests(draft_status);
  CREATE INDEX IF NOT EXISTS idx_intake_requestor    ON intake_requests(requestor_email);
  CREATE INDEX IF NOT EXISTS idx_intake_track_status ON intake_requests(ticket_track, current_status);
  CREATE INDEX IF NOT EXISTS idx_intake_code         ON intake_requests(intake_code);
`);

// ---- Field lists ---------------------------------------------------------
// FIELDS: everything settable via the intake form (create + full update)
const FIELDS = [
  'title', 'request_type', 'ticket_track', 'application_name', 'requested_date',
  'requestor_name', 'requestor_email', 'liaison_po', 'business_owner',
  'business_impact', 'priority', 'severity', 't_shirt_size', 'epmo_approved', 'description',
  'effort_hours', 'estimation_status', 'environment', 'planned_release_date',
  'current_status', 'assigned_to', 'uat_approver', 'close_date', 'remarks'
];

// Fields required before a draft can be finalized into a real submitted ticket
const REQUIRED_FOR_SUBMIT = ['title', 'request_type', 'application_name', 'requestor_name', 'priority', 'epmo_approved', 'description'];

// ============================================================================
// AUTH: users, sessions, password hashing
// ============================================================================
const crypto = require('crypto');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    email                TEXT NOT NULL UNIQUE,
    first_name           TEXT,
    last_name            TEXT,
    password_hash        TEXT NOT NULL,
    role                 TEXT NOT NULL DEFAULT 'Requestor',
    must_reset_password  INTEGER NOT NULL DEFAULT 1,
    created_at           TEXT DEFAULT CURRENT_TIMESTAMP,
    last_login_at        TEXT
  );
`);

function ensureUserColumn(name, declaration) {
  const existing = db.prepare('PRAGMA table_info(users)').all().map(c => c.name);
  if (!existing.includes(name)) {
    db.exec(`ALTER TABLE users ADD COLUMN ${name} ${declaration}`);
  }
}
// Offboarding: disable an account without deleting it (preserves history —
// who requested/approved what — while blocking further login).
ensureUserColumn('is_active', 'INTEGER NOT NULL DEFAULT 1');

db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    token          TEXT PRIMARY KEY,
    user_id        INTEGER NOT NULL,
    pending_reset  INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = String(stored).split(':');
  if (!salt || !hash) return false;
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(check, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function generateTempPassword() {
  // Readable random temp password, e.g. "A3F9-0C2B-7E41-D8A6-19BC" (80 bits).
  // Single-use: the user is forced to choose their own on first login.
  const chunk = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `${chunk()}-${chunk()}-${chunk()}-${chunk()}-${chunk()}`;
}

function sanitizeUser(u) {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return rest;
}

function findUserByEmail(email) {
  const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
  return stmt.get(String(email).toLowerCase().trim()) || null;
}

function getUserById(id) {
  const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
  return stmt.get(id) || null;
}

function listUsers() {
  const stmt = db.prepare('SELECT * FROM users ORDER BY created_at DESC');
  return stmt.all().map(sanitizeUser);
}

function createUser({ email, first_name, last_name, role, tempPassword }) {
  const pw = tempPassword || generateTempPassword();
  const stmt = db.prepare(`
    INSERT INTO users (email, first_name, last_name, password_hash, role, must_reset_password)
    VALUES (@email, @first_name, @last_name, @password_hash, @role, 1)
  `);
  const result = stmt.run({
    email: String(email).toLowerCase().trim(),
    first_name: first_name || '',
    last_name: last_name || '',
    password_hash: hashPassword(pw),
    role: role || 'Requestor',
  });
  return { id: Number(result.lastInsertRowid), tempPassword: pw };
}

function adminResetPassword(id, chosenPassword) {
  const tempPassword = chosenPassword || generateTempPassword();
  const stmt = db.prepare(`
    UPDATE users SET password_hash = @password_hash, must_reset_password = 1 WHERE id = @id
  `);
  const result = stmt.run({ id: Number(id), password_hash: hashPassword(tempPassword) });
  if (result.changes === 0) return null;
  return { tempPassword };
}

function setPassword(userId, newPassword) {
  const stmt = db.prepare(`
    UPDATE users SET password_hash = @password_hash, must_reset_password = 0 WHERE id = @id
  `);
  stmt.run({ id: Number(userId), password_hash: hashPassword(newPassword) });
}

function touchLastLogin(userId) {
  db.prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?').run(userId);
}

function createSession(userId, pendingReset = false) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token, user_id, pending_reset) VALUES (?, ?, ?)')
    .run(token, userId, pendingReset ? 1 : 0);
  return token;
}

const SESSION_TTL_DAYS = Number(process.env.SESSION_TTL_DAYS || 7); // matches cookie Max-Age

function purgeExpiredSessions() {
  const r = db.prepare(`DELETE FROM sessions WHERE created_at < datetime('now', ?)`)
    .run(`-${SESSION_TTL_DAYS} days`);
  return Number(r.changes);
}
purgeExpiredSessions(); // on boot; server.js also runs it hourly

function getSession(token) {
  if (!token) return null;
  const session = db.prepare(`SELECT * FROM sessions WHERE token = ? AND created_at >= datetime('now', ?)`)
    .get(token, `-${SESSION_TTL_DAYS} days`);
  if (!session) return null;
  const user = getUserById(session.user_id);
  if (!user) return null;
  return { token: session.token, pendingReset: !!session.pending_reset, user };
}

function deleteSession(token) {
  if (!token) return;
  db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

// Enable/disable a user account. Disabling immediately kills any active
// sessions for that user (so a currently-logged-in person is bounced on
// their very next request, not just blocked on future login attempts) —
// the account and its history stay intact, nothing is deleted.
function setUserActive(id, isActive) {
  const result = db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(isActive ? 1 : 0, Number(id));
  if (result.changes === 0) return null;
  if (!isActive) {
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(Number(id));
  }
  return sanitizeUser(getUserById(id));
}

// ---- Bootstrap: ensure at least one Admin account exists ---------------
(function ensureDefaultAdmin() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (count === 0) {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@mosaichealth.com';
    const { tempPassword } = createUser({
      email: adminEmail,
      first_name: 'System',
      last_name: 'Admin',
      role: 'Admin',
      tempPassword: process.env.ADMIN_TEMP_PASSWORD || undefined, // optional; else random
    });
    console.log('============================================================');
    console.log(' No users found — created a default Admin account:');
    console.log('   email:    ' + adminEmail);
    console.log('   temp pw:  ' + (process.env.ADMIN_TEMP_PASSWORD ? '(from ADMIN_TEMP_PASSWORD)' : tempPassword));
    console.log(' You will be required to set a new password on first login.');
    console.log('============================================================');
  }
})();

// ---- Queries -----------------------------------------------------------

function insertIntake(data) {
  const cols = FIELDS.join(', ');
  const placeholders = FIELDS.map(f => '@' + f).join(', ');
  // insertIntake creates a fully-formed record directly (not a draft), so
  // mark it Submitted immediately — otherwise it inherits the draft_status
  // column's DEFAULT 'Draft' and silently disappears from every view.
  const stmt = db.prepare(`
    INSERT INTO intake_requests (${cols}, draft_status, stage_updated_at)
    VALUES (${placeholders}, 'Submitted', CURRENT_TIMESTAMP)
  `);

  const params = {};
  for (const f of FIELDS) {
    let v = data[f];
    if (v === undefined) v = null;
    if (f === 'effort_hours') v = (v === null || v === '') ? null : Number(v);
    params[f] = v;
  }

  const result = stmt.run(params);
  const id = Number(result.lastInsertRowid);
  if (!params.intake_code) {
    const code = generateIntakeCode(nextIntakeNumber());
    db.prepare('UPDATE intake_requests SET intake_code = ? WHERE id = ?').run(code, id);
  }
  return id;
}

// Bulk import (Excel/CSV upload). Runs every insert inside one transaction
// so 2,000+ rows commit in well under a second, and a failure on one row
// doesn't roll back the ones that already succeeded — each row reports its
// own outcome instead. Assumes rows have already passed field validation
// (done both client-side and again in server.js before this is called).
function bulkInsertIntakes(rows) {
  const results = [];
  db.exec('BEGIN');
  try {
    rows.forEach((data, index) => {
      try {
        const id = insertIntake(data);
        const record = getIntakeById(id);
        results.push({ index, ok: true, id, intake_code: record.intake_code, title: record.title });
      } catch (err) {
        results.push({ index, ok: false, error: err.message, title: data.title });
      }
    });
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  return results;
}

function getAllIntakes(includeDrafts) {
  const sql = includeDrafts
    ? 'SELECT * FROM intake_requests ORDER BY created_at DESC, id DESC'
    : `SELECT * FROM intake_requests WHERE draft_status != 'Draft' OR draft_status IS NULL ORDER BY created_at DESC, id DESC`;
  return db.prepare(sql).all();
}

// "My Drafts": drafts belonging to one requestor, or every open draft for
// Admin/Analyst/Approver roles who might need to help someone finish one.
function getDrafts(email, includeAll) {
  const sql = includeAll
    ? `SELECT * FROM intake_requests WHERE draft_status = 'Draft' ORDER BY created_at DESC`
    : `SELECT * FROM intake_requests WHERE draft_status = 'Draft' AND requestor_email = ? ORDER BY created_at DESC`;
  return includeAll ? db.prepare(sql).all() : db.prepare(sql).all(email);
}

function deleteDraft(id) {
  const result = db.prepare(`DELETE FROM intake_requests WHERE id = ? AND draft_status = 'Draft'`).run(Number(id));
  return result.changes > 0;
}

function getIntakeById(id) {
  const stmt = db.prepare('SELECT * FROM intake_requests WHERE id = ?');
  return stmt.get(id) || null;
}

function updateIntake(id, data) {
  const setClause = FIELDS.map(f => `${f} = @${f}`).join(', ');
  const stmt = db.prepare(`UPDATE intake_requests SET ${setClause}, stage_updated_at = CURRENT_TIMESTAMP WHERE id = @id`);

  const params = { id: Number(id) };
  for (const f of FIELDS) {
    let v = data[f];
    if (v === undefined) v = null;
    if (f === 'effort_hours') v = (v === null || v === '') ? null : Number(v);
    params[f] = v;
  }

  const result = stmt.run(params);
  return Number(result.changes); // 0 if no row matched that id
}

// Lightweight partial update used by the Kanban board when a card is
// dragged to a new column. Only touches stage (current_status) and,
// optionally, the assignee — never clobbers the rest of the record.
function updateStage(id, stage, assignedTo) {
  const existing = getIntakeById(id);
  if (!existing) return null;

  const stmt = db.prepare(`
    UPDATE intake_requests
    SET current_status = @stage,
        assigned_to = COALESCE(@assigned_to, assigned_to),
        stage_updated_at = CURRENT_TIMESTAMP
    WHERE id = @id
  `);
  stmt.run({ id: Number(id), stage, assigned_to: assignedTo ?? null });
  return getIntakeById(id);
}

// ============================================================================
// DRAFT WORKFLOW: create-as-you-go intake with an assigned Intake ID,
// auto-saved per section, and a final validated "finalize" step.
// ============================================================================

// Creates an (almost) empty draft row so the UI can show a real Intake ID
// and auto-save into it as the user works through the wizard sections.
function createDraft(initial) {
  const cols = FIELDS.join(', ');
  const placeholders = FIELDS.map(f => '@' + f).join(', ');
  const stmt = db.prepare(`
    INSERT INTO intake_requests (${cols}, draft_status, stage_updated_at)
    VALUES (${placeholders}, 'Draft', CURRENT_TIMESTAMP)
  `);
  const params = {};
  for (const f of FIELDS) {
    let v = (initial || {})[f];
    if (v === undefined) v = null;
    if (f === 'effort_hours') v = (v === null || v === '') ? null : Number(v);
    if (f === 'title' && !v) v = ''; // NOT NULL column
    params[f] = v;
  }
  const result = stmt.run(params);
  const id = Number(result.lastInsertRowid);
  const code = generateIntakeCode(nextIntakeNumber());
  db.prepare('UPDATE intake_requests SET intake_code = ? WHERE id = ?').run(code, id);
  return getIntakeById(id);
}

// Partial update for auto-save — only touches whichever fields are present
// in `data`, never requires the rest of the record to be valid yet.
function patchDraft(id, data) {
  const existing = getIntakeById(id);
  if (!existing) return null;

  const presentFields = FIELDS.filter(f => Object.prototype.hasOwnProperty.call(data, f));
  if (presentFields.length === 0) return existing;

  const setClause = presentFields.map(f => `${f} = @${f}`).join(', ');
  const stmt = db.prepare(`UPDATE intake_requests SET ${setClause}, stage_updated_at = CURRENT_TIMESTAMP WHERE id = @id`);

  const params = { id: Number(id) };
  presentFields.forEach(f => {
    let v = data[f];
    if (f === 'effort_hours') v = (v === null || v === '') ? null : Number(v);
    params[f] = v;
  });

  stmt.run(params);
  return getIntakeById(id);
}

// Validates required fields, then flips a Draft into a real Submitted ticket.
// Returns { ok: true, record } or { ok: false, missing: [...] }.
function finalizeDraft(id, data) {
  const merged = { ...getIntakeById(id), ...data };
  const missing = REQUIRED_FOR_SUBMIT.filter(f => !String(merged[f] ?? '').trim());
  if (missing.length) return { ok: false, missing };

  const setClause = FIELDS.map(f => `${f} = @${f}`).join(', ');
  const stmt = db.prepare(`
    UPDATE intake_requests
    SET ${setClause}, draft_status = 'Submitted', stage_updated_at = CURRENT_TIMESTAMP
    WHERE id = @id
  `);
  const params = { id: Number(id) };
  FIELDS.forEach(f => {
    let v = data[f];
    if (v === undefined) v = getIntakeById(id)[f];
    if (f === 'effort_hours') v = (v === null || v === '') ? null : Number(v);
    if (f === 'current_status' && !v) v = 'Submitted';
    params[f] = v;
  });
  stmt.run(params);
  return { ok: true, record: getIntakeById(id) };
}

module.exports = {
  db, insertIntake, bulkInsertIntakes, getAllIntakes, getIntakeById, updateIntake, updateStage,
  // drafts
  createDraft, patchDraft, finalizeDraft, getDrafts, deleteDraft,
  // auth
  findUserByEmail, getUserById, listUsers, createUser, adminResetPassword,
  setPassword, touchLastLogin, verifyPassword, sanitizeUser,
  createSession, getSession, deleteSession, setUserActive, purgeExpiredSessions,
  DB_PATH,
};
