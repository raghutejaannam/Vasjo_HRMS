// server.js
// Zero-dependency HTTP server for the Mosaic Health intake portal.
// Run with:  node server.js
// Serves the form at http://localhost:3000 and exposes the intake + auth API.

const http = require('http');
const fs = require('fs');
const path = require('path');
const {
  insertIntake, bulkInsertIntakes, getAllIntakes, getIntakeById, updateIntake, updateStage,
  createDraft, patchDraft, finalizeDraft, getDrafts, deleteDraft,
  findUserByEmail, getUserById, listUsers, createUser, adminResetPassword,
  setPassword, touchLastLogin, verifyPassword, sanitizeUser,
  createSession, getSession, deleteSession, setUserActive, purgeExpiredSessions, db,
} = require('./db.js');

// ---- Config (all overridable via environment / .env) -----------------------
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const IS_PROD = process.env.NODE_ENV === 'production';
// Secure cookies require HTTPS. Default: on in production. Set COOKIE_SECURE=false
// only if you are testing over plain http on a non-localhost address.
const COOKIE_SECURE = process.env.COOKIE_SECURE
  ? process.env.COOKIE_SECURE === 'true'
  : IS_PROD;
// Set TRUST_PROXY=true when running behind nginx/ALB so client IPs (rate limiting)
// come from X-Forwarded-For instead of the proxy's own address.
const TRUST_PROXY = process.env.TRUST_PROXY === 'true';
// Only needed if the frontend is hosted on a DIFFERENT origin than this server.
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const DISABLE_CSP = process.env.DISABLE_CSP === 'true';
const HTML_FILE = path.join(__dirname, 'mosaic-health-intake.html');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_COOKIE = 'mh_session';
const SESSION_MAX_AGE = Number(process.env.SESSION_TTL_DAYS || 7) * 86400;

const MIME = {
  '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json',
  '.map': 'application/json', '.txt': 'text/plain; charset=utf-8',
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  header.split(';').forEach((pair) => {
    const idx = pair.indexOf('=');
    if (idx === -1) return;
    const key = pair.slice(0, idx).trim();
    const val = pair.slice(idx + 1).trim();
    out[key] = decodeURIComponent(val);
  });
  return out;
}

function securityHeaders() {
  const h = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  };
  if (IS_PROD || COOKIE_SECURE) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  if (!DISABLE_CSP) {
    // The app is one HTML file with inline <script>/<style>, plus xlsx + Chart.js
    // from cdnjs and Google Fonts. If you self-host those (see README), you can
    // drop the two external hosts below.
    h['Content-Security-Policy'] = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com data:",
      "img-src 'self' data: blob:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; ');
  }
  return h;
}

// CORS is only emitted when ALLOWED_ORIGIN is set. The old "*" + credentials
// combination is rejected by browsers and unsafe anyway; same-origin needs none.
function corsHeaders(req) {
  if (!ALLOWED_ORIGIN || req.headers.origin !== ALLOWED_ORIGIN) return {};
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
  };
}

function sendJson(res, status, body, cookie) {
  const payload = JSON.stringify(body);
  const headers = {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
    ...res.mhExtraHeaders, // security + CORS headers attached per-request
  };
  if (cookie) headers['Set-Cookie'] = cookie;
  res.writeHead(status, headers);
  res.end(payload);
}

function sessionCookie(token) {
  return `${SESSION_COOKIE}=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_MAX_AGE}${COOKIE_SECURE ? '; Secure' : ''}`;
}

function clearSessionCookie() {
  return `${SESSION_COOKIE}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${COOKIE_SECURE ? '; Secure' : ''}`;
}

function httpError(status, message) {
  const e = new Error(message);
  e.statusCode = status;
  return e;
}

const MAX_BODY = 25e6; // ~25MB: fits a multi-thousand-row bulk import

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(httpError(413, 'Request body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        const text = Buffer.concat(chunks).toString('utf8');
        resolve(text ? JSON.parse(text) : {});
      } catch (e) {
        reject(httpError(400, 'Request body is not valid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// ---- Login brute-force protection (in-memory, per IP + email) -------------
const LOGIN_MAX_FAILS = 10;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const loginFails = new Map(); // key -> { count, first }

function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = req.headers['x-forwarded-for'];
    if (xff) return String(xff).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}
function loginKey(req, email) { return clientIp(req) + '|' + String(email).toLowerCase(); }
function isLoginBlocked(key) {
  const e = loginFails.get(key);
  if (!e) return false;
  if (Date.now() - e.first > LOGIN_WINDOW_MS) { loginFails.delete(key); return false; }
  return e.count >= LOGIN_MAX_FAILS;
}
function recordLoginFail(key) {
  const e = loginFails.get(key);
  if (!e || Date.now() - e.first > LOGIN_WINDOW_MS) loginFails.set(key, { count: 1, first: Date.now() });
  else e.count++;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, e] of loginFails) if (now - e.first > LOGIN_WINDOW_MS) loginFails.delete(k);
}, 10 * 60 * 1000).unref();

// Returns the authenticated (non-pending-reset) session, or null.
function getAuthedSession(req) {
  const token = parseCookies(req)[SESSION_COOKIE];
  const session = getSession(token);
  if (!session || session.pendingReset) return null;
  if (!session.user.is_active) return null; // disabled since the session was issued
  return session;
}

const EDITOR_ROLES = ['Admin', 'Analyst', 'Approver'];

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const { pathname } = url;

  res.mhExtraHeaders = { ...securityHeaders(), ...corsHeaders(req) };

  // Minimal access log (method, path, status, ms) — no bodies, no cookies.
  const t0 = Date.now();
  if (pathname !== '/health') {
    res.on('finish', () => {
      console.log(`${new Date().toISOString()} ${clientIp(req)} ${req.method} ${pathname} ${res.statusCode} ${Date.now() - t0}ms`);
    });
  }

  // CORS preflight (only meaningful when ALLOWED_ORIGIN is configured)
  if (req.method === 'OPTIONS') {
    res.writeHead(204, res.mhExtraHeaders);
    return res.end();
  }

  try {
    // =====================================================================
    // AUTH ROUTES (public)
    // =====================================================================

    // ---- Log in with email + password ----
    if (pathname === '/api/auth/login' && req.method === 'POST') {
      const body = await readBody(req);
      const email = String(body.email || '').trim();
      const password = String(body.password || '').trim(); // guards against accidental
      // leading/trailing whitespace from a partial or sloppy copy-paste of a temp password
      if (!email || !password) return sendJson(res, 400, { error: 'email and password are required' });

      const rlKey = loginKey(req, email);
      if (isLoginBlocked(rlKey)) {
        return sendJson(res, 429, { error: 'Too many failed attempts. Try again in 15 minutes.' });
      }

      const user = findUserByEmail(email);
      if (!user || !verifyPassword(password, user.password_hash)) {
        recordLoginFail(rlKey);
        return sendJson(res, 401, { error: 'Invalid email or password' });
      }
      loginFails.delete(rlKey);
      if (!user.is_active) {
        return sendJson(res, 403, { error: 'This account has been disabled. Contact an administrator.' });
      }

      if (user.must_reset_password) {
        const token = createSession(user.id, true); // pending reset
        return sendJson(res, 200, { resetRequired: true, email: user.email }, sessionCookie(token));
      }

      touchLastLogin(user.id);
      const token = createSession(user.id, false);
      return sendJson(res, 200, { resetRequired: false, user: sanitizeUser(user) }, sessionCookie(token));
    }

    // ---- Set a new password (first-login reset) ----
    if (pathname === '/api/auth/set-password' && req.method === 'POST') {
      const cookieToken = parseCookies(req)[SESSION_COOKIE];
      const session = getSession(cookieToken);
      if (!session || !session.pendingReset) {
        return sendJson(res, 401, { error: 'No pending password reset for this session' });
      }
      const body = await readBody(req);
      const newPassword = String(body.newPassword || '').trim();
      if (!newPassword || newPassword.length < 8) {
        return sendJson(res, 400, { error: 'Password must be at least 8 characters' });
      }

      setPassword(session.user.id, newPassword);
      deleteSession(cookieToken);
      touchLastLogin(session.user.id);
      const token = createSession(session.user.id, false);
      const freshUser = getUserById(session.user.id);
      return sendJson(res, 200, { user: sanitizeUser(freshUser) }, sessionCookie(token));
    }

    // ---- Who am I? ----
    if (pathname === '/api/auth/me' && req.method === 'GET') {
      const token = parseCookies(req)[SESSION_COOKIE];
      const session = getSession(token);
      if (!session) return sendJson(res, 401, { error: 'Not logged in' });
      if (session.pendingReset) return sendJson(res, 200, { resetRequired: true, email: session.user.email });
      return sendJson(res, 200, { user: sanitizeUser(session.user) });
    }

    // ---- Log out ----
    if (pathname === '/api/auth/logout' && req.method === 'POST') {
      const token = parseCookies(req)[SESSION_COOKIE];
      deleteSession(token);
      return sendJson(res, 200, { ok: true }, clearSessionCookie());
    }

    // =====================================================================
    // Everything below this line requires a full (non-pending) session
    // =====================================================================
    const session = getAuthedSession(req);
    const isApiRoute = pathname.startsWith('/api/');
    if (isApiRoute && !session) {
      return sendJson(res, 401, { error: 'Login required' });
    }
    const currentUser = session ? session.user : null;

    // =====================================================================
    // USER MANAGEMENT (Admin only)
    // =====================================================================

    if (pathname === '/api/users' && req.method === 'GET') {
      if (currentUser.role !== 'Admin') return sendJson(res, 403, { error: 'Admin access required' });
      return sendJson(res, 200, listUsers());
    }

    if (pathname === '/api/users' && req.method === 'POST') {
      if (currentUser.role !== 'Admin') return sendJson(res, 403, { error: 'Admin access required' });
      const { email, first_name, last_name, role, temp_password } = await readBody(req);
      if (!email || !String(email).trim()) return sendJson(res, 400, { error: 'email is required' });
      if (findUserByEmail(email)) return sendJson(res, 409, { error: 'A user with that email already exists' });

      const { id, tempPassword } = createUser({
        email, first_name, last_name, role, tempPassword: temp_password,
      });
      return sendJson(res, 201, { id, tempPassword });
    }

    const userResetMatch = pathname.match(/^\/api\/users\/(\d+)\/reset$/);
    if (userResetMatch && req.method === 'POST') {
      if (currentUser.role !== 'Admin') return sendJson(res, 403, { error: 'Admin access required' });
      const result = adminResetPassword(Number(userResetMatch[1]));
      if (!result) return sendJson(res, 404, { error: 'User not found' });
      return sendJson(res, 200, result);
    }

    // ---- Enable / disable a user account (offboarding) ----
    const userActiveMatch = pathname.match(/^\/api\/users\/(\d+)\/active$/);
    if (userActiveMatch && req.method === 'PUT') {
      if (currentUser.role !== 'Admin') return sendJson(res, 403, { error: 'Admin access required' });
      const id = Number(userActiveMatch[1]);
      if (id === currentUser.id) return sendJson(res, 400, { error: 'You cannot disable your own account' });
      const body = await readBody(req);
      const updated = setUserActive(id, !!body.is_active);
      if (!updated) return sendJson(res, 404, { error: 'User not found' });
      return sendJson(res, 200, updated);
    }

    // =====================================================================
    // INTAKE ROUTES (any logged-in user, edits gated by role/ownership)
    // =====================================================================

    // ---- API: create intake ----
    if (pathname === '/api/intake' && req.method === 'POST') {
      const data = await readBody(req);
      if (!data.title || !String(data.title).trim()) {
        return sendJson(res, 400, { error: 'title is required' });
      }
      const id = insertIntake(data);
      return sendJson(res, 201, { id });
    }

    // ---- API: bulk import from Excel/CSV (Admin/Analyst/Approver only) ----
    if (pathname === '/api/intake/bulk' && req.method === 'POST') {
      if (!EDITOR_ROLES.includes(currentUser.role)) {
        return sendJson(res, 403, { error: 'Admin, Analyst, or Approver access required for bulk import' });
      }
      const body = await readBody(req);
      const rows = Array.isArray(body.rows) ? body.rows : null;
      if (!rows || !rows.length) {
        return sendJson(res, 400, { error: 'rows array is required and must not be empty' });
      }
      if (rows.length > 10000) {
        return sendJson(res, 400, { error: 'Maximum 10,000 rows per import — split into smaller batches' });
      }

      // Server-side validation, same required fields as the wizard's
      // finalize step. The frontend already validates before sending, but
      // this is the real gate — never trust a client-only check.
      const REQUIRED = ['title', 'request_type', 'application_name', 'requestor_name', 'priority', 'epmo_approved', 'description'];
      const VALID_REQUEST_TYPES = ['Infra / IT', 'Config', 'Data Fix', 'SSCR'];
      const VALID_PRIORITIES = ['P1', 'P2', 'P3', 'P4'];
      const VALID_EPMO = ['Yes', 'No'];
      const VALID_TRACKS = ['Project / Enhancement', 'Lights-On / Steady State'];

      const validRows = [];
      const rejected = [];
      rows.forEach((row, index) => {
        const errors = [];
        REQUIRED.forEach(f => { if (!String(row[f] ?? '').trim()) errors.push(`Missing ${f}`); });
        if (row.request_type && !VALID_REQUEST_TYPES.includes(row.request_type)) errors.push(`Invalid request_type "${row.request_type}"`);
        if (row.priority && !VALID_PRIORITIES.includes(row.priority)) errors.push(`Invalid priority "${row.priority}"`);
        if (row.epmo_approved && !VALID_EPMO.includes(row.epmo_approved)) errors.push(`Invalid epmo_approved "${row.epmo_approved}"`);
        if (row.ticket_track && !VALID_TRACKS.includes(row.ticket_track)) errors.push(`Invalid ticket_track "${row.ticket_track}"`);

        if (errors.length) {
          rejected.push({ index, title: row.title || '(untitled)', errors });
        } else {
          validRows.push({
            ...row,
            ticket_track: row.ticket_track || 'Project / Enhancement',
            current_status: row.current_status || 'Submitted',
          });
        }
      });

      const inserted = validRows.length ? bulkInsertIntakes(validRows) : [];
      const insertFailures = inserted.filter(r => !r.ok);

      return sendJson(res, 200, {
        totalRows: rows.length,
        insertedCount: inserted.filter(r => r.ok).length,
        rejectedCount: rejected.length + insertFailures.length,
        rejected: [
          ...rejected,
          ...insertFailures.map(f => ({ index: f.index, title: f.title, errors: [f.error] })),
        ],
      });
    }

    // ---- API: create a draft (assigns an Intake ID immediately) ----
    if (pathname === '/api/intake/draft' && req.method === 'POST') {
      const data = await readBody(req);
      const draft = createDraft({
        requestor_name: `${currentUser.first_name || ''} ${currentUser.last_name || ''}`.trim(),
        requestor_email: currentUser.email,
        ...data,
      });
      return sendJson(res, 201, draft);
    }

    // ---- API: auto-save a draft (partial update, no validation) ----
    const draftPatchMatch = pathname.match(/^\/api\/intake\/(\d+)\/draft$/);
    if (draftPatchMatch && req.method === 'PATCH') {
      const id = Number(draftPatchMatch[1]);
      const existing = getIntakeById(id);
      if (!existing) return sendJson(res, 404, { error: 'not found' });

      const canEdit = EDITOR_ROLES.includes(currentUser.role)
        || (existing.requestor_email && existing.requestor_email.toLowerCase() === currentUser.email.toLowerCase());
      if (!canEdit) return sendJson(res, 403, { error: 'You do not have permission to edit this draft' });

      const data = await readBody(req);
      const updated = patchDraft(id, data);
      return sendJson(res, 200, updated);
    }

    // ---- API: finalize a draft into a real submitted ticket ----
    const draftFinalizeMatch = pathname.match(/^\/api\/intake\/(\d+)\/finalize$/);
    if (draftFinalizeMatch && req.method === 'POST') {
      const id = Number(draftFinalizeMatch[1]);
      const existing = getIntakeById(id);
      if (!existing) return sendJson(res, 404, { error: 'not found' });

      const canEdit = EDITOR_ROLES.includes(currentUser.role)
        || (existing.requestor_email && existing.requestor_email.toLowerCase() === currentUser.email.toLowerCase());
      if (!canEdit) return sendJson(res, 403, { error: 'You do not have permission to submit this draft' });

      const data = await readBody(req);
      const result = finalizeDraft(id, data);
      if (!result.ok) return sendJson(res, 400, { error: 'Missing required fields', missing: result.missing });
      return sendJson(res, 200, result.record);
    }

    // ---- API: list "my drafts" (all open drafts for Admin/Analyst/Approver) ----
    if (pathname === '/api/intake/drafts' && req.method === 'GET') {
      const includeAll = EDITOR_ROLES.includes(currentUser.role);
      return sendJson(res, 200, getDrafts(currentUser.email, includeAll));
    }

    // ---- API: discard a draft ----
    if (draftPatchMatch && req.method === 'DELETE') {
      const id = Number(draftPatchMatch[1]);
      const existing = getIntakeById(id);
      if (!existing) return sendJson(res, 404, { error: 'not found' });
      if (existing.draft_status !== 'Draft') return sendJson(res, 400, { error: 'Only drafts can be discarded' });

      const canEdit = EDITOR_ROLES.includes(currentUser.role)
        || (existing.requestor_email && existing.requestor_email.toLowerCase() === currentUser.email.toLowerCase());
      if (!canEdit) return sendJson(res, 403, { error: 'You do not have permission to discard this draft' });

      const deleted = deleteDraft(id);
      return sendJson(res, deleted ? 200 : 404, { deleted });
    }

    // ---- API: list intakes ----
    if (pathname === '/api/intake' && req.method === 'GET') {
      return sendJson(res, 200, getAllIntakes());
    }

    // ---- API: single intake by id ----
    const singleMatch = pathname.match(/^\/api\/intake\/(\d+)$/);
    if (singleMatch && req.method === 'GET') {
      const record = getIntakeById(Number(singleMatch[1]));
      if (!record) return sendJson(res, 404, { error: 'not found' });
      return sendJson(res, 200, record);
    }

    // ---- API: update intake (Admin/Analyst/Approver, or the original requestor) ----
    if (singleMatch && req.method === 'PUT') {
      const id = Number(singleMatch[1]);
      const existing = getIntakeById(id);
      if (!existing) return sendJson(res, 404, { error: 'not found' });

      const canEdit = EDITOR_ROLES.includes(currentUser.role)
        || (existing.requestor_email && existing.requestor_email.toLowerCase() === currentUser.email.toLowerCase());
      if (!canEdit) return sendJson(res, 403, { error: 'You do not have permission to edit this request' });

      const data = await readBody(req);
      if (!data.title || !String(data.title).trim()) {
        return sendJson(res, 400, { error: 'title is required' });
      }
      const changes = updateIntake(id, data);
      if (changes === 0) return sendJson(res, 404, { error: 'not found' });
      return sendJson(res, 200, getIntakeById(id));
    }

    // ---- API: update stage only (Kanban drag-and-drop) ----
    const stageMatch = pathname.match(/^\/api\/intake\/(\d+)\/stage$/);
    if (stageMatch && req.method === 'PATCH') {
      const id = Number(stageMatch[1]);
      const existing = getIntakeById(id);
      if (!existing) return sendJson(res, 404, { error: 'not found' });

      const canEdit = EDITOR_ROLES.includes(currentUser.role)
        || (existing.requestor_email && existing.requestor_email.toLowerCase() === currentUser.email.toLowerCase());
      if (!canEdit) return sendJson(res, 403, { error: 'You do not have permission to move this ticket' });

      const data = await readBody(req);
      if (!data.stage || !String(data.stage).trim()) {
        return sendJson(res, 400, { error: 'stage is required' });
      }
      const updated = updateStage(id, data.stage, data.assigned_to);
      if (!updated) return sendJson(res, 404, { error: 'not found' });
      return sendJson(res, 200, updated);
    }

    // ---- Health check (load balancers, uptime monitors, Docker) ----
    if (pathname === '/health' && req.method === 'GET') {
      db.prepare('SELECT 1').get(); // proves the DB is reachable
      return sendJson(res, 200, { status: 'ok', uptime: Math.round(process.uptime()) });
    }

    // ---- Static: serve the app shell at / (public — the app itself gates via JS) ----
    if ((pathname === '/' || pathname === '/index.html') && req.method === 'GET') {
      const html = fs.readFileSync(HTML_FILE);
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...res.mhExtraHeaders });
      return res.end(html);
    }

    // ---- Static: optional self-hosted assets from ./public (vendor libs, fonts, favicon) ----
    if (req.method === 'GET' && pathname !== '/' && !isApiRoute) {
      let rel;
      try { rel = decodeURIComponent(pathname); } catch (e) { rel = null; }
      if (rel) {
        const file = path.normalize(path.join(PUBLIC_DIR, rel));
        // path-traversal guard: resolved file must stay inside ./public
        if (file.startsWith(PUBLIC_DIR + path.sep) && fs.existsSync(file) && fs.statSync(file).isFile()) {
          const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
          res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'public, max-age=86400', ...res.mhExtraHeaders });
          return fs.createReadStream(file).pipe(res);
        }
      }
      if (pathname === '/favicon.ico') { res.writeHead(204, res.mhExtraHeaders); return res.end(); }
    }

    // ---- 404 ----
    res.writeHead(404, { 'Content-Type': 'text/plain', ...res.mhExtraHeaders });
    res.end('Not found');
  } catch (err) {
    if (err && err.statusCode) {
      return sendJson(res, err.statusCode, { error: err.message }); // 400 bad JSON, 413 too large
    }
    console.error(err);
    // Never leak internals (stack, SQL, file paths) to clients in production.
    sendJson(res, 500, IS_PROD
      ? { error: 'internal server error' }
      : { error: 'internal server error', detail: err.message });
  }
});

// Slow-client protection
server.headersTimeout = 20000;
server.requestTimeout = 60000;

server.listen(PORT, HOST, () => {
  console.log(`Mosaic Health intake server running at http://localhost:${PORT}  (${IS_PROD ? 'production' : 'development'}, secure cookies: ${COOKIE_SECURE})`);
  console.log(`Health: GET http://localhost:${PORT}/health`);
  console.log(`API:  POST       http://localhost:${PORT}/api/auth/login`);
  console.log(`API:  POST       http://localhost:${PORT}/api/auth/set-password`);
  console.log(`API:  GET        http://localhost:${PORT}/api/auth/me`);
  console.log(`API:  POST       http://localhost:${PORT}/api/auth/logout`);
  console.log(`API:  GET/POST   http://localhost:${PORT}/api/users  (Admin only)`);
  console.log(`API:  POST/GET   http://localhost:${PORT}/api/intake`);
  console.log(`API:  POST       http://localhost:${PORT}/api/intake/bulk  (Admin/Analyst/Approver only)`);
  console.log(`API:  GET/PUT    http://localhost:${PORT}/api/intake/:id`);
  console.log(`API:  PATCH      http://localhost:${PORT}/api/intake/:id/stage`);
  console.log(`API:  POST       http://localhost:${PORT}/api/intake/draft`);
  console.log(`API:  PATCH      http://localhost:${PORT}/api/intake/:id/draft`);
  console.log(`API:  POST       http://localhost:${PORT}/api/intake/:id/finalize`);
});

// ---- Housekeeping ------------------------------------------------------------
// Drop expired sessions hourly so the sessions table can't grow without bound.
setInterval(() => {
  try { const n = purgeExpiredSessions(); if (n) console.log(`Purged ${n} expired session(s)`); }
  catch (e) { console.error('Session purge failed:', e.message); }
}, 60 * 60 * 1000).unref();

// Graceful shutdown: finish in-flight requests, flush WAL, then exit.
function shutdown(signal) {
  console.log(`${signal} received — shutting down…`);
  server.close(() => {
    try { db.exec('PRAGMA wal_checkpoint(TRUNCATE);'); db.close(); } catch (e) { /* ignore */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref(); // hard stop if something hangs
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e));
