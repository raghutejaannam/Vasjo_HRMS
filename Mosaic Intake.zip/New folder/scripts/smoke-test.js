// Usage: BASE=http://localhost:3000 EMAIL=admin@... PASSWORD=... node scripts/smoke-test.js
// Post-deploy check: logs in, creates a draft, autosaves it, lists, then discards the draft.
// Leaves NO data behind (drafts are deleted; nothing is ever submitted).
const BASE = process.env.BASE || 'http://localhost:3000';
const { EMAIL, PASSWORD } = process.env;
if (!EMAIL || !PASSWORD) { console.error('Set EMAIL and PASSWORD (a fully activated account)'); process.exit(1); }

let cookie = '';
async function call(method, url, body) {
  const res = await fetch(BASE + url, {
    method, headers: { 'Content-Type': 'application/json', ...(cookie && { Cookie: cookie }) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const set = res.headers.get('set-cookie'); if (set) cookie = set.split(';')[0];
  let json = null; try { json = await res.json(); } catch (e) {}
  return { status: res.status, json };
}
let failed = 0;
const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) failed++; };

(async () => {
  let r = await call('GET', '/health'); check('health', r.status === 200);
  r = await call('GET', '/api/intake'); check('API blocked when logged out', r.status === 401);
  r = await call('POST', '/api/auth/login', { email: EMAIL, password: PASSWORD });
  check('login', r.status === 200 && r.json && r.json.resetRequired === false, r.json && r.json.error);
  if (failed) process.exit(1);
  r = await call('GET', '/api/auth/me'); check('session /me', r.status === 200);
  r = await call('POST', '/api/intake/draft', { title: '[SMOKE TEST]' });
  check('create draft', r.status === 201 && r.json.intake_code, r.json && r.json.intake_code);
  const id = r.json.id;
  r = await call('POST', `/api/intake/${id}/finalize`, { title: '[SMOKE TEST]' });
  check('finalize rejects incomplete draft', r.status === 400 && Array.isArray(r.json.missing));
  r = await call('PATCH', `/api/intake/${id}/draft`, { description: 'autosave works' });
  check('draft autosave', r.status === 200 && r.json.description === 'autosave works');
  r = await call('GET', '/api/intake/drafts'); check('drafts list', r.status === 200 && r.json.some(t => t.id === id));
  r = await call('GET', '/api/intake'); check('list works', r.status === 200 && Array.isArray(r.json));
  r = await call('DELETE', `/api/intake/${id}/draft`); check('discard draft (cleanup)', r.status === 200 && r.json.deleted === true);
  r = await call('POST', '/api/auth/logout'); check('logout', r.status === 200);
  r = await call('GET', '/api/intake'); check('API blocked after logout', r.status === 401);
  console.log(failed ? `\n${failed} check(s) FAILED` : '\nAll checks passed.');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
