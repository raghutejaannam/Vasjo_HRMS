// Usage: node scripts/create-user.js <email> <role> [first_name] [last_name]
// Roles: Admin | Analyst | Approver | Requestor
// Prints a one-time temp password; the user must change it at first login.
const { createUser, findUserByEmail } = require('../db.js');
const [email, role = 'Requestor', first = '', last = ''] = process.argv.slice(2);
const ROLES = ['Admin', 'Analyst', 'Approver', 'Requestor'];
if (!email || !ROLES.includes(role)) {
  console.error('Usage: node scripts/create-user.js <email> <Admin|Analyst|Approver|Requestor> [first] [last]');
  process.exit(1);
}
if (findUserByEmail(email)) { console.error('User already exists: ' + email); process.exit(1); }
const { tempPassword } = createUser({ email, first_name: first, last_name: last, role });
console.log(`Created ${role}: ${email}\nTemp password: ${tempPassword}`);
