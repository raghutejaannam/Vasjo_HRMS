// Usage: node scripts/backup.js [keep=14]
// Consistent hot backup (safe while the server is running) using VACUUM INTO.
// Writes backups/intakes-YYYYMMDD-HHMMSS.db and keeps the newest N.
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { db } = require('../db.js');

const keep = Number(process.argv[2] || process.env.BACKUP_KEEP || 14);
const dir = process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups');
fs.mkdirSync(dir, { recursive: true });

const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
const out = path.join(dir, `intakes-${stamp}.db`);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`);
// Sessions are transient login tokens — don't keep them in backups.
const b = new DatabaseSync(out); b.exec('DELETE FROM sessions'); b.exec('VACUUM'); b.close();
fs.chmodSync(out, 0o600);
console.log('Backup written: ' + out);

const files = fs.readdirSync(dir).filter(f => /^intakes-.*\.db$/.test(f)).sort().reverse();
files.slice(keep).forEach(f => { fs.unlinkSync(path.join(dir, f)); console.log('Pruned old backup: ' + f); });
