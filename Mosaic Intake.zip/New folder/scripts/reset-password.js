// Usage: node --no-warnings scripts/reset-password.js [email] [temp-password]
//   email         defaults to ADMIN_EMAIL or admin@mosaichealth.com
//   temp-password optional (min 8 chars). If omitted, a random one is generated.
// Lock-out recovery (e.g. the only Admin forgot / never knew the password).
// Sets a one-time temp password, forces a new password at next login,
// re-enables the account, and signs the user out everywhere.
const { db, findUserByEmail, adminResetPassword, setUserActive } = require('../db.js');

const email = process.argv[2] || process.env.ADMIN_EMAIL || 'admin@mosaichealth.com';
const chosen = process.argv[3] || process.env.NEW_TEMP_PASSWORD || undefined;

const user = findUserByEmail(email);
if (!user) {
  console.error('No such user: ' + email);
  console.error('Existing users: ' + db.prepare('SELECT email FROM users').all().map(u => u.email).join(', '));
  process.exit(1);
}
if (chosen && chosen.trim().length < 8) {
  console.error('Temp password must be at least 8 characters');
  process.exit(1);
}

const { tempPassword } = adminResetPassword(user.id, chosen && chosen.trim());
setUserActive(user.id, true);
db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
console.log(`Password reset for ${user.email}\nTemp password: ${tempPassword}\nYou will be asked to set a new password at first login.`);
