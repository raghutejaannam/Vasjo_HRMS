# Mosaic Health Intake Portal

Node + SQLite, **zero npm dependencies**. Requires **Node.js 22.5 or newer** (uses the built-in `node:sqlite`).

## Files

| File | Purpose |
|---|---|
| `server.js` | HTTP server, auth, API routes, security headers, rate limiting, `/health` |
| `db.js` | SQLite schema, migrations, queries, users/sessions |
| `mosaic-health-intake.html` | The whole frontend (served at `/`) |
| `intakes.db` | Your existing data (114 tickets, 1 admin). Stale session tokens removed. Delete it for a clean start. |
| `package.json` | `npm start`, `npm run backup`, etc. |
| `.env.example` | Every setting, documented |
| `scripts/create-user.js` | Add a user from the command line |
| `scripts/reset-password.js` | Recover a locked-out account (incl. the only Admin) |
| `scripts/backup.js` | Safe hot backup of the DB, keeps the newest 14 |
| `scripts/smoke-test.js` | Post-deploy check; leaves no data behind |
| `Dockerfile`, `docker-compose.yml` | Container deploy |
| `deploy/` | systemd unit, nginx HTTPS config, backup cron |
| `public/` | Optional self-hosted assets (served at `/...`) |

## Run locally

```bash
node --version          # must be v22.5+
npm start               # http://localhost:3000
```
First boot with an empty DB prints a one-time admin temp password in the console.
With the shipped `intakes.db`, the admin already exists; if you don't know its password:
`node --no-warnings scripts/reset-password.js` (defaults to admin@mosaichealth.com), or choose your own temp password:
`node --no-warnings scripts/reset-password.js admin@mosaichealth.com 'MyTempPass123'`
You are forced to set a new password at first login.

## Go-live checklist

1. **Decide on data.** Keep `intakes.db` (real tickets) or delete it to start clean.
2. **Copy `.env.example` to `.env`** and set `NODE_ENV=production`, `TRUST_PROXY=true`.
3. **Put HTTPS in front** (`deploy/nginx.conf` + certbot). Login cookies are marked `Secure`
   in production, so **login will not work over plain http** except on `localhost`.
4. **Run it under a supervisor**: Docker (`docker compose up -d --build`) or systemd (`deploy/mosaic-intake.service`).
5. **Log in as admin, set a new password**, then create real users in the Users screen
   (or `npm run create-user -- someone@mosaichealth.com Analyst First Last`).
6. **Schedule backups** (`deploy/backup.cron`) and copy them off the server. Do one restore test.
7. **Run the smoke test**:
   `BASE=https://intake.example.com EMAIL=... PASSWORD=... npm run smoke`
8. Monitor `GET /health` (returns 200 + `{"status":"ok"}`).

## Docker notes
The DB lives in the `intake-data` volume (`/data/intakes.db`). The image does **not** contain `intakes.db`.
To seed it with your existing data:
`docker compose cp intakes.db intake:/data/intakes.db && docker compose restart intake`
(do this before first login; ownership must be the `node` user: `docker compose exec -u root intake chown node /data/intakes.db`).

## Offline / no-CDN environments
The page loads SheetJS and Chart.js from cdnjs and fonts from Google Fonts. If the network blocks those,
download both libraries into `public/vendor/`, change the two `<script src>` lines (lines 10-11 of the HTML)
to `/vendor/xlsx.full.min.js` and `/vendor/chart.umd.min.js`. Fonts fall back to system fonts.

## Behaviour to be aware of (business decisions, unchanged)
- Any logged-in user, including **Requestors, can read all tickets** (`GET /api/intake`).
- A Requestor can edit **every field** of their own ticket, including status, EPMO approval and assignee.
- Submitted tickets cannot be deleted through the app (only drafts can).
- Login lockout: 10 failed attempts per IP+email locks that pair for 15 minutes (in memory; resets on restart).
- Single-server design: SQLite + in-memory rate limits mean run **one** instance, not a cluster.
