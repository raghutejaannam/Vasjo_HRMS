# Vasjo HR Platform - Defect Fixes

Date: 2026-09-22

This package addresses the findings in the supplied Field-Level Security & RBAC Inconsistency Audit.

## Fixed

### FL-001 / P1: Worker profile sensitive-field exposure
- Manager-visible worker profiles strip PAN, UAN, PF, ESI, bank account and bank name.
- Sensitive profile fields remain available only to self or explicit sensitive/HR/payroll permissions.
- Employee history masks sensitive before/after values for unauthorized viewers.

### FL-002 / P1: Generic user lookup IDOR and cross-tenant exposure
- `GET /api/users/:id` is tenant-scoped.
- Managers can only retrieve their direct reports.
- HR/Admin permission is required for broad directory access.
- Sensitive fields are removed from manager responses.

### FL-003 / P1: Direct sensitive writes through `/api/me`
- `/api/me` rejects direct PAN/UAN/PF/ESI/bank changes.
- Sensitive changes must use the change-request workflow.
- Change-request approval supports statutory fields with fixed SQL statements.

### FL-004 / P1: Admin directory over-exposure / tenant scope
- `/api/users` and `/api/admin/employees` require `admin.configure`.
- User lists are tenant-scoped.
- Sensitive/compensation columns are returned only to HR Admin/admin.configure contexts.
- Manager directory endpoints are tenant-scoped.

### FL-005 / P1 / RBAC-006: Payroll access
- Payroll access is permission-based (`payroll.read` / `payroll.*` / `admin.configure`) rather than `users.role`.
- Managers no longer receive another employee's payroll/tax/Form 16 data solely because they manage that employee.
- Payroll access remains tenant-scoped.
- Attendance access was separated from payroll access so manager attendance access is not accidentally removed.

### FL-006 / P2: `/api/me` least-privilege response
- Generic `/api/me` response no longer contains statutory/banking fields.
- Added authenticated `/api/me/sensitive` for the signed-in employee's own sensitive data.
- Profile UI loads sensitive values separately and no longer sends them in normal profile updates.

### RBAC-001: Dual authorization model
- Permission resolution no longer falls back to `users.role`.
- Built-in role assignments are the authorization source.
- Built-in system role permissions are synchronized deterministically so removed permissions do not remain attached.
- Legacy `requireRoleMw` remains as a compatibility wrapper that maps requested legacy labels to canonical permission codes.

### RBAC-002: Employee `performance.write`
Introduced narrower permissions:
- `performance.self`
- `performance.manage`
- `performance.calibrate`

Employee no longer receives `performance.write`.
Manager receives `performance.manage`.
HR Admin receives `performance.manage` and `performance.calibrate`.

Calibration and rating-scale administration require `performance.calibrate`.
Competency catalog administration requires `performance.manage`.
Self competency ratings remain available to the reviewee without granting management permissions.

### RBAC-003: P2 privileged routes
- P2 onboarding management, workflow delegation, recruitment conversion/interviews, reports, calibration, rating-scale administration and PIP actions now use explicit permission gates.
- Onboarding task creation requires onboarding-management permission; employees can only create/load their own onboarding process where the self workflow permits it.

### RBAC-004: Tenant isolation
Tenant filtering added to:
- `findUserById` where used by externally accessible user APIs
- `listUsers`
- `listAllUsersFlat`
- `listDirectReports`
- payroll target lookup
- user/profile APIs

### RBAC-005: Document archive route
- Document archive now requires `document.upload` or `document.verify` at the route layer, matching the service ownership/verification rules.

### RBAC-007: Permission naming consistency
Performance administration now uses the dedicated performance permission family instead of employee-level `performance.write`.

### Recruitment credential exposure
- Candidate conversion requires `recruitment.write`.
- Conversion no longer returns a temporary password in the API response.
- The conversion flow accepts an initial password through the protected request, hashes it server-side, sets `must_reset_password`, and returns only employee metadata.
- Frontend conversion UI no longer displays a password returned by the API.

## Validation

- JavaScript syntax checks passed for all modified backend files.
- Security regression suite: **13/13 passed**.
- Existing backend suite: **55 tests passed before the environment-level dependency failures**; the remaining 2 suite failures were caused by the sandbox's incomplete `dotenv` installation, not application assertions.
- Full frontend build/browser E2E was not executed because frontend dependencies are not installed in the sandbox.

## Remaining environment limitation

The supplied sandbox could not reliably materialize the full npm dependency tree. `npm test` reaches and passes the functional/unit tests that can load, but the regression and unit runners that import the full application fail when the incomplete environment cannot resolve `dotenv`.

The repository contains a locked `package-lock.json` and `.npmrc` with retry/backoff settings. In a networked CI/development environment, run `npm ci` before the complete runtime suite.
