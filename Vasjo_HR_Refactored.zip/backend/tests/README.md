# Test layout (post-refactor)

- `unit/` — pure unit tests (no DB required)
- `integration/` — tests requiring PostgreSQL / SQLite harness
- `security/` — authentication, authorization, tenant isolation
- `migration/` — migration safety checks
- `helpers/` — shared harness and SQLite Prisma helpers

Current entry points remain at `tests/*.test.js` for CI compatibility.
Domain-specific suites will be migrated gradually without dropping coverage.
