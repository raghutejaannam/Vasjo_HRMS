'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- LEAVE ---
app.get('/api/leave-types', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json(await db.listLeaveTypes(false));
}));
app.post('/api/leave-types', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { name, defaultAnnualDays, maxCarryForwardDays } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  const id = await db.createLeaveType(name, defaultAnnualDays, maxCarryForwardDays);
  res.status(201).json({ id });
}));
app.patch('/api/leave-types/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.updateLeaveType(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));
app.delete('/api/leave-types/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.deleteLeaveType(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

app.get('/api/leave-balances', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ balances: await db.getLeaveBalances(req.session.user.id, req.query.year ? parseInt(req.query.year, 10) : undefined) });
}));
app.put('/api/admin/leave/balances', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { userId, leaveTypeId, year, totalDays, usedDays } = req.body || {};
  await db.adjustLeaveBalance(userId, leaveTypeId, year, totalDays, usedDays);
  res.json({ ok: true });
}));

app.get('/api/leave-applications', auth.requireAuth, asyncHandler(async (req, res) => {
  const { all, status, team } = req.query;

  if (all === '1') {
    if (!authz.isApprover(req.session.user)) {
      const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e;
    }
    const scope = await db.resolveManagerScope(req.session.user);
    return res.json({ leave: await db.listAllLeave(status || null, scope) });
  }

  if (team === '1') {
    if (!authz.isApprover(req.session.user)) {
      const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e;
    }
    const scope = await db.resolveManagerScope(req.session.user);
    return res.json({ leave: await db.listTeamLeave(scope) });
  }

  res.json({ leave: await db.listLeaveForUser(req.session.user.id) });
}));

app.post('/api/leave-applications', auth.requireAuth, asyncHandler(async (req, res) => {
  const { leaveTypeId, from, to, reason, halfDay } = req.body || {};
  if (!leaveTypeId || !from || !to) return res.status(400).json({ error: 'leaveTypeId, from and to are required' });
  const id = await db.applyForLeave(req.session.user.id, { leaveTypeId, from, to, reason, halfDay });
  res.status(201).json({ id });
}));

app.patch('/api/leave-applications/:id/cancel', auth.requireAuth, asyncHandler(async (req, res) => {
  await db.cancelLeave(req.params.id, req.session.user.id);
  res.json({ ok: true });
}));

app.patch('/api/leave-applications/:id', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { action, comment } = req.body || {};
  if (!['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'action must be approve or reject' });
  await db.decideLeave(req.params.id, action, req.session.user.id, comment);
  res.json({ ok: true });
}));

app.post('/api/leave-applications/bulk-decide', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { ids, action, comment } = req.body || {};
  if (!Array.isArray(ids) || !['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'ids[] and action are required' });
  res.json(await db.bulkDecideLeave(ids, action, req.session.user.id, comment));
}));

app.post('/api/admin/leave/carry-forward', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { fromYear, toYear } = req.body || {};
  if (!fromYear || !toYear) return res.status(400).json({ error: 'fromYear and toYear are required' });
  // Superseded by leave.js's policy-aware version (Block 3): respects
  // per-employee/department carry-forward policy overrides and records an
  // expiry date on the carried-forward days, instead of a single flat
  // per-leave-type cap with no expiry. db.runYearEndCarryForward still
  // exists but nothing calls it anymore.
  res.json(await leave.runYearEndCarryForward(fromYear, toYear));
}));

// ---------------------------------------------------------------------------

};
