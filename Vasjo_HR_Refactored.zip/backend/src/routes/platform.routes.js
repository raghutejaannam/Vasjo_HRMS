'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- P2/P3/P4 TALENT & PLATFORM ---
// Recruitment / ATS
app.get('/api/recruitment/requisitions', auth.requireAuth, enterprise.requirePermission('recruitment.read'), asyncHandler(async(req,res)=>res.json({requisitions:await platform.listRequisitions(tenantCtx(req))})));
app.put('/api/recruitment/requisitions', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.json(await platform.saveRequisition(tenantCtx(req),req.body||{}))));
app.get('/api/recruitment/candidates', auth.requireAuth, enterprise.requirePermission('recruitment.read'), asyncHandler(async(req,res)=>res.json({candidates:await platform.listCandidates(tenantCtx(req),{stage:req.query.stage,search:req.query.search})})));
app.post('/api/recruitment/candidates', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.createCandidate(tenantCtx(req),req.body||{}))));
app.post('/api/recruitment/candidates/:id/stage', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.json(await platform.moveCandidate(tenantCtx(req),req.params.id,req.body?.stage,req.body?.reason))));
app.get('/api/recruitment/interviews', auth.requireAuth, enterprise.requirePermission('recruitment.read'), asyncHandler(async(req,res)=>res.json({interviews:await platform.listInterviews(tenantCtx(req))})));
app.post('/api/recruitment/interviews', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.scheduleInterview(tenantCtx(req),req.body||{}))));
app.patch('/api/recruitment/interviews/:id', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.json(await platform.updateInterview(tenantCtx(req),req.params.id,req.body||{}))));
app.post('/api/recruitment/offers', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.createOffer(tenantCtx(req),req.body||{}))));
app.post('/api/recruitment/offers/:id/accept', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.json(await platform.acceptOffer(tenantCtx(req),req.params.id))));
app.post('/api/recruitment/candidates/:id/convert', auth.requireAuth, enterprise.requirePermission('recruitment.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.convertCandidateToEmployee(tenantCtx(req),req.params.id,req.body||{}))));
app.get('/api/recruitment/analytics', auth.requireAuth, enterprise.requirePermission('recruitment.read'), asyncHandler(async(req,res)=>res.json(await platform.recruitmentAnalytics(tenantCtx(req)))));

// Performance / Goals
app.get('/api/performance/cycles', auth.requireAuth, enterprise.requirePermission('performance.read'), asyncHandler(async(req,res)=>res.json({cycles:await platform.listCycles(tenantCtx(req))})));
app.post('/api/performance/cycles', auth.requireAuth, enterprise.requirePermission('performance.manage'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveCycle(tenantCtx(req),req.body||{}))));
app.get('/api/performance/goals', auth.requireAuth, enterprise.requirePermission('performance.read'), asyncHandler(async(req,res)=>res.json({goals:await platform.listGoals(tenantCtx(req),req.query.userId)})));
app.post('/api/performance/goals', auth.requireAuth, enterprise.requireAnyPermission(['performance.self','performance.manage']), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveGoal(tenantCtx(req),req.body||{}))));
app.get('/api/performance/reviews', auth.requireAuth, enterprise.requirePermission('performance.read'), asyncHandler(async(req,res)=>res.json({reviews:await platform.listReviews(tenantCtx(req),req.query.userId)})));
app.post('/api/performance/reviews', auth.requireAuth, enterprise.requireAnyPermission(['performance.self','performance.manage']), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveReview(tenantCtx(req),req.body||{}))));
app.get('/api/performance/feedback', auth.requireAuth, enterprise.requirePermission('performance.read'), asyncHandler(async(req,res)=>res.json({feedback:await platform.listFeedback(tenantCtx(req),req.query.userId)})));
app.post('/api/performance/pips', auth.requireAuth, enterprise.requirePermission('performance.manage'), asyncHandler(async(req,res)=>res.status(201).json(await platform.savePip(tenantCtx(req),req.body||{}))));
app.get('/api/performance/calibrations', auth.requireAuth, enterprise.requirePermission('performance.calibrate'), asyncHandler(async(req,res)=>res.json({calibrations:await platform.listCalibrations(tenantCtx(req),req.query.cycleId)})));
app.post('/api/performance/calibrations', auth.requireAuth, enterprise.requirePermission('performance.calibrate'), asyncHandler(async(req,res)=>res.status(201).json(await platform.calibrateRating(tenantCtx(req),req.body||{}))));

// Learning
app.get('/api/learning/courses', auth.requireAuth, enterprise.requirePermission('learning.read'), asyncHandler(async(req,res)=>res.json({courses:await platform.listCourses(tenantCtx(req))})));
app.post('/api/learning/courses', auth.requireAuth, enterprise.requirePermission('learning.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveCourse(tenantCtx(req),req.body||{}))));
app.get('/api/learning/enrollments', auth.requireAuth, enterprise.requirePermission('learning.read'), asyncHandler(async(req,res)=>res.json({enrollments:await platform.listEnrollments(tenantCtx(req),req.query.userId)})));
app.post('/api/learning/enrollments', auth.requireAuth, enterprise.requirePermission('learning.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.enroll(tenantCtx(req),req.body?.courseId,req.body?.userId))));
app.post('/api/learning/enrollments/:id/complete', auth.requireAuth, enterprise.requirePermission('learning.write'), asyncHandler(async(req,res)=>res.json(await platform.completeEnrollment(tenantCtx(req),req.params.id,req.body?.score))));
app.post('/api/learning/certifications', auth.requireAuth, enterprise.requirePermission('learning.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveCertification(tenantCtx(req),req.body||{}))));
app.get('/api/learning/certifications', auth.requireAuth, enterprise.requirePermission('learning.read'), asyncHandler(async(req,res)=>res.json({certifications:await platform.listCertifications(tenantCtx(req),req.query.userId)})));
app.post('/api/learning/skills', auth.requireAuth, enterprise.requirePermission('learning.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveSkill(tenantCtx(req),req.body||{}))));

// Benefits
app.get('/api/benefits/plans', auth.requireAuth, enterprise.requirePermission('benefits.read'), asyncHandler(async(req,res)=>res.json({plans:await platform.listBenefitPlans(tenantCtx(req))})));
app.post('/api/benefits/plans', auth.requireAuth, enterprise.requirePermission('benefits.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveBenefitPlan(tenantCtx(req),req.body||{}))));
app.get('/api/benefits/me', auth.requireAuth, enterprise.requirePermission('benefits.read'), asyncHandler(async(req,res)=>res.json(await platform.listBenefitsForUser(tenantCtx(req),req.query.userId))));
app.post('/api/benefits/enroll', auth.requireAuth, enterprise.requirePermission('benefits.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.enrollBenefit(tenantCtx(req),req.body?.planId,req.body?.userId))));
app.post('/api/benefits/dependents', auth.requireAuth, enterprise.requirePermission('benefits.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveDependent(tenantCtx(req),req.body||{}))));

// Assets
app.get('/api/assets', auth.requireAuth, enterprise.requirePermission('asset.read'), asyncHandler(async(req,res)=>res.json({assets:await platform.listAssets(tenantCtx(req))})));
app.post('/api/assets', auth.requireAuth, enterprise.requirePermission('asset.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveAsset(tenantCtx(req),req.body||{}))));
app.post('/api/assets/:id/assign', auth.requireAuth, enterprise.requirePermission('asset.write'), asyncHandler(async(req,res)=>res.status(201).json(await platform.assignAsset(tenantCtx(req),req.params.id,req.body||{}))));
app.post('/api/assets/:id/return', auth.requireAuth, enterprise.requirePermission('asset.write'), asyncHandler(async(req,res)=>res.json(await platform.returnAsset(tenantCtx(req),req.params.id,req.body||{}))));
app.get('/api/assets/me', auth.requireAuth, enterprise.requirePermission('asset.read'), asyncHandler(async(req,res)=>res.json({assets:await platform.listAssetsForUser(tenantCtx(req),req.query.userId)})));

// Integration Hub
app.get('/api/integration-hub', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.json(await platform.listIntegrations(tenantCtx(req)))));
app.post('/api/integration-hub/sync-jobs', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.status(201).json(await platform.createSyncJob(tenantCtx(req),req.body||{}))));
app.post('/api/integration-hub/test/:provider', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.json(await platform.testIntegration(tenantCtx(req),req.params.provider))));
app.post('/api/integration-hub/disconnect/:provider', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.json(await platform.removeIntegration(tenantCtx(req),req.params.provider))));
app.post('/api/integration-hub/webhooks', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveWebhook(tenantCtx(req),req.body||{}))));
app.post('/api/integration-hub/webhooks/:id/disable', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.json(await platform.disableWebhook(tenantCtx(req),req.params.id))));
app.get('/api/analytics/reports/saved', auth.requireAuth, enterprise.requirePermission('analytics.read'), asyncHandler(async(req,res)=>res.json({reports:await platform.listReports(tenantCtx(req))})));
app.post('/api/analytics/reports/saved', auth.requireAuth, enterprise.requirePermission('analytics.read'), asyncHandler(async(req,res)=>res.status(201).json(await platform.saveReport(tenantCtx(req),req.body||{}))));
app.get('/api/analytics/reports/saved/:id/execute', auth.requireAuth, enterprise.requirePermission('analytics.read'), asyncHandler(async(req,res)=>res.json(await platform.executeSavedReport(tenantCtx(req),req.params.id))));
app.post('/api/integration-hub/events/:eventType/publish', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.status(202).json(await platform.publishEvent(tenantCtx(req),req.params.eventType,req.body||{}))));
app.post('/api/integration-hub/webhooks/process', auth.requireAuth, enterprise.requirePermission('integration.manage'), asyncHandler(async(req,res)=>res.json(await platform.processWebhookDeliveries(tenantCtx(req)))));

// Mobile BFF: the same policy-aware contract works for mobile/native/PWA clients.
app.get('/api/mobile/home', auth.requireAuth, asyncHandler(async(req,res)=>res.json(await platform.mobileHome(tenantCtx(req)))));

// AI intelligence layer
app.post('/api/ai/assistant/query', auth.requireAuth, enterprise.requirePermission('ai.assistant'), asyncHandler(async(req,res)=>res.json(await platform.aiAssistant({...tenantCtx(req),permissions:req.session.user.permissions||[]},req.body?.question))));
app.get('/api/ai/assistant/history', auth.requireAuth, enterprise.requirePermission('ai.assistant'), asyncHandler(async(req,res)=>res.json({history:await platform.getAiHistory(tenantCtx(req))})));
app.post('/api/ai/documents/:id/extract', auth.requireAuth, enterprise.requirePermission('ai.document'), asyncHandler(async(req,res)=>{
  const extraction = await platform.extractDocument({...tenantCtx(req),permissions:req.session.user.permissions||[]}, req.params.id);
  res.status(201).json({ extraction: normalizeDocumentExtraction(extraction) });
}));
app.get('/api/ai/documents/extractions', auth.requireAuth, enterprise.requirePermission('ai.document'), asyncHandler(async(req,res)=>{
  const rows = await platform.listAiExtractions(tenantCtx(req), req.query.documentId);
  res.json({ extractions: rows.map(normalizeDocumentExtraction) });
}));
app.post('/api/ai/documents/extractions/:id/confirm', auth.requireAuth, enterprise.requirePermission('ai.document'), asyncHandler(async(req,res)=>{
  const extraction = await platform.confirmDocumentExtraction({...tenantCtx(req),permissions:req.session.user.permissions||[]}, req.params.id, req.body||{});
  res.json({ extraction: normalizeDocumentExtraction(extraction) });
}));
app.post('/api/ai/payroll/runs/:id/scan', auth.requireAuth, enterprise.requirePermission('ai.payroll'), asyncHandler(async(req,res)=>res.json({anomalies:await platform.scanPayrollAnomalies({...tenantCtx(req),permissions:req.session.user.permissions||[]},req.params.id)})));
app.get('/api/ai/payroll/runs/:id/anomalies', auth.requireAuth, enterprise.requirePermission('ai.payroll'), asyncHandler(async(req,res)=>res.json({anomalies:await platform.scanPayrollAnomalies({...tenantCtx(req),permissions:req.session.user.permissions||[]},req.params.id)})));
app.post('/api/ai/payroll/anomalies/:id/review', auth.requireAuth, enterprise.requirePermission('ai.payroll'), asyncHandler(async(req,res)=>res.json(await platform.reviewAnomaly(tenantCtx(req),req.params.id,req.body?.status,req.body?.notes))));

// ---------------------------------------------------------------------------

};
