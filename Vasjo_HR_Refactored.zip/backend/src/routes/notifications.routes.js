'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- NOTIFICATIONS ---
app.get('/api/notifications', auth.requireAuth, asyncHandler(async (req, res) => {
  const [items, unreadCount] = await Promise.all([
    db.listNotifications(req.session.user.id, req.query.unread === '1'),
    db.unreadNotificationCount(req.session.user.id),
  ]);
  res.json({ items, unreadCount });
}));

app.get('/api/notifications/unread-count', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ count: await db.unreadNotificationCount(req.session.user.id) });
}));

app.patch('/api/notifications/:id/read', auth.requireAuth, asyncHandler(async (req, res) => {
  await db.markNotificationRead(parseInt(req.params.id, 10), req.session.user.id);
  res.json({ ok: true });
}));

app.patch('/api/notifications/read-all', auth.requireAuth, asyncHandler(async (req, res) => {
  await db.markAllNotificationsRead(req.session.user.id);
  res.json({ ok: true });
}));


// ---------------------------------------------------------------------------

};
