'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- ADVANCED EMPLOYEE LIFECYCLE ---
app.get('/api/lifecycle/employees/:userId/profile', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  res.json(await lifecycle.getEmployeeLifecycleProfile(userId));
}));

app.post('/api/lifecycle/employees/:userId/transfer-department', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.transferDepartment({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));
app.post('/api/lifecycle/employees/:userId/change-designation', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.changeDesignation({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));
app.post('/api/lifecycle/employees/:userId/change-manager', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.changeManager({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));
app.post('/api/lifecycle/employees/:userId/change-location', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.changeLocation({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));
app.post('/api/lifecycle/employees/:userId/promote', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.promoteEmployee({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));

app.post('/api/lifecycle/employees/:userId/probation/start', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.status(201).json(await lifecycle.startProbation({ userId: parseInt(req.params.userId, 10), ...req.body, actorId: req.session.user.id }));
}));
app.post('/api/lifecycle/probation/:id/confirm', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.confirmProbation(parseInt(req.params.id, 10), req.session.user.id, req.body ? req.body.notes : undefined));
}));
app.post('/api/lifecycle/probation/:id/extend', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { newEndDate, notes } = req.body || {};
  if (!newEndDate) return res.status(400).json({ error: 'newEndDate is required' });
  res.json(await lifecycle.extendProbation(parseInt(req.params.id, 10), newEndDate, req.session.user.id, notes));
}));

app.get('/api/lifecycle/employees/:userId/documents', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  res.json(await db.listDocumentsForUser(userId));
}));
app.post('/api/lifecycle/employees/:userId/documents', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const id = await lifecycle.uploadDocument({ userId: parseInt(req.params.userId, 10), ...req.body, uploadedBy: req.session.user.id });
  res.status(201).json({ id });
}));

// Binary lifecycle document upload. The legacy JSON endpoint above continues to
// support file-path/URL records; this endpoint stores the actual local file in
// the configured private object store and links the generated object key to the
// employee document record.
app.post('/api/lifecycle/employees/:userId/documents/upload', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const buffer = Buffer.isBuffer(req.body) ? req.body : null;
  if (!buffer || !buffer.length) return res.status(400).json({ error: 'Binary request body required' });
  const max = Number(process.env.MAX_FILE_BYTES || process.env.MAX_DOCUMENT_SIZE_BYTES || 50 * 1024 * 1024);
  if (buffer.length > max) return res.status(413).json({ error: 'File too large' });
  const filename = String(req.headers['x-file-name'] || 'document.bin').replace(/[\/\0\r\n]/g, '_').slice(0, 255);
  const mimeType = String(req.headers['x-file-mime'] || 'application/octet-stream').slice(0, 120);
  const scan = await storage.scanBuffer(buffer, filename);
  if (scan.status !== 'clean') return res.status(422).json({ error: scan.reason, status: scan.status });
  const extension = filename.includes('.') ? `.${filename.split('.').pop().toLowerCase()}` : '';
  const objectKey = `tenant/${req.session.user.tenant_id}/lifecycle/${userId}/${crypto.randomUUID()}-${crypto.createHash('sha256').update(filename).digest('hex').slice(0, 12)}${extension}`;
  await storage.putObject({ objectKey, buffer, contentType: mimeType });
  const id = await lifecycle.uploadDocument({ userId, docType: String(req.headers['x-doc-type'] || 'Document'), filePath: `storage:${objectKey}`, issueDate: req.headers['x-issue-date'] || null, expiryDate: req.headers['x-expiry-date'] || null, uploadedBy: req.session.user.id });
  res.status(201).json({ id, filePath: `storage:${objectKey}`, filename, mimeType });
}));

app.get('/api/lifecycle/documents/:id/open', auth.requireAuth, asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) return res.status(422).json({ error: 'Invalid document id' });
  const doc = await db.dbGet('SELECT * FROM employee_documents WHERE tenant_id=? AND id=?', [req.session.user.tenant_id, id]);
  if (!doc) return res.status(404).json({ error: 'Document not found' });
  await assertAttendanceAccess(req, doc.user_id);
  const filePath = String(doc.file_path || '');
  if (!filePath) return res.status(404).json({ error: 'No file is attached to this document' });
  if (/^https?:\/\//i.test(filePath)) return res.redirect(filePath);
  if (!filePath.startsWith('storage:')) return res.status(404).json({ error: 'Stored file is not available for browser preview' });
  const objectKey = filePath.slice('storage:'.length);
  const buffer = await storage.getObject({ objectKey });
  const ext = objectKey.split('.').pop().toLowerCase();
  const types = { pdf:'application/pdf', png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', txt:'text/plain', csv:'text/csv' };
  res.setHeader('Content-Type', types[ext] || 'application/octet-stream');
  res.setHeader('Content-Disposition', 'inline');
  res.setHeader('Cache-Control', 'private, no-store');
  res.send(buffer);
}));
app.get('/api/lifecycle/documents/expiring', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await lifecycle.getExpiringDocuments(req.query.daysAhead ? parseInt(req.query.daysAhead, 10) : undefined));
}));

app.get('/api/lifecycle/checklist/templates', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(req.query.type ? await db.listChecklistTemplateItems(req.query.type) : await db.listAllChecklistTemplateItems());
}));
app.post('/api/lifecycle/checklist/templates', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const id = await db.createChecklistTemplateItem(req.body || {});
  res.status(201).json({ id });
}));
app.put('/api/lifecycle/checklist/templates/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.updateChecklistTemplateItem(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));
app.get('/api/lifecycle/employees/:userId/checklist', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  res.json(await db.listChecklistTasksForUser(userId, req.query.type));
}));
app.post('/api/lifecycle/checklist/tasks/:id/complete', auth.requireAuth, asyncHandler(async (req, res) => {
  const task = await db.dbGet('SELECT * FROM employee_checklist_tasks WHERE tenant_id=? AND id=?', [req.session.user.tenant_id, parseInt(req.params.id,10)]);
  if (!task) return res.status(404).json({error:'Task not found'});
  if (Number(task.user_id)!==Number(req.session.user.id) && !authz.hasPermission(req.session.user,'admin.configure') && !(await authz.isManagerOf(authz.contextFrom(req),task.user_id))) return res.status(403).json({error:'Forbidden',code:'FORBIDDEN'});
  await lifecycle.completeChecklistTask(parseInt(req.params.id, 10), req.session.user.id, req.body ? req.body.notes : undefined);
  res.json({ ok: true });
}));

app.post('/api/fnf/separations/:id/exit-interview', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const interview = await lifecycle.recordExitInterview({ employeeSeparationId: parseInt(req.params.id, 10), ...req.body, conductedBy: req.session.user.id });
  res.status(201).json(interview);
}));
app.get('/api/fnf/separations/:id/exit-interview', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.getExitInterview(parseInt(req.params.id, 10)));
}));
app.get('/api/fnf/separations/:id/checklist', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listChecklistTasksForSeparation(parseInt(req.params.id, 10)));
}));

// ---------------------------------------------------------------------------

};
