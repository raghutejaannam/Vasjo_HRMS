'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- ATTENDANCE ---
async function assertAttendanceAccess(req, targetUserId) {
  const target = await db.findUserById(targetUserId, req.session.user.tenant_id);
  if (!target) { const e = new Error('User not found'); e.code = 'NOT_FOUND'; e.httpStatus = 404; throw e; }
  const self = Number(req.session.user.id) === Number(targetUserId);
  const admin = authz.hasPermission(req.session.user, 'admin.configure');
  const manager = authz.hasPermission(req.session.user, 'manager.approve') && await authz.isManagerOf(authz.contextFrom(req), targetUserId);
  if (!self && !admin && !manager) { const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e; }
}

// -- Shifts ------------------------------------------------------------

app.get('/api/attendance/shifts', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json(await db.listShifts(req.query.all !== 'true'));
}));
app.post('/api/attendance/shifts', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const id = await attendance.createShift(req.body || {});
  res.status(201).json({ id });
}));
app.put('/api/attendance/shifts/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.updateShift(parseInt(req.params.id, 10), req.body || {}));
}));
app.post('/api/attendance/employees/:userId/shift', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const { shiftId, effectiveFrom } = req.body || {};
  if (!shiftId) return res.status(400).json({ error: 'shiftId is required' });
  const id = await attendance.assignShift({ userId, shiftId, effectiveFrom, createdBy: req.session.user.id });
  res.status(201).json({ id });
}));
app.get('/api/attendance/employees/:userId/shift-history', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  res.json(await db.listShiftAssignmentsForUser(userId));
}));

// -- Weekly-off configuration -------------------------------------------

app.get('/api/attendance/weekly-off', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ days: await db.getWeeklyOffDays() });
}));
app.put('/api/attendance/weekly-off', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { days } = req.body || {};
  if (!Array.isArray(days)) return res.status(400).json({ error: 'days must be an array of 0-6 (Sunday-Saturday)' });
  await db.setWeeklyOffDays(days);
  res.json({ ok: true });
}));

// -- Check-in / check-out -------------------------------------------------

app.post('/api/attendance/check-in', auth.requireAuth, asyncHandler(async (req, res) => {
  const result = await attendance.checkIn(req.session.user.id, req.body ? req.body.timestamp : undefined);
  res.status(201).json(result);
}));
app.post('/api/attendance/check-out', auth.requireAuth, asyncHandler(async (req, res) => {
  const result = await attendance.checkOut(req.session.user.id, req.body ? req.body.timestamp : undefined);
  res.json(result);
}));
app.get('/api/attendance/today', auth.requireAuth, asyncHandler(async (req, res) => {
  const today = services.utils.todayStr();
  res.json(await db.getAttendanceRecord(req.session.user.id, today) || { status: 'pending' });
}));

// -- Manual marking (admin) ------------------------------------------------

app.post('/api/attendance/employees/:userId/mark', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const { date, status, notes } = req.body || {};
  if (!date || !status) return res.status(400).json({ error: 'date and status are required' });
  const record = await attendance.markAttendance({ userId, date, status, actorId: req.session.user.id, notes });
  res.json(record);
}));

// -- Records / calendar -----------------------------------------------------

app.get('/api/attendance/employees/:userId/calendar', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  const year = parseInt(req.query.year, 10), month = parseInt(req.query.month, 10);
  if (!year || !month) return res.status(400).json({ error: 'year and month query params are required' });
  res.json(await attendance.getMonthlyCalendar(userId, year, month));
}));
app.get('/api/attendance/day/:date', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listAttendanceRecordsForDate(req.params.date));
}));
app.get('/api/attendance/team', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from and to query params are required' });
  let userIds;
  if (authz.isAdmin(req.session.user)) {
    userIds = (await db.dbAll("SELECT id FROM users WHERE active = 'active'")).map(u => u.id);
  } else {
    const scope = await db.resolveManagerScope(req.session.user);
    userIds = (await db.dbAll(`SELECT id FROM users WHERE active = 'active' AND manager_id IN (${scope.map(() => '?').join(',') || 'NULL'})`, scope)).map(u => u.id);
  }
  res.json(await db.listAttendanceRecordsForUsersInRange(userIds, from, to));
}));

// -- Correction / regularization requests ------------------------------

app.post('/api/attendance/employees/:userId/correction', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  if (userId !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  const id = await attendance.requestCorrection({ userId, ...req.body });
  res.status(201).json({ id });
}));
app.get('/api/attendance/employees/:userId/corrections', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertAttendanceAccess(req, userId);
  res.json(await db.listAttendanceCorrectionRequestsForUser(userId));
}));
app.get('/api/attendance/corrections', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listAttendanceCorrectionRequests(req.query.status));
}));
app.post('/api/attendance/corrections/:id/decide', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const request = await attendance.decideCorrection(parseInt(req.params.id, 10), req.body.decision, req.session.user.id);
  res.json(request);
}));

// ---------------------------------------------------------------------------

};
