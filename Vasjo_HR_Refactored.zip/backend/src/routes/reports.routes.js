'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- REPORTS ---
function sendReportResult(res, rows, filename, format) {
  if (format === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(reports.reportRowsToCsv(rows));
  }
  return res.json({ rows });
}

app.get('/api/reports/project-hours', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from and to query params are required' });
  const rows = await reports.reportProjectHours(from, to);
  sendReportResult(res, rows, 'project-hours.csv', req.query.format);
}));

app.get('/api/reports/utilization', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from and to query params are required' });
  const scope = await db.resolveManagerScope(req.session.user);
  const rows = await reports.reportEmployeeUtilization(from, to, scope);
  sendReportResult(res, rows, 'utilization.csv', req.query.format);
}));

app.get('/api/reports/leave-usage', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  const rows = await reports.reportLeaveUsage(parseInt(req.query.year, 10) || new Date().getFullYear(), scope);
  sendReportResult(res, rows, 'leave-usage.csv', req.query.format);
}));

app.get('/api/reports/compliance', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { weekStart, from, to } = req.query;
  const rangeFrom = from || weekStart;
  const rangeTo = to || weekStart;
  if (!rangeFrom || !rangeTo) return res.status(400).json({ error: 'weekStart (or from/to) query param is required' });
  const scope = await db.resolveManagerScope(req.session.user);
  const rows = await reports.reportTimesheetCompliance(rangeFrom, rangeTo, scope);
  sendReportResult(res, rows, 'compliance.csv', req.query.format);
}));

app.get('/api/reports/pending-approvals', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  res.json(await reports.reportPendingApprovals(scope));
}));

app.get('/api/reports/timesheets.csv', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  const { items } = await db.listAllTimesheets(req.query.status || null, scope, { page: 1, pageSize: 100000 });
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="timesheets.csv"');
  res.send(reports.timesheetsToCsv(items));
}));

app.get('/api/reports/leave.csv', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  const rows = await db.listAllLeave(req.query.status || null, scope);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="leave.csv"');
  res.send(reports.leaveToCsv(rows));
}));

// ---------------------------------------------------------------------------

};
