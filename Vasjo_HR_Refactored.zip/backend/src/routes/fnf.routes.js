'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- FULL & FINAL SETTLEMENT ---
app.post('/api/fnf/separations', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const separation = await fnf.initiateSeparation({ ...req.body, initiatedBy: req.session.user.id });
  res.status(201).json(separation);
}));
app.get('/api/fnf/separations', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listSeparations(req.query.status));
}));
app.get('/api/fnf/separations/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const separation = await db.getSeparation(parseInt(req.params.id, 10));
  if (!separation) return res.status(404).json({ error: 'Separation not found' });
  res.json(separation);
}));
app.post('/api/fnf/separations/:id/decide', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const separation = await fnf.decideSeparationRequest(parseInt(req.params.id, 10), req.body.decision, req.session.user.id);
  res.json(separation);
}));

app.post('/api/fnf/separations/:id/settlement', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const settlement = await fnf.generateSettlement(parseInt(req.params.id, 10), req.session.user.id, req.body || {});
  res.status(201).json(settlement);
}));
app.get('/api/fnf/settlements', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listFnfSettlements(req.query.status));
}));
app.get('/api/fnf/settlements/:id', auth.requireAuth, asyncHandler(async (req, res) => {
  const settlement = await db.getFnfSettlement(parseInt(req.params.id, 10));
  if (!settlement) return res.status(404).json({ error: 'Settlement not found' });
  await assertPayrollAccess(req, settlement.user_id);
  res.json(settlement);
}));
app.get('/api/fnf/settlements/:id/statement', auth.requireAuth, asyncHandler(async (req, res) => {
  const statement = await fnf.getSettlementStatement(parseInt(req.params.id, 10), req.session.user.tenant_id);
  await assertPayrollAccess(req, statement.settlement.user_id);
  res.json(statement);
}));
app.post('/api/fnf/settlements/:id/submit', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await fnf.submitSettlementForApproval(parseInt(req.params.id, 10)));
}));
app.post('/api/fnf/settlements/:id/decide', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await fnf.decideSettlement(parseInt(req.params.id, 10), req.body.decision, req.session.user.id));
}));
app.post('/api/fnf/settlements/:id/mark-paid', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await fnf.markSettlementPaid(parseInt(req.params.id, 10), req.session.user.id));
}));

// ---------------------------------------------------------------------------

};
