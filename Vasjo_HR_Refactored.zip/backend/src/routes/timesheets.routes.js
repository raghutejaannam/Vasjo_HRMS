'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- TIMESHEETS ---
app.get('/api/timesheets', auth.requireAuth, asyncHandler(async (req, res) => {
  const { weekStart, all, page, pageSize, status, employeeId } = req.query;

  // Mode 1: a specific week for the current user (used by the weekly entry
  // screen) — identified by ?weekStart=YYYY-MM-DD.
  if (weekStart) {
    const ts = await db.getTimesheetForWeek(req.session.user.id, weekStart);
    const entries = ts ? await db.getTimesheetEntries(ts.id) : [];
    return res.json({ timesheet: ts || null, entries });
  }

  // Mode 2: manager/admin "all timesheets" queue — ?all=1[&status=][&employeeId=].
  if (all === '1') {
    if (!authz.isApprover(req.session.user)) {
      const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e;
    }
    const scope = await db.resolveManagerScope(req.session.user);
    const result = await db.listAllTimesheets(status || null, scope, {
      page: parseInt(page, 10) || 1,
      pageSize: parseInt(pageSize, 10) || 20,
      userId: employeeId ? parseInt(employeeId, 10) : undefined,
    });
    return res.json({ timesheets: result.items, total: result.total });
  }

  // Mode 3: the current user's own timesheets, optionally paginated.
  const result = await db.listTimesheetsForUser(req.session.user.id, {
    page: parseInt(page, 10) || 1,
    pageSize: parseInt(pageSize, 10) || 20,
  });
  res.json({ timesheets: result.items, total: result.total });
}));

app.get('/api/timesheets/:id/entries', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json(await db.getTimesheetEntries(req.params.id));
}));

app.post('/api/timesheets', auth.requireAuth, asyncHandler(async (req, res) => {
  const { weekStart, entries, submit } = req.body || {};
  if (!weekStart || !Array.isArray(entries)) return res.status(400).json({ error: 'weekStart and entries[] are required' });
  const settings = await db.getSettings();
  const lockWeeks = numSetting(settings.timesheet_lock_weeks, 8);
  db.checkTimesheetLock(weekStart, lockWeeks);
  const id = await db.saveTimesheet(req.session.user.id, weekStart, entries, !!submit, numSetting(settings.standard_hours_per_day, 8));
  res.json({ id });
}));

app.patch('/api/timesheets/:id', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { action, comment } = req.body || {};
  if (!['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'action must be approve or reject' });
  await db.decideTimesheet(req.params.id, action, req.session.user.id, comment);
  res.json({ ok: true });
}));

app.post('/api/timesheets/bulk-decide', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { ids, action, comment } = req.body || {};
  if (!Array.isArray(ids) || !['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'ids[] and action are required' });
  res.json(await db.bulkDecideTimesheets(ids, action, req.session.user.id, comment));
}));

app.post('/api/timesheets/:id/request-correction', auth.requireAuth, asyncHandler(async (req, res) => {
  await db.requestTimesheetCorrection(req.params.id, req.session.user.id, (req.body || {}).reason);
  res.json({ ok: true });
}));

app.get('/api/correction-requests', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  res.json({ requests: await db.listCorrectionRequests(scope) });
}));

app.patch('/api/timesheets/:id/decide-correction', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { action, comment } = req.body || {};
  if (!['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'action must be approve or reject' });
  await db.decideCorrection(req.params.id, action, req.session.user.id, comment);
  res.json({ ok: true });
}));

app.get('/api/analytics/my-trend', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ trend: await db.weeklyHoursTrend(req.session.user.id, parseInt(req.query.weeks, 10) || 12) });
}));

app.get('/api/analytics/team-summary', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const scope = await db.resolveManagerScope(req.session.user);
  res.json({ summary: await db.teamHoursSummary(scope) });
}));

// ---------------------------------------------------------------------------

};
