'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- COMPANY HOLIDAYS ---
app.get('/api/holidays', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ holidays: await db.listHolidays() });
}));
app.post('/api/holidays', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { date, name, blackout } = req.body || {};
  if (!date || !name) return res.status(400).json({ error: 'date and name are required' });
  const id = await db.addHoliday(date, name, blackout);
  res.status(201).json({ id });
}));
app.delete('/api/holidays/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.deleteHoliday(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------

};
