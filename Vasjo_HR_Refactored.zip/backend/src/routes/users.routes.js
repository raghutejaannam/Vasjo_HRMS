'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- USERS / PROFILE / ADMIN DIRECTORY ---
app.patch('/api/me', auth.requireAuth, asyncHandler(async (req, res) => {
  const forbiddenSensitive = ['uan','pfNumber','pan','bankAccountNo','bankName','esiNumber'];
  const attempted = forbiddenSensitive.filter(k => Object.prototype.hasOwnProperty.call(req.body || {}, k));
  if (attempted.length) return res.status(403).json({ error: 'Sensitive statutory or banking fields must be changed through the HR change-request workflow', code: 'SENSITIVE_FIELD_CHANGE_REQUEST_REQUIRED', fields: attempted });
  await db.updateProfile(req.session.user.id, req.body || {});
  const updated = await db.findUserById(req.session.user.id, req.session.user.tenant_id);
  delete updated.password_hash; delete updated.password_salt;
  res.json({ user: updated });
}));

app.get('/api/users/flat', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ users: await db.listAllUsersFlat(req.session.user.tenant_id) });
}));

app.get('/api/team-members', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  res.json({ members: await db.listDirectReports(req.session.user.id, req.session.user.tenant_id) });
}));

app.get('/api/users/:id', auth.requireAuth, enterprise.requirePermission('employee.read'), asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = await db.findUserById(id, req.session.user.tenant_id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const self = Number(id) === Number(req.session.user.id);
  const admin = authz.hasPermission(req.session.user, 'admin.configure');
  const manager = authz.hasPermission(req.session.user, 'manager.approve');
  if (!self && !admin) {
    if (!manager) return res.status(403).json({ error: 'Forbidden' });
    const targetManager = await db.findUserById(id, req.session.user.tenant_id);
    if (Number(targetManager.manager_id) !== Number(req.session.user.id)) return res.status(403).json({ error: 'Forbidden' });
  }
  const sensitive = ['uan','pf_number','pan','esi_number','bank_account_no','bank_name'];
  const allowSensitive = self || admin || authz.hasPermission(req.session.user, 'employee.sensitive.read') || authz.hasPermission(req.session.user, 'payroll.read');
  for (const k of sensitive) if (!allowSensitive) delete user[k];
  delete user.password_hash; delete user.password_salt;
  res.json(user);
}));

// Generic listing (used e.g. to populate the "assign employees" picklist on
// the admin Projects page). Kept admin-only since it surfaces CTC/salary
// columns alongside each user row.
app.get('/api/users', auth.requireAuth, enterprise.requirePermission('admin.configure'), asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const pageSize = parseInt(req.query.pageSize, 10) || 50;
  res.json(await db.listUsers({ page, pageSize, tenantId: req.session.user.tenant_id, includeSensitive: authz.hasPermission(req.session.user, 'employee.sensitive.read') || authz.hasPermission(req.session.user, 'admin.configure') }));
}));

app.get('/api/admin/employees', auth.requireAuth, enterprise.requirePermission('admin.configure'), asyncHandler(async (req, res) => {
  const { page, pageSize, search, department, status, sortBy, sortDir } = req.query;
  res.json(await db.listUsers({
    page: parseInt(page, 10) || 1,
    pageSize: parseInt(pageSize, 10) || 50,
    search: search || '', department: department || '', status: status || '',
    sortBy: sortBy || 'name', sortDir: sortDir || 'asc', tenantId: req.session.user.tenant_id, includeSensitive: true,
  }));
}));

app.get('/api/admin/departments', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  // Admin directory filters expect department names, not department objects.
  // Keep the generic /api/departments endpoint unchanged for other callers.
  const departments = await db.listDepartments(false);
  res.json({ departments: departments.map((d) => d.name) });
}));

app.post('/api/users', auth.requireAuth, enterprise.requirePermission('admin.configure'), asyncHandler(async (req, res) => {
  const id = await db.createUser({ ...(req.body || {}), tenantId: req.session.user.tenant_id });
  try { await lifecycle.initializeLifecycle(id, req.session.user.id); }
  catch (e) { /* lifecycle bootstrap failing shouldn't block user creation itself */ }
  res.status(201).json({ id });
}));

app.patch('/api/users/:id', auth.requireAuth, enterprise.requirePermission('admin.configure'), asyncHandler(async (req, res) => {
  await db.updateUserAdmin(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));

app.post('/api/users/import-csv', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { csv } = req.body || {};
  if (!csv) return res.status(400).json({ error: 'csv text is required' });
  res.json(await db.bulkImportUsersFromCsv(csv, req.session.user.tenant_id));
}));

// ---------------------------------------------------------------------------

};
