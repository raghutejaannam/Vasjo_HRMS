'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- PROJECTS / TASKS / DEPARTMENTS ---
app.get('/api/projects', auth.requireAuth, asyncHandler(async (req, res) => {
  if (req.query.all === '1') {
    if (!authz.isAdmin(req.session.user)) { const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e; }
    return res.json({ projects: await db.listProjects(false) });
  }
  res.json({ projects: await db.listProjectsForUser(req.session.user.id) });
}));
app.post('/api/projects', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { name, code } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  const id = await db.createProject(name, code);
  res.status(201).json({ id });
}));
app.patch('/api/projects/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.updateProject(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));
app.get('/api/projects/:projectId/assignments', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json({ members: await db.listProjectAssignments(parseInt(req.params.projectId, 10)) });
}));
app.put('/api/projects/:projectId/assignments', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { userIds } = req.body || {};
  if (!Array.isArray(userIds)) return res.status(400).json({ error: 'userIds[] is required' });
  await db.setProjectAssignments(parseInt(req.params.projectId, 10), userIds);
  res.json({ ok: true });
}));

app.get('/api/tasks', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json({ tasks: await db.listAllTasks(req.query.all !== '1') });
}));
app.get('/api/projects/:id/tasks', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json(await db.listTasks(parseInt(req.params.id, 10), true));
}));
app.post('/api/tasks', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { projectId, name } = req.body || {};
  if (!projectId || !name) return res.status(400).json({ error: 'projectId and name are required' });
  const id = await db.createTask(parseInt(projectId, 10), name);
  res.status(201).json({ id });
}));
app.put('/api/admin/tasks/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.updateTask(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));

app.get('/api/departments', auth.requireAuth, asyncHandler(async (req, res) => {
  if (req.query.all === '1') {
    if (!authz.isAdmin(req.session.user)) { const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e; }
    return res.json({ departments: await db.listDepartments(false) });
  }
  res.json({ departments: await db.listDepartments(true) });
}));
app.post('/api/departments', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  const id = await db.createDepartment(name);
  res.status(201).json({ id });
}));
app.patch('/api/departments/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.updateDepartment(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------

};
