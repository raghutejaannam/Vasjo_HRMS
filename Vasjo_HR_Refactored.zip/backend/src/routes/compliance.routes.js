'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- TAX & COMPLIANCE ---
app.get('/api/compliance/employer-info', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await compliance.getEmployerStatutoryInfo());
}));
app.put('/api/compliance/employer-info', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await compliance.updateEmployerStatutoryInfo(req.body || {}));
}));

app.get('/api/compliance/employees/:userId/annual-tax-statement', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await compliance.getAnnualTaxStatement(userId, fyId));
}));
app.get('/api/compliance/employees/:userId/form16', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await compliance.getForm16Data(userId, fyId));
}));

app.get('/api/compliance/form24q', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { financialYearId, quarter } = req.query;
  if (!financialYearId || !quarter) return res.status(400).json({ error: 'financialYearId and quarter are required' });
  res.json(await compliance.getForm24QData(parseInt(financialYearId, 10), quarter));
}));
app.get('/api/compliance/pf-report', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.query;
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  res.json(await compliance.getPfComplianceReport(parseInt(financialYearId, 10), payrollMonth));
}));
app.get('/api/compliance/esi-report', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.query;
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  res.json(await compliance.getEsiComplianceReport(parseInt(financialYearId, 10), payrollMonth));
}));
app.get('/api/compliance/pt-report', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.query;
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  res.json(await compliance.getPtComplianceReport(parseInt(financialYearId, 10), payrollMonth));
}));
app.get('/api/compliance/wage-register', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.query;
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  res.json(await compliance.getStatutoryWageRegister(parseInt(financialYearId, 10), payrollMonth));
}));

// ---------------------------------------------------------------------------

};
