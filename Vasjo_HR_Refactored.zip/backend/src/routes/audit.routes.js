'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- AUDIT TRAIL ---
app.get('/api/audit-log', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { entityType, entityId } = req.query;
  if (!entityType || !entityId) return res.status(400).json({ error: 'entityType and entityId query params are required' });
  res.json({ log: await db.getAuditLog(entityType, entityId) });
}));

// ---------------------------------------------------------------------------

};
