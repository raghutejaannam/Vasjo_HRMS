'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- AUTH ---
app.post('/api/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });

  const lock = auth.checkLoginLock(email);
  if (lock.locked) {
    return res.status(429).json({ error: `Too many failed attempts. Try again in ${Math.ceil(lock.retryAfterMs / 60000)} minute(s).` });
  }

  const user = await db.findUserByEmail(String(email).trim().toLowerCase());
  if (!user || !['active', 1, true].includes(user.active) || !auth.verifyPassword(password, user.password_hash, user.password_salt)) {
    auth.recordLoginFailure(email);
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  auth.clearLoginFailures(email);
  const tenant = await enterprise.getTenantByUser(user.id);
  if (!tenant) return res.status(403).json({ error: 'User has no active tenant membership' });
  await enterprise.ensureMembership(user.id, tenant.tenant_id, user.role);
  user.tenant_id = tenant.tenant_id;
  user.permissions = await enterprise.permissionsForUser(user.id, tenant.tenant_id);
  user.tenant = { id: tenant.tenant_id, name: tenant.name, timezone: tenant.timezone, locale: tenant.locale, currency: tenant.currency };

  const { token, csrfToken } = await auth.createSession(user.id, tenant.tenant_id);
  res.cookie('session', token, {
    httpOnly: true, sameSite: 'lax', secure: IS_PROD, maxAge: 1000 * 60 * 60 * 12, path: '/',
  });
  const mustReset = !!user.must_reset_password;
  delete user.password_hash; delete user.password_salt;
  res.json({ user, csrfToken, mustReset });
  enterprise.audit({ tenantId: tenant.tenant_id, actorId: user.id, req }, 'auth.login', 'user', user.id, null, { ok: true }).catch(() => {});
}));

app.post('/api/logout', asyncHandler(async (req, res) => {
  if (req.session.token) await auth.deleteSession(req.session.token);
  res.clearCookie('session', { path: '/' });
  res.json({ ok: true });
}));

app.get('/api/me', asyncHandler(async (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not signed in' });
  const tenant = await enterprise.getTenantByUser(req.session.user.id);
  if (tenant) {
    req.session.user.tenant_id = tenant.tenant_id;
    req.session.user.permissions = await enterprise.permissionsForUser(req.session.user.id, tenant.tenant_id);
    req.session.user.tenant = { id: tenant.tenant_id, name: tenant.name, timezone: tenant.timezone, locale: tenant.locale, currency: tenant.currency };
  }
  const safeUser = { ...req.session.user };
  for (const key of ['uan','pf_number','pan','esi_number','bank_account_no','bank_name']) delete safeUser[key];
  res.json({ user: safeUser, csrfToken: req.session.user._csrfToken });
}));

app.get('/api/me/sensitive', auth.requireAuth, asyncHandler(async (req, res) => {
  const u = await db.findUserById(req.session.user.id, req.session.user.tenant_id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  res.json({ sensitive: { uan:u.uan||null, pf_number:u.pf_number||null, pan:u.pan||null, esi_number:u.esi_number||null, bank_account_no:u.bank_account_no||null, bank_name:u.bank_name||null } });
}));

app.get('/api/auth/sessions', auth.requireAuth, asyncHandler(async (req,res)=>res.json({sessions:await auth.listSessions(req.session.user.id,req.session.token)})));
app.delete('/api/auth/sessions/:token', auth.requireAuth, asyncHandler(async(req,res)=>{await auth.revokeSession(String(req.params.token),req.session.user.id);res.json({ok:true})}));
app.post('/api/auth/logout-all', auth.requireAuth, asyncHandler(async(req,res)=>{await auth.deleteAllSessionsForUser(req.session.user.id);res.clearCookie('session',{path:'/'});res.json({ok:true})}));

app.post('/api/change-password', auth.requireAuth, asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword) return res.status(400).json({ error: 'A new password is required' });
  await auth.changePassword(req.session.user.id, currentPassword, newPassword);
  res.json({ ok: true });
}));

app.post('/api/users/:id/reset-password', auth.requireAuth, enterprise.requirePermission('admin.configure'), asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = await db.findUserById(id, req.session.user.tenant_id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const tempPassword = await auth.adminResetPassword(id);
  res.json({ tempPassword, userName: user.name, userEmail: user.email });
}));


};
