'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- ADVANCED LEAVE MANAGEMENT ---
app.get('/api/leave/policies', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  if (!req.query.leaveTypeId) return res.status(400).json({ error: 'leaveTypeId query param is required' });
  res.json(await db.listLeavePoliciesForType(parseInt(req.query.leaveTypeId, 10)));
}));
app.post('/api/leave/policies', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const id = await db.createLeavePolicy(req.body || {});
  res.status(201).json({ id });
}));
app.put('/api/leave/policies/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.updateLeavePolicy(parseInt(req.params.id, 10), req.body || {}));
}));
app.delete('/api/leave/policies/:id', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  await db.deleteLeavePolicy(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));
app.get('/api/leave/effective-policy', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.query.userId, 10);
  const leaveTypeId = parseInt(req.query.leaveTypeId, 10);
  if (!userId || !leaveTypeId) return res.status(400).json({ error: 'userId and leaveTypeId query params are required' });
  await assertAttendanceAccess(req, userId); // same self/manager/admin scope check; reused across advanced modules
  res.json(await leave.getEffectiveLeavePolicy(userId, leaveTypeId));
}));

app.post('/api/leave/applications-advanced', auth.requireAuth, asyncHandler(async (req, res) => {
  const result = await leave.applyForLeaveAdvanced({ userId: req.session.user.id, ...req.body });
  res.status(201).json(result);
}));
app.post('/api/leave/applications/:id/decide-advanced', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { decision, comment } = req.body || {};
  res.json(await leave.decideLeaveApplicationMultiLevel(req.params.id, decision, req.session.user.id, comment));
}));
app.get('/api/leave/applications/:id/approvals', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  res.json(await db.listLeaveApprovalsForApplication(req.params.id));
}));

app.post('/api/leave/comp-offs', auth.requireAuth, asyncHandler(async (req, res) => {
  const id = await leave.requestCompOff({ userId: req.session.user.id, ...req.body });
  res.status(201).json({ id });
}));
app.get('/api/leave/comp-offs', auth.requireAuth, asyncHandler(async (req, res) => {
  res.json(await db.listCompOffsForUser(req.session.user.id));
}));
app.get('/api/leave/comp-offs/all', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await db.listCompOffs(req.query.status));
}));
app.post('/api/leave/comp-offs/:id/decide', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { decision, expiryMonths } = req.body || {};
  res.json(await leave.decideCompOffRequest(parseInt(req.params.id, 10), decision, req.session.user.id, expiryMonths));
}));
app.post('/api/leave/comp-offs/:id/redeem', auth.requireAuth, asyncHandler(async (req, res) => {
  const result = await leave.redeemCompOff({ userId: req.session.user.id, compOffId: parseInt(req.params.id, 10), date: req.body.date });
  res.status(201).json(result);
}));

app.post('/api/leave/accrual/run', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  const { year, month } = req.body || {};
  if (!year || !month) return res.status(400).json({ error: 'year and month are required' });
  res.json(await leave.runMonthlyAccrual(year, month));
}));
app.post('/api/leave/carry-forward-expiry/run', auth.requireAuth, auth.requireRoleMw(['admin']), asyncHandler(async (req, res) => {
  res.json(await leave.expireCarriedForwardLeave(req.body ? req.body.asOfDate : undefined));
}));
app.get('/api/leave/conflicts', auth.requireAuth, auth.requireRoleMw(['manager', 'admin']), asyncHandler(async (req, res) => {
  const { from, to, excludeApplicationId } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from and to query params are required' });
  const scope = await db.resolveManagerScope(req.session.user);
  const userIds = authz.isAdmin(req.session.user)
    ? (await db.dbAll("SELECT id FROM users WHERE tenant_id = ? AND active = 'active'", [req.session.user.tenant_id])).map(u => u.id)
    : (await db.dbAll(`SELECT id FROM users WHERE tenant_id = ? AND active = 'active' AND manager_id IN (${scope.map(() => '?').join(',') || 'NULL'})`, [req.session.user.tenant_id, ...scope])).map(u => u.id);
  res.json(await leave.getLeaveConflicts(userIds, from, to, excludeApplicationId));
}));

// ---------------------------------------------------------------------------

};
