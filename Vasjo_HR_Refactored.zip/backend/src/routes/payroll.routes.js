'use strict';
// Domain route module — HTTP routing only. Business logic lives in services / db.
// Extracted from server.js; handlers preserve original behavior and contracts.

module.exports = function register(app, deps) {
  const {
    auth, authz, enterprise, db, services,
    asyncHandler, tenantCtx,
  } = deps;
  const { numSetting, nowStr } = services.utils;
  const payroll = services.payroll;
  const attendance = services.attendance;
  const compliance = services.compliance;
  const fnf = services.fnf;
  const leave = services.leave;
  const lifecycle = services.lifecycle;
  const reports = services.reports;
  const platform = services.platform;
  const storage = services.storage;
  const documents = services.document;
  const payrollControls = services.payrollControls;

  // --- PAYROLL (all blocks) ---
app.get('/api/payroll/financial-years', auth.requireAuth, authz.requireAnyPermission(['payroll.read','payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json({ financialYears: await db.listFinancialYears() });
}));
app.post('/api/payroll/financial-years', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { name, startDate, endDate } = req.body || {};
  if (!name || !startDate || !endDate) return res.status(400).json({ error: 'name, startDate and endDate are required' });
  const id = await db.createFinancialYear(name, startDate, endDate);
  await payroll.ensureStatutoryTaxRules(id);
  res.status(201).json({ id });
}));
app.post('/api/payroll/financial-years/:id/activate', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.setActiveFinancialYear(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

app.get('/api/payroll/components', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listSalaryComponents(false));
}));
app.post('/api/payroll/components', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const id = await db.createSalaryComponent(req.body || {});
  res.status(201).json({ id });
}));
app.put('/api/payroll/components/:id', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.updateSalaryComponent(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------
// PAYROLL — EMPLOYEE SALARY STRUCTURE & REVISIONS
// ---------------------------------------------------------------------------

async function assertPayrollAccess(req, targetUserId) {
  const ok = await db.canAccessEmployeePayroll(req.session.user, targetUserId);
  if (!ok) { const e = new Error('Forbidden'); e.code = 'FORBIDDEN'; e.httpStatus = 403; throw e; }
}

app.get('/api/payroll/salary-structures', auth.requireAuth, authz.requireAnyPermission(['payroll.read','payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.query.userId, 10);
  if (!userId) return res.status(400).json({ error: 'userId query param is required' });
  await assertPayrollAccess(req, userId);
  res.json({ structures: await db.listSalaryStructuresForEmployee(userId) });
}));

app.get('/api/payroll/salary-structures/:id', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const structure = await db.getSalaryStructureById(parseInt(req.params.id, 10));
  if (!structure) return res.status(404).json({ error: 'Salary structure not found' });
  const components = await db.getStructureComponents(structure.id);
  res.json({ ...structure, components });
}));

app.post('/api/payroll/salary-structures', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { userId, financialYearId, effectiveFrom, annualCtc, basicSalary, componentOverrides } = req.body || {};
  if (!userId || !effectiveFrom || !annualCtc) return res.status(400).json({ error: 'userId, effectiveFrom and annualCtc are required' });
  const fyId = financialYearId || (await db.getActiveFinancialYear()).id;
  const id = await payroll.createSalaryStructure({ userId, financialYearId: fyId, effectiveFrom, annualCtc, basicSalary, createdBy: req.session.user.id, componentOverrides });
  res.status(201).json({ id });
}));

app.patch('/api/payroll/salary-structures/:id', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.updateSalaryStructureBasics(parseInt(req.params.id, 10), req.body || {});
  res.json({ ok: true });
}));

app.put('/api/payroll/salary-structures/:id/components', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const structureId = parseInt(req.params.id, 10);
  const { componentAmounts, components } = req.body || {};
  if (Array.isArray(components)) {
    // Admin "Salary Structure Builder" shape: full replace with free-form
    // {componentName, type, category, amount, isTaxable} rows.
    await db.replaceStructureComponents(structureId, components.map((c) => ({
      name: c.componentName, type: c.type, category: c.category, amount: payroll.roundMoney(c.amount), isTaxable: !!c.isTaxable,
    })));
    const monthlyCtc = (await db.getStructureComponents(structureId))
      .filter((c) => c.type === 'earning').reduce((sum, c) => sum + Number(c.amount || 0), 0);
    return res.json({ monthlyCtc });
  }
  if (componentAmounts) {
    const monthlyCtc = await payroll.setSalaryStructureComponents(structureId, componentAmounts, req.session.user.id);
    return res.json({ monthlyCtc });
  }
  return res.status(400).json({ error: 'components[] or componentAmounts is required' });
}));

app.post('/api/payroll/salary-structures/:id/activate', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await payroll.activateSalaryStructureFull(parseInt(req.params.id, 10), req.session.user.id);
  res.json({ ok: true });
}));

app.get('/api/admin/employees/:userId/compensation', auth.requireAuth, authz.requireAnyPermission(['payroll.read','payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const user = await db.findUserById(userId, req.session.user.tenant_id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  delete user.password_hash; delete user.password_salt;
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  const activeStructure = await db.getActiveSalaryStructure(userId, fyId);
  const components = activeStructure ? await db.getStructureComponents(activeStructure.id) : [];
  res.json({ user, activeStructure, components });
}));

app.post('/api/admin/employees/:userId/hike', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const body = req.body || {};
  if (!body.effectiveDate || (!body.newAnnualCtc && !body.hikePercentage && !body.hikeAmount)) {
    return res.status(400).json({ error: 'effectiveDate and one of newAnnualCtc/hikePercentage/hikeAmount are required' });
  }
  const financialYearId = body.financialYearId || (await db.getActiveFinancialYear()).id;
  const result = await payroll.giveSalaryHike({ userId, approvedBy: req.session.user.id, ...body, financialYearId });
  res.status(201).json(result);
}));

app.get('/api/admin/employees/:userId/salary-revisions', auth.requireAuth, authz.requireAnyPermission(['payroll.read','payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json({ revisions: await db.listSalaryRevisionsForUser(userId) });
}));

app.get('/api/payroll/revisions/recent', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listRecentSalaryRevisions(parseInt(req.query.limit, 10) || 50));
}));

app.post('/api/payroll/employees/:userId/offer-letter', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { structureId, path } = req.body || {};
  if (!structureId || !path) return res.status(400).json({ error: 'structureId and path are required' });
  await db.attachOfferLetter(structureId, path);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------
// PAYROLL — EMPLOYEE LOANS
// ---------------------------------------------------------------------------

app.get('/api/payroll/employees/:userId/loans', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json(await db.listLoansForUser(userId));
}));
app.post('/api/payroll/employees/:userId/loans', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  if (userId !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  const id = await payroll.requestLoan({ userId, ...req.body });
  res.status(201).json({ id });
}));
app.get('/api/payroll/loans', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listLoans(req.query.status));
}));
app.post('/api/payroll/loans/:id/decide', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const loan = await payroll.decideLoanRequest(parseInt(req.params.id, 10), req.body.decision, req.session.user.id);
  res.json(loan);
}));
app.post('/api/payroll/loans/:id/disburse', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const loan = await payroll.disburseLoanFull(parseInt(req.params.id, 10), req.session.user.id);
  res.json(loan);
}));
app.get('/api/payroll/loans/:id/repayments', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listLoanRepayments(parseInt(req.params.id, 10)));
}));

// ---------------------------------------------------------------------------
// PAYROLL — SALARY ADVANCES
// ---------------------------------------------------------------------------

app.get('/api/payroll/employees/:userId/advances', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json(await db.listSalaryAdvancesForUser(userId));
}));
app.post('/api/payroll/employees/:userId/advances', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  if (userId !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  const id = await payroll.requestSalaryAdvance({ userId, ...req.body });
  res.status(201).json({ id });
}));
app.get('/api/payroll/advances', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listSalaryAdvances(req.query.status));
}));
app.post('/api/payroll/advances/:id/decide', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { decision, recoveryMonths, monthlyRecoveryAmount } = req.body || {};
  const advance = await payroll.decideSalaryAdvanceRequest(parseInt(req.params.id, 10), decision, req.session.user.id, recoveryMonths, monthlyRecoveryAmount);
  res.json(advance);
}));
app.get('/api/payroll/advances/:id/recoveries', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listAdvanceRecoveries(parseInt(req.params.id, 10)));
}));

// ---------------------------------------------------------------------------
// PAYROLL — LEAVE ENCASHMENT
// ---------------------------------------------------------------------------

app.get('/api/payroll/employees/:userId/leave-encashment', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json(await db.listLeaveEncashmentsForUser(userId));
}));
app.post('/api/payroll/employees/:userId/leave-encashment', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  if (userId !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  const financialYearId = req.body.financialYearId || (await db.getActiveFinancialYear()).id;
  const result = await payroll.requestLeaveEncashment({ userId, financialYearId, ...req.body });
  res.status(201).json(result);
}));
app.get('/api/payroll/leave-encashment', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listLeaveEncashments(req.query.status));
}));
app.post('/api/payroll/leave-encashment/:id/decide', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const enc = await payroll.decideLeaveEncashmentRequest(parseInt(req.params.id, 10), req.body.decision, req.session.user.id);
  res.json(enc);
}));

// ---------------------------------------------------------------------------
// PAYROLL — GRATUITY & ARREARS
// ---------------------------------------------------------------------------

app.get('/api/payroll/employees/:userId/gratuity', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : undefined;
  res.json(await payroll.calculateGratuity(userId, fyId, req.query.asOfDate));
}));
app.get('/api/payroll/employees/:userId/arrears', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json(await db.listArrearsForUser(userId));
}));

// ---------------------------------------------------------------------------
// PAYROLL — REPORTS: MONTH-TO-MONTH COMPARISON & VARIANCE
// ---------------------------------------------------------------------------

app.get('/api/payroll/reports/comparison', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { financialYearId, monthA, monthB } = req.query;
  if (!financialYearId || !monthA || !monthB) return res.status(400).json({ error: 'financialYearId, monthA and monthB are required' });
  res.json(await payroll.comparePayrollMonths(parseInt(financialYearId, 10), monthA, monthB));
}));
app.get('/api/payroll/reports/variance', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { financialYearId, monthA, monthB, threshold } = req.query;
  if (!financialYearId || !monthA || !monthB) return res.status(400).json({ error: 'financialYearId, monthA and monthB are required' });
  res.json(await payroll.payrollVarianceReport(parseInt(financialYearId, 10), monthA, monthB, threshold));
}));

// ---------------------------------------------------------------------------
// PAYROLL — TAX REGIME / DECLARATIONS
// ---------------------------------------------------------------------------

app.get('/api/payroll/tax-regimes', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json({ regimes: await db.listTaxRegimes(fyId) });
}));

app.get('/api/payroll/my-tax-regime', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json({ regime: (await db.getEmployeeTaxRegime(req.session.user.id, fyId)) || null });
}));

app.post('/api/payroll/my-tax-regime', auth.requireAuth, asyncHandler(async (req, res) => {
  const { financialYearId, taxRegimeId } = req.body || {};
  if (!financialYearId || !taxRegimeId) return res.status(400).json({ error: 'financialYearId and taxRegimeId are required' });
  await db.setEmployeeTaxRegime(req.session.user.id, financialYearId, taxRegimeId, req.session.user.id);
  res.json({ ok: true });
}));

app.get('/api/payroll/my-tax-regime/compare', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  const raw = await payroll.compareTaxRegimesForEmployee(req.session.user.id, fyId);
  const minTax = raw.length ? Math.min(...raw.map(r => r.annualTax)) : 0;
  const comparison = raw.map(r => ({
    regime_name: r.name,
    is_lower_tax: r.annualTax === minTax,
    taxable_income: r.taxableIncome,
    income_tax: r.annualTax,
    total_annual_tax: r.annualTax,
    monthly_tds: payroll.roundMoney(r.annualTax / 12),
    estimated_annual_takehome: payroll.roundMoney(r.annualGrossIncome - r.annualTax),
  }));
  const lower = comparison.find(r => r.is_lower_tax);
  res.json({ comparison: { comparison, lower_tax_regime: lower ? lower.regime_name : null } });
}));

app.get('/api/payroll/my-tax-summary', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await payroll.getEmployeeTaxSummary(req.session.user.id, fyId));
}));

app.get('/api/payroll/tax-declaration-sections', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json({ sections: await db.listTaxDeclarationSections(fyId, req.query.regime) });
}));

app.get('/api/payroll/my-tax-declarations', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  const declarations = await db.listDeclarationsForUser(req.session.user.id, fyId);
  for (const d of declarations) d.entries = await db.listDeclarationEntries(d.id);
  res.json({ declarations });
}));

app.post('/api/payroll/my-tax-declarations', auth.requireAuth, asyncHandler(async (req, res) => {
  const { financialYearId, sectionId } = req.body || {};
  if (!sectionId) return res.status(400).json({ error: 'sectionId is required' });
  const fyId = financialYearId || (await db.getActiveFinancialYear()).id;
  const declaration = await db.getOrCreateDeclaration(req.session.user.id, fyId, sectionId);
  res.status(201).json({ id: declaration.id });
}));

app.post('/api/payroll/tax-declarations/:declarationId/entries', auth.requireAuth, asyncHandler(async (req, res) => {
  const declarationId = parseInt(req.params.declarationId, 10);
  const declaration = await db.getDeclarationById(declarationId);
  if (!declaration) return res.status(404).json({ error: 'Declaration not found' });
  if (declaration.user_id !== req.session.user.id && !authz.isAdmin(req.session.user)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const entryId = await db.addDeclarationEntry(declarationId, req.body || {});
  await db.recomputeDeclaredAmount(declarationId);
  res.status(201).json({ entryId, declarationId });
}));

app.delete('/api/payroll/tax-entries/:entryId', auth.requireAuth, asyncHandler(async (req, res) => {
  const entryId = parseInt(req.params.entryId, 10);
  const entry = await db.dbGet('SELECT tde.*, td.user_id FROM tax_declaration_entries tde JOIN tax_declarations td ON td.id = tde.tax_declaration_id WHERE tde.id = ?', [entryId]);
  if (!entry) return res.status(404).json({ error: 'Entry not found' });
  if (entry.user_id !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  await db.deleteDeclarationEntry(entryId);
  res.json({ ok: true });
}));

app.post('/api/payroll/tax-declaration-entries/:id/decide', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { status, approvedAmount, rejectionReason } = req.body || {};
  if (!['approved', 'rejected', 'proof_uploaded', 'correction_requested'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  await db.updateDeclarationEntryStatus(parseInt(req.params.id, 10), status, { approvedAmount, approvedBy: req.session.user.id, rejectionReason });
  res.json({ ok: true });
}));

app.post('/api/payroll/my-tax-declarations/submit-all', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = (req.body || {}).financialYearId || (await db.getActiveFinancialYear()).id;
  await db.submitTaxDeclarations(req.session.user.id, fyId);
  res.json({ ok: true });
}));

app.post('/api/payroll/tax-declarations/:id/verify', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { eligibleAmount } = req.body || {};
  await db.verifyTaxDeclaration(parseInt(req.params.id, 10), req.session.user.id, eligibleAmount);
  res.json({ ok: true });
}));
app.post('/api/payroll/tax-declarations/:id/reject', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.rejectTaxDeclaration(parseInt(req.params.id, 10), req.session.user.id, (req.body || {}).reason);
  res.json({ ok: true });
}));

app.get('/api/payroll/deduction-limits', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await db.listDeductionLimits(fyId));
}));

// ---------------------------------------------------------------------------
// PAYROLL — FIXED / VARIABLE DEDUCTIONS & PREVIOUS EMPLOYER INCOME
// ---------------------------------------------------------------------------

app.get('/api/payroll/employees/:userId/fixed-deductions', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await db.listFixedDeductions(userId, fyId));
}));
app.post('/api/payroll/employees/:userId/fixed-deductions', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const id = await db.addFixedDeduction({ userId, ...req.body });
  res.status(201).json({ id });
}));
app.delete('/api/payroll/fixed-deductions/:id', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.deactivateFixedDeduction(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

app.get('/api/payroll/employees/:userId/variable-deductions', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  if (!req.query.payrollMonth) return res.status(400).json({ error: 'payrollMonth query param is required' });
  res.json(await db.listVariableDeductions(userId, req.query.payrollMonth));
}));
app.post('/api/payroll/employees/:userId/variable-deductions', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await db.addVariableDeduction({ userId, createdBy: req.session.user.id, ...req.body });
  res.status(201).json({ ok: true });
}));
app.delete('/api/payroll/variable-deductions/:id', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  await db.removeVariableDeduction(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

app.get('/api/payroll/employees/:userId/previous-employer-income', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await db.getPreviousEmployerIncome(userId, fyId));
}));
app.post('/api/payroll/employees/:userId/previous-employer-income', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  if (userId !== req.session.user.id && !authz.isAdmin(req.session.user)) return res.status(403).json({ error: 'Forbidden' });
  const fyId = (req.body || {}).financialYearId || (await db.getActiveFinancialYear()).id;
  await db.upsertPreviousEmployerIncome({ userId, financialYearId: fyId, ...req.body });
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------
// PAYROLL — RUNS
// ---------------------------------------------------------------------------

app.get('/api/payroll/runs', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  // req.query.financialYearId can arrive as the literal string "undefined"
  // (some frontend callers omit the argument, and template-literal
  // interpolation turns that into the text "undefined" rather than leaving
  // the query param absent). Parsing that yields NaN, and `if (NaN)` is
  // falsy, so the previous code silently fell through to "return every run
  // across every financial year" instead of the intended "no filter" vs.
  // "filter by this year" distinction. Validate the parsed integer instead
  // of the raw query string.
  const parsedFy = req.query.financialYearId !== undefined ? parseInt(req.query.financialYearId, 10) : NaN;
  res.json({ runs: await db.listPayrollRuns(Number.isInteger(parsedFy) ? parsedFy : undefined) });
}));

app.get('/api/payroll/dashboard', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  const dashboard = await db.getPayrollDashboardData(fyId, req.session.user.tenant_id);
  // Keep the named dashboard envelope used by the current UI while exposing
  // the flat legacy shape expected by existing API consumers.
  res.json({ ...dashboard, dashboard });
}));

// Create a new draft run for a month (no calculation yet — the admin UI
// calculates it separately, by id, once created).
app.post('/api/payroll/runs', auth.requireAuth, enterprise.requirePermission('payroll.calculate'), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.body || {};
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  const run = await db.getOrCreatePayrollRun(financialYearId, payrollMonth);
  res.status(201).json({ id: run.id });
}));

app.delete('/api/payroll/runs/:id', auth.requireAuth, enterprise.requirePermission('payroll.calculate'), asyncHandler(async (req, res) => {
  await db.deletePayrollRun(parseInt(req.params.id, 10));
  res.json({ ok: true });
}));

// Legacy one-shot "find-or-create + calculate by month" endpoint (kept for
// any external/API caller that already targets it directly).
app.post('/api/payroll/runs/calculate', auth.requireAuth, enterprise.requirePermission('payroll.calculate'), asyncHandler(async (req, res) => {
  const { financialYearId, payrollMonth } = req.body || {};
  if (!financialYearId || !payrollMonth) return res.status(400).json({ error: 'financialYearId and payrollMonth are required' });
  const run = await payroll.calculatePayrollRun(financialYearId, payrollMonth, req.session.user.id);
  res.json({ ...run, totalEmployees: run.total_employees });
}));

// Calculate (or recalculate) an existing run by id — this is what the admin
// "Calculate" button on a specific run actually hits.
app.post('/api/payroll/runs/:id/calculate', auth.requireAuth, enterprise.requirePermission('payroll.calculate'), asyncHandler(async (req, res) => {
  const existing = await db.getPayrollRun(parseInt(req.params.id, 10));
  if (!existing) return res.status(404).json({ error: 'Payroll run not found' });
  const run = await payroll.calculatePayrollRun(existing.financial_year_id, existing.payroll_month, req.session.user.id);
  res.json({ ...run, totalEmployees: run.total_employees });
}));

app.get('/api/payroll/runs/:id', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  res.json(await db.getPayrollRun(parseInt(req.params.id, 10)));
}));

app.get('/api/payroll/runs/:id/details', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  res.json({ details: await db.listPayrollDetails(parseInt(req.params.id, 10)) });
}));

app.get('/api/payroll/runs/:id/details.csv', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  const rows = await db.listPayrollDetails(parseInt(req.params.id, 10));
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="payroll-details.csv"');
  res.send(reports.payrollDetailsToCsv(rows));
}));

app.post('/api/payroll/runs/:id/review', auth.requireAuth, enterprise.requirePermission('payroll.review'), asyncHandler(async (req, res) => {
  await payroll.reviewPayrollRun(parseInt(req.params.id, 10), req.session.user.id);
  res.json({ ok: true });
}));
app.post('/api/payroll/runs/:id/approve', auth.requireAuth, enterprise.requirePermission('payroll.approve'), asyncHandler(async (req, res) => {
  await payrollControls.assertControlsClear(tenantCtx(req), parseInt(req.params.id, 10));
  await payroll.approvePayrollRun(parseInt(req.params.id, 10), req.session.user.id);
  res.json({ ok: true });
}));
app.post('/api/payroll/runs/:id/lock', auth.requireAuth, enterprise.requirePermission('payroll.lock'), asyncHandler(async (req, res) => {
  await payroll.lockPayrollRun(parseInt(req.params.id, 10), req.session.user.id);
  res.json({ ok: true });
}));

app.get('/api/payroll/runs/:id/exceptions', auth.requireAuth, enterprise.requirePermission('payroll.read'), asyncHandler(async (req, res) => {
  res.json({ exceptions: await db.listPayrollExceptions(parseInt(req.params.id, 10), req.query.unresolved === '1') });
}));
app.post('/api/payroll/exceptions/:id/resolve', auth.requireAuth, enterprise.requirePermission('payroll.review'), asyncHandler(async (req, res) => {
  await db.resolveException(parseInt(req.params.id, 10), req.session.user.id, (req.body || {}).notes);
  res.json({ ok: true });
}));

app.post('/api/payroll/details/:id/adjustments', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { adjustmentType, amount, reason } = req.body || {};
  if (!adjustmentType || amount === undefined || !reason) return res.status(400).json({ error: 'adjustmentType, amount and reason are required' });
  const id = await payroll.requestPayrollAdjustment(parseInt(req.params.id, 10), adjustmentType, amount, reason, req.session.user.id);
  res.status(201).json({ id });
}));
app.get('/api/payroll/details/:id/adjustments', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.listPayrollAdjustments(parseInt(req.params.id, 10)));
}));
app.post('/api/payroll/adjustments/:id/decide', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { decision } = req.body || {};
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject' });
  await payroll.decidePayrollAdjustment(parseInt(req.params.id, 10), decision, req.session.user.id);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------------------
// PAYROLL — PAYSLIPS
// ---------------------------------------------------------------------------

app.post('/api/payroll/payslips/generate', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const { payrollDetailId } = req.body || {};
  if (!payrollDetailId) return res.status(400).json({ error: 'payrollDetailId is required' });
  const data = await payroll.preparePayslipData(payrollDetailId);
  const pdfBuffer = reports.buildPayslipPdf(data);
  const payslip = await payroll.generatePayslipRecord(payrollDetailId, req.session.user.id, null);
  res.status(201).json({ id: payslip.id, sizeBytes: pdfBuffer.length });
}));

app.get('/api/payroll/payslips/:id/pdf', auth.requireAuth, asyncHandler(async (req, res) => {
  const payslip = await db.getPayslip(parseInt(req.params.id, 10));
  if (!payslip) return res.status(404).json({ error: 'Payslip not found' });
  await assertPayrollAccess(req, payslip.user_id);
  const data = await payroll.preparePayslipData(payslip.payroll_detail_id);
  const pdfBuffer = reports.buildPayslipPdf(data);
  await db.markPayslipDownloaded(payslip.id, req.session.user.id);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="payslip-${payslip.payroll_month}.pdf"`);
  res.send(pdfBuffer);
}));

app.get('/api/payroll/my-payslips', auth.requireAuth, asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : undefined;
  res.json({ payslips: await db.listPayslipsForEmployee(req.session.user.id, fyId) });
}));

app.get('/api/payroll/employees/:userId/history', auth.requireAuth, asyncHandler(async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  await assertPayrollAccess(req, userId);
  res.json(await db.listPayrollHistoryForUser(userId));
}));

app.get('/api/payroll/employees-status', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  const fyId = req.query.financialYearId ? parseInt(req.query.financialYearId, 10) : (await db.getActiveFinancialYear()).id;
  res.json(await db.listEmployeesWithPayrollStatus(fyId));
}));

app.get('/api/payroll/audit-log/:entityType/:entityId', auth.requireAuth, authz.requireAnyPermission(['payroll.*','admin.configure']), asyncHandler(async (req, res) => {
  res.json(await db.getPayrollAuditLog(req.params.entityType, req.params.entityId));
}));


// ---------------------------------------------------------------------------

};
