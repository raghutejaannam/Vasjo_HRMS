'use strict';
// Shared Prisma client instance. Single source of truth for the ORM connection.
require('dotenv').config();
const { PrismaClient, Prisma } = require('@prisma/client');

const prisma = new PrismaClient();

module.exports = { prisma, Prisma };
