'use strict';
// Raw SQL helpers — translate '?' placeholders into PostgreSQL positional
// parameters and run them through Prisma's parameterized raw-query API.
const { Prisma, prisma } = require('./prisma');
const { currentClient } = require('./context');

function toPrismaSql(sqlText, params = []) {
  const parts = sqlText.split('?');
  if (parts.length === 1) return Prisma.sql(parts);
  // Prisma.sql is a tag function. Supplying .raw makes this dynamically
  // constructed template behave like a tagged-template invocation while
  // keeping every value as a bound parameter.
  parts.raw = parts;
  return Prisma.sql(parts, ...params);
}

function normalizeDbValue(value) {
  if (typeof value === 'bigint') return Number(value);
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(normalizeDbValue);
  if (value && typeof value === 'object') {
    if (typeof value.toNumber === 'function') return value.toNumber();
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = normalizeDbValue(item);
    return out;
  }
  return value;
}

async function dbAll(sqlText, params = [], client) {
  client = client || currentClient();
  const rows = await client.$queryRaw(toPrismaSql(sqlText, params));
  return normalizeDbValue(rows);
}

async function dbGet(sqlText, params = [], client) {
  const rows = await dbAll(sqlText, params, client);
  return rows[0];
}

async function dbRun(sqlText, params = [], client) {
  client = client || currentClient();
  const n = await client.$executeRaw(toPrismaSql(sqlText, params));
  return { changes: n };
}

async function dbInsert(sqlText, params = [], client) {
  client = client || currentClient();
  const rows = await client.$queryRaw(toPrismaSql(sqlText + ' RETURNING id', params));
  return { id: rows[0] ? rows[0].id : undefined };
}

async function healthCheck() {
  await prisma.$queryRaw`SELECT 1`;
  return true;
}

module.exports = {
  toPrismaSql,
  normalizeDbValue,
  dbAll,
  dbGet,
  dbRun,
  dbInsert,
  healthCheck,
};
