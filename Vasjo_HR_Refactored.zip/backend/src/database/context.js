'use strict';
// Request-scoped database context (AsyncLocalStorage) for multi-tenant RLS.
// Every authenticated request runs inside withRequestContext so PostgreSQL
// Row-Level Security can see app.tenant_id for the duration of the transaction.
const { AsyncLocalStorage } = require('node:async_hooks');
const { prisma } = require('./prisma');

const requestDbContext = new AsyncLocalStorage();

function currentClient() {
  return requestDbContext.getStore()?.client || prisma;
}

// Reuse the current request/seed transaction when one is already active.
// Critical for PostgreSQL read-after-write visibility within a request.
async function withTx(fn) {
  const activeClient = requestDbContext.getStore()?.client;
  if (activeClient) return fn(activeClient);
  return prisma.$transaction(fn, { maxWait: 10000, timeout: 120000 });
}

async function authLookup(fn) {
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT set_config('app.auth_lookup', 'true', true)`;
    return fn(tx);
  });
}

async function withRequestContext(tenantId, fn) {
  const activeClient = requestDbContext.getStore()?.client;
  if (activeClient) {
    if (tenantId) {
      await activeClient.$executeRaw`SELECT set_config('app.tenant_id', ${String(tenantId)}, true)`;
    }
    return requestDbContext.run({ client: activeClient, tenantId: tenantId ? Number(tenantId) : null }, fn);
  }
  return prisma.$transaction(async (tx) => {
    if (tenantId) {
      await tx.$executeRaw`SELECT set_config('app.tenant_id', ${String(tenantId)}, true)`;
    }
    return requestDbContext.run({ client: tx, tenantId: tenantId ? Number(tenantId) : null }, fn);
  }, { maxWait: 10000, timeout: 120000 });
}

module.exports = {
  requestDbContext,
  currentClient,
  withTx,
  authLookup,
  withRequestContext,
};
