// src/server.js — Express HTTP layer for the Vasjo Technologies Timesheet
// Portal backend. Ported from the original hand-rolled http.createServer
// router (src/server.js, SQLite version) — same routes, same request/response
// shapes, same status codes and error messages, now expressed as Express
// routes calling into the async db/auth/payroll/reports modules.
//
// Static file serving for a bundled frontend build was part of the original
// server; this migration is backend-only (per the migration brief the
// frontend is out of scope), so that section is omitted here. If you need
// it, add `express.static(path.join(__dirname, '..', 'public'))` back in.

require('dotenv').config();
const express = require('express');
const crypto = require('node:crypto');
const { createCorsMiddleware } = require('./cors');

const db = require('./db');
const services = require('./services');
const auth = services.auth;
const payroll = services.payroll;
const attendance = services.attendance;
const compliance = services.compliance;
const fnf = services.fnf;
const leave = services.leave;
const lifecycle = services.lifecycle;
const reports = services.reports;
const enterprise = services.enterprise;
const platform = services.platform;
const storage = services.storage;
const { numSetting, nowStr } = services.utils;
const authz = services.authorization;
const documents = services.document;
const payrollControls = services.payrollControls;
const { asyncHandler, errorHandler, notFoundHandler, atomicRequest } = require('./http/error-handler');

const PORT = parseInt(process.env.PORT || '3000', 10);
const IS_PROD = process.env.NODE_ENV === 'production';

const app = express();
app.set('trust proxy', 1);
app.use(createCorsMiddleware());
app.use(express.json({ limit: '2mb' }));
app.use(express.raw({ type: 'application/octet-stream', limit: '50mb' }));

// Security headers, request correlation and lightweight API rate limiting.
app.use((req, res, next) => {
  req.requestId = req.headers['x-request-id'] || crypto.randomUUID();
  res.setHeader('X-Request-Id', req.requestId);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  if (IS_PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
const apiHits = new Map();
app.use('/api', (req, res, next) => {
  const key = `${req.ip}:${req.path.startsWith('/login') ? 'login' : 'api'}`;
  const now = Date.now(); const rec = apiHits.get(key) || { start: now, count: 0 };
  if (now - rec.start > 60_000) { rec.start = now; rec.count = 0; }
  rec.count += 1; apiHits.set(key, rec);
  const limit = key.endsWith(':login') ? 30 : 600;
  if (rec.count > limit) return res.status(429).json({ error: 'Too many requests' });
  next();
});

// asyncHandler + central error handling live in ./http/error-handler.js
app.use(auth.attachSession);
app.use(auth.csrfProtection);

// Every authenticated request runs in ONE transaction carrying the tenant
// context used by PostgreSQL RLS. The transaction COMMITS BEFORE the response
// is sent (read-your-writes) and ROLLS BACK on any 4xx/5xx response.
app.use(atomicRequest(db));


function tenantCtx(req) { return authz.contextFrom(req); }


// ---------------------------------------------------------------------------
// DOMAIN ROUTE REGISTRATION
// ---------------------------------------------------------------------------
const routeDeps = {
  auth, authz, enterprise, db, services,
  asyncHandler, tenantCtx,
};

const domainRoutes = [
  'auth.routes',
  'users.routes',
  'lifecycle.routes',
  'notifications.routes',
  'timesheets.routes',
  'leave.routes',
  'leave-advanced.routes',
  'holidays.routes',
  'projects.routes',
  'settings.routes',
  'audit.routes',
  'reports.routes',
  'attendance.routes',
  'compliance.routes',
  'fnf.routes',
  'payroll.routes',
  'platform.routes',
  'health.routes',
];

for (const name of domainRoutes) {
  require(`./routes/${name}`)(app, routeDeps);
}

// Existing modular route modules (P0/P1, P2, approvals, documents, etc.)
const registerP0P1 = require('./routes/p0p1');
registerP0P1(app, { auth, authz, asyncHandler, tenantCtx });
const registerP2 = require('./routes/p2');
registerP2(app, { auth, authz, asyncHandler, tenantCtx });

for (const register of ['approvals', 'documents', 'compliance-rules', 'payroll-controls', 'analytics', 'leave-calendar']) {
  require(`./routes/${register}`)(app, { requireAuth: auth.requireAuth });
}

app.use('/api', notFoundHandler);
app.use(errorHandler);

module.exports = app;


// ---------------------------------------------------------------------------
// STARTUP — only when run directly (not when required by tests)
// ---------------------------------------------------------------------------

if (require.main === module) {
  (async () => {
    await db.ensureRuntimeDefaults();
    const existingTenants = await db.dbAll("SELECT id FROM tenants WHERE status='active'");
    for (const tenant of existingTenants) {
      await db.withRequestContext(tenant.id, async () => { await enterprise.seedBuiltins({tenantId: tenant.id, actorId: null, req: null}); });
    }
    const server = app.listen(PORT, () => {
      console.log(`Vasjo Timesheet Portal API listening on port ${PORT}`);
    });

    // Escalation sweep — same "check every N hours" pattern as the original
    // server, driven by settings.escalation_days.
    const ESCALATION_INTERVAL_MS = 1000 * 60 * 60; // hourly
    const escalationTimer = setInterval(async () => {
      try {
        const tenants = await db.dbAll("SELECT id FROM tenants WHERE status='active'");
        for (const t of tenants) {
          await db.withRequestContext(t.id, async () => {
            const settings = await db.getSettings();
            await db.runEscalationCheck(numSetting(settings.escalation_days, 3));
            await documents.documentExpirySweep({tenantId: t.id, actorId: null, req: null});
            await platform.processWebhookDeliveries({tenantId: t.id, actorId: null, req: null});
          });
        }
      } catch (e) {
        console.error('Escalation check failed:', e);
      }
    }, ESCALATION_INTERVAL_MS);
    escalationTimer.unref();

    function shutdown() {
      clearInterval(escalationTimer);
      server.close(() => {
        db.prisma.$disconnect().finally(() => process.exit(0));
      });
    }
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  })();
}
