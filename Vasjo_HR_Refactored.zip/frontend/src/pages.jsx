/**
 * Page registry — maps view keys to page components.
 * Domain implementations live under ./pages/<domain>/.
 */
import React from "react";

export { WorkspacePage } from "./pages/dashboard/WorkspacePage.jsx";
export { LoginScreen, ForcedResetScreen } from "./pages/auth/AuthScreens.jsx";
export { DashboardPage } from "./pages/dashboard/DashboardPage.jsx";
export { CalendarPage } from "./pages/dashboard/CalendarPage.jsx";
export { TimesheetEntryPage } from "./pages/timesheets/TimesheetEntryPage.jsx";
export { TimesheetHistoryPage } from "./pages/timesheets/TimesheetHistoryPage.jsx";
export { LeaveApplicationPage } from "./pages/leave/LeaveApplicationPage.jsx";
export { LeaveHistoryPage } from "./pages/leave/LeaveHistoryPage.jsx";
export { ApprovalsPage } from "./pages/approvals/ApprovalsPage.jsx";
export { TeamTimesheetsPage } from "./pages/timesheets/TeamTimesheetsPage.jsx";
export { ReportsPage } from "./pages/reports/ReportsPage.jsx";
export { ProfilePage } from "./pages/employees/ProfilePage.jsx";
export { TeamPage } from "./pages/employees/TeamPage.jsx";
export { AdminPage } from "./pages/admin/AdminPage.jsx";
export {
  MySalaryPage, MyTaxDeclarationPage, MyPayslipsPage, PayrollDashboardPage,
  PayrollRunPage, SalaryAdminPage, MyBenefitsPage, PayrollBenefitsAdminPage, PayrollReportsPage,
} from "./pages/payroll/PayrollPages.jsx";
export { MyAttendancePage, AttendanceAdminPage } from "./pages/attendance/AttendancePages.jsx";
export { MyTaxStatementPage, ComplianceAdminPage, FnfAdminPage } from "./pages/compliance/ComplianceFnfPages.jsx";
export { MyCompOffPage, TeamLeaveCalendarPage, LeaveAdminPage } from "./pages/leave/LeaveAdminPages.jsx";
export { EmployeeLifecycleAdminPage } from "./pages/lifecycle/EmployeeLifecycleAdminPage.jsx";

export {
  MyOnboardingPage, TeamOnboardingPage, MyDocumentsPage, WorkerProfilePage,
  GoalsPage, TeamReviewsPage, InboxPage, MyReviewsPage, DocumentVerificationPage,
} from "./p0p1Pages.jsx";
export {
  OrgChartPage, OffboardingPage, BackgroundChecksPage, PerformanceDepthPage,
  WorkforceExperiencePage, TaxExperiencePage, RecruitmentDepthPage, LearningBenefitsPage,
  WorkflowDelegationPage, OnboardingJourneyPage, DocumentTemplatesPage, P2ReportsPage,
  MyOnboardingExperiencePage, GoalsExperiencePage, ReviewExperiencePage,
  TeamReviewDetailPage, DocumentsExperiencePage, DocumentVerificationExperiencePage,
} from "./p2Pages.jsx";
export {
  RecruitmentPage, PerformancePage, LearningPage, BenefitsPage, ExpensePage,
  AssetsPage, HelpdeskPage, IntegrationHubPage, EnterpriseAnalyticsPage,
  MobileWorkspacePage, AiAssistantPage, AiPayrollPage, AiDocumentPage, SavedReportsPage,
} from "./advancedPages.jsx";
export {
  EnterpriseDocumentsPage, WorkflowAdminPage, OrganizationPage,
  PayrollControlCenterPage, ComplianceRulesPage, SecurityAdminPage,
} from "./enterprisePages.jsx";

import { WorkspacePage } from "./pages/dashboard/WorkspacePage.jsx";
import { DashboardPage } from "./pages/dashboard/DashboardPage.jsx";
import { CalendarPage } from "./pages/dashboard/CalendarPage.jsx";
import { TimesheetEntryPage } from "./pages/timesheets/TimesheetEntryPage.jsx";
import { TimesheetHistoryPage } from "./pages/timesheets/TimesheetHistoryPage.jsx";
import { LeaveApplicationPage } from "./pages/leave/LeaveApplicationPage.jsx";
import { LeaveHistoryPage } from "./pages/leave/LeaveHistoryPage.jsx";
import { ApprovalsPage } from "./pages/approvals/ApprovalsPage.jsx";
import { TeamTimesheetsPage } from "./pages/timesheets/TeamTimesheetsPage.jsx";
import { ReportsPage } from "./pages/reports/ReportsPage.jsx";
import { ProfilePage } from "./pages/employees/ProfilePage.jsx";
import { TeamPage } from "./pages/employees/TeamPage.jsx";
import { AdminPage } from "./pages/admin/AdminPage.jsx";
import {
  MySalaryPage, MyTaxDeclarationPage, MyPayslipsPage, PayrollDashboardPage,
  PayrollRunPage, SalaryAdminPage, MyBenefitsPage, PayrollBenefitsAdminPage, PayrollReportsPage,
} from "./pages/payroll/PayrollPages.jsx";
import { MyAttendancePage, AttendanceAdminPage } from "./pages/attendance/AttendancePages.jsx";
import { MyTaxStatementPage, ComplianceAdminPage, FnfAdminPage } from "./pages/compliance/ComplianceFnfPages.jsx";
import { MyCompOffPage, TeamLeaveCalendarPage, LeaveAdminPage } from "./pages/leave/LeaveAdminPages.jsx";
import { EmployeeLifecycleAdminPage } from "./pages/lifecycle/EmployeeLifecycleAdminPage.jsx";
import {
  MyOnboardingPage, TeamOnboardingPage, MyDocumentsPage, WorkerProfilePage,
  GoalsPage, TeamReviewsPage, InboxPage, MyReviewsPage, DocumentVerificationPage,
} from "./p0p1Pages.jsx";
import {
  OrgChartPage, OffboardingPage, BackgroundChecksPage, PerformanceDepthPage,
  WorkforceExperiencePage, TaxExperiencePage, RecruitmentDepthPage, LearningBenefitsPage,
  WorkflowDelegationPage, OnboardingJourneyPage, DocumentTemplatesPage, P2ReportsPage,
  MyOnboardingExperiencePage, GoalsExperiencePage, ReviewExperiencePage,
  TeamReviewDetailPage, DocumentsExperiencePage, DocumentVerificationExperiencePage,
} from "./p2Pages.jsx";
import {
  RecruitmentPage, PerformancePage, LearningPage, BenefitsPage, ExpensePage,
  AssetsPage, HelpdeskPage, IntegrationHubPage, EnterpriseAnalyticsPage,
  MobileWorkspacePage, AiAssistantPage, AiPayrollPage, AiDocumentPage, SavedReportsPage,
} from "./advancedPages.jsx";
import {
  EnterpriseDocumentsPage, WorkflowAdminPage, OrganizationPage,
  PayrollControlCenterPage, ComplianceRulesPage, SecurityAdminPage,
} from "./enterprisePages.jsx";

export const PAGES = {
  "my-onboarding": MyOnboardingExperiencePage,
  "team-onboarding": TeamOnboardingPage,
  "my-documents": MyDocumentsPage,
  "worker-profile": WorkerProfilePage,
  "performance-goals": GoalsExperiencePage,
  "team-performance-reviews": (props) => props.reviewId ? <TeamReviewDetailPage {...props}/> : <TeamReviewsPage {...props}/>,
  inbox: InboxPage,
  "my-reviews": ReviewExperiencePage,
  "document-verification": DocumentVerificationExperiencePage,
  "org-chart": OrgChartPage,
  offboarding: OffboardingPage,
  "background-checks": BackgroundChecksPage,
  "performance-depth": PerformanceDepthPage,
  "workforce-experience": WorkforceExperiencePage,
  "tax-experience": TaxExperiencePage,
  "recruitment-depth": RecruitmentDepthPage,
  "learning-benefits": LearningBenefitsPage,
  "workflow-delegation": WorkflowDelegationPage,
  "onboarding-journey": OnboardingJourneyPage,
  "document-templates": DocumentTemplatesPage,
  "p2-reports": P2ReportsPage,
  dashboard: DashboardPage,
  "workspace-home": (props) => <WorkspacePage {...props} domain="home" />,
  "workspace-my-work": (props) => <WorkspacePage {...props} domain="my-work" />,
  "workspace-approvals": (props) => <WorkspacePage {...props} domain="approvals" />,
  "workspace-leave": (props) => <WorkspacePage {...props} domain="leave" />,
  "workspace-payroll": (props) => <WorkspacePage {...props} domain="payroll" />,
  "workspace-people": (props) => <WorkspacePage {...props} domain="people" />,
  "workspace-talent": (props) => <WorkspacePage {...props} domain="talent" />,
  "workspace-services": (props) => <WorkspacePage {...props} domain="services" />,
  "workspace-reports": (props) => <WorkspacePage {...props} domain="reports" />,
  "workspace-admin": (props) => <WorkspacePage {...props} domain="admin" />,
  "workspace-ai": (props) => <WorkspacePage {...props} domain="ai" />,
  calendar: CalendarPage,
  "timesheet-entry": TimesheetEntryPage,
  "timesheet-history": TimesheetHistoryPage,
  "leave-application": LeaveApplicationPage,
  "leave-history": LeaveHistoryPage,
  approvals: ApprovalsPage,
  "team-timesheets": TeamTimesheetsPage,
  reports: ReportsPage,
  team: TeamPage,
  profile: ProfilePage,
  admin: AdminPage,
  "my-salary": MySalaryPage,
  "my-tax-declaration": MyTaxDeclarationPage,
  "my-payslips": MyPayslipsPage,
  "payroll-dashboard": PayrollDashboardPage,
  "payroll-run": PayrollRunPage,
  "salary-admin": SalaryAdminPage,
  "payroll-benefits-admin": PayrollBenefitsAdminPage,
  "payroll-reports": PayrollReportsPage,
  "my-benefits": MyBenefitsPage,
  "my-attendance": MyAttendancePage,
  "attendance-admin": AttendanceAdminPage,
  "my-tax-statement": MyTaxStatementPage,
  "compliance-admin": ComplianceAdminPage,
  "fnf-admin": FnfAdminPage,
  "my-comp-off": MyCompOffPage,
  "leave-calendar": TeamLeaveCalendarPage,
  "leave-admin": LeaveAdminPage,
  "lifecycle-admin": EmployeeLifecycleAdminPage,
  "document-center": EnterpriseDocumentsPage,
  "workflow-admin": WorkflowAdminPage,
  "organization-admin": OrganizationPage,
  "payroll-controls": PayrollControlCenterPage,
  "compliance-rules": ComplianceRulesPage,
  "security-admin": SecurityAdminPage,
  recruitment: RecruitmentPage,
  performance: PerformancePage,
  learning: LearningPage,
  benefits: BenefitsPage,
  expenses: ExpensePage,
  assets: AssetsPage,
  helpdesk: HelpdeskPage,
  "integration-hub": IntegrationHubPage,
  "enterprise-analytics": EnterpriseAnalyticsPage,
  mobile: MobileWorkspacePage,
  "ai-assistant": AiAssistantPage,
  "ai-payroll": AiPayrollPage,
  "ai-documents": AiDocumentPage,
  "saved-reports": SavedReportsPage,
};
