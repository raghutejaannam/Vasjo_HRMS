import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

const WORKSPACE_CONTENT = {
  home: { title: "Home", eyebrow: "Workspace", sub: "Your daily work, requests and team activity in one place.", cards: [{ id: "dashboard", title: "Dashboard", text: "See your current work summary and pending activity." }] },
  "my-work": { title: "My Work", eyebrow: "Workspace", sub: "Time, attendance and leave tools for your working day.", cards: [{ id: "calendar", title: "My Calendar", text: "Review work days, holidays and leave." }, { id: "timesheet-entry", title: "My Timesheet", text: "Submit this week's hours." }, { id: "timesheet-history", title: "Timesheet History", text: "Review submitted timesheets." }, { id: "my-attendance", title: "My Attendance", text: "View attendance records." }, { id: "my-comp-off", title: "My Comp-Off", text: "Request and redeem comp-off." }] },
  approvals: { title: "Approval Center", eyebrow: "Approvals", sub: "Review every request that needs your decision.", cards: [{ id: "approvals", title: "Approval Center", text: "Review leave, timesheet, expense and workflow requests." }, { id: "team-timesheets", title: "Team Timesheets", text: "Review team hours and submission status." }] },
  leave: { title: "Leave", eyebrow: "Workspace", sub: "Manage leave requests, balances and policies.", cards: [{ id: "leave-application", title: "Apply for Leave", text: "Create a new leave request." }, { id: "leave-history", title: "Leave History", text: "Track your submitted requests." }, { id: "leave-calendar", title: "Leave Calendar", text: "See team leave at a glance." }, { id: "leave-admin", title: "Leave Policies", text: "Configure policies and accrual rules.", roles: ["admin"] }] },
  payroll: { title: "Payroll", eyebrow: "Workspace", sub: "Manage salary, payroll runs, payslips, tax and payroll operations.", cards: [{ id: "my-salary", title: "My Salary", text: "View your salary details." }, { id: "my-payslips", title: "My Payslips", text: "Access monthly payslips." }, { id: "my-tax-declaration", title: "Tax", text: "Submit and manage tax declarations." }, { id: "my-benefits", title: "Benefits", text: "Review your benefits." }, { id: "payroll-dashboard", title: "Payroll Dashboard", text: "Monitor payroll status.", roles: ["admin"] }, { id: "payroll-run", title: "Payroll Runs", text: "Calculate and manage payroll runs.", roles: ["admin"] }, { id: "salary-admin", title: "Salary Setup", text: "Manage salary structures.", roles: ["admin"] }, { id: "payroll-benefits-admin", title: "Loans & Advances", text: "Manage employee loans and advances.", roles: ["admin"] }, { id: "payroll-reports", title: "Payroll Reports", text: "Review payroll reports.", roles: ["admin"] }, { id: "payroll-controls", title: "Payroll Controls", text: "Run pre-checks and reconciliation.", roles: ["admin"] }] },
  people: { title: "People", eyebrow: "Workspace", sub: "Teams, organization and employee lifecycle management.", cards: [{ id: "team", title: "My Team", text: "View your team and team activity.", roles: ["manager", "admin"] }, { id: "organization-admin", title: "Organization", text: "Manage positions and reporting lines.", roles: ["admin"] }, { id: "lifecycle-admin", title: "Employee Lifecycle", text: "Manage onboarding and employee changes.", roles: ["admin"] }] },
  talent: { title: "Talent", eyebrow: "Workspace", sub: "Build capability across recruitment, performance and learning.", cards: [{ id: "recruitment", title: "Recruitment", text: "Manage candidates and open roles." }, { id: "performance", title: "Performance & Goals", text: "Track goals and reviews." }, { id: "learning", title: "Learning", text: "Manage learning and certifications." }, { id: "benefits", title: "Benefits", text: "Explore employee benefits." }] },
  services: { title: "Services", eyebrow: "Workspace", sub: "Employee services, documents and support.", cards: [{ id: "expenses", title: "Expenses", text: "Submit and track expense claims." }, { id: "assets", title: "Assets", text: "Track assigned company assets." }, { id: "helpdesk", title: "HR Service Desk", text: "Raise and track HR requests." }, { id: "document-center", title: "Documents", text: "Find your employee documents." }] },
  reports: { title: "Reports & Analytics", eyebrow: "Workspace", sub: "Understand workforce, payroll and business performance.", cards: [{ id: "reports", title: "Reports", text: "Review operational reports.", roles: ["manager", "admin"] }, { id: "payroll-reports", title: "Payroll Reports", text: "Review payroll reports.", roles: ["admin"] }, { id: "enterprise-analytics", title: "Enterprise Analytics", text: "Explore organization analytics.", roles: ["manager", "admin"] }, { id: "saved-reports", title: "Saved Reports", text: "Open saved report views.", roles: ["admin"] }] },
  admin: { title: "Administration", eyebrow: "Workspace", sub: "Configure people, security, workflows, compliance and integrations.", cards: [{ id: "admin", title: "People & Organization", text: "Manage users and system administration.", roles: ["admin"] }, { id: "security-admin", title: "Security & Access", text: "Manage access and security policies.", roles: ["admin"] }, { id: "workflow-admin", title: "Workflows", text: "Configure workflow actions and notifications.", roles: ["admin", "manager"] }, { id: "attendance-admin", title: "Attendance Management", text: "Configure attendance operations.", roles: ["admin"] }, { id: "compliance-rules", title: "Compliance", text: "Manage compliance rules.", roles: ["admin"] }, { id: "integration-hub", title: "Integrations", text: "Connect enterprise systems.", roles: ["admin"] }] },
  ai: { title: "AI", eyebrow: "Workspace", sub: "Intelligent assistance for everyday work and operations.", cards: [{ id: "ai-assistant", title: "AI Assistant", text: "Ask questions and get help with your work." }, { id: "ai-payroll", title: "Payroll Intelligence", text: "Analyze payroll operations.", roles: ["admin"] }, { id: "ai-documents", title: "Document Intelligence", text: "Extract insight from documents.", roles: ["admin"] }] },
};

export function WorkspacePage({ domain, navTo }) {
  const { user } = useAuth();
  const content = WORKSPACE_CONTENT[domain] || WORKSPACE_CONTENT.home;
  const cards = content.cards.filter((card) => !card.roles || card.roles.includes(user.role));
  return <>
    <PageHead eyebrow={content.eyebrow} title={content.title} sub={content.sub} />
    <div className="workspace-quick-actions">
      {cards.slice(0, 3).map((card) => <button key={card.id} className="btn btn-ghost btn-sm" onClick={() => navTo(card.id)}>Open {card.title}</button>)}
    </div>
    <div className="workspace-card-grid">
      {cards.map((card) => <button className="workspace-card" key={card.id} onClick={() => navTo(card.id)}>
        <span className="workspace-card-icon">{NAV_ICONS[card.id] || "◆"}</span><span className="workspace-card-copy"><strong>{card.title}</strong><span>{card.text}</span></span><span className="workspace-card-arrow">→</span>
      </button>)}
    </div>
  </>;
}

// ============================================================
// LOGIN SCREEN
// ============================================================
