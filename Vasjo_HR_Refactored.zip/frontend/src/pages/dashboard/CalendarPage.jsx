import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function CalendarPage() {
  const { user } = useAuth();
  const { showError } = useToast();
  const isManagerish = user.role === "manager" || user.role === "admin";
  const [mode, setMode] = useState("mine");
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [state, setState] = useState(null); // { holidays, leave, timesheets, types }

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const leavePromise = mode === "team" ? api.getTeamLeaveApplications() : api.getMyLeaveApplications();
        const [{ leave }, { holidays }, { timesheets }, types] = await Promise.all([
          leavePromise, api.getHolidays(), api.getMyTimesheetsPaged(1, 100), api.getLeaveTypes(),
        ]);
        if (!cancelled) setState({ leave, holidays, timesheets, types });
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [mode]);

  function prevMonth() { setMonth((m) => { if (m === 0) { setYear((y) => y - 1); return 11; } return m - 1; }); }
  function nextMonth() { setMonth((m) => { if (m === 11) { setYear((y) => y + 1); return 0; } return m + 1; }); }

  const cells = useMemo(() => {
    if (!state) return null;
    const { holidays, leave, timesheets, types } = state;
    const holidayByDate = {};
    holidays.forEach((h) => { holidayByDate[h.holiday_date] = h; });
    const tsByWeekStart = {};
    timesheets.forEach((t) => { tsByWeekStart[t.week_start] = t.status; });
    const relevant = leave.filter((l) => l.status !== "rejected" && l.status !== "cancelled");

    const first = new Date(year, month, 1);
    const startOffset = (first.getDay() + 6) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const out = [];
    for (let i = 0; i < startOffset; i++) out.push({ blank: true, key: `b${i}` });
    for (let day = 1; day <= daysInMonth; day++) {
      const dateObj = new Date(year, month, day);
      const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      const isWeekend = dateObj.getDay() === 0 || dateObj.getDay() === 6;
      const holiday = holidayByDate[dateStr];
      const weekStart = toISODate(mondayOf(dateStr));
      const tsStatus = tsByWeekStart[weekStart];
      const matches = relevant.filter((l) => dateStr >= l.from_date && dateStr <= l.to_date);
      let cls = "cal-cell in-month";
      if (isWeekend) cls += " weekend-cell";
      if (tsStatus) cls += ` ts-${tsStatus}`;
      let marker = null;
      if (holiday) {
        cls += " has-holiday";
        marker = <div className="cal-holiday-tag" title={holiday.name}>🎉</div>;
      } else if (mode === "team" && matches.length) {
        cls += " team-cal-cell";
        marker = (
          <div className="initials-row">
            {matches.slice(0, 4).map((m, i) => (
              <span key={i} className={`init-chip${m.status === "pending" ? " pending" : ""}`} title={`${m.user_name} — ${leaveTypeName(m.leave_type_id, types)}`}>{initials(m.user_name)}</span>
            ))}
          </div>
        );
      } else if (matches.length) {
        cls += matches[0].status === "approved" ? " has-leave" : " has-pending";
      }
      out.push({ key: dateStr, day, cls, title: holiday ? holiday.name : "", marker });
    }
    return out;
  }, [state, month, year, mode]);

  return (
    <>
      <PageHead eyebrow="Time" title="Calendar" sub="Working days, holidays, leave, and your timesheet status at a glance." />
      <Card>
        {isManagerish ? (
          <div className="tabs" style={{ marginBottom: "0.8rem" }}>
            <button className={`tab-btn${mode === "mine" ? " active" : ""}`} onClick={() => setMode("mine")}>My Calendar</button>
            <button className={`tab-btn${mode === "team" ? " active" : ""}`} onClick={() => setMode("team")}>Team Calendar</button>
          </div>
        ) : null}
        <div className="cal-head">
          <button className="icon-btn" onClick={prevMonth}>‹</button>
          <div className="month-label">{MONTH_NAMES[month]} {year}</div>
          <button className="icon-btn" onClick={nextMonth}>›</button>
        </div>
        <div className="cal-grid">
          {WEEKDAYS.map((d) => <div className="cal-dow" key={d}>{d}</div>)}
          {cells ? cells.map((c) => c.blank ? <div className="cal-cell" key={c.key} /> : (
            <div className={c.cls} title={c.title} key={c.key}>{c.day}{c.marker}</div>
          )) : null}
        </div>
        <div className="cal-legend">
          <span><span className="legend-dot holiday" /> Holiday</span>
          <span><span className="legend-dot leave-approved" /> Leave approved</span>
          <span><span className="legend-dot leave-pending" /> Leave pending</span>
          <span><span className="legend-bar approved" /> Timesheet approved</span>
        </div>
      </Card>
    </>
  );
}

// ============================================================
// TIMESHEET ENTRY
// ============================================================
function computeRowHours(inTime, outTime) {
  if (!inTime || !outTime) return 0;
  const [ih, im] = inTime.split(":").map(Number);
  const [oh, om] = outTime.split(":").map(Number);
  const diff = (oh * 60 + om - (ih * 60 + im)) / 60;
  return diff > 0 ? Math.round(diff * 100) / 100 : 0;
}
function rowError(row) {
  if (!row.inTime && !row.outTime && !row.note.trim()) return null;
  if (!row.inTime || !row.outTime) return "Enter both In and Out time";
  if (computeRowHours(row.inTime, row.outTime) <= 0) return "Out time must be after In time";
  return null;
}
function defaultOutTime(inTime, standardHours) {
  const [h, m] = inTime.split(":").map(Number);
  const total = h * 60 + m + standardHours * 60;
  const oh = Math.floor(total / 60) % 24;
  const om = total % 60;
  return `${String(oh).padStart(2, "0")}:${String(om).padStart(2, "0")}`;
}

