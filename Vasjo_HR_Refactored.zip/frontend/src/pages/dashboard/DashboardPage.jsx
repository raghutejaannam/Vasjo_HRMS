import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function DashboardPage({ navTo }) {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const { showError } = useToast();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ timesheets: myTs }, { leave: myLeave }, { balances }, settings, types] = await Promise.all([
          api.getMyTimesheets(), api.getMyLeaveApplications(), api.getLeaveBalances(), api.getSettings(), api.getLeaveTypes(),
        ]);
        let teamPending = null;
        if (user.role === "manager" || user.role === "admin") {
          const [{ timesheets: allPendingTs }, { leave: allPendingLv }] = await Promise.all([
            api.getPendingTimesheets(), api.getPendingLeaveApplications(),
          ]);
          teamPending = { ts: allPendingTs.length, lv: allPendingLv.length };
        }
        let trend = null;
        try { trend = (await api.getMyTrend(8)).trend; } catch (e) { /* skip chart */ }
        let teamSummary = null;
        if (user.role === "manager" || user.role === "admin") {
          try { teamSummary = (await api.getTeamSummary()).summary; } catch (e) { /* skip */ }
        }
        if (!cancelled) setData({ myTs, myLeave, balances, settings, types, teamPending, trend, teamSummary });
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [user.role]);

  if (!data) return <PageLoading />;

  const { myTs, myLeave, balances, settings, types, teamPending, trend, teamSummary } = data;
  const pendingTs = myTs.filter((t) => t.status === "pending").length;
  const pendingLeave = myLeave.filter((l) => l.status === "pending").length;
  const annual = balances.find((b) => b.type_name === "Casual Leave");
  const annualRemaining = annual ? annual.total_days - annual.used_days : "—";

  const currentWeekStart = toISODate(mondayOf(toISODate(new Date())));
  const hasCurrentWeek = myTs.some((t) => t.week_start === currentWeekStart && t.status !== "draft");
  const today = new Date().getDay();
  const showReminder = !hasCurrentWeek && today >= 4 && user.role !== "admin";

  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  return (
    <>
      <div className="dashboard-hero">
        <PageHead eyebrow={`${timeGreeting} · Overview`} title={`Welcome back, ${user.name.split(" ")[0]}`} sub="Here's where things stand this week." />
      </div>

      {showReminder ? (
        <div className="card" style={{ borderColor: "var(--amber)", background: "var(--amber-soft)", marginBottom: "1.1rem" }}>
          <strong>Reminder:</strong> you haven't submitted a timesheet for this week yet.
          <a href="#" style={{ color: "var(--teal)", textDecoration: "underline", marginLeft: "0.4rem" }} onClick={(e) => { e.preventDefault(); navTo("timesheet-entry"); }}>Submit now →</a>
        </div>
      ) : null}

      <div className="stat-grid">
        <StatCard label="Most recent week logged" value={`${myTs.length ? myTs[0].total_hours : 0}h`} foot={`of ${(parseFloat(settings.standard_hours_per_day) || 8) * 5}h expected`} />
        <StatCard label="Timesheets pending" value={pendingTs} foot="awaiting approval" tone="amber" />
        <StatCard label="Leave balance" value={annualRemaining} foot="annual days remaining" />
        <StatCard label="Leave requests pending" value={pendingLeave} foot="in review" tone={pendingLeave ? "amber" : undefined} />
        {teamPending ? (
          <StatCard label="Team approvals waiting" value={teamPending.ts + teamPending.lv} foot={`${teamPending.ts} timesheets · ${teamPending.lv} leave requests`} tone="amber" />
        ) : null}
      </div>

      <div className="two-col">
        <Card title="Recent timesheets">
          <table>
            <thead><tr><th>Week of</th><th>Hours</th><th>Status</th></tr></thead>
            <tbody>
              {myTs.length ? myTs.slice(0, 6).map((t) => (
                <tr key={t.id}>
                  <td className="mono">{fmtDate(t.week_start)}</td>
                  <td className="mono">{t.total_hours}h</td>
                  <td><Stamp status={t.status} /></td>
                </tr>
              )) : <EmptyRow colSpan={3}>No timesheets submitted yet.</EmptyRow>}
            </tbody>
          </table>
        </Card>
        <Card title="Upcoming leave">
          {myLeave.filter((l) => l.status !== "rejected" && l.status !== "cancelled").length === 0 ? (
            <div style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No leave scheduled.</div>
          ) : myLeave.filter((l) => l.status !== "rejected" && l.status !== "cancelled").slice(0, 6).map((l) => (
            <div className="approval-item" key={l.id}>
              <div className="who">
                <div>
                  <div className="name">{leaveTypeName(l.leave_type_id, types)}</div>
                  <div className="meta">{fmtDate(l.from_date)} → {fmtDate(l.to_date)}</div>
                </div>
              </div>
              <Stamp status={l.status} />
            </div>
          ))}
        </Card>
      </div>

      <div className="two-col" style={{ marginTop: "1.1rem" }}>
        {trend ? (
          <Card title="Your hours — last 8 weeks">
            <BarChart rows={trend.map((t) => ({ label: t.week_start.slice(5), total_hours: t.total_hours }))} labelKey="label" valueKey="total_hours" unit="h" />
          </Card>
        ) : null}
        {teamSummary ? (
          <Card title="Team hours — last 8 weeks (approved)">
            <BarChart rows={teamSummary.map((s) => ({ label: s.user_name, total_hours: s.total_hours }))} labelKey="label" valueKey="total_hours" unit="h" />
          </Card>
        ) : null}
      </div>
    </>
  );
}

// ============================================================
// CALENDAR
// ============================================================
