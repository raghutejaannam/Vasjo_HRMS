import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function TimesheetHistoryPage() {
  const { showError } = useToast();
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { timesheets, total } = await api.getMyTimesheetsPaged(1, page * 10);
        if (!cancelled) setData({ timesheets, total });
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [page]);

  return (
    <>
      <PageHead eyebrow="Time" title="Timesheet History" sub="Your past submissions and their approval status."
        actions={<a className="btn btn-ghost btn-sm" href={api.timesheetsCsvUrl()} download>Export CSV</a>} />
      <Card>
        <table>
          <thead><tr><th>ID</th><th>Week of</th><th>Total Hours</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {!data ? <EmptyRow colSpan={5}>Loading…</EmptyRow> : data.timesheets.length === 0 ? (
              <EmptyRow colSpan={5}>No timesheets yet — submit your first one from the Submit Timesheet page.</EmptyRow>
            ) : data.timesheets.map((t) => (
              <tr key={t.id}>
                <td className="mono">{t.id}</td>
                <td className="mono">{fmtDate(t.week_start)}</td>
                <td className="mono">{t.total_hours}h</td>
                <td><Stamp status={t.status} /></td>
                <td><AuditToggle entityType="timesheet" entityId={t.id} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        {data && data.timesheets.length < data.total ? (
          <div className="load-more-row"><button className="btn btn-ghost btn-sm" onClick={() => setPage((p) => p + 1)}>Load more</button></div>
        ) : null}
      </Card>
    </>
  );
}

// ============================================================
// LEAVE APPLICATION
// ============================================================
