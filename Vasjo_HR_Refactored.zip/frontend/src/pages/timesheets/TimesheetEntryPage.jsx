import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function TimesheetEntryPage({ navTo }) {
  const { showToast, showError } = useToast();
  const { openModal, closeModal } = useModal();
  const [weekOffset, setWeekOffset] = useState(0);
  const [loaded, setLoaded] = useState(null); // { existing, dayRows, holidayByDate, standardHours, days }
  const [saving, setSaving] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const monday = useMemo(() => addWeeks(mondayOf(toISODate(new Date())), weekOffset), [weekOffset]);
  const days = useMemo(() => weekDates(monday), [monday]);
  const weekStartStr = toISODate(monday);
  const weekEndStr = toISODate(days[6]);

  useEffect(() => {
    let cancelled = false;
    setLoaded(null);
    (async () => {
      try {
        const settings = await api.getSettings();
        const standardHours = parseFloat(settings.standard_hours_per_day) || 8;
        const [{ timesheet: existing, entries: existingEntries }, { holidays }] = await Promise.all([
          api.getTimesheetByWeek(weekStartStr), api.getHolidays(),
        ]);
        const holidayByDate = {};
        holidays.forEach((h) => { holidayByDate[h.holiday_date] = h; });
        const entriesByDate = {};
        existingEntries.forEach((e) => {
          if (!entriesByDate[e.entry_date]) entriesByDate[e.entry_date] = [];
          entriesByDate[e.entry_date].push({ inTime: e.in_time || "", outTime: e.out_time || "", note: e.note || "" });
        });
        const dayRows = {};
        days.forEach((d) => {
          const dateStr = toISODate(d);
          const holiday = holidayByDate[dateStr];
          if (holiday) { dayRows[dateStr] = []; return; }
          if (entriesByDate[dateStr]) { dayRows[dateStr] = entriesByDate[dateStr].map((r) => ({ ...r })); return; }
          const isWeekend = d.getDay() === 0 || d.getDay() === 6;
          if (isWeekend || existing) {
            dayRows[dateStr] = [];
          } else {
            dayRows[dateStr] = [{ inTime: "09:00", outTime: defaultOutTime("09:00", standardHours), note: "" }];
          }
        });
        if (!cancelled) setLoaded({ existing, holidays, holidayByDate, standardHours, dayRows });
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [weekStartStr, reloadKey]);

  const [rowsVersion, setRowsVersion] = useState(0);
  function mutateRows(fn) {
    setLoaded((prev) => {
      if (!prev) return prev;
      fn(prev.dayRows);
      return { ...prev, dayRows: { ...prev.dayRows } };
    });
    setRowsVersion((v) => v + 1);
  }

  if (!loaded) return <PageLoading />;

  const { existing, holidays, holidayByDate, standardHours, dayRows } = loaded;
  const isApproved = existing && existing.status === "approved";
  const isLocked = isApproved;
  const correctionRequested = existing && existing.correction_status === "requested";

  function dayTotal(dateStr) {
    return (dayRows[dateStr] || []).reduce((s, r) => s + computeRowHours(r.inTime, r.outTime), 0);
  }
  function weekTotal() {
    return Object.keys(dayRows).reduce((s, d) => s + dayTotal(d), 0);
  }
  const holidaysThisWeek = holidays.filter((h) => h.holiday_date >= weekStartStr && h.holiday_date <= weekEndStr);
  const overtime = Object.keys(dayRows).reduce((s, d) => s + Math.max(0, dayTotal(d) - standardHours), 0);

  function addRow(dateStr) {
    mutateRows((rows) => { rows[dateStr] = [...(rows[dateStr] || []), { inTime: "", outTime: "", note: "" }]; });
  }
  function deleteRow(dateStr, idx) {
    mutateRows((rows) => { rows[dateStr] = rows[dateStr].filter((_, i) => i !== idx); });
  }
  function updateField(dateStr, idx, field, value) {
    mutateRows((rows) => { rows[dateStr] = rows[dateStr].map((r, i) => (i === idx ? { ...r, [field]: value } : r)); });
  }

  function collectEntries() {
    const entries = [];
    Object.keys(dayRows).forEach((dateStr) => {
      const rows = dayRows[dateStr];
      if (!rows.length) { entries.push({ date: dateStr, inTime: "", outTime: "", note: "" }); return; }
      rows.forEach((r) => entries.push({ date: dateStr, inTime: r.inTime, outTime: r.outTime, note: r.note.trim() }));
    });
    return entries;
  }
  function hasRowErrors() {
    return Object.keys(dayRows).some((d) => (dayRows[d] || []).some((r) => rowError(r)));
  }

  async function saveDraft() {
    if (hasRowErrors()) { showToast("Fix the highlighted time entries before saving", true); return; }
    setSaving(true);
    try {
      const entries = collectEntries();
      await api.saveTimesheet(weekStartStr, entries, false);
      showToast("Saved as draft");
    } catch (err) { showError(err); } finally { setSaving(false); }
  }

  async function doSubmit() {
    setSaving(true);
    try {
      const entries = collectEntries();
      const { id } = await api.saveTimesheet(weekStartStr, entries, true);
      showToast(`Timesheet ${id} submitted for approval`);
      navTo("timesheet-history");
    } catch (err) { showError(err); setSaving(false); }
  }

  function onSubmitClick() {
    if (hasRowErrors()) { showToast("Fix the highlighted time entries before submitting", true); return; }
    const weekday0h = Object.keys(dayRows).filter((dateStr) => {
      const day = new Date(dateStr + "T00:00:00").getDay();
      if (day === 0 || day === 6) return false;
      return dayTotal(dateStr) === 0;
    });
    if (weekday0h.length) {
      const list = weekday0h.map((d) => fmtDate(d)).join(", ");
      if (!window.confirm(`These weekdays have no time logged: ${list}.\n\nIf they're covered by a holiday or approved leave this is fine — otherwise, submit anyway?`)) return;
    }
    doSubmit();
  }

  function openCorrectionModal() {
    let reason = "";
    let error = "";
    const render = () => (
      <>
        <p className="subtle-note" style={{ marginTop: 0 }}>Explain what needs to change. Your manager will review and, if approved, unlock this timesheet for editing.</p>
        <div className="field">
          <textarea placeholder="e.g. Forgot to log Friday's hours" onChange={(e) => { reason = e.target.value; }} />
        </div>
        {error ? <div className="inline-error">{error}</div> : null}
      </>
    );
    openModal("Request a correction", render(), (
      <>
        <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
        <button className="btn btn-primary" onClick={async () => {
          const r = reason.trim();
          if (!r) { showToast("Please explain what needs to be corrected.", true); return; }
          try {
            await api.requestTimesheetCorrection(existing.id, r);
            closeModal();
            showToast("Correction request sent to your manager");
            setLoaded(null);
            setReloadKey((k) => k + 1);
          } catch (err) { showError(err); }
        }}>Send request</button>
      </>
    ));
  }

  return (
    <>
      <div className="page-head">
        <div>
          <div className="eyebrow">Time</div>
          <h1>Submit Timesheet</h1>
          <div className="week-nav">
            <button onClick={() => setWeekOffset((w) => w - 1)} title="Previous week">‹</button>
            <span className="week-label">Week of {monday.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</span>
            <button onClick={() => weekOffset < 0 && setWeekOffset((w) => w + 1)} disabled={weekOffset >= 0} title="Next week">›</button>
          </div>
        </div>
      </div>

      {existing ? (
        <div className="status-pill-row">
          <Stamp status={existing.status} />
          {existing.last_comment ? <span className="subtle-note" style={{ margin: 0 }}>Manager note: "{existing.last_comment}"</span> : null}
          {correctionRequested ? <span className="subtle-note" style={{ margin: 0, color: "var(--amber)" }}>Correction request pending manager review</span> : null}
        </div>
      ) : null}

      {days.map((d, i) => {
        const dateStr = toISODate(d);
        const isWeekend = i >= 5;
        const holiday = holidayByDate[dateStr];
        const dateLabel = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
        if (holiday) {
          return (
            <div className="day-accordion holiday-day-flat" key={dateStr}>
              <div className="day-accordion-title">
                <span className="dow">{WEEKDAYS[i]}</span>
                <span className="date">{dateLabel}</span>
                <span className="holiday-label">🎉 {holiday.name}</span>
              </div>
              <span className="day-total zero">Holiday</span>
            </div>
          );
        }
        const total = dayTotal(dateStr);
        const rows = dayRows[dateStr] || [];
        const hasContent = rows.length > 0;
        return (
          <details className="day-accordion" open={!isWeekend || hasContent} key={dateStr}>
            <summary>
              <div className={`day-accordion-title${isWeekend ? " weekend" : ""}`}>
                <span className="dow">{WEEKDAYS[i]}</span>
                <span className="date">{dateLabel}</span>
              </div>
              <div className="day-accordion-meta">
                <span className={`day-total${total > 0 ? "" : " zero"}`}>{total > 0 ? total.toFixed(2) + "h" : "0h"}</span>
                <span className="accordion-chevron">▾</span>
              </div>
            </summary>
            <div className="day-accordion-body">
              {rows.length === 0 ? <p className="subtle-note" style={{ margin: "0 0 0.6rem" }}>No time logged yet.</p> : rows.map((row, idx) => {
                const hours = computeRowHours(row.inTime, row.outTime);
                const err = rowError(row);
                return (
                  <div className="time-entry-row" key={idx}>
                    <div className="field-inline">
                      <label>In</label>
                      <input type="time" className={err ? "row-error" : ""} value={row.inTime} disabled={isLocked}
                        onChange={(e) => updateField(dateStr, idx, "inTime", e.target.value)} />
                    </div>
                    <div className="field-inline">
                      <label>Out</label>
                      <input type="time" className={err ? "row-error" : ""} value={row.outTime} disabled={isLocked}
                        onChange={(e) => updateField(dateStr, idx, "outTime", e.target.value)} />
                    </div>
                    <div className="row-note-wrap">
                      <label>Note</label>
                      <input type="text" className="row-note" placeholder="Optional" value={row.note} disabled={isLocked}
                        onChange={(e) => updateField(dateStr, idx, "note", e.target.value)} />
                    </div>
                    <div className="row-hours-wrap"><span className={`row-hours${hours > 0 ? " has-value" : ""}`}>{hours > 0 ? hours.toFixed(2) + "h" : "—"}</span></div>
                    <div className="row-delete-wrap">
                      <button type="button" className="row-delete-btn" title="Remove row" disabled={isLocked} onClick={() => deleteRow(dateStr, idx)}>✕</button>
                    </div>
                    {err ? <div className="row-error-text">{err}</div> : null}
                  </div>
                );
              })}
              {!isLocked ? <button type="button" className="add-row-btn" onClick={() => addRow(dateStr)}>+ Add Row</button> : null}
            </div>
          </details>
        );
      })}

      <div className="card" style={{ marginTop: "1rem" }}>
        <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap", marginBottom: "0.8rem" }}>
          <div><span className="text-dim">Week total:</span> <strong className="mono">{weekTotal().toFixed(2)}h</strong></div>
          <div><span className="text-dim">Overtime:</span> <strong className="mono">{overtime.toFixed(2)}h</strong></div>
          {holidaysThisWeek.length ? <div><span className="text-dim">Holidays this week:</span> {holidaysThisWeek.map((h) => h.name).join(", ")}</div> : null}
        </div>
        <div className="form-actions">
          {isApproved && !correctionRequested ? (
            <button className="btn btn-ghost" onClick={openCorrectionModal}>Request a correction</button>
          ) : null}
          {!isLocked ? (
            <>
              <button className="btn btn-ghost" disabled={saving} onClick={saveDraft}>Save as draft</button>
              <button className="btn btn-primary" disabled={saving} onClick={onSubmitClick}>Submit for approval</button>
            </>
          ) : null}
        </div>
      </div>
    </>
  );
}

// ============================================================
// TIMESHEET HISTORY
// ============================================================
