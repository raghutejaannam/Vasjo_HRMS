import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function TeamTimesheetsPage() {
  const { showError } = useToast();
  const [teamUsers, setTeamUsers] = useState(null);
  const [employeeId, setEmployeeId] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const pageSize = 25;

  useEffect(() => {
    (async () => {
      try { setTeamUsers((await api.getUsersFlat()).users); } catch (err) { showError(err); }
    })();
  }, []);

  const load = useCallback(async (reset) => {
    try {
      const p = reset ? 1 : page;
      const { timesheets, total: t } = await api.getAllTimesheets({ page: p, pageSize, employeeId: employeeId || undefined, status: status || undefined });
      setRows((prev) => (reset ? timesheets : prev.concat(timesheets)));
      setTotal(t);
      if (reset) setPage(1);
    } catch (err) { showError(err); }
  }, [page, employeeId, status]);

  useEffect(() => { load(true); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <PageHead eyebrow="Team" title="Team Timesheets" sub="Submitted and approved hours across your team, including overtime and work mode." />
      <div className="report-controls">
        <Field label="Employee">
          <select value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
            <option value="">All</option>
            {(teamUsers || []).filter((u) => u.role !== "admin").map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </Field>
        <Field label="Status">
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="draft">Draft</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </Field>
        <button className="btn btn-ghost btn-sm" onClick={() => load(true)}>Apply filters</button>
      </div>
      <Card>
        <table>
          <thead><tr><th>Employee</th><th>ID</th><th>Week of</th><th>Hours</th><th>Overtime</th><th>Status</th></tr></thead>
          <tbody>
            {rows.length === 0 ? <EmptyRow colSpan={6}>No timesheets match these filters.</EmptyRow> : rows.map((t) => (
              <tr key={t.id}>
                <td>{t.user_name}</td>
                <td className="mono">{t.id}</td>
                <td className="mono">{fmtDate(t.week_start)}</td>
                <td className="mono">{t.total_hours}h</td>
                <td className={`mono${t.overtime_hours > 0 ? " overtime-value" : ""}`}>{t.overtime_hours > 0 ? t.overtime_hours + "h" : "—"}</td>
                <td><Stamp status={t.status} />{t.escalated ? <span className="escalated-tag"> ⚠ overdue</span> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length < total ? (
          <div className="load-more-row"><button className="btn btn-ghost btn-sm" onClick={() => { setPage((p) => p + 1); load(false); }}>Load more</button></div>
        ) : null}
      </Card>
    </>
  );
}

// ============================================================
// REPORTS
// ============================================================
