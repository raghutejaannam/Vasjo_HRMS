import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function ProfilePage() {
  const { user, setUser } = useAuth();
  const { showToast, showError } = useToast();
  const [departments, setDepartments] = useState([]);
  const [form, setForm] = useState(null);
  const [color, setColor] = useState(user.avatar_color);
  const [pwCurrent, setPwCurrent] = useState("");
  const [pwNew, setPwNew] = useState("");
  const [pwError, setPwError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [{ user: u }, { sensitive }] = await Promise.all([api.me(), api.meSensitive()]);
        setUser(u);
        setColor(u.avatar_color);
        setForm({
          name: u.name || "", email: u.email || "", employeeCode: u.employee_code || "", phone: u.phone || "",
          location: u.location || "", gender: u.gender || "", uan: sensitive.uan || "", pfNumber: sensitive.pf_number || "",
          pan: sensitive.pan || "", bankAccountNo: sensitive.bank_account_no || "", bankName: sensitive.bank_name || "",
          employeeGroup: u.employee_group || "", dept: u.dept || "",
          emergencyContactName: u.emergency_contact_name || "", emergencyContactPhone: u.emergency_contact_phone || "",
        });
        const { departments: d } = await api.getDepartments();
        setDepartments(d);
      } catch (err) { showError(err); }
    })();
  }, []);

  function set(field, value) { setForm((f) => ({ ...f, [field]: value })); }

  async function saveProfile() {
    setSaving(true);
    try {
      if (!form.name.trim() || !form.email.trim()) throw new Error("Name and email are required");
      const payload = { name: form.name.trim(), email: form.email.trim(), employeeCode: form.employeeCode.trim() || null, phone: form.phone.trim() || null, location: form.location.trim() || null, gender: form.gender || null, employeeGroup: form.employeeGroup.trim() || null, dept: form.dept || null, emergencyContactName: form.emergencyContactName.trim() || null, emergencyContactPhone: form.emergencyContactPhone.trim() || null, avatarColor: color };
      const updated = await api.updateMe(payload);
      setUser(updated.user || { ...user, ...payload, avatar_color: color });
      showToast("Profile updated");
    } catch (err) { showError(err); } finally { setSaving(false); }
  }

  async function saveEmergencyContact() {
    try {
      const updated = await api.updateMe({ emergencyContactName: form.emergencyContactName, emergencyContactPhone: form.emergencyContactPhone });
      if (updated.user) setUser(updated.user);
      showToast("Emergency contact saved");
    } catch (err) { showError(err); }
  }

  async function savePassword() {
    setPwError("");
    if (!pwCurrent || !pwNew) { setPwError("Both fields are required."); return; }
    try {
      await api.changePassword(pwCurrent, pwNew);
      showToast("Password updated");
      setPwCurrent(""); setPwNew("");
    } catch (err) { setPwError(err.message); }
  }

  if (!form) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Account" title="My Profile" />
      <Card>
        <div className="profile-head">
          <div className="profile-avatar" style={{ background: color || "#C08A2E" }}>{initials(user.name)}</div>
          <div><h2>{user.name || ""}</h2><span className="role-tag">{user.title || user.role || ""}</span></div>
        </div>
        <Field label="Avatar color">
          <div style={{ display: "flex", gap: ".5rem" }}>
            {AVATAR_COLORS.map((c) => (
              <button key={c} type="button" onClick={() => setColor(c)}
                style={{ width: 28, height: 28, borderRadius: "50%", background: c, border: `2px solid ${c === color ? "var(--ink)" : "transparent"}` }} />
            ))}
          </div>
        </Field>
        <div className="form-grid" style={{ marginTop: "1rem" }}>
          <Field label="Full name"><input type="text" value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
          <Field label="Email"><input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label="Employee ID"><input type="text" placeholder="e.g. VJT-2461" value={form.employeeCode} onChange={(e) => set("employeeCode", e.target.value)} /></Field>
          <Field label="Phone"><input type="text" value={form.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label="Location"><input type="text" placeholder="e.g. Remote / Hyderabad" value={form.location} onChange={(e) => set("location", e.target.value)} /></Field>
          <Field label="Gender">
            <select value={form.gender} onChange={(e) => set("gender", e.target.value)}>
              <option value="">— Select —</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option>
            </select>
          </Field>
          <Field label="UAN"><input type="text" value={form.uan || "—"} disabled /></Field>
          <Field label="PF Number"><input type="text" value={form.pfNumber || "—"} disabled /></Field>
          <Field label="PAN"><input type="text" style={{ textTransform: "uppercase" }} value={form.pan || "—"} disabled /></Field>
          <Field label="Bank A/C No."><input type="text" value={form.bankAccountNo || "—"} disabled /></Field>
          <Field label="Bank Name"><input type="text" value={form.bankName || "—"} disabled /></Field>
          <Field label="Employee Group"><input type="text" placeholder="e.g. IT-WB" value={form.employeeGroup} onChange={(e) => set("employeeGroup", e.target.value)} /></Field>
          <Field label="Department">
            <select value={form.dept} onChange={(e) => set("dept", e.target.value)}>
              {departments.map((d) => <option key={d.id || d.name} value={d.name}>{d.name}</option>)}
            </select>
          </Field>
          <Field label="Designation"><input type="text" value={user.title || ""} disabled /></Field>
          <Field label="Date of Joining"><input type="text" value={fmtDate(user.joined_date)} disabled /></Field>
          <Field label="Reporting Manager"><input type="text" value={user.manager_name || "—"} disabled /></Field>
        </div>
        <div className="form-actions"><button className="btn btn-primary" disabled={saving} onClick={saveProfile}>Save changes</button></div>
        <div className="empty-state" style={{ marginTop: ".75rem" }}>Statutory and banking fields are read-only here. Request changes through the HR change-request workflow.</div>
      </Card>
      <Card title="Emergency contact">
        <div className="form-grid">
          <Field label="Contact name"><input type="text" value={form.emergencyContactName} onChange={(e) => set("emergencyContactName", e.target.value)} /></Field>
          <Field label="Contact phone"><input type="text" value={form.emergencyContactPhone} onChange={(e) => set("emergencyContactPhone", e.target.value)} /></Field>
        </div>
        <div className="form-actions"><button className="btn btn-ghost" onClick={saveEmergencyContact}>Save emergency contact</button></div>
      </Card>
      <Card title="Change password">
        <div className="form-grid">
          <Field label="Current password"><input type="password" value={pwCurrent} onChange={(e) => setPwCurrent(e.target.value)} /></Field>
          <Field label="New password"><input type="password" placeholder="At least 8 characters" value={pwNew} onChange={(e) => setPwNew(e.target.value)} /></Field>
        </div>
        {pwError ? <div className="inline-error">{pwError}</div> : null}
        <div className="form-actions"><button className="btn btn-ghost" onClick={savePassword}>Update password</button></div>
      </Card>
    </>
  );
}

// ============================================================
// MY TEAM (manager-only account management)
// ============================================================
