import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function TeamPage() {
  const { showError } = useToast();
  const [members, setMembers] = useState(null);

  useEffect(() => {
    (async () => { try { setMembers((await api.getTeamMembers()).members); } catch (err) { showError(err); } })();
  }, []);

  return (
    <>
      <PageHead eyebrow="Team" title="My Team" sub="Your direct reports. Reset a password here to issue a temporary one you can share directly." />
      <Card>
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Title</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {!members ? <EmptyRow colSpan={5}>Loading…</EmptyRow> : members.length === 0 ? (
              <EmptyRow colSpan={5}>No one reports to you yet.</EmptyRow>
            ) : members.map((m) => (
              <tr key={m.id}>
                <td>{m.name}</td>
                <td className="mono">{m.email}</td>
                <td>{m.title || "—"}</td>
                <td>{m.active === "active" || m.active === 1 || m.active === true ? <span className="stamp approved">active</span> : <span className="stamp rejected">inactive</span>}{m.must_reset_password ? <span className="stamp pending"> pending reset</span> : null}</td>
                <td><ResetPasswordButton userId={m.id} userName={m.name} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// ADMIN — User & System Admin
// ============================================================
function EmployeeRow({ u, onOpenDetails, onViewComp, onGiveHike }) {
  const annualCtc = u.annual_ctc ? `₹${Number(u.annual_ctc).toLocaleString("en-IN")}` : <span style={{ color: "var(--text-dim)" }}>—</span>;
  const monthlyCtc = u.monthly_ctc ? `₹${Number(u.monthly_ctc).toLocaleString("en-IN")}` : <span style={{ color: "var(--text-dim)" }}>—</span>;
  const salaryBadge = u.salary_status === "active" ? <span className="stamp approved">active</span>
    : u.salary_status === "draft" ? <span className="stamp warning">draft</span>
    : <span style={{ color: "var(--text-dim)", fontSize: "0.8rem" }}>No salary</span>;
  return (
    <tr>
      <td><a href="#" style={{ fontWeight: 600, color: "var(--teal)", textDecoration: "underline", textUnderlineOffset: "3px" }} onClick={(e) => { e.preventDefault(); onOpenDetails(u.id); }}>{u.name}</a></td>
      <td className="mono" style={{ fontSize: "0.82rem" }}>{u.email}</td>
      <td>{u.dept || "—"}</td>
      <td style={{ fontSize: "0.85rem" }}>{u.title || "—"}</td>
      <td style={{ fontSize: "0.85rem" }}>{u.manager_name || "—"}</td>
      <td style={{ fontSize: "0.85rem" }}>{u.joined_date || "—"}</td>
      <td style={{ fontWeight: 600, whiteSpace: "nowrap" }}>{annualCtc}</td>
      <td style={{ whiteSpace: "nowrap" }}>{monthlyCtc}</td>
      <td>{salaryBadge}</td>
      <td>{u.active === "active" || u.active === 1 || u.active === true ? <span className="stamp approved">active</span> : <span className="stamp rejected">inactive</span>}</td>
      <td><button className="btn btn-ghost btn-sm" title="View Compensation" onClick={() => onViewComp(u.id)}>Comp</button></td>
      <td><button className="btn btn-ghost btn-sm" title="Give Salary Hike" onClick={() => onGiveHike(u.id, u.name)}>Hike</button></td>
      <td><ResetPasswordButton userId={u.id} userName={u.name} /></td>
    </tr>
  );
}

function EmployeeDetailsModalBody({ userId, onSaved }) {
  const { showError } = useToast();
  const { closeModal } = useModal();
  const [u, setU] = useState(null);
  const [managers, setManagers] = useState([]);
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const emp = await api.getUser(userId);
        const { users: mgrs } = await api.getUsersFlat();
        setU(emp);
        setManagers(mgrs);
        setForm({
          name: emp.name || "", email: emp.email || "", employeeCode: emp.employee_code || "", location: emp.location || "",
          gender: emp.gender || "", uan: emp.uan || "", pfNumber: emp.pf_number || "", pan: emp.pan || "",
          bankAccountNo: emp.bank_account_no || "", bankName: emp.bank_name || "", employeeGroup: emp.employee_group || "",
          phone: emp.phone || "", title: emp.title || "", dept: emp.dept || "", joinedDate: emp.joined_date || "",
          role: emp.role, active: emp.active === "active" || emp.active === 1 || emp.active === true ? "active" : "inactive", managerId: emp.manager_id || "", delegateId: emp.delegate_id || "",
          emergencyContactName: emp.emergency_contact_name || "", emergencyContactPhone: emp.emergency_contact_phone || "",
        });
      } catch (err) { showError(err); }
    })();
  }, [userId]);

  function set(field, value) { setForm((f) => ({ ...f, [field]: value })); }

  async function update() {
    setSaving(true);
    try {
      const name = form.name.trim(), email = form.email.trim();
      if (!name || !email) throw new Error("Name and email are required");
      await api.updateUser(userId, {
        name, email,
        employeeCode: form.employeeCode.trim() || null, location: form.location.trim() || null, gender: form.gender || null,
        uan: form.uan.trim() || null, pfNumber: form.pfNumber.trim() || null, pan: form.pan.trim().toUpperCase() || null,
        bankAccountNo: form.bankAccountNo.trim() || null, bankName: form.bankName.trim() || null, employeeGroup: form.employeeGroup.trim() || null,
        phone: form.phone.trim() || null, title: form.title.trim() || null, dept: form.dept.trim() || null, joinedDate: form.joinedDate || null,
        role: form.role, active: form.active, managerId: form.managerId || null, delegateId: form.delegateId || null,
        emergencyContactName: form.emergencyContactName.trim() || null, emergencyContactPhone: form.emergencyContactPhone.trim() || null,
      });
      closeModal();
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  }

  if (!u || !form) return <div style={{ padding: "1rem 0", color: "var(--text-dim)" }}>Loading…</div>;

  return (
    <>
      <div className="form-grid">
        <Field label="Full name"><input type="text" value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
        <Field label="Email"><input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} /></Field>
        <Field label="Employee ID"><input type="text" value={form.employeeCode} onChange={(e) => set("employeeCode", e.target.value)} /></Field>
        <Field label="Location"><input type="text" value={form.location} onChange={(e) => set("location", e.target.value)} /></Field>
        <Field label="Gender">
          <select value={form.gender} onChange={(e) => set("gender", e.target.value)}>
            <option value="">— Select —</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option>
          </select>
        </Field>
        <Field label="UAN"><input type="text" value={form.uan} onChange={(e) => set("uan", e.target.value)} /></Field>
        <Field label="PF Number"><input type="text" value={form.pfNumber} onChange={(e) => set("pfNumber", e.target.value)} /></Field>
        <Field label="PAN"><input type="text" value={form.pan} onChange={(e) => set("pan", e.target.value)} /></Field>
        <Field label="Bank A/C No."><input type="text" value={form.bankAccountNo} onChange={(e) => set("bankAccountNo", e.target.value)} /></Field>
        <Field label="Bank Name"><input type="text" value={form.bankName} onChange={(e) => set("bankName", e.target.value)} /></Field>
        <Field label="Employee Group"><input type="text" value={form.employeeGroup} onChange={(e) => set("employeeGroup", e.target.value)} /></Field>
        <Field label="Phone"><input type="tel" value={form.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
        <Field label="Designation / Title"><input type="text" value={form.title} onChange={(e) => set("title", e.target.value)} /></Field>
        <Field label="Department"><input type="text" value={form.dept} onChange={(e) => set("dept", e.target.value)} /></Field>
        <Field label="Date of Joining"><input type="date" value={form.joinedDate} onChange={(e) => set("joinedDate", e.target.value)} /></Field>
        <Field label="Role">
          <select value={form.role} onChange={(e) => set("role", e.target.value)}>
            <option value="employee">Employee</option><option value="manager">Manager</option><option value="admin">Admin</option>
          </select>
        </Field>
        <Field label="Status">
          <select value={form.active} onChange={(e) => set("active", e.target.value)}>
            <option value="active">Active</option><option value="inactive">Inactive</option>
          </select>
        </Field>
        <Field label="Reporting Manager">
          <select value={form.managerId} onChange={(e) => set("managerId", e.target.value)}>
            <option value="">— None —</option>
            {managers.filter((m) => Number(m.id) !== Number(u.id)).map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
        </Field>
        <Field label="Approval Delegate">
          <select value={form.delegateId} onChange={(e) => set("delegateId", e.target.value)}>
            <option value="">— None —</option>
            {managers.filter((m) => Number(m.id) !== Number(u.id) && m.role !== "employee").map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
        </Field>
        <Field label="Emergency Contact Name"><input type="text" value={form.emergencyContactName} onChange={(e) => set("emergencyContactName", e.target.value)} /></Field>
        <Field label="Emergency Contact Phone"><input type="tel" value={form.emergencyContactPhone} onChange={(e) => set("emergencyContactPhone", e.target.value)} /></Field>
      </div>
      <div style={{ marginTop: "1rem", padding: "0.8rem", border: "1px solid var(--border)", borderRadius: 8, background: "var(--paper-dim)" }}>
        <strong>Payroll</strong><br />
        Annual CTC: {u.annual_ctc ? `₹${Number(u.annual_ctc).toLocaleString("en-IN")}` : "—"} &nbsp;|&nbsp;
        Monthly CTC: {u.monthly_ctc ? `₹${Number(u.monthly_ctc).toLocaleString("en-IN")}` : "—"} &nbsp;|&nbsp;
        Salary status: {u.salary_status || "—"}
      </div>
      <p className="subtle-note" style={{ marginBottom: 0 }}>Review the information. If nothing needs changing, click Close. Click Update to save changes.</p>
      <div className="form-actions">
        <button className="btn btn-ghost" onClick={closeModal}>Close</button>
        <button className="btn btn-primary" disabled={saving} onClick={update}>Update</button>
      </div>
    </>
  );
}

function HikeModalBody({ userId, empName, currentCtc, onApplied }) {
  const { showToast, showError } = useToast();
  const [pct, setPct] = useState("");
  const [amt, setAmt] = useState("");
  const [newCtc, setNewCtc] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [reason, setReason] = useState("");

  const preview = useMemo(() => {
    const p = parseFloat(pct) || 0, a = parseFloat(amt) || 0, nc = parseFloat(newCtc) || 0;
    if (nc > 0) return { newCtc: nc, hikeAmt: nc - currentCtc, hikePct: currentCtc ? ((nc - currentCtc) / currentCtc * 100).toFixed(1) : 0 };
    if (p > 0) return { newCtc: Math.round(currentCtc * (1 + p / 100)), hikeAmt: Math.round(currentCtc * p / 100), hikePct: p };
    if (a > 0) return { newCtc: currentCtc + a, hikeAmt: a, hikePct: currentCtc ? (a / currentCtc * 100).toFixed(1) : 0 };
    return null;
  }, [pct, amt, newCtc, currentCtc]);

  async function confirmHike() {
    const p = parseFloat(pct) || undefined, a = parseFloat(amt) || undefined, nc = parseFloat(newCtc) || undefined;
    if (!p && !a && !nc) { showToast("Enter a hike percentage, amount, or new CTC", true); return; }
    if (!date) { showToast("Effective date is required", true); return; }
    try {
      const result = await api.giveEmployeeHike(userId, { hikePercentage: p, hikeAmount: a, newAnnualCtc: nc, effectiveDate: date, reason: reason.trim() });
      showToast(`Hike applied: New CTC ₹${Number(result.newCtc).toLocaleString("en-IN")} (${result.hikePercentage}% hike)`);
      onApplied();
    } catch (err) { showError(err); }
  }

  return (
    <>
      <div style={{ marginBottom: "1rem" }}>
        <div className="subtle-note">Employee: <strong>{empName}</strong></div>
        <div className="subtle-note">Current Annual CTC: <strong>₹{Number(currentCtc).toLocaleString("en-IN")}</strong></div>
      </div>
      <div className="form-grid">
        <Field label="Hike Percentage (%)"><input type="number" step="0.1" min="0" placeholder="e.g. 10" value={pct} onChange={(e) => { setPct(e.target.value); setAmt(""); setNewCtc(""); }} /></Field>
        <Field label="OR Fixed Amount (₹)"><input type="number" step="1" min="0" placeholder="e.g. 50000" value={amt} onChange={(e) => { setAmt(e.target.value); setPct(""); setNewCtc(""); }} /></Field>
        <Field label="OR New Annual CTC (₹)"><input type="number" step="1" min="0" placeholder="e.g. 1200000" value={newCtc} onChange={(e) => { setNewCtc(e.target.value); setPct(""); setAmt(""); }} /></Field>
        <Field label="Effective Date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
        <div className="field full"><label>Reason</label><textarea rows={2} placeholder="e.g. Annual appraisal, promotion..." value={reason} onChange={(e) => setReason(e.target.value)} /></div>
      </div>
      {preview ? (
        <div style={{ background: "var(--bg-dim)", padding: "0.8rem", borderRadius: 8, margin: "0.8rem 0" }}>
          <strong>Preview:</strong> New CTC: ₹{Number(preview.newCtc).toLocaleString("en-IN")} (Hike: {preview.hikePct}% / ₹{Number(preview.hikeAmt).toLocaleString("en-IN")})
        </div>
      ) : null}
      <div className="form-actions"><button className="btn btn-primary" onClick={confirmHike}>Confirm &amp; Apply</button></div>
    </>
  );
}

function CompensationDetail({ userId, onGiveHike }) {
  const { showError } = useToast();
  const [comp, setComp] = useState(null);
  const [revisions, setRevisions] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [c, r] = await Promise.all([api.getEmployeeCompensation(userId), api.getEmployeeSalaryRevisions(userId)]);
        if (!cancelled) { setComp(c); setRevisions(r.revisions); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [userId]);

  if (!comp) return <div style={{ color: "var(--text-dim)" }}>Loading…</div>;
  const s = comp.activeStructure || {};
  const annual = s.annual_ctc || 0, monthly = s.monthly_ctc || 0, basic = s.basic_salary || 0;

  return (
    <>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <div>
          <div className="subtle-note">Employee</div>
          <div style={{ fontWeight: 600 }}>{comp.user.name}</div>
          <div style={{ fontSize: "0.85rem", color: "var(--text-dim)" }}>{comp.user.email}</div>
          <div style={{ fontSize: "0.85rem", color: "var(--text-dim)" }}>{comp.user.dept || "No department"} · {comp.user.title || "No title"}</div>
          <div style={{ fontSize: "0.85rem", color: "var(--text-dim)" }}>Joined: {comp.user.joined_date || "Not set"}</div>
        </div>
        <div>
          <div className="subtle-note">Current CTC</div>
          {annual ? (
            <>
              <div style={{ fontSize: "1.3rem", fontWeight: 700, color: "var(--accent)" }}>₹{Number(annual).toLocaleString("en-IN")}/year</div>
              <div style={{ fontSize: "0.9rem" }}>₹{Number(monthly).toLocaleString("en-IN")}/month</div>
              <div style={{ fontSize: "0.85rem", color: "var(--text-dim)" }}>Basic: ₹{Number(basic).toLocaleString("en-IN")} · Effective: {s.effective_from || "—"}</div>
            </>
          ) : <div style={{ color: "var(--text-dim)" }}>No salary structure assigned</div>}
        </div>
      </div>
      {comp.components.length ? (
        <div style={{ marginBottom: "1rem" }}>
          <div className="subtle-note" style={{ marginBottom: "0.4rem" }}>Salary Components</div>
          <table>
            <thead><tr><th>Component</th><th>Type</th><th>Category</th><th>Annual</th><th>Monthly</th><th>Taxable</th></tr></thead>
            <tbody>{comp.components.map((cp, i) => (
              <tr key={i}><td>{cp.component_name}</td><td><span className="badge-role">{cp.type}</span></td><td>{cp.category || "—"}</td>
                <td>₹{Number(cp.amount).toLocaleString("en-IN")}</td><td>₹{Math.round(cp.amount / 12).toLocaleString("en-IN")}</td><td>{cp.is_taxable ? "Yes" : "No"}</td></tr>
            ))}</tbody>
          </table>
        </div>
      ) : null}
      {revisions && revisions.length ? (
        <div style={{ marginBottom: "1rem" }}>
          <div className="subtle-note" style={{ marginBottom: "0.4rem" }}>Salary Revision History</div>
          <table>
            <thead><tr><th>Date</th><th>Type</th><th>Previous CTC</th><th>New CTC</th><th>Hike</th><th>Approved By</th></tr></thead>
            <tbody>{revisions.map((r, i) => (
              <tr key={i}><td>{r.effective_date}</td><td><span className="badge-role">{r.revision_type}</span></td>
                <td>{r.previous_annual_ctc ? "₹" + Number(r.previous_annual_ctc).toLocaleString("en-IN") : "—"}</td>
                <td style={{ fontWeight: 600 }}>₹{Number(r.new_annual_ctc).toLocaleString("en-IN")}</td>
                <td>{r.hike_percentage ? r.hike_percentage + "%" : r.hike_amount ? "₹" + Number(r.hike_amount).toLocaleString("en-IN") : "—"}</td>
                <td>{r.actor_name || "—"}</td></tr>
            ))}</tbody>
          </table>
        </div>
      ) : null}
      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
        <button className="btn btn-primary btn-sm" onClick={() => onGiveHike(comp.user.id, comp.user.name, annual)}>Give Hike</button>
      </div>
    </>
  );
}

