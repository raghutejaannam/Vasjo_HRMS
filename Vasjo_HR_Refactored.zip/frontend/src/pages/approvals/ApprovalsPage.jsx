import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function ApprovalsPage() {
  const { showToast, showError } = useToast();
  const { promptComment } = useModal();
  const [tab, setTab] = useState("all");
  const [data, setData] = useState(null);
  const [types, setTypes] = useState(null);
  const [selectedTs, setSelectedTs] = useState({});
  const [selectedLv, setSelectedLv] = useState({});
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // allSettled: one failing source (e.g. no permission for HR requests)
        // must not blank the whole Approval Center.
        const names = ["Timesheets", "Leave", "Corrections", "Leave types", "Expenses", "HR requests"];
        const results = await Promise.allSettled([
          api.getPendingTimesheets(), api.getPendingLeaveApplications(), api.getCorrectionRequests(), api.getLeaveTypes(),
          api.getExpenseApprovals(), api.getHrRequestApprovals(),
        ]);
        const val = (i, dflt) => (results[i].status === "fulfilled" ? results[i].value : dflt);
        const failures = results.map((r, i) => (r.status === "rejected" ? `${names[i]}: ${r.reason?.message || "failed"}` : null)).filter(Boolean);
        const ts = val(0, {}), lv = val(1, {}), cr = val(2, {}), t = val(3, null), ex = val(4, {}), hr = val(5, {});
        if (!cancelled) {
          setData({ pendingTs: ts.timesheets || [], pendingLv: lv.leave || [], corrections: cr.requests || [], expenses: ex.claims || [], hrRequests: hr.requests || [], failures });
          setTypes(t); setSelectedTs({}); setSelectedLv({});
        }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  function reload() { setReloadKey((k) => k + 1); }
  async function decideOne(kind, id, action) {
    const comment = await promptComment(`${action === "approve" ? "Approve" : "Reject"} ${id}`, action === "reject");
    if (comment === null) return;
    try {
      if (kind === "ts") await api.decideTimesheet(id, action, comment);
      else if (kind === "lv") await api.decideLeaveApplication(id, action, comment);
      else if (kind === "ex") await api.decideExpenseApproval(id, action, comment);
      else await api.decideHrRequestApproval(id, action, comment);
      showToast(`${id} ${action}d`); reload();
    } catch (err) { showError(err); }
  }
  async function decideCorrection(id, action) {
    const comment = await promptComment(action === "approve" ? `Approve correction on ${id} — this unlocks it for editing` : `Decline correction request on ${id}`, action === "reject");
    if (comment === null) return;
    try { await api.decideTimesheetCorrection(id, action, comment); showToast(action === "approve" ? `Correction approved — ${id} is now editable` : "Correction request declined"); reload(); } catch (err) { showError(err); }
  }
  async function bulkDecide(kind, action) {
    const selected = kind === "ts" ? selectedTs : selectedLv; const ids = Object.keys(selected).filter((k) => selected[k]);
    if (!ids.length) return;
    const comment = await promptComment(`${action === "approve" ? "Approve" : "Reject"} ${ids.length} item(s)`, action === "reject"); if (comment === null) return;
    try { if (kind === "ts") await api.bulkDecideTimesheets(ids, action, comment); else await api.bulkDecideLeaveApplications(ids, action, comment); showToast(`${ids.length} item(s) ${action}d`); reload(); } catch (err) { showError(err); }
  }
  if (!data) return <PageLoading />;
  const { pendingTs, pendingLv, corrections, expenses, hrRequests } = data;
  const tsCount = Object.values(selectedTs).filter(Boolean).length, lvCount = Object.values(selectedLv).filter(Boolean).length;
  const approvalItems = [
    ...pendingTs.map((item) => ({ id: item.id, employee: item.user_name, type: "Timesheet", submitted: item.week_start, status: item.status, kind: "ts", record: item })),
    ...pendingLv.map((item) => ({ id: item.id, employee: item.user_name, type: "Leave", submitted: item.from_date, status: item.status, kind: "lv", record: item })),
    ...corrections.map((item) => ({ id: item.id, employee: item.user_name, type: "Timesheet", submitted: item.week_start, status: "pending", kind: "cr", record: item })),
    ...expenses.map((item) => ({ id: item.id, employee: item.employee_name, type: "Expense", submitted: item.claim_date, status: item.status, kind: "ex", record: item })),
    ...hrRequests.map((item) => ({ id: item.id, employee: item.requester_name, type: "HR Request", submitted: item.created_at, status: item.status, kind: "hr", record: item })),
  ];
  const tabCounts = {
    all: approvalItems.length,
    leave: pendingLv.length,
    timesheet: pendingTs.length + corrections.length,
    loan: 0,
    advance: 0,
    compoff: 0,
    expense: expenses.length,
    encashment: 0,
    other: hrRequests.length,
  };
  const visibleItems = approvalItems.filter((item) => {
    if (tab === "all") return true;
    if (tab === "timesheet") return item.type === "Timesheet";
    if (tab === "other") return item.type === "HR Request";
    return item.type.toLowerCase() === tab;
  });
  const filters = [
    ["all", "All"], ["leave", "Leave"], ["timesheet", "Timesheet"], ["loan", "Loan"],
    ["advance", "Advance"], ["compoff", "Comp-Off"], ["expense", "Expense"], ["encashment", "Encashment"],
  ];
  const decideItem = (item, action) => {
    if (item.kind === "cr") return decideCorrection(item.id, action);
    return decideOne(item.kind, item.id, action);
  };
  return <>
    <PageHead eyebrow="Team workflow" title="Approval Center" sub="Review every request that needs your decision from one queue." />
      {data?.failures?.length ? <div className="inline-error" style={{ marginBottom: "0.8rem" }}>Some queues could not be loaded — {data.failures.join(" · ")}</div> : null}
    <div className="approval-center-summary">
      <div><span className="approval-center-kicker">Awaiting your review</span><strong>{approvalItems.length}</strong><span className="text-dim">requests across all workflows</span></div>
      <span className="approval-center-icon">✓</span>
    </div>
    <div className="tabs approval-filters" role="tablist" aria-label="Approval types">
      {filters.map(([key, label]) => <button key={key} role="tab" aria-selected={tab === key} className={`tab-btn${tab === key ? " active" : ""}`} onClick={() => setTab(key)}>{label}<span className="tab-count">{tabCounts[key]}</span></button>)}
    </div>
    <Card title={tab === "all" ? "All pending approvals" : `${filters.find(([key]) => key === tab)?.[1] || "Approval"} requests`}>
      <div className="approval-table-wrap">
        <table className="approval-center-table">
          <thead><tr><th>Employee</th><th>Type</th><th>Submitted</th><th>Status</th><th aria-label="Actions" /></tr></thead>
          <tbody>{visibleItems.length ? visibleItems.map((item) => <tr key={`${item.kind}-${item.id}`}>
            <td><div className="approval-employee"><span className="approval-avatar">{initials(item.employee)}</span><span>{item.employee}</span></div></td>
            <td><span className="approval-type">{item.type}</span></td>
            <td className="mono">{fmtDate(item.submitted)}</td>
            <td><Stamp status={item.status} /></td>
            <td className="approval-row-actions"><button className="btn btn-primary btn-sm" onClick={() => decideItem(item, "approve")}>Approve</button><button className="btn btn-ghost btn-sm" onClick={() => decideItem(item, "reject")}>Reject</button></td>
          </tr>) : <EmptyRow colSpan={5}>No {tab === "all" ? "pending" : filters.find(([key]) => key === tab)?.[1].toLowerCase()} approvals right now.</EmptyRow>}</tbody>
        </table>
      </div>
    </Card>
    {(tab === "all" || tab === "timesheet" || tab === "leave") && (tsCount || lvCount) ? <div className="approval-bulk-actions"><span>{tsCount + lvCount} selected</span><button className="btn btn-primary btn-sm" onClick={() => { if (tsCount) bulkDecide("ts", "approve"); if (lvCount) bulkDecide("lv", "approve"); }}>Approve selected</button></div> : null}
  </>;
}
