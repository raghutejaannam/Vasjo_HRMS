import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function MyCompOffPage() {
  const { user } = useAuth();
  const { showToast, showError } = useToast();
  const [compOffs, setCompOffs] = useState(null);
  const [form, setForm] = useState({ workedDate: "", earnedDays: "1", reason: "" });
  const [redeemDate, setRedeemDate] = useState({});
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try { const c = await api.getMyCompOffs(); if (!cancelled) setCompOffs(c); }
      catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function submitRequest(e) {
    e.preventDefault();
    try {
      await api.requestCompOff({ workedDate: form.workedDate, earnedDays: Number(form.earnedDays), reason: form.reason });
      showToast("Comp-off request submitted");
      setForm({ workedDate: "", earnedDays: "1", reason: "" });
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not submit request", true); }
  }

  async function redeem(id) {
    const date = redeemDate[id];
    if (!date) { showToast("Pick a date to redeem against", true); return; }
    try { await api.redeemCompOff(id, date); showToast("Comp-off redeemed as leave"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not redeem comp-off", true); }
  }

  if (!compOffs) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Leave" title="My Comp-Off" sub="Request compensatory time off for working a holiday or weekend, then redeem it as leave." />
      <Card title="Request Comp-Off">
        <form onSubmit={submitRequest} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end" }}>
          <Field label="Date Worked"><input type="date" className="input-sm" value={form.workedDate} onChange={(e) => setForm({ ...form, workedDate: e.target.value })} required /></Field>
          <Field label="Days Earned">
            <select className="input-sm" value={form.earnedDays} onChange={(e) => setForm({ ...form, earnedDays: e.target.value })}>
              <option value="1">1 (full day)</option><option value="0.5">0.5 (half day)</option>
            </select>
          </Field>
          <Field label="Reason"><input className="input-sm" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <button className="btn btn-primary btn-sm" type="submit">Submit</button>
        </form>
      </Card>
      <Card style={{ marginTop: "1rem" }} title="My Comp-Off Credits">
        <table>
          <thead><tr><th>Worked Date</th><th>Days</th><th>Status</th><th>Expires</th><th></th></tr></thead>
          <tbody>
            {compOffs.length === 0 ? <EmptyRow colSpan={5}>No comp-off requests yet.</EmptyRow> : compOffs.map((c) => (
              <tr key={c.id}>
                <td>{fmtDate(c.worked_date)}</td><td className="mono">{c.earned_days}</td><td><Stamp status={c.status} /></td>
                <td>{c.expires_on ? fmtDate(c.expires_on) : "—"}</td>
                <td>
                  {c.status === "approved" ? (
                    <div style={{ display: "flex", gap: "0.3rem" }}>
                      <input type="date" className="input-sm" value={redeemDate[c.id] || ""} onChange={(e) => setRedeemDate({ ...redeemDate, [c.id]: e.target.value })} />
                      <button className="btn btn-ghost btn-sm" onClick={() => redeem(c.id)}>Redeem</button>
                    </div>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// TEAM LEAVE CALENDAR
// ============================================================
export function TeamLeaveCalendarPage() {
  const { user } = useAuth();
  const teamCapable = isApprover(user);
  const [scope, setScope] = useState(teamCapable ? "team" : "mine");
  const [status, setStatus] = useState("default");
  const [nameFilter, setNameFilter] = useState("");
  const [cursor, setCursor] = useState(() => { const d = new Date(); return { year: d.getFullYear(), month: d.getMonth() + 1 }; });
  const [entries, setEntries] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError(null);
    (async () => {
      try {
        const mm = String(cursor.month).padStart(2, "0");
        const from = `${cursor.year}-${mm}-01`;
        const to = `${cursor.year}-${mm}-${String(new Date(cursor.year, cursor.month, 0).getDate()).padStart(2, "0")}`;
        const data = await api.getLeaveCalendar(from, to, scope, { status: status === "default" ? "" : status });
        if (!cancelled) setEntries(Array.isArray(data) ? data : []);
      } catch (err) { if (!cancelled) { setError(err); setEntries([]); } }
      finally { if (!cancelled) setLoading(false); }
    })();
    return () => { cancelled = true; };
  }, [cursor.year, cursor.month, scope, status, reloadKey]);

  function shiftMonth(delta) {
    setCursor((c) => { let month = c.month + delta, year = c.year; if (month < 1) { month = 12; year--; } if (month > 12) { month = 1; year++; } return { year, month }; });
  }
  const shown = (entries || []).filter((e) => !nameFilter || (e.user_name || "").toLowerCase().includes(nameFilter.toLowerCase()));

  return (
    <>
      <PageHead eyebrow="Leave" title="Leave Calendar" sub="Who's on leave this month." />
      <Card title={`${MONTH_NAMES[cursor.month - 1]} ${cursor.year}`} right={
        <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap" }}>
          {teamCapable ? (
            <select className="input-sm" value={scope} onChange={(e) => setScope(e.target.value)} aria-label="Scope">
              <option value="mine">Just Me</option><option value="team">{can(user, "admin.configure") ? "Everyone" : "My Team"}</option>
            </select>
          ) : null}
          <select className="input-sm" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="default">Approved + pending</option><option value="approved">Approved</option><option value="pending">Pending</option><option value="rejected">Rejected</option><option value="all">All</option>
          </select>
          {scope === "team" ? <input className="input-sm" placeholder="Filter employee" value={nameFilter} onChange={(e) => setNameFilter(e.target.value)} /> : null}
          <button className="btn btn-ghost btn-sm" onClick={() => shiftMonth(-1)}>← Prev</button>
          <button className="btn btn-ghost btn-sm" onClick={() => setCursor(() => { const d = new Date(); return { year: d.getFullYear(), month: d.getMonth() + 1 }; })}>Today</button>
          <button className="btn btn-ghost btn-sm" onClick={() => shiftMonth(1)}>Next →</button>
        </div>
      }>
        {error ? (
          <div className="inline-error" style={{ marginBottom: "0.8rem" }}>
            Couldn't load the calendar: {error.message} <button className="btn btn-ghost btn-sm" onClick={() => setReloadKey((k) => k + 1)}>Retry</button>
          </div>
        ) : null}
        {entries === null || (loading && entries.length === 0 && !error) ? <PageLoading /> : (
          <table>
            <thead><tr><th>Employee</th><th>Leave Type</th><th>From</th><th>To</th><th>Days</th><th>Status</th></tr></thead>
            <tbody>
              {shown.length === 0 ? <EmptyRow colSpan={6}>{error ? "—" : "No leave scheduled this month."}</EmptyRow> : shown.map((e) => (
                <tr key={e.id}>
                  <td>{e.user_name}</td><td>{e.leave_type_name}</td><td>{fmtDate(e.from_date)}</td><td>{fmtDate(e.to_date)}</td>
                  <td className="mono">{e.days}</td><td><Stamp status={e.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </>
  );
}

// ============================================================
// LEAVE ADMIN (Block 3 — policies, comp-off approvals, accrual/carry-forward)
// ============================================================
export function LeaveAdminPage() {
  const { showToast, showError } = useToast();
  const [tab, setTab] = useState("policies");
  const [leaveTypes, setLeaveTypes] = useState(null);
  const [selectedType, setSelectedType] = useState("");
  const [policies, setPolicies] = useState(null);
  const [compOffs, setCompOffs] = useState(null);
  const [policyForm, setPolicyForm] = useState({ departmentName: "", userId: "", annualDays: "12", accrualMethod: "annual", monthlyAccrualDays: "1", carryForwardEnabled: false, maxCarryForwardDays: "5", carryForwardExpiryMonths: "3", minServiceDaysBeforeEligible: "0", allowNegativeBalance: false, maxNegativeDays: "0", isSandwichLeave: false, unit: "day" });
  const [accrualForm, setAccrualForm] = useState(() => { const d = new Date(); return { year: String(d.getFullYear()), month: String(d.getMonth() + 1) }; });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const lt = await api.getLeaveTypes();
        setLeaveTypes(lt.leaveTypes || lt || []);
        const co = await api.getAllCompOffs();
        setCompOffs(co);
      } catch (err) { showError(err); }
    })();
  }, [reloadKey]);

  useEffect(() => {
    if (!selectedType) { setPolicies(null); return; }
    (async () => {
      try { setPolicies(await api.getLeavePolicies(selectedType)); }
      catch (err) { showError(err); }
    })();
  }, [selectedType, reloadKey]);

  async function createPolicy(e) {
    e.preventDefault();
    try {
      await api.createLeavePolicy({
        leaveTypeId: Number(selectedType), departmentName: policyForm.departmentName || undefined, userId: policyForm.userId ? Number(policyForm.userId) : undefined,
        annualDays: Number(policyForm.annualDays), accrualMethod: policyForm.accrualMethod, monthlyAccrualDays: Number(policyForm.monthlyAccrualDays),
        carryForwardEnabled: policyForm.carryForwardEnabled, maxCarryForwardDays: Number(policyForm.maxCarryForwardDays), carryForwardExpiryMonths: Number(policyForm.carryForwardExpiryMonths),
        minServiceDaysBeforeEligible: Number(policyForm.minServiceDaysBeforeEligible), allowNegativeBalance: policyForm.allowNegativeBalance, maxNegativeDays: Number(policyForm.maxNegativeDays),
        isSandwichLeave: policyForm.isSandwichLeave, unit: policyForm.unit,
      });
      showToast("Policy created");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not create policy", true); }
  }
  async function removePolicy(id) {
    try { await api.deleteLeavePolicy(id); showToast("Policy removed"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not remove policy", true); }
  }
  async function actCompOff(id, decision) {
    try { await api.decideCompOff(id, decision); showToast(`Comp-off ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update comp-off", true); }
  }
  async function runAccrual() {
    try { const r = await api.runLeaveAccrual(Number(accrualForm.year), Number(accrualForm.month)); showToast(`Accrual applied to ${r.accrualsApplied} balance(s)`); }
    catch (err) { showToast(err.message || "Could not run accrual", true); }
  }
  async function runExpiry() {
    try { const r = await api.runCarryForwardExpiry(); showToast(`${r.expiredCount} carry-forward balance(s) expired`); }
    catch (err) { showToast(err.message || "Could not run expiry", true); }
  }

  if (!leaveTypes || !compOffs) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Leave Admin" title="Advanced Leave Management" sub="Policies, comp-off approvals, and accrual/carry-forward maintenance." />
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <button className={`btn btn-sm ${tab === "policies" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("policies")}>Policies</button>
        <button className={`btn btn-sm ${tab === "compoff" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("compoff")}>Comp-Off ({compOffs.filter((c) => c.status === "pending").length})</button>
        <button className={`btn btn-sm ${tab === "maintenance" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("maintenance")}>Accrual & Carry-Forward</button>
      </div>

      {tab === "policies" ? (
        <Card title="Leave Policies">
          <Field label="Leave Type">
            <select className="input-sm" value={selectedType} onChange={(e) => setSelectedType(e.target.value)}>
              <option value="">Select…</option>
              {leaveTypes.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </Field>
          {selectedType ? (
            <>
              <form onSubmit={createPolicy} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end", margin: "0.8rem 0" }}>
                <Field label="Department (optional)"><input className="input-sm" value={policyForm.departmentName} onChange={(e) => setPolicyForm({ ...policyForm, departmentName: e.target.value })} /></Field>
                <Field label="Employee ID (optional)"><input className="input-sm" value={policyForm.userId} onChange={(e) => setPolicyForm({ ...policyForm, userId: e.target.value })} /></Field>
                <Field label="Annual Days"><input type="number" className="input-sm" value={policyForm.annualDays} onChange={(e) => setPolicyForm({ ...policyForm, annualDays: e.target.value })} /></Field>
                <Field label="Accrual">
                  <select className="input-sm" value={policyForm.accrualMethod} onChange={(e) => setPolicyForm({ ...policyForm, accrualMethod: e.target.value })}>
                    <option value="annual">Annual (lump sum)</option><option value="monthly">Monthly</option>
                  </select>
                </Field>
                {policyForm.accrualMethod === "monthly" ? (
                  <Field label="Monthly Days"><input type="number" className="input-sm" value={policyForm.monthlyAccrualDays} onChange={(e) => setPolicyForm({ ...policyForm, monthlyAccrualDays: e.target.value })} /></Field>
                ) : null}
                <Field label="Unit">
                  <select className="input-sm" value={policyForm.unit} onChange={(e) => setPolicyForm({ ...policyForm, unit: e.target.value })}>
                    <option value="day">Day</option><option value="hour">Hour</option>
                  </select>
                </Field>
                <Field label="Waiting Period (days)"><input type="number" className="input-sm" value={policyForm.minServiceDaysBeforeEligible} onChange={(e) => setPolicyForm({ ...policyForm, minServiceDaysBeforeEligible: e.target.value })} /></Field>
                <label style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.85rem" }}>
                  <input type="checkbox" checked={policyForm.carryForwardEnabled} onChange={(e) => setPolicyForm({ ...policyForm, carryForwardEnabled: e.target.checked })} /> Carry-forward
                </label>
                {policyForm.carryForwardEnabled ? (<>
                  <Field label="Max Carry-Forward"><input type="number" className="input-sm" value={policyForm.maxCarryForwardDays} onChange={(e) => setPolicyForm({ ...policyForm, maxCarryForwardDays: e.target.value })} /></Field>
                  <Field label="Expires After (months)"><input type="number" className="input-sm" value={policyForm.carryForwardExpiryMonths} onChange={(e) => setPolicyForm({ ...policyForm, carryForwardExpiryMonths: e.target.value })} /></Field>
                </>) : null}
                <label style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.85rem" }}>
                  <input type="checkbox" checked={policyForm.allowNegativeBalance} onChange={(e) => setPolicyForm({ ...policyForm, allowNegativeBalance: e.target.checked })} /> Allow negative
                </label>
                {policyForm.allowNegativeBalance ? (
                  <Field label="Max Negative"><input type="number" className="input-sm" value={policyForm.maxNegativeDays} onChange={(e) => setPolicyForm({ ...policyForm, maxNegativeDays: e.target.value })} /></Field>
                ) : null}
                <label style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.85rem" }}>
                  <input type="checkbox" checked={policyForm.isSandwichLeave} onChange={(e) => setPolicyForm({ ...policyForm, isSandwichLeave: e.target.checked })} /> Sandwich rule
                </label>
                <button className="btn btn-primary btn-sm" type="submit">Add Policy</button>
              </form>
              <table>
                <thead><tr><th>Scope</th><th>Annual Days</th><th>Accrual</th><th>Carry-Forward</th><th>Negative</th><th></th></tr></thead>
                <tbody>
                  {!policies || policies.length === 0 ? <EmptyRow colSpan={6}>No overrides for this leave type — the type's own default applies to everyone.</EmptyRow> : policies.map((p) => (
                    <tr key={p.id}>
                      <td>{p.user_id ? `Employee #${p.user_id}` : p.department_name ? `Dept: ${p.department_name}` : "—"}</td>
                      <td className="mono">{p.annual_days} {p.unit}</td>
                      <td>{p.accrual_method === "monthly" ? `${p.monthly_accrual_days}/mo` : "Annual"}</td>
                      <td>{p.carry_forward_enabled ? `up to ${p.max_carry_forward_days}` : "No"}</td>
                      <td>{p.allow_negative_balance ? `up to -${p.max_negative_days}` : "No"}</td>
                      <td><button className="btn btn-ghost btn-sm" onClick={() => removePolicy(p.id)}>Remove</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : null}
        </Card>
      ) : null}

      {tab === "compoff" ? (
        <Card title="Comp-Off Requests">
          <table>
            <thead><tr><th>Employee</th><th>Worked Date</th><th>Days</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {compOffs.length === 0 ? <EmptyRow colSpan={5}>No comp-off requests.</EmptyRow> : compOffs.map((c) => (
                <tr key={c.id}>
                  <td>{c.user_name}</td><td>{fmtDate(c.worked_date)}</td><td className="mono">{c.earned_days}</td><td><Stamp status={c.status} /></td>
                  <td style={{ display: "flex", gap: "0.3rem" }}>
                    {c.status === "pending" ? (<>
                      <button className="btn btn-ghost btn-sm" onClick={() => actCompOff(c.id, "approved")}>Approve</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => actCompOff(c.id, "rejected")}>Reject</button>
                    </>) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "maintenance" ? (
        <Card title="Accrual & Carry-Forward">
          <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
            <div>
              <div style={{ fontWeight: 600, marginBottom: "0.4rem" }}>Run Monthly Accrual</div>
              <div style={{ display: "flex", gap: "0.5rem" }}>
                <input type="number" className="input-sm" style={{ width: 90 }} value={accrualForm.year} onChange={(e) => setAccrualForm({ ...accrualForm, year: e.target.value })} />
                <select className="input-sm" value={accrualForm.month} onChange={(e) => setAccrualForm({ ...accrualForm, month: e.target.value })}>
                  {MONTH_NAMES.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
                </select>
                <button className="btn btn-primary btn-sm" onClick={runAccrual}>Run</button>
              </div>
            </div>
            <div>
              <div style={{ fontWeight: 600, marginBottom: "0.4rem" }}>Expire Stale Carry-Forward</div>
              <button className="btn btn-primary btn-sm" onClick={runExpiry}>Run Now</button>
            </div>
          </div>
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// EMPLOYEE LIFECYCLE ADMIN (Block 1)
// ============================================================
