import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function LeaveHistoryPage({ navTo }) {
  const { showToast, showError } = useToast();
  const [data, setData] = useState(null);
  const [types, setTypes] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ leave }, t] = await Promise.all([api.getMyLeaveApplications(), api.getLeaveTypes()]);
        if (!cancelled) { setData(leave); setTypes(t); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function cancel(id) {
    if (!window.confirm("Cancel this leave request?")) return;
    try {
      await api.cancelLeaveApplication(id);
      showToast("Leave request cancelled");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  return (
    <>
      <PageHead eyebrow="Leave" title="Leave History"
        sub={<>Track your requests. See <a href="#" style={{ color: "var(--teal)", textDecoration: "underline" }} onClick={(e) => { e.preventDefault(); navTo("calendar"); }}>Calendar</a> for the month-at-a-glance view.</>}
        actions={<a className="btn btn-ghost btn-sm" href={api.leaveCsvUrl()} download>Export CSV</a>} />
      <Card>
        <table>
          <thead><tr><th>ID</th><th>Type</th><th>Dates</th><th>Days</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {!data ? <EmptyRow colSpan={6}>Loading…</EmptyRow> : data.length === 0 ? (
              <EmptyRow colSpan={6}>No leave requests yet.</EmptyRow>
            ) : data.map((l) => (
              <tr key={l.id}>
                <td className="mono">{l.id}</td>
                <td>{leaveTypeName(l.leave_type_id, types)}</td>
                <td className="mono">{fmtDate(l.from_date)} → {fmtDate(l.to_date)}</td>
                <td className="mono">{l.days}</td>
                <td><Stamp status={l.status} /></td>
                <td>{["pending", "approved"].includes(l.status) ? <button className="btn btn-ghost btn-sm" onClick={() => cancel(l.id)}>Cancel</button> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// APPROVALS
// ============================================================
