import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function LeaveApplicationPage({ navTo }) {
  const { showToast, showError } = useToast();
  const [types, setTypes] = useState(null);
  const [balances, setBalances] = useState(null);
  const [leaveTypeId, setLeaveTypeId] = useState(null);
  const [duration, setDuration] = useState("full");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [t, { balances: b }] = await Promise.all([api.getLeaveTypes(), api.getLeaveBalances()]);
        setTypes(t);
        setBalances(b);
        if (t.length) setLeaveTypeId(t[0].id);
      } catch (err) { showError(err); }
    })();
  }, []);

  async function submit() {
    if (!from) { showToast("Please select a start date", true); return; }
    setBusy(true);
    try {
      const { id } = await api.applyForLeave({ leaveTypeId: parseInt(leaveTypeId, 10), from, to: to || from, reason: reason.trim(), halfDay: duration === "half" });
      showToast(`Leave request ${id} submitted`);
      navTo("leave-history");
    } catch (err) { showError(err); setBusy(false); }
  }

  return (
    <>
      <PageHead eyebrow="Leave" title="Apply for Leave" sub="Balances update automatically once your request is approved. Weekends don't count toward the day total." />
      <div className="balance-grid" style={{ marginBottom: "1.1rem" }}>
        {types ? types.map((t) => {
          const b = (balances || []).find((x) => x.leave_type_id === t.id) || { total_days: 0, used_days: 0, pending_days: 0 };
          return (
            <div className="balance-chip" key={t.id}>
              <div className="n">{b.total_days - b.used_days}</div>
              <div className="lbl">{t.name} left</div>
              {b.pending_days > 0 ? <div className="lbl" style={{ color: "var(--amber)" }}>{b.pending_days} pending</div> : null}
            </div>
          );
        }) : null}
      </div>
      <Card title="New request">
        <div className="form-grid">
          <Field label="Leave type">
            <select value={leaveTypeId || ""} onChange={(e) => setLeaveTypeId(e.target.value)}>
              {(types || []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </Field>
          <Field label="Duration">
            <select value={duration} onChange={(e) => setDuration(e.target.value)}>
              <option value="full">Full day(s)</option>
              <option value="half">Half day</option>
            </select>
          </Field>
          <Field label="From"><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="To"><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <div className="field full">
            <label>Reason</label>
            <input type="text" placeholder="Brief reason for leave" value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
        </div>
        <div className="form-actions">
          <button className="btn btn-primary" disabled={busy} onClick={submit}>Submit request</button>
        </div>
      </Card>
    </>
  );
}

// ============================================================
// LEAVE HISTORY
// ============================================================
