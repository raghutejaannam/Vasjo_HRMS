import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function MySalaryPage({ navTo }) {
  const { user } = useAuth();
  const { showError } = useToast();
  const [data, setData] = useState(null);
  const [noFy, setNoFy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const fy = await api.getFinancialYears();
        const activeFy = fy.financialYears.find((f) => f.is_active) || fy.financialYears[0];
        if (!activeFy) { setNoFy(true); return; }
        const [{ structures }, { regime }, taxSummary] = await Promise.all([
          api.getSalaryStructures(user.id), api.getMyTaxRegime(activeFy.id),
          api.getMyTaxSummary(activeFy.id).catch(() => ({ taxLiability: null })),
        ]);
        const active = structures.find((s) => s.status === "active") || structures[0];
        setData({ activeFy, active, regime, taxLiability: taxSummary.taxLiability });
      } catch (err) { showError(err); }
    })();
  }, [user.id]);

  if (noFy) return <div className="card">No financial year configured. Contact administrator.</div>;
  if (!data) return <PageLoading />;
  const { activeFy, active, regime, taxLiability } = data;

  return (
    <>
      <PageHead eyebrow="Payroll" title={`My Salary — ${activeFy.name}`} sub="Your salary structure and tax details for the current financial year." />
      {active ? (
        <>
          <div className="stat-grid">
            <StatCard label="Annual CTC" value={fmtMoney(active.annual_ctc)} foot="per year" />
            <StatCard label="Monthly CTC" value={fmtMoney(active.monthly_ctc)} foot="per month" />
            <StatCard label="Status" value={<Stamp status={active.status} />} foot="salary structure" />
            <StatCard label="Tax Regime" value={regime ? regime.regime_name : "—"} foot={regime ? "selected" : "not selected"} />
          </div>
          {taxLiability ? (
            <div className="two-col">
              <Card title="Tax Summary">
                <table>
                  <tbody>
                    <tr><td className="text-dim">Annual Taxable Income</td><td className="mono">{fmtMoneyDec(taxLiability.taxableIncome)}</td></tr>
                    <tr><td className="text-dim">Income Tax</td><td className="mono">{fmtMoneyDec(taxLiability.incomeTax)}</td></tr>
                    <tr><td className="text-dim">Cess</td><td className="mono">{fmtMoneyDec(taxLiability.cess)}</td></tr>
                    <tr><td className="text-dim">Total Annual Tax</td><td className="mono"><strong>{fmtMoneyDec(taxLiability.totalTax)}</strong></td></tr>
                    <tr><td className="text-dim">Monthly TDS</td><td className="mono">{fmtMoneyDec(taxLiability.totalTax / 12)}</td></tr>
                  </tbody>
                </table>
              </Card>
              <Card title="Previous Employer Income">
                <div className="subtle-note">Not provided. <button className="btn btn-ghost btn-sm" onClick={() => navTo("my-tax-declaration")}>Declare Now</button></div>
              </Card>
            </div>
          ) : null}
        </>
      ) : (
        <Card title="No Salary Structure">
          <p style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>Your salary structure has not been set up yet. Please contact your administrator.</p>
        </Card>
      )}
    </>
  );
}

// ============================================================
// MY TAX DECLARATION
// ============================================================
function TaxSectionCard({ sec, decl, isDraft, onAddEntry, onDeleteEntry }) {
  const entries = decl ? decl.entries : [];
  const totalDeclared = entries.reduce((s, e) => s + (e.amount || 0), 0);
  const statusLabel = decl ? decl.status : "not started";
  const [invType, setInvType] = useState("");
  const [provider, setProvider] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");

  return (
    <div className="card" style={{ marginBottom: "0.8rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem" }}>
        <div>
          <strong>{sec.section_name}</strong>
          {sec.max_limit ? <span style={{ color: "var(--text-dim)", fontSize: "0.8rem", marginLeft: "0.5rem" }}>Limit: {fmtMoney(sec.max_limit)}</span> : null}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <span className={`stamp ${statusLabel === "submitted" ? "pending" : statusLabel === "verified" ? "approved" : "draft"}`}>{statusLabel}</span>
          <span className="mono" style={{ fontSize: "0.85rem" }}>{fmtMoney(totalDeclared)}</span>
        </div>
      </div>
      {entries.length ? (
        <table style={{ marginBottom: "0.5rem" }}>
          <thead><tr><th>Type</th><th>Provider</th><th>Amount</th><th>Date</th><th>Status</th><th></th></tr></thead>
          <tbody>{entries.map((e) => (
            <tr key={e.id}>
              <td>{e.investment_type || "—"}</td><td>{e.provider_name || "—"}</td><td className="mono">{fmtMoney(e.amount)}</td>
              <td>{fmtDate(e.investment_date)}</td><td><Stamp status={e.status || "draft"} /></td>
              <td>{isDraft ? <button className="btn btn-ghost btn-sm" title="Remove" onClick={() => onDeleteEntry(e.id)}>✕</button> : null}</td>
            </tr>
          ))}</tbody>
        </table>
      ) : null}
      {isDraft ? (
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center" }}>
          <input type="text" placeholder="Type (e.g. PPF, LIC)" style={{ width: 120 }} className="input-sm" value={invType} onChange={(e) => setInvType(e.target.value)} />
          <input type="text" placeholder="Provider" style={{ width: 120 }} className="input-sm" value={provider} onChange={(e) => setProvider(e.target.value)} />
          <input type="number" placeholder="Amount" style={{ width: 100 }} className="input-sm" value={amount} onChange={(e) => setAmount(e.target.value)} />
          <input type="date" className="input-sm" value={date} onChange={(e) => setDate(e.target.value)} />
          <button className="btn btn-sm btn-primary" onClick={() => onAddEntry(sec.id, { invType, provider, amount, date })}>+ Add</button>
        </div>
      ) : null}
    </div>
  );
}

export function MyTaxDeclarationPage() {
  const { showToast, showError } = useToast();
  const [noFy, setNoFy] = useState(false);
  const [state, setState] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [compareOpen, setCompareOpen] = useState(false);
  const [comparison, setComparison] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const fy = await api.getFinancialYears();
        const activeFy = fy.financialYears.find((f) => f.is_active) || fy.financialYears[0];
        if (!activeFy) { setNoFy(true); return; }
        const [declarationsData, sectionsData, regimesData, myRegimeData] = await Promise.all([
          api.getMyTaxDeclarations(activeFy.id), api.getTaxDeclarationSections(activeFy.id),
          api.getTaxRegimes(activeFy.id), api.getMyTaxRegime(activeFy.id),
        ]);
        if (!cancelled) setState({
          activeFy, declarations: declarationsData.declarations, sections: sectionsData.sections,
          regimes: regimesData.regimes, selectedRegime: myRegimeData.regime,
        });
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function selectRegime(regimeId) {
    try {
      await api.setMyTaxRegime(state.activeFy.id, regimeId);
      showToast("Tax regime updated");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  async function openCompare() {
    try {
      const { comparison: c } = await api.compareMyTaxRegimes(state.activeFy.id);
      setComparison(c);
      setCompareOpen(true);
    } catch (err) { showError(err); }
  }

  async function addEntry(sectionId, { invType, provider, amount, date }) {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { showToast("Enter a valid amount", true); return; }
    try {
      const { id: declId } = await api.createOrGetTaxDeclaration(state.activeFy.id, sectionId);
      await api.addTaxDeclarationEntry(declId, { investmentType: invType, providerName: provider, amount: amt, investmentDate: date });
      showToast("Entry added");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  async function deleteEntry(entryId) {
    if (!window.confirm("Remove this entry?")) return;
    try {
      await api.deleteTaxDeclarationEntry(entryId);
      showToast("Entry removed");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  async function submitAll() {
    try {
      await api.submitAllTaxDeclarations(state.activeFy.id);
      showToast("Declarations submitted");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  if (noFy) return <div className="card">No financial year configured.</div>;
  if (!state) return <PageLoading />;
  const { activeFy, declarations, sections, regimes, selectedRegime } = state;

  const regimeBlock = regimes.length ? (
    <Card style={{ marginBottom: "1.1rem" }} title="Choose Your Tax Regime">
      <p style={{ fontSize: "0.85rem", color: "var(--text-dim)", marginBottom: "0.8rem" }}>
        {selectedRegime
          ? <>You're currently on the <strong>{selectedRegime.regime_name}</strong> for {activeFy.name}. You can switch any time before payroll is finalized for this year.</>
          : "Pick a regime to see which deduction sections apply to you. Not sure? Compare both first."}
      </p>
      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
        {regimes.map((r) => (
          <button key={r.id} className={`btn btn-sm ${selectedRegime && selectedRegime.tax_regime_id === r.id ? "btn-primary" : "btn-ghost"}`} onClick={() => selectRegime(r.id)}>{r.name}</button>
        ))}
        <button className="btn btn-sm btn-ghost" onClick={openCompare}>Compare Regimes</button>
      </div>
    </Card>
  ) : null;

  const compareModal = compareOpen ? (
    <div style={{ display: "flex", position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 1000, alignItems: "center", justifyContent: "center" }}>
      <div className="card" style={{ maxWidth: 600, width: "90%", maxHeight: "80vh", overflow: "auto", padding: "1.5rem" }}>
        <div className="card-title">Tax Regime Comparison</div>
        {comparison && comparison.comparison && comparison.comparison.length ? (
          <>
            <p style={{ fontSize: "0.85rem", color: "var(--text-dim)", marginBottom: "1rem" }}>Recommended: <strong>{comparison.lower_tax_regime}</strong></p>
            <table>
              <thead><tr><th>Item</th>{comparison.comparison.map((r) => <th key={r.regime_name} className={r.is_lower_tax ? "mono" : ""}>{r.regime_name}{r.is_lower_tax ? " ✓" : ""}</th>)}</tr></thead>
              <tbody>
                {[
                  ["Taxable Income", "taxable_income"], ["Income Tax", "income_tax"], ["Total Annual Tax (incl. cess)", "total_annual_tax"],
                  ["Monthly TDS", "monthly_tds"], ["Est. Annual Take-home", "estimated_annual_takehome"],
                ].map(([label, key]) => (
                  <tr key={key}>
                    <td>{label}</td>
                    {comparison.comparison.map((r) => <td key={r.regime_name} className="mono" style={r.is_lower_tax ? { background: "var(--teal-soft)" } : undefined}>{fmtMoneyDec(r[key])}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        ) : <p style={{ color: "var(--text-dim)" }}>Set up your salary structure first to see a comparison.</p>}
        <button className="btn btn-ghost" style={{ marginTop: "1rem" }} onClick={() => setCompareOpen(false)}>Close</button>
      </div>
    </div>
  ) : null;

  if (!selectedRegime) {
    return (
      <>
        <PageHead eyebrow="Tax" title={`Tax Declaration — ${activeFy.name}`} sub="Declare your tax-saving investments and deductions for this financial year." />
        {regimeBlock}
        <div className="card"><p style={{ color: "var(--text-dim)" }}>Choose a tax regime above to see the deduction sections that apply to you.</p></div>
        {compareModal}
      </>
    );
  }

  const regimeCode = selectedRegime.regime_code;
  const visibleSections = sections.filter((s) => s.applicable_regime === "both" || s.applicable_regime === regimeCode);
  const newRegimeNote = regimeCode === "new" ? (
    <Card style={{ marginBottom: "0.8rem" }} title={<span style={{ fontSize: "0.9rem" }}>About the New Regime</span>}>
      <p style={{ fontSize: "0.85rem", color: "var(--text-dim)" }}>
        Most exemptions and deductions (80C, 80D, HRA, home loan interest, and others) don't apply under the new regime.
        The flat standard deduction and any employer NPS contribution (80CCD(2)) are applied automatically during payroll —
        there's nothing to declare for those. The section below is the one exception that still needs your input.
      </p>
    </Card>
  ) : null;

  return (
    <>
      <PageHead eyebrow="Tax" title={`Tax Declaration — ${activeFy.name}`} sub="Declare your tax-saving investments and deductions for this financial year." />
      {regimeBlock}
      {newRegimeNote}
      {visibleSections.length === 0 ? (
        <div className="card"><p style={{ color: "var(--text-dim)" }}>No declaration sections apply under this regime.</p></div>
      ) : visibleSections.map((sec) => {
        const decl = declarations.find((d) => d.section_id === sec.id);
        const isDraft = !decl || decl.status === "draft";
        return <TaxSectionCard key={sec.id} sec={sec} decl={decl} isDraft={isDraft} onAddEntry={addEntry} onDeleteEntry={deleteEntry} />;
      })}
      {visibleSections.length ? (
        <div style={{ marginTop: "1rem", display: "flex", gap: "0.5rem" }}>
          <button className="btn btn-primary" onClick={submitAll}>Submit All Declarations</button>
        </div>
      ) : null}
      {compareModal}
    </>
  );
}

// ============================================================
// MY PAYSLIPS
// ============================================================
export function MyPayslipsPage() {
  const { showError, showToast } = useToast();
  const [noFy, setNoFy] = useState(false);
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const fy = await api.getFinancialYears();
        const activeFy = fy.financialYears.find((f) => f.is_active) || fy.financialYears[0];
        if (!activeFy) { setNoFy(true); return; }
        const { payslips } = await api.getMyPayslips(activeFy.id);
        setData({ activeFy, payslips });
      } catch (err) { showError(err); }
    })();
  }, []);

  function download(id) {
    if (!id) { showToast("Payslip not found", true); return; }
    const a = document.createElement("a");
    a.href = api.payslipPdfUrl(id);
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  if (noFy) return <div className="card">No financial year configured.</div>;
  if (!data) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Payroll" title={`My Payslips — ${data.activeFy.name}`} sub="View and download your monthly payslips." />
      <Card>
        <table>
          <thead><tr><th>Month</th><th>Gross</th><th>Deductions</th><th>TDS</th><th>Net Pay</th><th></th></tr></thead>
          <tbody>
            {data.payslips.length === 0 ? <EmptyRow colSpan={6}>No payslips generated yet for this financial year.</EmptyRow> : data.payslips.map((p) => (
              <tr key={p.id}>
                <td>{p.payroll_month}</td><td className="mono">{fmtMoneyDec(p.gross_earning)}</td><td className="mono">{fmtMoneyDec(p.total_deductions)}</td>
                <td className="mono">{fmtMoneyDec(p.tds_deduction)}</td><td className="mono"><strong>{fmtMoneyDec(p.net_salary)}</strong></td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => download(p.id)}>Download PDF</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// PAYROLL DASHBOARD (admin)
// ============================================================
export function PayrollDashboardPage({ navTo }) {
  const { showError } = useToast();
  const [noFy, setNoFy] = useState(false);
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const fy = await api.getFinancialYears();
        const activeFy = fy.financialYears.find((f) => f.is_active) || fy.financialYears[0];
        if (!activeFy) { setNoFy(true); return; }
        const { dashboard } = await api.getPayrollDashboard(activeFy.id);
        setData({ activeFy, dashboard });
      } catch (err) { showError(err); }
    })();
  }, []);

  if (noFy) return <div className="card">No financial year configured.</div>;
  if (!data) return <PageLoading />;
  const { activeFy, dashboard } = data;

  return (
    <>
      <PageHead eyebrow="Payroll Admin" title={`Payroll Dashboard — ${activeFy.name}`} sub="Overview of payroll status for the current financial year." />
      <div className="stat-grid">
        <StatCard label="Total Employees" value={dashboard.totalEmployees} />
        <StatCard label="Processed Runs" value={dashboard.processed} foot={`of ${dashboard.processed + dashboard.pending} total`} tone="amber" />
        <StatCard label="Total Gross Payroll" value={fmtMoney(dashboard.totalGross)} />
        <StatCard label="Total Net Payroll" value={fmtMoney(dashboard.totalNetPayroll)} />
        <StatCard label="Total TDS" value={fmtMoney(dashboard.totalTds)} />
        <StatCard label="Open Exceptions" value={dashboard.payrollExceptions} tone={dashboard.payrollExceptions ? "amber" : undefined} />
        <StatCard label="Missing Salary Setup" value={dashboard.employeesMissingSalary} foot="employees without salary structure" tone={dashboard.employeesMissingSalary ? "amber" : undefined} />
        <StatCard label="Pending Tax Proofs" value={dashboard.pendingTaxProofs} tone={dashboard.pendingTaxProofs ? "amber" : undefined} />
      </div>

      {dashboard.currentRun ? (
        <Card style={{ marginTop: "1rem" }} title={`Current Month: ${dashboard.currentMonth}`}>
          <PayrollStagePath status={dashboard.currentRun.status} />
          <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap", marginTop: "0.9rem" }}>
            <div><span className="text-dim">Run Status:</span> <Stamp status={dashboard.currentRun.status} /></div>
            <div><span className="text-dim">Employees:</span> <span className="mono">{dashboard.currentRun.total_employees}</span></div>
            <div><span className="text-dim">Gross:</span> <span className="mono">{fmtMoney(dashboard.currentRun.total_gross)}</span></div>
            <div><span className="text-dim">Net:</span> <span className="mono">{fmtMoney(dashboard.currentRun.total_net)}</span></div>
          </div>
        </Card>
      ) : null}

      <Card style={{ marginTop: "1rem" }} title="Quick Actions">
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
          <button className="btn btn-primary btn-sm" onClick={() => navTo("payroll-run")}>Manage Payroll Runs</button>
          <button className="btn btn-ghost btn-sm" onClick={() => navTo("salary-admin")}>Salary Setup</button>
        </div>
      </Card>
    </>
  );
}

// ============================================================
// PAYROLL RUN (admin)
// ============================================================
function RunDetailPanel({ runId }) {
  const { showToast, showError } = useToast();
  const [details, setDetails] = useState(null);
  const [exceptions, setExceptions] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ details: d }, { exceptions: ex }] = await Promise.all([api.getPayrollRunDetails(runId), api.getPayrollRunExceptions(runId)]);
        if (!cancelled) { setDetails(d); setExceptions(ex); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [runId, reloadKey]);

  async function generate(payrollDetailId) {
    try {
      const result = await api.generatePayslip(payrollDetailId);
      showToast("Payslip generated — downloading PDF");
      const a = document.createElement("a");
      a.href = api.payslipPdfUrl(result.id);
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) { showToast(err.message || "Could not generate payslip", true); }
  }
  async function resolveException(id) {
    try {
      await api.resolvePayrollException(id, "Reviewed");
      showToast("Exception resolved");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  if (!details) return <div style={{ color: "var(--text-dim)" }}>Loading…</div>;
  const unresolved = (exceptions || []).filter((e) => !e.is_resolved);

  return (
    <Card style={{ marginTop: "1rem" }} title={`Run #${runId} — ${details.length} employees`}>
      {unresolved.length ? (
        <div style={{ marginBottom: "1rem" }}>
          <div className="card-title" style={{ fontSize: "0.85rem" }}>Exceptions ({unresolved.length})</div>
          {unresolved.map((e) => (
            <div key={e.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "0.5rem", padding: "0.4rem 0", borderBottom: "1px solid var(--line)", fontSize: "0.85rem" }}>
              <div><span className={`stamp ${e.severity === "error" ? "rejected" : "pending"}`}>{e.severity || "warning"}</span><span style={{ marginLeft: "0.5rem" }}>{e.exception_message || e.exception_code}</span></div>
              <button className="btn btn-ghost btn-sm" onClick={() => resolveException(e.id)}>Resolve</button>
            </div>
          ))}
        </div>
      ) : null}
      <table>
        <thead><tr><th>Employee</th><th>Gross</th><th>Deductions</th><th>TDS</th><th>Net</th><th>Payslip</th></tr></thead>
        <tbody>
          {details.length === 0 ? <EmptyRow colSpan={6}>No details.</EmptyRow> : details.map((d) => (
            <tr key={d.id}>
              <td>{d.user_name}</td><td className="mono">{fmtMoneyDec(d.gross_earning)}</td><td className="mono">{fmtMoneyDec(d.total_deductions)}</td>
              <td className="mono">{fmtMoneyDec(d.tds_deduction)}</td><td className="mono"><strong>{fmtMoneyDec(d.net_salary)}</strong></td>
              <td><button className="btn btn-ghost btn-sm" onClick={() => generate(d.id)}>Generate</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}

export function PayrollRunPage() {
  const { showToast, showError } = useToast();
  const [noFy, setNoFy] = useState(false);
  const [activeFy, setActiveFy] = useState(null);
  const [runs, setRuns] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newMonth, setNewMonth] = useState("");
  const [detailRunId, setDetailRunId] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const fy = await api.getFinancialYears();
        const fyActive = fy.financialYears.find((f) => f.is_active) || fy.financialYears[0];
        if (!fyActive) { setNoFy(true); return; }
        setActiveFy(fyActive);
        const { runs: r } = await api.getPayrollRuns(fyActive.id);
        if (!cancelled) setRuns(r);
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function createRun() {
    if (!newMonth) { showToast("Select a month", true); return; }
    try {
      await api.createPayrollRun(activeFy.id, newMonth);
      showToast("Payroll run created");
      setShowCreate(false);
      setNewMonth("");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  async function act(runId, action) {
    if (action === "calculate" && !window.confirm("Calculate payroll for all active employees?")) return;
    if (action === "approve" && !window.confirm("Approve this payroll run? This cannot be undone.")) return;
    if (action === "lock" && !window.confirm("Lock this payroll run? No further changes allowed.")) return;
    try {
      const result = await api.actOnPayrollRun(runId, action);
      showToast(result.totalEmployees ? `Calculated: ${result.totalEmployees} employees` : `Run ${action}d`);
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message, true); }
  }

  async function deleteRun(run) {
    if (!window.confirm(`Delete the ${run.payroll_month} payroll run? All pre-lock calculations, exceptions, and generated payslips for this run will be removed. You can then create the same month again and rerun payroll. This cannot be undone.`)) return;
    try {
      await api.deletePayrollRun(run.id);
      showToast(`Payroll run ${run.payroll_month} deleted. You can create it again.`);
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message, true); }
  }

  if (noFy) return <div className="card">No financial year configured.</div>;
  if (!runs) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Payroll Admin" title="Payroll Runs" sub="Create, calculate, and manage monthly payroll runs."
        actions={<button className="btn btn-primary" onClick={() => setShowCreate((v) => !v)}>Create New Run</button>} />

      {showCreate ? (
        <Card style={{ marginBottom: "1rem" }} title="New Payroll Run">
          <div style={{ display: "flex", gap: "0.5rem", alignItems: "end", flexWrap: "wrap" }}>
            <div>
              <label className="field-label">Month (YYYY-MM)</label>
              <input type="month" className="input-sm" required value={newMonth} onChange={(e) => setNewMonth(e.target.value)} />
            </div>
            <button className="btn btn-primary btn-sm" onClick={createRun}>Create</button>
            <button className="btn btn-ghost btn-sm" onClick={() => setShowCreate(false)}>Cancel</button>
          </div>
        </Card>
      ) : null}

      <Card>
        <table>
          <thead><tr><th>Month</th><th>Status</th><th>Employees</th><th>Gross</th><th>Net</th><th>TDS</th><th>Actions</th></tr></thead>
          <tbody>
            {runs.length === 0 ? <EmptyRow colSpan={7}>No payroll runs yet. Click "Create New Run" to start.</EmptyRow> : runs.map((r) => (
              <tr key={r.id}>
                <td>{r.payroll_month}</td>
                <td><Stamp status={r.status} /><div style={{ marginTop: "0.35rem" }}><PayrollStagePath status={r.status} compact /></div></td>
                <td className="mono">{r.total_employees || 0}</td>
                <td className="mono">{fmtMoney(r.total_gross)}</td><td className="mono">{fmtMoney(r.total_net)}</td><td className="mono">{fmtMoney(r.total_tds)}</td>
                <td>
                  <div style={{ display: "flex", gap: "0.3rem", flexWrap: "wrap" }}>
                    {r.status === "draft" ? <button className="btn btn-sm btn-primary" onClick={() => act(r.id, "calculate")}>Calculate</button> : null}
                    {["calculated", "reviewed", "approved"].includes(r.status) ? <button className="btn btn-sm btn-primary" onClick={() => act(r.id, "calculate")}>Update &amp; Recalculate</button> : null}
                    {r.status === "calculated" ? <button className="btn btn-sm btn-primary" onClick={() => act(r.id, "review")}>Review</button> : null}
                    {r.status === "reviewed" ? <button className="btn btn-sm btn-primary" onClick={() => act(r.id, "approve")}>Approve</button> : null}
                    {r.status === "approved" ? <button className="btn btn-sm btn-primary" onClick={() => act(r.id, "lock")}>Lock</button> : null}
                    {!["locked", "disbursed"].includes(r.status) ? <button className="btn btn-sm btn-ghost" onClick={() => deleteRun(r)}>Delete &amp; Rerun</button> : null}
                    <button className="btn btn-sm btn-ghost" onClick={() => setDetailRunId(r.id)}>Details</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {detailRunId ? <RunDetailPanel runId={detailRunId} key={`${detailRunId}-${reloadKey}`} /> : null}
    </>
  );
}

// ============================================================
// SALARY ADMIN — build/activate salary structures
// (React only sends component amounts the admin types; the backend computes
// CTC totals, PF, gratuity, insurance and any derived math.)
// ============================================================
function ComponentRow({ c, onChange, onRemove, disabled }) {
  return (
    <tr>
      <td><input type="text" className="input-sm" value={c.componentName} disabled={disabled} onChange={(e) => onChange({ ...c, componentName: e.target.value })} /></td>
      <td>
        <select className="input-sm" value={c.type} disabled={disabled} onChange={(e) => onChange({ ...c, type: e.target.value })}>
          <option value="earning">Earning</option><option value="deduction">Deduction</option>
        </select>
      </td>
      <td><input type="text" className="input-sm" placeholder="e.g. allowance" value={c.category} disabled={disabled} onChange={(e) => onChange({ ...c, category: e.target.value })} /></td>
      <td><input type="number" className="input-sm" value={c.amount} disabled={disabled} onChange={(e) => onChange({ ...c, amount: e.target.value })} /></td>
      <td><input type="checkbox" checked={!!c.isTaxable} disabled={disabled} onChange={(e) => onChange({ ...c, isTaxable: e.target.checked })} /></td>
      <td>{!disabled ? <button className="btn btn-ghost btn-sm" onClick={onRemove}>✕</button> : null}</td>
    </tr>
  );
}

export function SalaryAdminPage() {
  const { showToast, showError } = useToast();
  const [employees, setEmployees] = useState(null);
  const [userId, setUserId] = useState("");
  const [structures, setStructures] = useState(null);
  const [openStructureId, setOpenStructureId] = useState(null);
  const [openStructure, setOpenStructure] = useState(null);
  const [components, setComponents] = useState([]);
  const [reloadKey, setReloadKey] = useState(0);

  const [showNew, setShowNew] = useState(false);
  const [newAnnualCtc, setNewAnnualCtc] = useState("");
  const [newBasic, setNewBasic] = useState("");
  const [newEffectiveFrom, setNewEffectiveFrom] = useState(new Date().toISOString().slice(0, 10));

  useEffect(() => {
    (async () => { try { setEmployees((await api.getUsersFlat()).users.filter((u) => u.role !== "admin")); } catch (err) { showError(err); } })();
  }, []);

  useEffect(() => {
    if (!userId) { setStructures(null); return; }
    let cancelled = false;
    (async () => {
      try { const { structures: s } = await api.getSalaryStructures(userId); if (!cancelled) setStructures(s); }
      catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [userId, reloadKey]);

  useEffect(() => {
    if (!openStructureId) { setOpenStructure(null); setComponents([]); return; }
    let cancelled = false;
    (async () => {
      try {
        const s = await api.getSalaryStructure(openStructureId);
        if (!cancelled) { setOpenStructure(s); setComponents((s.components || []).map((c) => ({ id: c.id, componentName: c.component_name, type: c.type, category: c.category || "", amount: c.amount, isTaxable: !!c.is_taxable }))); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [openStructureId, reloadKey]);

  async function createStructure() {
    const ctc = parseFloat(newAnnualCtc);
    if (!ctc || ctc <= 0) { showToast("Enter a valid annual CTC", true); return; }
    try {
      const { id } = await api.createSalaryStructure({
        userId: parseInt(userId, 10), annualCtc: ctc, basicSalary: parseFloat(newBasic) || undefined, effectiveFrom: newEffectiveFrom,
      });
      showToast("Salary structure created (draft)");
      setShowNew(false); setNewAnnualCtc(""); setNewBasic("");
      setReloadKey((k) => k + 1);
      setOpenStructureId(id);
    } catch (err) { showError(err); }
  }

  function addComponentRow() {
    setComponents((c) => [...c, { componentName: "", type: "earning", category: "", amount: "", isTaxable: true }]);
  }
  function updateComponentRow(idx, next) {
    setComponents((c) => c.map((row, i) => (i === idx ? next : row)));
  }
  function removeComponentRow(idx) {
    setComponents((c) => c.filter((_, i) => i !== idx));
  }

  async function saveComponents() {
    const cleaned = components
      .filter((c) => c.componentName.trim() && parseFloat(c.amount) > 0)
      .map((c) => ({ componentName: c.componentName.trim(), type: c.type, category: c.category.trim() || null, amount: parseFloat(c.amount), isTaxable: !!c.isTaxable }));
    try {
      await api.saveSalaryStructureComponents(openStructureId, cleaned);
      showToast("Components saved");
      setReloadKey((k) => k + 1);
    } catch (err) { showError(err); }
  }

  async function activate() {
    if (!window.confirm("Activate this salary structure? It will become the employee's active salary and any previous active structure will be superseded.")) return;
    try {
      await api.activateSalaryStructure(openStructureId);
      showToast("Salary structure activated");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message, true); }
  }

  const isDraft = openStructure && openStructure.status === "draft";

  return (
    <>
      <PageHead eyebrow="Payroll Admin" title="Salary Setup" sub="Build and activate salary structures per employee. All CTC, PF, gratuity, and tax math is computed by the backend when payroll runs." />
      <Card>
        <Field label="Employee">
          <select value={userId} onChange={(e) => { setUserId(e.target.value); setOpenStructureId(null); }}>
            <option value="">— Select employee —</option>
            {(employees || []).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </Field>
      </Card>

      {userId ? (
        <Card title="Salary Structures" right={<button className="btn btn-primary btn-sm" onClick={() => setShowNew((v) => !v)}>+ New Structure</button>}>
          {showNew ? (
            <div className="form-grid" style={{ marginBottom: "0.8rem" }}>
              <Field label="Annual CTC (₹)"><input type="number" value={newAnnualCtc} onChange={(e) => setNewAnnualCtc(e.target.value)} /></Field>
              <Field label="Basic Salary (₹, optional)"><input type="number" value={newBasic} onChange={(e) => setNewBasic(e.target.value)} /></Field>
              <Field label="Effective from"><input type="date" value={newEffectiveFrom} onChange={(e) => setNewEffectiveFrom(e.target.value)} /></Field>
              <div className="field full"><button className="btn btn-primary btn-sm" onClick={createStructure}>Create draft</button></div>
            </div>
          ) : null}
          <table>
            <thead><tr><th>Annual CTC</th><th>Monthly CTC</th><th>Effective From</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {!structures ? <EmptyRow colSpan={5}>Loading…</EmptyRow> : structures.length === 0 ? <EmptyRow colSpan={5}>No salary structures yet for this employee.</EmptyRow> : structures.map((s) => (
                <tr key={s.id}>
                  <td className="mono">{fmtMoney(s.annual_ctc)}</td><td className="mono">{fmtMoney(s.monthly_ctc)}</td><td>{s.effective_from}</td>
                  <td><Stamp status={s.status} /></td>
                  <td><button className="btn btn-ghost btn-sm" onClick={() => setOpenStructureId(s.id)}>Open</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {openStructure ? (
        <Card title={`Structure — ${fmtMoney(openStructure.annual_ctc)}/yr (${openStructure.status})`}>
          <table>
            <thead><tr><th>Component</th><th>Type</th><th>Category</th><th>Annual Amount (₹)</th><th>Taxable</th><th></th></tr></thead>
            <tbody>
              {components.map((c, i) => (
                <ComponentRow key={c.id || i} c={c} disabled={!isDraft} onChange={(next) => updateComponentRow(i, next)} onRemove={() => removeComponentRow(i)} />
              ))}
            </tbody>
          </table>
          {isDraft ? (
            <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.8rem", flexWrap: "wrap" }}>
              <button className="btn btn-ghost btn-sm" onClick={addComponentRow}>+ Add component</button>
              <button className="btn btn-primary btn-sm" onClick={saveComponents}>Save components</button>
              <button className="btn btn-primary btn-sm" onClick={activate}>Activate structure</button>
            </div>
          ) : (
            <p className="subtle-note">This structure is {openStructure.status} and can no longer be edited.</p>
          )}
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// Route registry — maps view id -> page component.
// Consumed by App.jsx so the sidebar/routing logic stays tiny.
// ============================================================
// ============================================================
// MY BENEFITS (employee/manager self-service — loans, advances,
// leave encashment, gratuity estimate)
// ============================================================
export function MyBenefitsPage() {
  const { user } = useAuth();
  const { showToast, showError } = useToast();
  const [loans, setLoans] = useState(null);
  const [advances, setAdvances] = useState(null);
  const [encashments, setEncashments] = useState(null);
  const [gratuity, setGratuity] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [loanForm, setLoanForm] = useState({ principalAmount: "", interestRateAnnual: "0", tenureMonths: "", purpose: "" });
  const [advanceForm, setAdvanceForm] = useState({ amount: "", reason: "", recoveryMonths: "1" });
  const [encashDays, setEncashDays] = useState("");
  const [leaveTypeId, setLeaveTypeId] = useState("");
  const [leaveTypes, setLeaveTypes] = useState([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [l, a, e, g, lt] = await Promise.all([
          api.getLoansForEmployee(user.id),
          api.getAdvancesForEmployee(user.id),
          api.getLeaveEncashmentsForEmployee(user.id),
          api.getGratuityEstimate(user.id).catch(() => null),
          api.getLeaveTypes ? api.getLeaveTypes().catch(() => ({ leaveTypes: [] })) : Promise.resolve({ leaveTypes: [] }),
        ]);
        if (cancelled) return;
        setLoans(l); setAdvances(a); setEncashments(e); setGratuity(g);
        setLeaveTypes(lt.leaveTypes || lt || []);
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [user.id, reloadKey]);

  async function submitLoan(e) {
    e.preventDefault();
    try {
      await api.requestLoan(user.id, {
        principalAmount: Number(loanForm.principalAmount),
        interestRateAnnual: Number(loanForm.interestRateAnnual) || 0,
        tenureMonths: Number(loanForm.tenureMonths),
        purpose: loanForm.purpose,
      });
      showToast("Loan request submitted");
      setLoanForm({ principalAmount: "", interestRateAnnual: "0", tenureMonths: "", purpose: "" });
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not submit loan request", true); }
  }

  async function submitAdvance(e) {
    e.preventDefault();
    try {
      await api.requestAdvance(user.id, {
        amount: Number(advanceForm.amount), reason: advanceForm.reason, recoveryMonths: Number(advanceForm.recoveryMonths) || 1,
      });
      showToast("Salary advance request submitted");
      setAdvanceForm({ amount: "", reason: "", recoveryMonths: "1" });
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not submit advance request", true); }
  }

  async function submitEncashment(e) {
    e.preventDefault();
    if (!leaveTypeId) { showToast("Select a leave type", true); return; }
    try {
      await api.requestLeaveEncashment(user.id, { leaveTypeId: Number(leaveTypeId), days: Number(encashDays) });
      showToast("Leave encashment request submitted");
      setEncashDays(""); setLeaveTypeId("");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not submit encashment request", true); }
  }

  if (!loans || !advances || !encashments) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Payroll" title="My Benefits" sub="Loans, salary advances, leave encashment and your gratuity estimate." />

      {gratuity ? (
        <div className="stat-grid" style={{ marginBottom: "1rem" }}>
          <StatCard label="Years of Service" value={gratuity.yearsOfService} />
          <StatCard label="Gratuity Eligible" value={gratuity.eligible ? "Yes" : "No"} foot={`from ${gratuity.eligibilityThresholdYears} years`} tone={gratuity.eligible ? undefined : "amber"} />
          <StatCard label="Estimated Gratuity" value={fmtMoney(gratuity.gratuityAmount)} foot="on last-drawn basic, not yet payable" />
        </div>
      ) : null}

      <div className="two-col">
        <Card title="Request a Loan">
          <form onSubmit={submitLoan} style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            <Field label="Principal Amount">
              <input type="number" className="input-sm" value={loanForm.principalAmount} onChange={(e) => setLoanForm({ ...loanForm, principalAmount: e.target.value })} required />
            </Field>
            <Field label="Annual Interest Rate (%)">
              <input type="number" className="input-sm" value={loanForm.interestRateAnnual} onChange={(e) => setLoanForm({ ...loanForm, interestRateAnnual: e.target.value })} />
            </Field>
            <Field label="Tenure (months)">
              <input type="number" className="input-sm" value={loanForm.tenureMonths} onChange={(e) => setLoanForm({ ...loanForm, tenureMonths: e.target.value })} required />
            </Field>
            <Field label="Purpose">
              <input type="text" className="input-sm" value={loanForm.purpose} onChange={(e) => setLoanForm({ ...loanForm, purpose: e.target.value })} />
            </Field>
            <button className="btn btn-primary btn-sm" type="submit">Submit Loan Request</button>
          </form>
          <table style={{ marginTop: "0.8rem" }}>
            <thead><tr><th>Principal</th><th>EMI</th><th>Outstanding</th><th>Status</th></tr></thead>
            <tbody>
              {loans.length === 0 ? <EmptyRow colSpan={4}>No loans yet.</EmptyRow> : loans.map((l) => (
                <tr key={l.id}>
                  <td className="mono">{fmtMoney(l.principal_amount)}</td>
                  <td className="mono">{l.emi_amount ? fmtMoney(l.emi_amount) : "—"}</td>
                  <td className="mono">{fmtMoney(l.outstanding_balance)}</td>
                  <td><Stamp status={l.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card title="Request a Salary Advance">
          <form onSubmit={submitAdvance} style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            <Field label="Amount">
              <input type="number" className="input-sm" value={advanceForm.amount} onChange={(e) => setAdvanceForm({ ...advanceForm, amount: e.target.value })} required />
            </Field>
            <Field label="Reason">
              <input type="text" className="input-sm" value={advanceForm.reason} onChange={(e) => setAdvanceForm({ ...advanceForm, reason: e.target.value })} />
            </Field>
            <Field label="Preferred Recovery (months)">
              <input type="number" className="input-sm" value={advanceForm.recoveryMonths} onChange={(e) => setAdvanceForm({ ...advanceForm, recoveryMonths: e.target.value })} />
            </Field>
            <button className="btn btn-primary btn-sm" type="submit">Submit Advance Request</button>
          </form>
          <table style={{ marginTop: "0.8rem" }}>
            <thead><tr><th>Amount</th><th>Monthly Recovery</th><th>Outstanding</th><th>Status</th></tr></thead>
            <tbody>
              {advances.length === 0 ? <EmptyRow colSpan={4}>No advances yet.</EmptyRow> : advances.map((a) => (
                <tr key={a.id}>
                  <td className="mono">{fmtMoney(a.amount)}</td>
                  <td className="mono">{a.monthly_recovery_amount ? fmtMoney(a.monthly_recovery_amount) : "—"}</td>
                  <td className="mono">{fmtMoney(a.outstanding_balance)}</td>
                  <td><Stamp status={a.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <Card style={{ marginTop: "1rem" }} title="Leave Encashment">
        <form onSubmit={submitEncashment} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end", marginBottom: "0.8rem" }}>
          <Field label="Leave Type">
            <select className="input-sm" value={leaveTypeId} onChange={(e) => setLeaveTypeId(e.target.value)}>
              <option value="">Select…</option>
              {leaveTypes.map((lt) => <option key={lt.id} value={lt.id}>{lt.name}</option>)}
            </select>
          </Field>
          <Field label="Days to Encash">
            <input type="number" className="input-sm" value={encashDays} onChange={(e) => setEncashDays(e.target.value)} required />
          </Field>
          <button className="btn btn-primary btn-sm" type="submit">Request Encashment</button>
        </form>
        <table>
          <thead><tr><th>Leave Type</th><th>Days</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
            {encashments.length === 0 ? <EmptyRow colSpan={4}>No leave encashment requests yet.</EmptyRow> : encashments.map((e) => (
              <tr key={e.id}>
                <td>{e.leave_type_name}</td><td className="mono">{e.days}</td>
                <td className="mono">{fmtMoney(e.amount)}</td><td><Stamp status={e.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// PAYROLL BENEFITS ADMIN (loans / advances / leave encashment approvals)
// ============================================================
export function PayrollBenefitsAdminPage() {
  const { showToast, showError } = useToast();
  const [tab, setTab] = useState("loans");
  const [loans, setLoans] = useState(null);
  const [advances, setAdvances] = useState(null);
  const [encashments, setEncashments] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [l, a, e] = await Promise.all([api.getAllLoans(), api.getAllAdvances(), api.getAllLeaveEncashments()]);
        if (!cancelled) { setLoans(l); setAdvances(a); setEncashments(e); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function actLoan(id, decision) {
    try { await api.decideLoan(id, decision); showToast(`Loan ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update loan", true); }
  }
  async function disburse(id) {
    try { await api.disburseLoan(id); showToast("Loan disbursed"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not disburse loan", true); }
  }
  async function actAdvance(id, decision) {
    try { await api.decideAdvance(id, decision); showToast(`Advance ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update advance", true); }
  }
  async function actEncashment(id, decision) {
    try { await api.decideLeaveEncashment(id, decision); showToast(`Encashment ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update encashment", true); }
  }

  if (!loans || !advances || !encashments) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Payroll Admin" title="Loans, Advances & Leave Encashment" sub="Review and approve employee loan, salary advance and leave encashment requests." />
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <button className={`btn btn-sm ${tab === "loans" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("loans")}>Loans ({loans.length})</button>
        <button className={`btn btn-sm ${tab === "advances" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("advances")}>Advances ({advances.length})</button>
        <button className={`btn btn-sm ${tab === "encashment" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("encashment")}>Leave Encashment ({encashments.length})</button>
      </div>

      {tab === "loans" ? (
        <Card title="Loan Requests">
          <table>
            <thead><tr><th>Employee</th><th>Principal</th><th>Tenure</th><th>EMI</th><th>Outstanding</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {loans.length === 0 ? <EmptyRow colSpan={7}>No loan requests.</EmptyRow> : loans.map((l) => (
                <tr key={l.id}>
                  <td>{l.user_name}</td><td className="mono">{fmtMoney(l.principal_amount)}</td>
                  <td className="mono">{l.tenure_months}mo</td>
                  <td className="mono">{l.emi_amount ? fmtMoney(l.emi_amount) : "—"}</td>
                  <td className="mono">{fmtMoney(l.outstanding_balance)}</td>
                  <td><Stamp status={l.status} /></td>
                  <td style={{ display: "flex", gap: "0.3rem" }}>
                    {l.status === "pending" ? (<>
                      <button className="btn btn-ghost btn-sm" onClick={() => actLoan(l.id, "approved")}>Approve</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => actLoan(l.id, "rejected")}>Reject</button>
                    </>) : null}
                    {l.status === "approved" ? <button className="btn btn-primary btn-sm" onClick={() => disburse(l.id)}>Disburse</button> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "advances" ? (
        <Card title="Salary Advance Requests">
          <table>
            <thead><tr><th>Employee</th><th>Amount</th><th>Recovery</th><th>Outstanding</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {advances.length === 0 ? <EmptyRow colSpan={6}>No advance requests.</EmptyRow> : advances.map((a) => (
                <tr key={a.id}>
                  <td>{a.user_name}</td><td className="mono">{fmtMoney(a.amount)}</td>
                  <td className="mono">{a.monthly_recovery_amount ? `${fmtMoney(a.monthly_recovery_amount)}/mo` : `${a.recovery_months}mo`}</td>
                  <td className="mono">{fmtMoney(a.outstanding_balance)}</td>
                  <td><Stamp status={a.status} /></td>
                  <td style={{ display: "flex", gap: "0.3rem" }}>
                    {a.status === "pending" ? (<>
                      <button className="btn btn-ghost btn-sm" onClick={() => actAdvance(a.id, "approved")}>Approve</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => actAdvance(a.id, "rejected")}>Reject</button>
                    </>) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "encashment" ? (
        <Card title="Leave Encashment Requests">
          <table>
            <thead><tr><th>Employee</th><th>Leave Type</th><th>Days</th><th>Amount</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {encashments.length === 0 ? <EmptyRow colSpan={6}>No leave encashment requests.</EmptyRow> : encashments.map((e) => (
                <tr key={e.id}>
                  <td>{e.user_name}</td><td>{e.leave_type_name}</td><td className="mono">{e.days}</td>
                  <td className="mono">{fmtMoney(e.amount)}</td><td><Stamp status={e.status} /></td>
                  <td style={{ display: "flex", gap: "0.3rem" }}>
                    {e.status === "pending" ? (<>
                      <button className="btn btn-ghost btn-sm" onClick={() => actEncashment(e.id, "approved")}>Approve</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => actEncashment(e.id, "rejected")}>Reject</button>
                    </>) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// PAYROLL REPORTS — month-to-month comparison & variance
// ============================================================
export function PayrollReportsPage() {
  const { showError } = useToast();
  const [fy, setFy] = useState(null);
  const [monthA, setMonthA] = useState("");
  const [monthB, setMonthB] = useState("");
  const [threshold, setThreshold] = useState("10");
  const [comparison, setComparison] = useState(null);
  const [variance, setVariance] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { financialYears } = await api.getFinancialYears();
        const active = financialYears.find((f) => f.is_active) || financialYears[0];
        setFy(active);
      } catch (err) { showError(err); }
    })();
  }, []);

  async function run() {
    if (!fy || !monthA || !monthB) return;
    setBusy(true);
    try {
      const [cmp, vr] = await Promise.all([
        api.getPayrollComparisonReport(fy.id, monthA, monthB),
        api.getPayrollVarianceReport(fy.id, monthA, monthB, Number(threshold) || 10),
      ]);
      setComparison(cmp); setVariance(vr);
    } catch (err) { showError(err); }
    finally { setBusy(false); }
  }

  return (
    <>
      <PageHead eyebrow="Payroll Admin" title="Payroll Reports" sub="Compare two payroll months and flag employees whose net pay swung beyond a threshold." />
      <Card title="Choose Months to Compare">
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end" }}>
          <Field label="Month A"><input type="month" className="input-sm" value={monthA} onChange={(e) => setMonthA(e.target.value)} /></Field>
          <Field label="Month B"><input type="month" className="input-sm" value={monthB} onChange={(e) => setMonthB(e.target.value)} /></Field>
          <Field label="Variance Threshold (%)"><input type="number" className="input-sm" value={threshold} onChange={(e) => setThreshold(e.target.value)} /></Field>
          <button className="btn btn-primary btn-sm" disabled={busy || !monthA || !monthB} onClick={run}>Compare</button>
        </div>
      </Card>

      {comparison ? (
        <Card style={{ marginTop: "1rem" }} title={`Totals: ${comparison.monthA} vs ${comparison.monthB}`}>
          <div className="stat-grid">
            <StatCard label="Gross (A → B)" value={`${fmtMoney(comparison.totals.grossA)} → ${fmtMoney(comparison.totals.grossB)}`} />
            <StatCard label="Net (A → B)" value={`${fmtMoney(comparison.totals.netA)} → ${fmtMoney(comparison.totals.netB)}`} />
            <StatCard label="TDS (A → B)" value={`${fmtMoney(comparison.totals.tdsA)} → ${fmtMoney(comparison.totals.tdsB)}`} />
            <StatCard label="Headcount (A → B)" value={`${comparison.totals.headcountA} → ${comparison.totals.headcountB}`} />
          </div>
          <table style={{ marginTop: "0.8rem" }}>
            <thead><tr><th>Employee</th><th>Net A</th><th>Net B</th><th>Δ Net</th></tr></thead>
            <tbody>
              {comparison.employees.map((e) => (
                <tr key={e.userId}>
                  <td>{e.userName}{!e.presentInA ? " (new)" : ""}{!e.presentInB ? " (not in B)" : ""}</td>
                  <td className="mono">{fmtMoneyDec(e.netA)}</td><td className="mono">{fmtMoneyDec(e.netB)}</td>
                  <td className="mono" style={{ color: e.netDelta > 0 ? "var(--ok, #2a9d5c)" : e.netDelta < 0 ? "var(--danger, #d64545)" : undefined }}>
                    {e.netDelta > 0 ? "+" : ""}{fmtMoneyDec(e.netDelta)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {variance ? (
        <Card style={{ marginTop: "1rem" }} title={`Variance Flags (≥ ${variance.thresholdPercent}%)`}>
          <table>
            <thead><tr><th>Employee</th><th>Net A</th><th>Net B</th><th>% Change</th></tr></thead>
            <tbody>
              {variance.flagged.length === 0 ? <EmptyRow colSpan={4}>No employee exceeded the threshold.</EmptyRow> : variance.flagged.map((e) => (
                <tr key={e.userId}>
                  <td>{e.userName}</td><td className="mono">{fmtMoneyDec(e.netA)}</td><td className="mono">{fmtMoneyDec(e.netB)}</td>
                  <td className="mono">{e.pctChange > 0 ? "+" : ""}{e.pctChange}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// MY ATTENDANCE (employee self-service — check in/out, calendar, corrections)
// ============================================================
const ATTENDANCE_STATUS_LABEL = {
  present: "Present", absent: "Absent", half_day: "Half Day", wfh: "Work From Home",
  on_duty: "On Duty", holiday: "Holiday", weekly_off: "Weekly Off", leave: "Leave", pending: "—",
};

