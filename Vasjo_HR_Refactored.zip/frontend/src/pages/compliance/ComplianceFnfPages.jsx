import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function MyTaxStatementPage() {
  const { user } = useAuth();
  const { showError } = useToast();
  const [statement, setStatement] = useState(null);
  const [form16, setForm16] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [s, f] = await Promise.all([api.getAnnualTaxStatement(user.id), api.getForm16(user.id)]);
        if (!cancelled) { setStatement(s); setForm16(f); }
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [user.id]);

  if (!statement || !form16) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Tax" title="My Annual Tax Statement" sub={`${statement.financialYearName} — ${statement.regime.name}`} />

      <div className="stat-grid">
        <StatCard label="Total Annual Gross" value={fmtMoney(statement.totalAnnualGross)} />
        <StatCard label="Taxable Income" value={fmtMoney(statement.taxableIncome)} />
        <StatCard label="Tax Computed" value={fmtMoney(statement.annualTaxComputed)} />
        <StatCard label="TDS Deducted" value={fmtMoney(statement.totalTdsDeducted)} />
      </div>

      <Card style={{ marginTop: "1rem" }} title={statement.balanceType === "refund_due" ? "Refund Due" : statement.balanceType === "additional_tax_due" ? "Additional Tax Due" : "Settled"}>
        <div style={{ fontSize: "1.4rem", fontWeight: 700 }}>{fmtMoney(Math.abs(statement.balance))}</div>
        <div style={{ opacity: 0.7, fontSize: "0.85rem" }}>
          {statement.balanceType === "refund_due" ? "More TDS was deducted than your computed liability." :
            statement.balanceType === "additional_tax_due" ? "Your computed liability exceeds TDS deducted so far." : "TDS deducted matches your computed liability."}
        </div>
      </Card>

      {statement.previousEmployer ? (
        <Card style={{ marginTop: "1rem" }} title="Previous Employer Income">
          <table>
            <tbody>
              <tr><td>Employer</td><td className="mono">{statement.previousEmployer.name}</td></tr>
              <tr><td>Gross Income</td><td className="mono">{fmtMoney(statement.previousEmployer.grossIncome)}</td></tr>
              <tr><td>TDS Deducted</td><td className="mono">{fmtMoney(statement.previousEmployer.tdsDeducted)}</td></tr>
            </tbody>
          </table>
        </Card>
      ) : null}

      <Card style={{ marginTop: "1rem" }} title="Monthly Breakdown">
        <table>
          <thead><tr><th>Month</th><th>Gross</th><th>PF</th><th>PT</th><th>TDS</th><th>Net</th></tr></thead>
          <tbody>
            {statement.monthlyBreakdown.length === 0 ? <EmptyRow colSpan={6}>No payroll processed yet this year.</EmptyRow> : statement.monthlyBreakdown.map((m) => (
              <tr key={m.payrollMonth}>
                <td>{m.payrollMonth}</td><td className="mono">{fmtMoneyDec(m.grossEarning)}</td>
                <td className="mono">{fmtMoneyDec(m.pfEmployeeDeduction)}</td><td className="mono">{fmtMoneyDec(m.professionalTaxDeduction)}</td>
                <td className="mono">{fmtMoneyDec(m.tdsDeduction)}</td><td className="mono">{fmtMoneyDec(m.netSalary)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card style={{ marginTop: "1rem" }} title="Form 16 — Quarterly TDS Summary">
        <table>
          <thead><tr><th>Quarter</th><th>TDS Deducted</th></tr></thead>
          <tbody>
            {Object.entries(form16.partA.quarterlyTdsSummary).map(([q, amt]) => (
              <tr key={q}><td>{q}</td><td className="mono">{fmtMoney(amt)}</td></tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// COMPLIANCE ADMIN (Block 5 — employer info, Form 24Q, PF/ESI/PT
// reports, statutory wage register)
// ============================================================
export function ComplianceAdminPage() {
  const { showToast, showError } = useToast();
  const [tab, setTab] = useState("employer");
  const [fy, setFy] = useState(null);
  const [employerInfo, setEmployerInfo] = useState(null);
  const [quarter, setQuarter] = useState("Q1");
  const [payrollMonth, setPayrollMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [form24q, setForm24q] = useState(null);
  const [pfReport, setPfReport] = useState(null);
  const [esiReport, setEsiReport] = useState(null);
  const [ptReport, setPtReport] = useState(null);
  const [register, setRegister] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [info, fys] = await Promise.all([api.getEmployerStatutoryInfo(), api.getFinancialYears()]);
        setEmployerInfo(info);
        setFy(fys.financialYears.find((f) => f.is_active) || fys.financialYears[0]);
      } catch (err) { showError(err); }
    })();
  }, []);

  async function saveEmployerInfo(e) {
    e.preventDefault();
    try { await api.updateEmployerStatutoryInfo(employerInfo); showToast("Employer info saved"); }
    catch (err) { showToast(err.message || "Could not save", true); }
  }

  async function runReport(kind) {
    if (!fy) return;
    setBusy(true);
    try {
      if (kind === "24q") setForm24q(await api.getForm24Q(fy.id, quarter));
      if (kind === "pf") setPfReport(await api.getPfComplianceReport(fy.id, payrollMonth));
      if (kind === "esi") setEsiReport(await api.getEsiComplianceReport(fy.id, payrollMonth));
      if (kind === "pt") setPtReport(await api.getPtComplianceReport(fy.id, payrollMonth));
      if (kind === "register") setRegister(await api.getStatutoryWageRegister(fy.id, payrollMonth));
    } catch (err) { showToast(err.message || "Could not run report", true); }
    finally { setBusy(false); }
  }

  if (!employerInfo || !fy) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Compliance" title="Tax & Statutory Compliance" sub="Employer details, Form 24Q, and PF/ESI/PT compliance reports." />
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem", flexWrap: "wrap" }}>
        {["employer", "24q", "pf", "esi", "pt", "register"].map((t) => (
          <button key={t} className={`btn btn-sm ${tab === t ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab(t)}>
            {{ employer: "Employer Info", "24q": "Form 24Q", pf: "PF Report", esi: "ESI Report", pt: "PT Report", register: "Wage Register" }[t]}
          </button>
        ))}
      </div>

      {tab === "employer" ? (
        <Card title="Employer Statutory Info">
          <form onSubmit={saveEmployerInfo} style={{ display: "flex", flexDirection: "column", gap: "0.5rem", maxWidth: 420 }}>
            <Field label="Company Name"><input className="input-sm" value={employerInfo.company_name} onChange={(e) => setEmployerInfo({ ...employerInfo, company_name: e.target.value })} /></Field>
            <Field label="Company PAN"><input className="input-sm" value={employerInfo.company_pan} onChange={(e) => setEmployerInfo({ ...employerInfo, company_pan: e.target.value })} /></Field>
            <Field label="Company TAN"><input className="input-sm" value={employerInfo.company_tan} onChange={(e) => setEmployerInfo({ ...employerInfo, company_tan: e.target.value })} /></Field>
            <Field label="PF Establishment Code"><input className="input-sm" value={employerInfo.pf_establishment_code} onChange={(e) => setEmployerInfo({ ...employerInfo, pf_establishment_code: e.target.value })} /></Field>
            <Field label="ESI Establishment Code"><input className="input-sm" value={employerInfo.esi_establishment_code} onChange={(e) => setEmployerInfo({ ...employerInfo, esi_establishment_code: e.target.value })} /></Field>
            <Field label="Address"><input className="input-sm" value={employerInfo.company_address} onChange={(e) => setEmployerInfo({ ...employerInfo, company_address: e.target.value })} /></Field>
            <button className="btn btn-primary btn-sm" type="submit">Save</button>
          </form>
        </Card>
      ) : null}

      {tab === "24q" ? (
        <Card title="Form 24Q — Quarterly TDS Return Data" right={
          <div style={{ display: "flex", gap: "0.4rem" }}>
            <select className="input-sm" value={quarter} onChange={(e) => setQuarter(e.target.value)}>
              {["Q1", "Q2", "Q3", "Q4"].map((q) => <option key={q} value={q}>{q}</option>)}
            </select>
            <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => runReport("24q")}>Generate</button>
          </div>
        }>
          {form24q ? (
            <>
              <div className="stat-grid">
                <StatCard label="Deductees" value={form24q.deducteeCount} />
                <StatCard label="Total Gross Paid" value={fmtMoney(form24q.totalGrossPaid)} />
                <StatCard label="Total TDS Deducted" value={fmtMoney(form24q.totalTdsDeducted)} />
              </div>
              <table style={{ marginTop: "0.8rem" }}>
                <thead><tr><th>Employee</th><th>PAN</th><th>Gross Paid</th><th>TDS Deducted</th></tr></thead>
                <tbody>
                  {form24q.deductees.map((d) => (
                    <tr key={d.userId}><td>{d.name}</td><td className="mono">{d.pan}</td><td className="mono">{fmtMoneyDec(d.totalGrossPaid)}</td><td className="mono">{fmtMoneyDec(d.totalTdsDeducted)}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : <EmptyRow colSpan={1}>Choose a quarter and generate.</EmptyRow>}
        </Card>
      ) : null}

      {["pf", "esi", "pt", "register"].includes(tab) ? (
        <Card title={{ pf: "PF Compliance Report", esi: "ESI Compliance Report", pt: "PT Compliance Report", register: "Statutory Wage Register" }[tab]} right={
          <div style={{ display: "flex", gap: "0.4rem" }}>
            <input type="month" className="input-sm" value={payrollMonth} onChange={(e) => setPayrollMonth(e.target.value)} />
            <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => runReport(tab)}>Generate</button>
          </div>
        }>
          {tab === "pf" && pfReport ? (
            <>
              <div className="stat-grid">
                <StatCard label="Employees" value={pfReport.employeeCount} />
                <StatCard label="Employee PF" value={fmtMoney(pfReport.totals.employeePf)} />
                <StatCard label="Employer PF" value={fmtMoney(pfReport.totals.employerPfTotal)} />
                <StatCard label="Total Remittance" value={fmtMoney(pfReport.totals.totalRemittance)} />
              </div>
              <table style={{ marginTop: "0.8rem" }}>
                <thead><tr><th>Employee</th><th>UAN</th><th>PF Wage</th><th>Employee PF</th><th>Employer PF</th></tr></thead>
                <tbody>
                  {pfReport.employees.map((e) => (
                    <tr key={e.employeeCode}><td>{e.name}</td><td className="mono">{e.uan}</td><td className="mono">{fmtMoneyDec(e.pfWage)}</td><td className="mono">{fmtMoneyDec(e.employeePf)}</td><td className="mono">{fmtMoneyDec(e.employerPfTotal)}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : null}
          {tab === "esi" && esiReport ? (
            <>
              <div className="stat-grid">
                <StatCard label="Eligible Employees" value={esiReport.eligibleCount} />
                <StatCard label="Employee ESI" value={fmtMoney(esiReport.totals.employeeEsi)} />
                <StatCard label="Employer ESI" value={fmtMoney(esiReport.totals.employerEsi)} />
              </div>
              <div style={{ fontSize: "0.8rem", opacity: 0.7, margin: "0.5rem 0" }}>Advisory report — ESI is not currently withheld in payroll runs.</div>
              <table>
                <thead><tr><th>Employee</th><th>Gross Wage</th><th>Eligible</th><th>Employee ESI</th><th>Employer ESI</th></tr></thead>
                <tbody>
                  {esiReport.employees.map((e) => (
                    <tr key={e.employeeCode}><td>{e.name}</td><td className="mono">{fmtMoneyDec(e.grossWage)}</td><td>{e.eligible ? "Yes" : "No"}</td><td className="mono">{fmtMoneyDec(e.employeeEsi)}</td><td className="mono">{fmtMoneyDec(e.employerEsi)}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : null}
          {tab === "pt" && ptReport ? (
            <>
              <div className="stat-grid"><StatCard label="Total Professional Tax" value={fmtMoney(ptReport.totalProfessionalTax)} /></div>
              <table style={{ marginTop: "0.8rem" }}>
                <thead><tr><th>Employee</th><th>Location</th><th>PT Deducted</th></tr></thead>
                <tbody>
                  {ptReport.employees.map((e) => (
                    <tr key={e.employeeCode}><td>{e.name}</td><td>{e.location}</td><td className="mono">{fmtMoneyDec(e.professionalTaxDeducted)}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : null}
          {tab === "register" && register ? (
            <table>
              <thead><tr><th>Employee</th><th>Designation</th><th>Paid Days</th><th>Basic</th><th>Gross</th><th>Net</th></tr></thead>
              <tbody>
                {register.employees.map((e) => (
                  <tr key={e.employeeCode}><td>{e.name}</td><td>{e.designation}</td><td className="mono">{e.paidDays}/{e.workingDays}</td><td className="mono">{fmtMoneyDec(e.basicEarning)}</td><td className="mono">{fmtMoneyDec(e.grossEarning)}</td><td className="mono">{fmtMoneyDec(e.netSalary)}</td></tr>
                ))}
              </tbody>
            </table>
          ) : null}
          {!pfReport && !esiReport && !ptReport && !register ? <EmptyRow colSpan={1}>Choose a month and generate.</EmptyRow> : null}
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// FULL & FINAL SETTLEMENT ADMIN (Block 6)
// ============================================================
export function FnfAdminPage() {
  const { showToast, showError } = useToast();
  const [tab, setTab] = useState("separations");
  const [separations, setSeparations] = useState(null);
  const [settlements, setSettlements] = useState(null);
  const [employees, setEmployees] = useState(null);
  const [form, setForm] = useState({ userId: "", resignationDate: "", lastWorkingDate: "", noticePeriodRequiredDays: "30", reason: "" });
  const [statementFor, setStatementFor] = useState(null);
  const [statement, setStatement] = useState(null);
  const [overrides, setOverrides] = useState({ bonusAmount: "0", reimbursementsAmount: "0", assetRecoveryAmount: "0", otherDeductionsAmount: "0", otherDeductionsNotes: "" });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [sep, settle, emp] = await Promise.all([api.getSeparations(), api.getFnfSettlements(), api.getUsers(500)]);
        if (cancelled) return;
        setSeparations(sep); setSettlements(settle); setEmployees(emp.items || emp || []);
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function submitSeparation(e) {
    e.preventDefault();
    try {
      await api.initiateSeparation({ ...form, userId: Number(form.userId), noticePeriodRequiredDays: Number(form.noticePeriodRequiredDays) });
      showToast("Resignation recorded");
      setForm({ userId: "", resignationDate: "", lastWorkingDate: "", noticePeriodRequiredDays: "30", reason: "" });
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not record resignation", true); }
  }

  async function decideSep(id, decision) {
    try { await api.decideSeparation(id, decision); showToast(`Separation ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update separation", true); }
  }

  async function generate(separationId) {
    try {
      await api.generateFnfSettlement(separationId, {
        bonusAmount: Number(overrides.bonusAmount) || 0, reimbursementsAmount: Number(overrides.reimbursementsAmount) || 0,
        assetRecoveryAmount: Number(overrides.assetRecoveryAmount) || 0, otherDeductionsAmount: Number(overrides.otherDeductionsAmount) || 0,
        otherDeductionsNotes: overrides.otherDeductionsNotes,
      });
      showToast("Settlement generated");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not generate settlement", true); }
  }

  async function viewStatement(id) {
    try { setStatementFor(id); setStatement(await api.getFnfSettlementStatement(id)); }
    catch (err) { showToast(err.message || "Could not load statement", true); }
  }

  async function submitForApproval(id) {
    try { await api.submitFnfSettlement(id); showToast("Submitted for approval"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not submit", true); }
  }
  async function decideSettle(id, decision) {
    try { await api.decideFnfSettlement(id, decision); showToast(`Settlement ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not decide", true); }
  }
  async function markPaid(id) {
    try { await api.markFnfSettlementPaid(id); showToast("Settlement marked paid — employee deactivated"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not mark paid", true); }
  }

  if (!separations || !settlements) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Offboarding" title="Full & Final Settlement" sub="Resignations, notice period, and final settlement approval." />
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <button className={`btn btn-sm ${tab === "separations" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("separations")}>Separations ({separations.length})</button>
        <button className={`btn btn-sm ${tab === "settlements" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("settlements")}>Settlements ({settlements.length})</button>
      </div>

      {tab === "separations" ? (
        <>
          <Card title="Record a Resignation">
            <form onSubmit={submitSeparation} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end" }}>
              <Field label="Employee">
                <select className="input-sm" value={form.userId} onChange={(e) => setForm({ ...form, userId: e.target.value })} required>
                  <option value="">Select…</option>
                  {(employees || []).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </Field>
              <Field label="Resignation Date"><input type="date" className="input-sm" value={form.resignationDate} onChange={(e) => setForm({ ...form, resignationDate: e.target.value })} required /></Field>
              <Field label="Last Working Date"><input type="date" className="input-sm" value={form.lastWorkingDate} onChange={(e) => setForm({ ...form, lastWorkingDate: e.target.value })} required /></Field>
              <Field label="Notice Period (days)"><input type="number" className="input-sm" value={form.noticePeriodRequiredDays} onChange={(e) => setForm({ ...form, noticePeriodRequiredDays: e.target.value })} /></Field>
              <Field label="Reason"><input className="input-sm" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
              <button className="btn btn-primary btn-sm" type="submit">Record</button>
            </form>
          </Card>
          <Card style={{ marginTop: "1rem" }} title="Separations">
            <table>
              <thead><tr><th>Employee</th><th>Resignation</th><th>Last Working Day</th><th>Notice (days)</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {separations.length === 0 ? <EmptyRow colSpan={6}>No separations recorded.</EmptyRow> : separations.map((s) => (
                  <tr key={s.id}>
                    <td>{s.user_name}</td><td>{fmtDate(s.resignation_date)}</td><td>{fmtDate(s.last_working_date)}</td>
                    <td className="mono">{s.notice_period_required_days}</td><td><Stamp status={s.status} /></td>
                    <td style={{ display: "flex", gap: "0.3rem" }}>
                      {s.status === "pending" ? (<>
                        <button className="btn btn-ghost btn-sm" onClick={() => decideSep(s.id, "approved")}>Approve</button>
                        <button className="btn btn-ghost btn-sm" onClick={() => decideSep(s.id, "withdrawn")}>Withdraw</button>
                      </>) : null}
                      {s.status === "approved" ? <button className="btn btn-primary btn-sm" onClick={() => generate(s.id)}>Generate Settlement</button> : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      ) : null}

      {tab === "settlements" ? (
        <Card title="Settlements">
          <table>
            <thead><tr><th>Employee</th><th>Last Working Day</th><th>Final Payable</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {settlements.length === 0 ? <EmptyRow colSpan={5}>No settlements yet.</EmptyRow> : settlements.map((s) => (
                <React.Fragment key={s.id}>
                  <tr>
                    <td>{s.user_name}</td><td>{fmtDate(s.last_working_date)}</td>
                    <td className="mono">{fmtMoney(s.final_payable)}</td><td><Stamp status={s.status} /></td>
                    <td style={{ display: "flex", gap: "0.3rem" }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => viewStatement(s.id)}>{statementFor === s.id ? "Hide" : "View"} Statement</button>
                      {s.status === "draft" ? <button className="btn btn-primary btn-sm" onClick={() => submitForApproval(s.id)}>Submit</button> : null}
                      {s.status === "pending_approval" ? (<>
                        <button className="btn btn-ghost btn-sm" onClick={() => decideSettle(s.id, "approved")}>Approve</button>
                        <button className="btn btn-ghost btn-sm" onClick={() => decideSettle(s.id, "rejected")}>Reject</button>
                      </>) : null}
                      {s.status === "approved" ? <button className="btn btn-primary btn-sm" onClick={() => markPaid(s.id)}>Mark Paid</button> : null}
                    </td>
                  </tr>
                  {statementFor === s.id && statement ? (
                    <tr>
                      <td colSpan={5}>
                        <div style={{ padding: "0.8rem", background: "var(--surface-subtle, #f7f7f5)", borderRadius: 8 }}>
                          <div style={{ display: "flex", gap: "2rem", flexWrap: "wrap" }}>
                            <div>
                              <div style={{ fontWeight: 600, marginBottom: "0.3rem" }}>Earnings</div>
                              {statement.earnings.map((l) => <div key={l.label} style={{ display: "flex", justifyContent: "space-between", gap: "1rem" }}><span>{l.label}</span><span className="mono">{fmtMoney(l.amount)}</span></div>)}
                            </div>
                            <div>
                              <div style={{ fontWeight: 600, marginBottom: "0.3rem" }}>Deductions</div>
                              {statement.deductions.map((l) => <div key={l.label} style={{ display: "flex", justifyContent: "space-between", gap: "1rem" }}><span>{l.label}</span><span className="mono">{fmtMoney(l.amount)}</span></div>)}
                            </div>
                          </div>
                          <div style={{ marginTop: "0.6rem", fontWeight: 700 }}>Final Payable: {fmtMoney(statement.finalPayable)}</div>
                        </div>
                      </td>
                    </tr>
                  ) : null}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// MY COMP-OFF (employee self-service)
// ============================================================
