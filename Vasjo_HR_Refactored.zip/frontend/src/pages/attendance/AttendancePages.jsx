import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function MyAttendancePage() {
  const { user } = useAuth();
  const { showToast, showError } = useToast();
  const [today, setToday] = useState(null);
  const [busy, setBusy] = useState(false);
  const [cursor, setCursor] = useState(() => { const d = new Date(); return { year: d.getFullYear(), month: d.getMonth() + 1 }; });
  const [calendar, setCalendar] = useState(null);
  const [corrections, setCorrections] = useState(null);
  const [showCorrectionFor, setShowCorrectionFor] = useState(null);
  const [correctionReason, setCorrectionReason] = useState("");
  const [correctionStatus, setCorrectionStatus] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [t, cal, corr] = await Promise.all([
          api.getTodayAttendance(),
          api.getAttendanceCalendar(user.id, cursor.year, cursor.month),
          api.getAttendanceCorrectionsForEmployee(user.id),
        ]);
        if (cancelled) return;
        setToday(t); setCalendar(cal); setCorrections(corr);
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [user.id, cursor.year, cursor.month, reloadKey]);

  async function doCheckIn() {
    setBusy(true);
    try { await api.checkIn(); showToast("Checked in"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not check in", true); }
    finally { setBusy(false); }
  }
  async function doCheckOut() {
    setBusy(true);
    try { await api.checkOut(); showToast("Checked out"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not check out", true); }
    finally { setBusy(false); }
  }

  async function submitCorrection(date) {
    try {
      await api.requestAttendanceCorrection(user.id, { date, requestedStatus: correctionStatus || undefined, reason: correctionReason });
      showToast("Correction request submitted");
      setShowCorrectionFor(null); setCorrectionReason(""); setCorrectionStatus("");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not submit correction request", true); }
  }

  function shiftMonth(delta) {
    setCursor((c) => {
      let month = c.month + delta, year = c.year;
      if (month < 1) { month = 12; year--; } if (month > 12) { month = 1; year++; }
      return { year, month };
    });
  }

  if (!today || !calendar || !corrections) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Attendance" title="My Attendance" sub="Check in and out, review your monthly calendar, and request corrections." />

      <Card title="Today">
        <div style={{ display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: "0.85rem", opacity: 0.7 }}>Status</div>
            <div style={{ fontWeight: 600 }}>{ATTENDANCE_STATUS_LABEL[today.status] || today.status}</div>
          </div>
          {today.check_in_at ? (
            <div><div style={{ fontSize: "0.85rem", opacity: 0.7 }}>Checked in</div><div>{fmtDateTime(today.check_in_at)}</div></div>
          ) : null}
          {today.check_out_at ? (
            <div><div style={{ fontSize: "0.85rem", opacity: 0.7 }}>Checked out</div><div>{fmtDateTime(today.check_out_at)}</div></div>
          ) : null}
          <div style={{ marginLeft: "auto", display: "flex", gap: "0.5rem" }}>
            {!today.check_in_at ? <button className="btn btn-primary btn-sm" disabled={busy} onClick={doCheckIn}>Check In</button> : null}
            {today.check_in_at && !today.check_out_at ? <button className="btn btn-primary btn-sm" disabled={busy} onClick={doCheckOut}>Check Out</button> : null}
          </div>
        </div>
      </Card>

      <Card style={{ marginTop: "1rem" }} title={`${MONTH_NAMES[cursor.month - 1]} ${cursor.year}`} right={
        <div style={{ display: "flex", gap: "0.4rem" }}>
          <button className="btn btn-ghost btn-sm" onClick={() => shiftMonth(-1)}>← Prev</button>
          <button className="btn btn-ghost btn-sm" onClick={() => shiftMonth(1)}>Next →</button>
        </div>
      }>
        <table>
          <thead><tr><th>Date</th><th>Status</th><th>Check In</th><th>Check Out</th><th>Worked</th><th></th></tr></thead>
          <tbody>
            {calendar.days.map((d) => (
              <React.Fragment key={d.date}>
                <tr>
                  <td>{fmtDate(d.date)}</td>
                  <td><Stamp status={d.status === "present" ? "approved" : d.status === "absent" ? "rejected" : "pending"} label={ATTENDANCE_STATUS_LABEL[d.status] || d.status} /></td>
                  <td className="mono">{d.checkInAt ? fmtDateTime(d.checkInAt).split(" ").slice(-1)[0] : "—"}</td>
                  <td className="mono">{d.checkOutAt ? fmtDateTime(d.checkOutAt).split(" ").slice(-1)[0] : "—"}</td>
                  <td className="mono">{d.workedMinutes ? `${Math.floor(d.workedMinutes / 60)}h ${d.workedMinutes % 60}m` : "—"}</td>
                  <td>
                    {!d.isHoliday && !d.isWeeklyOff ? (
                      showCorrectionFor === d.date ? null : (
                        <button className="btn btn-ghost btn-sm" onClick={() => setShowCorrectionFor(d.date)}>Request Correction</button>
                      )
                    ) : null}
                  </td>
                </tr>
                {showCorrectionFor === d.date ? (
                  <tr>
                    <td colSpan={6}>
                      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end", padding: "0.5rem 0" }}>
                        <Field label="Correct Status To">
                          <select className="input-sm" value={correctionStatus} onChange={(e) => setCorrectionStatus(e.target.value)}>
                            <option value="">(leave as-is)</option>
                            <option value="present">Present</option>
                            <option value="wfh">Work From Home</option>
                            <option value="on_duty">On Duty</option>
                            <option value="half_day">Half Day</option>
                          </select>
                        </Field>
                        <Field label="Reason">
                          <input type="text" className="input-sm" value={correctionReason} onChange={(e) => setCorrectionReason(e.target.value)} placeholder="e.g. forgot to check out" />
                        </Field>
                        <button className="btn btn-primary btn-sm" onClick={() => submitCorrection(d.date)}>Submit</button>
                        <button className="btn btn-ghost btn-sm" onClick={() => setShowCorrectionFor(null)}>Cancel</button>
                      </div>
                    </td>
                  </tr>
                ) : null}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </Card>

      <Card style={{ marginTop: "1rem" }} title="My Correction Requests">
        <table>
          <thead><tr><th>Date</th><th>Reason</th><th>Status</th></tr></thead>
          <tbody>
            {corrections.length === 0 ? <EmptyRow colSpan={3}>No correction requests yet.</EmptyRow> : corrections.map((c) => (
              <tr key={c.id}><td>{fmtDate(c.date)}</td><td>{c.reason}</td><td><Stamp status={c.status} /></td></tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

// ============================================================
// ATTENDANCE ADMIN (shifts, team day/range view, manual marking,
// correction approvals, weekly-off config)
// ============================================================
export function AttendanceAdminPage() {
  const { showToast, showError } = useToast();
  const [tab, setTab] = useState("today");
  const [dayRecords, setDayRecords] = useState(null);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [shifts, setShifts] = useState(null);
  const [corrections, setCorrections] = useState(null);
  const [weeklyOff, setWeeklyOff] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [shiftForm, setShiftForm] = useState({ code: "", name: "", startTime: "09:00", endTime: "18:00", gracePeriodMinutes: "10", breakMinutes: "60" });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [d, s, c, w] = await Promise.all([
          api.getAttendanceForDay(date),
          api.getShifts(true),
          api.getAllAttendanceCorrections(),
          api.getWeeklyOffDays(),
        ]);
        if (cancelled) return;
        setDayRecords(d); setShifts(s); setCorrections(c); setWeeklyOff(w.days);
      } catch (err) { showError(err); }
    })();
    return () => { cancelled = true; };
  }, [date, reloadKey]);

  async function createShiftSubmit(e) {
    e.preventDefault();
    try {
      await api.createShift({
        ...shiftForm, gracePeriodMinutes: Number(shiftForm.gracePeriodMinutes), breakMinutes: Number(shiftForm.breakMinutes),
      });
      showToast("Shift created");
      setShiftForm({ code: "", name: "", startTime: "09:00", endTime: "18:00", gracePeriodMinutes: "10", breakMinutes: "60" });
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not create shift", true); }
  }

  async function decideCorr(id, decision) {
    try { await api.decideAttendanceCorrection(id, decision); showToast(`Correction ${decision}`); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not update correction", true); }
  }

  async function toggleWeeklyOff(dow) {
    const next = weeklyOff.includes(dow) ? weeklyOff.filter((d) => d !== dow) : [...weeklyOff, dow].sort();
    try { await api.setWeeklyOffDays(next); setWeeklyOff(next); showToast("Weekly off updated"); }
    catch (err) { showToast(err.message || "Could not update weekly off", true); }
  }

  if (!dayRecords || !shifts || !corrections || !weeklyOff) return <PageLoading />;

  const pendingCorrections = corrections.filter((c) => c.status === "pending");

  return (
    <>
      <PageHead eyebrow="Attendance Admin" title="Attendance Management" sub="Shifts, daily attendance, corrections and weekly-off configuration." />
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <button className={`btn btn-sm ${tab === "today" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("today")}>Daily View</button>
        <button className={`btn btn-sm ${tab === "shifts" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("shifts")}>Shifts</button>
        <button className={`btn btn-sm ${tab === "corrections" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("corrections")}>Corrections ({pendingCorrections.length})</button>
        <button className={`btn btn-sm ${tab === "settings" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("settings")}>Weekly Off</button>
      </div>

      {tab === "today" ? (
        <Card title="Daily Attendance" right={<input type="date" className="input-sm" value={date} onChange={(e) => setDate(e.target.value)} />}>
          <table>
            <thead><tr><th>Employee</th><th>Status</th><th>Check In</th><th>Check Out</th><th>Worked</th></tr></thead>
            <tbody>
              {dayRecords.length === 0 ? <EmptyRow colSpan={5}>No attendance records for this date.</EmptyRow> : dayRecords.map((r) => (
                <tr key={r.id}>
                  <td>{r.user_name}</td>
                  <td><Stamp status={r.status === "present" ? "approved" : r.status === "absent" ? "rejected" : "pending"} label={ATTENDANCE_STATUS_LABEL[r.status] || r.status} /></td>
                  <td className="mono">{r.check_in_at ? fmtDateTime(r.check_in_at) : "—"}</td>
                  <td className="mono">{r.check_out_at ? fmtDateTime(r.check_out_at) : "—"}</td>
                  <td className="mono">{r.worked_minutes ? `${Math.floor(r.worked_minutes / 60)}h ${r.worked_minutes % 60}m` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "shifts" ? (
        <Card title="Shifts">
          <form onSubmit={createShiftSubmit} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end", marginBottom: "1rem" }}>
            <Field label="Code"><input className="input-sm" value={shiftForm.code} onChange={(e) => setShiftForm({ ...shiftForm, code: e.target.value })} required /></Field>
            <Field label="Name"><input className="input-sm" value={shiftForm.name} onChange={(e) => setShiftForm({ ...shiftForm, name: e.target.value })} required /></Field>
            <Field label="Start"><input type="time" className="input-sm" value={shiftForm.startTime} onChange={(e) => setShiftForm({ ...shiftForm, startTime: e.target.value })} /></Field>
            <Field label="End"><input type="time" className="input-sm" value={shiftForm.endTime} onChange={(e) => setShiftForm({ ...shiftForm, endTime: e.target.value })} /></Field>
            <Field label="Grace (min)"><input type="number" className="input-sm" value={shiftForm.gracePeriodMinutes} onChange={(e) => setShiftForm({ ...shiftForm, gracePeriodMinutes: e.target.value })} /></Field>
            <Field label="Break (min)"><input type="number" className="input-sm" value={shiftForm.breakMinutes} onChange={(e) => setShiftForm({ ...shiftForm, breakMinutes: e.target.value })} /></Field>
            <button className="btn btn-primary btn-sm" type="submit">Add Shift</button>
          </form>
          <table>
            <thead><tr><th>Code</th><th>Name</th><th>Hours</th><th>Grace</th><th>Active</th></tr></thead>
            <tbody>
              {shifts.length === 0 ? <EmptyRow colSpan={5}>No shifts configured yet.</EmptyRow> : shifts.map((s) => (
                <tr key={s.id}>
                  <td className="mono">{s.code}</td><td>{s.name}</td>
                  <td className="mono">{s.start_time}–{s.end_time}</td>
                  <td className="mono">{s.grace_period_minutes}m</td>
                  <td>{s.active ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "corrections" ? (
        <Card title="Correction Requests">
          <table>
            <thead><tr><th>Employee</th><th>Date</th><th>Reason</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {corrections.length === 0 ? <EmptyRow colSpan={5}>No correction requests.</EmptyRow> : corrections.map((c) => (
                <tr key={c.id}>
                  <td>{c.user_name}</td><td>{fmtDate(c.date)}</td><td>{c.reason}</td><td><Stamp status={c.status} /></td>
                  <td style={{ display: "flex", gap: "0.3rem" }}>
                    {c.status === "pending" ? (<>
                      <button className="btn btn-ghost btn-sm" onClick={() => decideCorr(c.id, "approved")}>Approve</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => decideCorr(c.id, "rejected")}>Reject</button>
                    </>) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}

      {tab === "settings" ? (
        <Card title="Weekly Off Days">
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((label, dow) => (
              <button key={dow} className={`btn btn-sm ${weeklyOff.includes(dow) ? "btn-primary" : "btn-ghost"}`} onClick={() => toggleWeeklyOff(dow)}>{label}</button>
            ))}
          </div>
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// MY TAX STATEMENT (employee — annual reconciliation + Form 16 data)
// ============================================================
