import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function ReportsPage() {
  const { showError } = useToast();
  const [rtab, setRtab] = useState("project");

  const [rpFrom, setRpFrom] = useState(toISODate(new Date(new Date().getFullYear(), new Date().getMonth(), 1)));
  const [rpTo, setRpTo] = useState(toISODate(new Date()));
  const [rpRows, setRpRows] = useState(null);

  const [ruFrom, setRuFrom] = useState(toISODate(new Date(new Date().getFullYear(), new Date().getMonth(), 1)));
  const [ruTo, setRuTo] = useState(toISODate(new Date()));
  const [ruRows, setRuRows] = useState(null);

  const [rlYear, setRlYear] = useState(new Date().getFullYear());
  const [rlRows, setRlRows] = useState(null);

  const [rcWeek, setRcWeek] = useState(toISODate(mondayOf(toISODate(new Date()))));
  const [rcRows, setRcRows] = useState(null);

  const [pendingRows, setPendingRows] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const { timesheets, leave } = await api.getPendingApprovalsReport();
        const rows = [...timesheets.map((t) => ({ ...t, kind: "Timesheet" })), ...leave.map((l) => ({ ...l, kind: "Leave" }))]
          .sort((a, b) => b.days_pending - a.days_pending);
        setPendingRows(rows);
      } catch (err) { showError(err); }
    })();
  }, []);

  async function runProject() { try { setRpRows((await api.getProjectHoursReport(rpFrom, rpTo)).rows); } catch (err) { showError(err); } }
  async function runUtilization() { try { setRuRows((await api.getUtilizationReport(ruFrom, ruTo)).rows); } catch (err) { showError(err); } }
  async function runLeave() { try { setRlRows((await api.getLeaveUsageReport(rlYear)).rows); } catch (err) { showError(err); } }
  async function runCompliance() { try { setRcRows((await api.getComplianceReport(rcWeek)).rows); } catch (err) { showError(err); } }

  return (
    <>
      <PageHead eyebrow="Team" title="Reports" sub="Project hours, utilization, leave usage, compliance, and overdue approvals." />
      <div className="tabs">
        <button className={`tab-btn${rtab === "project" ? " active" : ""}`} onClick={() => setRtab("project")}>Project Hours</button>
        <button className={`tab-btn${rtab === "utilization" ? " active" : ""}`} onClick={() => setRtab("utilization")}>Utilization</button>
        <button className={`tab-btn${rtab === "leave" ? " active" : ""}`} onClick={() => setRtab("leave")}>Leave Usage</button>
        <button className={`tab-btn${rtab === "compliance" ? " active" : ""}`} onClick={() => setRtab("compliance")}>Compliance</button>
        <button className={`tab-btn${rtab === "pending" ? " active" : ""}`} onClick={() => setRtab("pending")}>Pending &amp; Overdue</button>
      </div>

      {rtab === "project" ? (
        <div>
          <div className="report-controls">
            <Field label="From"><input type="date" value={rpFrom} onChange={(e) => setRpFrom(e.target.value)} /></Field>
            <Field label="To"><input type="date" value={rpTo} onChange={(e) => setRpTo(e.target.value)} /></Field>
            <button className="btn btn-ghost btn-sm" onClick={runProject}>Run</button>
            <a className="btn btn-ghost btn-sm" href={api.projectHoursCsvUrl(rpFrom, rpTo)} download>Export CSV</a>
          </div>
          <Card>
            {!rpRows ? "Pick a date range and click Run." : rpRows.length ? (
              <table>
                <thead><tr><th>Project</th><th>Employee</th><th>Hours</th></tr></thead>
                <tbody>{rpRows.map((r, i) => <tr key={i}><td>{r.project_name || "Unassigned"}</td><td>{r.user_name}</td><td className="mono">{r.hours}h</td></tr>)}</tbody>
              </table>
            ) : <div style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No approved hours logged in this range.</div>}
          </Card>
        </div>
      ) : null}

      {rtab === "utilization" ? (
        <div>
          <div className="report-controls">
            <Field label="From"><input type="date" value={ruFrom} onChange={(e) => setRuFrom(e.target.value)} /></Field>
            <Field label="To"><input type="date" value={ruTo} onChange={(e) => setRuTo(e.target.value)} /></Field>
            <button className="btn btn-ghost btn-sm" onClick={runUtilization}>Run</button>
            <a className="btn btn-ghost btn-sm" href={api.utilizationCsvUrl(ruFrom, ruTo)} download>Export CSV</a>
          </div>
          <Card>
            {!ruRows ? "Pick a date range and click Run." : ruRows.length ? ruRows.map((r, i) => (
              <div className="util-bar-row" key={i}>
                <div className="bar-label">{r.user_name}</div>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${Math.min(100, r.utilization_pct)}%` }} /></div>
                <div className="bar-value">{r.utilization_pct}%</div>
              </div>
            )) : <div style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No data for this range.</div>}
          </Card>
        </div>
      ) : null}

      {rtab === "leave" ? (
        <div>
          <div className="report-controls">
            <Field label="Year"><input type="number" value={rlYear} onChange={(e) => setRlYear(e.target.value)} /></Field>
            <button className="btn btn-ghost btn-sm" onClick={runLeave}>Run</button>
            <a className="btn btn-ghost btn-sm" href={api.leaveUsageCsvUrl(rlYear)} download>Export CSV</a>
          </div>
          <Card>
            {!rlRows ? "Pick a year and click Run." : rlRows.length ? (
              <table>
                <thead><tr><th>Employee</th><th>Leave Type</th><th>Total</th><th>Used</th><th>Pending</th><th>Remaining</th></tr></thead>
                <tbody>{rlRows.map((r, i) => <tr key={i}><td>{r.user_name}</td><td>{r.type_name}</td><td className="mono">{r.total_days}</td><td className="mono">{r.used_days}</td><td className="mono">{r.pending_days}</td><td className="mono">{r.total_days - r.used_days}</td></tr>)}</tbody>
              </table>
            ) : <div style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No leave balance data for this year.</div>}
          </Card>
        </div>
      ) : null}

      {rtab === "compliance" ? (
        <div>
          <div className="report-controls">
            <Field label="Week starting (Monday)"><input type="date" value={rcWeek} onChange={(e) => setRcWeek(e.target.value)} /></Field>
            <button className="btn btn-ghost btn-sm" onClick={runCompliance}>Run</button>
            <a className="btn btn-ghost btn-sm" href={api.complianceCsvUrl(rcWeek)} download>Export CSV</a>
          </div>
          <Card>
            {!rcRows ? "Pick a week and click Run." : rcRows.length ? (
              <table>
                <thead><tr><th>Employee</th><th>Email</th><th>Status</th></tr></thead>
                <tbody>{rcRows.map((r, i) => <tr key={i}><td>{r.user_name}</td><td className="mono">{r.email}</td><td><span className="stamp rejected">{r.status || "not submitted"}</span></td></tr>)}</tbody>
              </table>
            ) : <div style={{ color: "var(--teal)", fontSize: "0.85rem" }}>Everyone submitted for this week. 🎉</div>}
          </Card>
        </div>
      ) : null}

      {rtab === "pending" ? (
        <Card>
          {!pendingRows ? "Loading…" : pendingRows.length ? (
            <table>
              <thead><tr><th>Type</th><th>ID</th><th>Employee</th><th>Manager</th><th>Days Pending</th><th></th></tr></thead>
              <tbody>{pendingRows.map((r, i) => (
                <tr key={i}>
                  <td>{r.kind}</td><td className="mono">{r.id}</td><td>{r.user_name}</td><td>{r.manager_name || "—"}</td><td className="mono">{r.days_pending}</td>
                  <td>{r.escalated ? <span className="escalated-tag">⚠ escalated</span> : null}</td>
                </tr>
              ))}</tbody>
            </table>
          ) : <div style={{ color: "var(--teal)", fontSize: "0.85rem" }}>Nothing pending. 🎉</div>}
        </Card>
      ) : null}
    </>
  );
}

// ============================================================
// PROFILE
// ============================================================
const AVATAR_COLORS = ["#2F6F5E", "#C08A2E", "#B4483F", "#3D6B6B", "#5B5FA6", "#8A5B3D"];

