import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function AdminPage() {
  const { showToast, showError } = useToast();
  const { openModal, closeModal } = useModal();

  // Directory state
  const [empPage, setEmpPage] = useState(1);
  const [empSearch, setEmpSearch] = useState("");
  const [empDept, setEmpDept] = useState("");
  const [empStatus, setEmpStatus] = useState("");
  const [empSortBy, setEmpSortBy] = useState("name");
  const [empDir, setEmpDir] = useState(null); // { items, total }
  const [depts, setDepts] = useState([]);

  const [types, setTypes] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [settings, setSettings] = useState(null);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [departments, setDepartments] = useState([]);

  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "employee", title: "", dept: "", joinedDate: new Date().toISOString().slice(0, 10), password: "" });

  const [compUserId, setCompUserId] = useState(null);

  const [reloadKey, setReloadKey] = useState(0);
  function reload() { setReloadKey((k) => k + 1); }

  const loadDirectory = useCallback(async () => {
    try {
      const result = await api.getAdminEmployees({ page: empPage, pageSize: 50, search: empSearch, department: empDept, status: empStatus, sortBy: empSortBy, sortDir: "asc" });
      setEmpDir(result);
    } catch (err) { showError(err); }
  }, [empPage, empSearch, empDept, empStatus, empSortBy]);

  useEffect(() => { loadDirectory(); }, [loadDirectory, reloadKey]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // Do not make the entire admin page depend on one auxiliary request.
      // After the SQLite -> PostgreSQL migration, a single broken subsystem
      // could previously leave `settings` null forever and show only a loader.
      const jobs = [
        ["departments", api.getAdminDepartments()],
        ["leave types", api.getLeaveTypes()],
        ["holidays", api.getHolidays()],
        ["settings", api.getSettings()],
        ["projects", api.getProjects(true)],
        ["tasks", api.getTasks(true)],
        ["all departments", api.getDepartments(true)],
      ];
      const results = await Promise.allSettled(jobs.map(([, promise]) => promise));
      if (cancelled) return;

      const failed = [];
      const value = (index, label) => {
        const result = results[index];
        if (result.status === "fulfilled") return result.value;
        failed.push(`${label}: ${result.reason?.message || "request failed"}`);
        return null;
      };

      const adminDepartments = value(0, jobs[0][0]);
      const leaveTypes = value(1, jobs[1][0]);
      const holidayResult = value(2, jobs[2][0]);
      const systemSettings = value(3, jobs[3][0]);
      const projectResult = value(4, jobs[4][0]);
      const taskResult = value(5, jobs[5][0]);
      const allDepartmentResult = value(6, jobs[6][0]);

      if (adminDepartments) setDepts(adminDepartments.departments || []);
      if (leaveTypes) setTypes(leaveTypes);
      if (holidayResult) setHolidays(holidayResult.holidays || []);
      setSettings(systemSettings || {});
      if (projectResult) setProjects(projectResult.projects || []);
      if (taskResult) setTasks(taskResult.tasks || []);
      if (allDepartmentResult) setDepartments(allDepartmentResult.departments || []);

      if (failed.length) showError(new Error(`Admin data: ${failed.join("; ")}`));
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  const debouncedSearch = useMemo(() => debounce((v) => { setEmpPage(1); setEmpSearch(v); }, 300), []);

  function openEmployeeDetails(userId) {
    openModal(`Employee`, <EmployeeDetailsModalBody userId={userId} onSaved={() => { showToast("Employee information updated"); reload(); }} />, null);
  }
  function openGiveHikeFor(userId, empName, currentCtc) {
    openModal(`Give Salary Hike — ${empName}`, <HikeModalBody userId={userId} empName={empName} currentCtc={currentCtc || 0} onApplied={() => { closeModal(); reload(); }} />, null);
  }
  async function openGiveHikeById(userId, empName) {
    try {
      const comp = await api.getEmployeeCompensation(userId);
      openGiveHikeFor(userId, empName, comp.activeStructure ? comp.activeStructure.annual_ctc : 0);
    } catch (err) { showError(err); }
  }
  function openCompensation(userId) { setCompUserId(userId); }

  async function createUser() {
    if (!newUser.name.trim() || !newUser.email.trim()) { showToast("Name and email are required", true); return; }
    try {
      await api.createUser({ ...newUser, name: newUser.name.trim(), email: newUser.email.trim(), dept: newUser.dept.trim(), title: newUser.title.trim(), password: newUser.password.trim() || undefined, joinedDate: newUser.joinedDate || undefined });
      showToast(`User ${newUser.name} created`);
      setShowAddUser(false);
      setNewUser({ name: "", email: "", role: "employee", title: "", dept: "", joinedDate: new Date().toISOString().slice(0, 10), password: "" });
      reload();
    } catch (err) { showError(err); }
  }

  function openImportCsv() {
    let csv = "";
    openModal("Import users from CSV", (
      <>
        <p className="subtle-note" style={{ marginTop: 0 }}>Paste CSV with columns: name, email, role, dept, title. Only name and email are required.</p>
        <div className="field"><textarea style={{ minHeight: "8rem" }} placeholder={"name,email,role,dept\nJane Doe,jane@company.com,employee,Sales"} onChange={(e) => { csv = e.target.value; }} /></div>
      </>
    ), (
      <>
        <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
        <button className="btn btn-primary" onClick={async () => {
          if (!csv.trim()) { showToast("Paste CSV content first", true); return; }
          try {
            const result = await api.importUsersCsv(csv.trim());
            closeModal();
            showToast(`Imported ${result.created} user(s), skipped ${result.skipped}`);
            reload();
          } catch (err) { showError(err); }
        }}>Import</button>
      </>
    ));
  }

  function openAddProject() {
    let name = "", code = "";
    openModal("Add project", (
      <>
        <Field label="Project name"><input type="text" onChange={(e) => { name = e.target.value; }} /></Field>
        <Field label="Code (optional)"><input type="text" placeholder="e.g. CLI-ACME" onChange={(e) => { code = e.target.value; }} /></Field>
      </>
    ), (
      <>
        <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
        <button className="btn btn-primary" onClick={async () => {
          if (!name.trim()) { showToast("Project name is required", true); return; }
          try { await api.addProject({ name: name.trim(), code: code.trim() }); closeModal(); showToast("Project added"); reload(); } catch (err) { showError(err); }
        }}>Add</button>
      </>
    ));
  }

  function openAddTask(projectId, projectName) {
    let name = "";
    openModal(`Add task — ${projectName}`, (
      <Field label="Task name"><input type="text" placeholder="e.g. Development" onChange={(e) => { name = e.target.value; }} /></Field>
    ), (
      <>
        <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
        <button className="btn btn-primary" onClick={async () => {
          if (!name.trim()) { showToast("Task name is required", true); return; }
          try { await api.addTask(projectId, name.trim()); closeModal(); showToast("Task added"); reload(); } catch (err) { showError(err); }
        }}>Add</button>
      </>
    ));
  }

  async function toggleProject(p) {
    try { await api.toggleProject(p.id, p.active ? 0 : 1); showToast(p.active ? "Project deactivated" : "Project activated"); reload(); } catch (err) { showError(err); }
  }

  async function openManageAssignments(project) {
    try {
      const [{ items: allUsers }, { members }] = await Promise.all([api.getUsers(100), api.getProjectAssignments(project.id)]);
      const assignedIds = new Set(members.map((m) => m.id));
      let checked = {};
      allUsers.forEach((u) => { checked[u.id] = assignedIds.has(u.id); });
      openModal(`Assign employees — ${project.name}`, (
        <>
          <div className="checkbox-list">
            {allUsers.filter((u) => u.role !== "admin").map((u) => (
              <label className="checkbox-list-item" key={u.id}>
                <input type="checkbox" defaultChecked={checked[u.id]} onChange={(e) => { checked[u.id] = e.target.checked; }} />
                <span>{u.name} <span style={{ color: "var(--text-dim)" }}>({u.email})</span></span>
              </label>
            ))}
          </div>
          <p className="subtle-note">If no one is assigned, this project falls back to visible-to-everyone.</p>
        </>
      ), (
        <>
          <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
          <button className="btn btn-primary" onClick={async () => {
            const userIds = Object.keys(checked).filter((id) => checked[id]).map((id) => parseInt(id, 10));
            try { await api.saveProjectAssignments(project.id, userIds); closeModal(); showToast("Assignments updated"); } catch (err) { showError(err); }
          }}>Save assignments</button>
        </>
      ));
    } catch (err) { showError(err); }
  }

  function openAddDept() {
    let name = "";
    openModal("Add department", (
      <Field label="Department name"><input type="text" onChange={(e) => { name = e.target.value; }} /></Field>
    ), (
      <>
        <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
        <button className="btn btn-primary" onClick={async () => {
          if (!name.trim()) { showToast("Department name is required", true); return; }
          try { await api.addDepartment(name.trim()); closeModal(); showToast("Department added"); reload(); } catch (err) { showError(err); }
        }}>Add</button>
      </>
    ));
  }
  async function toggleDept(d) {
    try { await api.toggleDepartment(d.id, d.active ? 0 : 1); showToast(d.active ? "Department deactivated" : "Department activated"); reload(); } catch (err) { showError(err); }
  }

  if (!settings) return <PageLoading />;

  return (
    <>
      <PageHead eyebrow="Administration" title="User & System Admin" sub="Manage accounts, projects, departments, leave types, holidays, and system settings."
        actions={<>
          <button className="btn btn-ghost btn-sm" onClick={openImportCsv}>Import CSV</button>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAddUser((v) => !v)}>+ Add user</button>
        </>} />

      {showAddUser ? (
        <Card title="New user">
          <div className="form-grid">
            <Field label="Full name"><input type="text" value={newUser.name} onChange={(e) => setNewUser((u) => ({ ...u, name: e.target.value }))} /></Field>
            <Field label="Email"><input type="email" value={newUser.email} onChange={(e) => setNewUser((u) => ({ ...u, email: e.target.value }))} /></Field>
            <Field label="Role">
              <select value={newUser.role} onChange={(e) => setNewUser((u) => ({ ...u, role: e.target.value }))}>
                <option value="employee">Employee</option><option value="manager">Manager</option><option value="admin">Admin</option>
              </select>
            </Field>
            <Field label="Title"><input type="text" value={newUser.title} onChange={(e) => setNewUser((u) => ({ ...u, title: e.target.value }))} /></Field>
            <Field label="Department">
              <select value={newUser.dept} onChange={(e) => setNewUser((u) => ({ ...u, dept: e.target.value }))}>
                <option value="">— None —</option>
                {departments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
              </select>
            </Field>
            <Field label="Date joined"><input type="date" value={newUser.joinedDate} onChange={(e) => setNewUser((u) => ({ ...u, joinedDate: e.target.value }))} /></Field>
            <Field label="Temporary password"><input type="text" placeholder="changeme123" value={newUser.password} onChange={(e) => setNewUser((u) => ({ ...u, password: e.target.value }))} /></Field>
          </div>
          <div className="form-actions">
            <button className="btn btn-ghost" onClick={() => setShowAddUser(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={createUser}>Create user</button>
          </div>
        </Card>
      ) : null}

      <Card title={`Employee Directory (${empDir ? empDir.total : "…"})`}>
        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.75rem", flexWrap: "wrap" }}>
          <input type="text" placeholder="Search name, email, title..." style={{ flex: 1, minWidth: 150, padding: "0.4rem 0.6rem", border: "1px solid var(--border)", borderRadius: 6 }}
            onChange={(e) => debouncedSearch(e.target.value)} />
          <select style={{ padding: "0.4rem 0.6rem", border: "1px solid var(--border)", borderRadius: 6 }} value={empDept} onChange={(e) => { setEmpPage(1); setEmpDept(e.target.value); }}>
            <option value="">All Departments</option>
            {depts.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
          <select style={{ padding: "0.4rem 0.6rem", border: "1px solid var(--border)", borderRadius: 6 }} value={empStatus} onChange={(e) => { setEmpPage(1); setEmpStatus(e.target.value); }}>
            <option value="">All Status</option><option value="active">Active</option><option value="inactive">Inactive</option>
          </select>
          <select style={{ padding: "0.4rem 0.6rem", border: "1px solid var(--border)", borderRadius: 6 }} value={empSortBy} onChange={(e) => { setEmpPage(1); setEmpSortBy(e.target.value); }}>
            <option value="name">Name</option><option value="annual_ctc">Annual CTC</option><option value="dept">Department</option><option value="joined_date">Joining Date</option>
          </select>
          <button className="btn btn-ghost btn-sm" onClick={loadDirectory}>Refresh</button>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr>
                <th>Name</th><th>Email</th><th>Department</th><th>Title</th><th>Manager</th><th>Joined</th>
                <th>Annual CTC</th><th>Monthly CTC</th><th>Salary Status</th><th>Status</th><th></th><th></th><th></th>
              </tr>
            </thead>
            <tbody>
              {!empDir ? <EmptyRow colSpan={13}>Loading…</EmptyRow> : empDir.items.map((u) => (
                <EmployeeRow key={u.id} u={u} onOpenDetails={openEmployeeDetails} onViewComp={openCompensation} onGiveHike={openGiveHikeById} />
              ))}
            </tbody>
          </table>
        </div>
        {empDir ? (
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "0.5rem", fontSize: "0.85rem" }}>
            <span>Showing {empDir.items.length} of {empDir.total} employees</span>
            <div style={{ display: "flex", gap: "0.4rem" }}>
              <button className="btn btn-ghost btn-sm" disabled={empPage <= 1} onClick={() => setEmpPage((p) => p - 1)}>← Prev</button>
              <button className="btn btn-ghost btn-sm" disabled={empPage * 50 >= empDir.total} onClick={() => setEmpPage((p) => p + 1)}>Next →</button>
            </div>
          </div>
        ) : null}
      </Card>

      {compUserId ? (
        <Card title={<>Employee Compensation <button className="btn btn-ghost btn-sm" style={{ float: "right" }} onClick={() => setCompUserId(null)}>Close</button></>}>
          <CompensationDetail userId={compUserId} onGiveHike={(id, name, ctc) => openGiveHikeFor(id, name, ctc)} />
        </Card>
      ) : null}

      <Card title="Projects & tasks">
        <p className="subtle-note" style={{ marginTop: 0 }}>Employees log timesheet hours against these. Only employees assigned to a project can select it — if a project has no assignments yet, everyone sees it as a fallback.</p>
        <table>
          <thead><tr><th>Project</th><th>Code</th><th>Tasks</th><th>Assigned</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {projects.length === 0 ? <EmptyRow colSpan={6}>No projects yet.</EmptyRow> : projects.map((p) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td className="mono">{p.code || "—"}</td>
                <td>{tasks.filter((t) => t.project_id === p.id).map((t) => t.name).join(", ") || <span style={{ color: "var(--text-dim)" }}>No tasks yet</span>}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => openManageAssignments(p)}>Manage</button></td>
                <td>{p.active ? "Active" : "Inactive"}</td>
                <td>
                  <button className="btn btn-ghost btn-sm" onClick={() => openAddTask(p.id, p.name)}>+ Task</button>{" "}
                  <button className="btn btn-ghost btn-sm" onClick={() => toggleProject(p)}>{p.active ? "Deactivate" : "Activate"}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="form-actions"><button className="btn btn-ghost btn-sm" onClick={openAddProject}>+ Add project</button></div>
      </Card>

      <Card title="Departments">
        <table>
          <thead><tr><th>Name</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {departments.length === 0 ? <EmptyRow colSpan={3}>No departments yet.</EmptyRow> : departments.map((d) => (
              <tr key={d.id}>
                <td>{d.name}</td><td>{d.active ? "Active" : "Inactive"}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => toggleDept(d)}>{d.active ? "Deactivate" : "Activate"}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="form-actions"><button className="btn btn-ghost btn-sm" onClick={openAddDept}>+ Add department</button></div>
      </Card>

      <Card title="Leave types & annual allocation">
        <p className="subtle-note" style={{ marginTop: 0 }}>Carry-forward defines how many unused days roll into next year at year-end.</p>
        <table>
          <thead><tr><th>Leave type</th><th>Default annual days</th><th>Max carry-forward</th><th>Status</th></tr></thead>
          <tbody>
            {types.map((t) => (
              <tr key={t.id}>
                <td>{t.name}</td><td className="mono">{t.default_annual_days || "—"}</td>
                <td className="mono">{t.max_carry_forward_days || 0}</td><td>{t.active ? "Active" : "Inactive"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card title="Company holidays & blackout periods">
        <div style={{ marginBottom: "1rem" }}>
          {holidays.length === 0 ? <span style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No holidays configured.</span> : holidays.map((h) => (
            <span className={`holiday-chip${h.blackout ? " blackout" : ""}`} key={h.id}>{fmtDate(h.holiday_date)} — {h.name} {h.blackout ? "(blackout)" : ""}</span>
          ))}
        </div>
      </Card>

      <Card title="System settings">
        <div className="form-grid">
          <Field label="Standard hours per day"><input type="number" defaultValue={settings.standard_hours_per_day} disabled /></Field>
          <Field label="Timesheet lock (weeks)"><input type="number" defaultValue={settings.timesheet_lock_weeks} disabled /></Field>
          <Field label="Financial year start month"><input type="number" min="1" max="12" defaultValue={settings.financial_year_start_month} disabled /></Field>
          <Field label="Company name"><input type="text" defaultValue={settings.company_name} disabled /></Field>
          <Field label="Submission deadline (weekday, 1=Mon..7=Sun)"><input type="number" min="1" max="7" defaultValue={settings.submission_deadline_day} disabled /></Field>
          <Field label="Escalation threshold (days pending)"><input type="number" defaultValue={settings.escalation_days} disabled /></Field>
        </div>
        <p className="subtle-note">Read-only in this build — matches the original app, where these controls weren't wired to save either.</p>
      </Card>
    </>
  );
}

// ============================================================
// MY SALARY
// ============================================================
