import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function LoginScreen({ onLoggedIn }) {
  const { doLogin } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [clock, setClock] = useState("—");

  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    tick();
    const h = setInterval(tick, 1000);
    return () => clearInterval(h);
  }, []);

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const { mustReset } = await doLogin(email, password);
      onLoggedIn(mustReset);
    } catch (err) {
      setError(err.message || "Invalid email or password. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div id="login-screen">
      <div className="login-hero">
        <span className="hero-orb o1" aria-hidden="true" />
        <span className="hero-orb o2" aria-hidden="true" />
        <span className="hero-orb o3" aria-hidden="true" />
        <div className="brand-mark">
          <div className="vasjo-mark">
            <span className="pix p1" /><span className="pix p2" /><span className="pix p3" />
            <span className="pix p4" /><span className="pix p5" /><span className="pix p6" />
            <div className="stroke-a" /><div className="stroke-b" /><div className="arrowhead" />
            <span className="node n1" /><span className="node n2" /><span className="node n3" />
          </div>
          <div className="vasjo-word">
            <span className="word-main"><span className="vas">VAS</span><span className="jo">JO</span></span>
            <span className="word-sub">TECHNOLOGIES</span>
          </div>
        </div>
        <div className="hero-copy">
          <div className="eyebrow">HRMS · Payroll · ERP</div>
          <h1>Every hour, every rupee, accounted for.</h1>
          <p>Timesheets, leave, approvals, and payroll — run from one calm, precise workspace built for teams who'd rather trust the record than chase it down.</p>
        </div>
        <div className="hero-foot">
          <span>Vasjo Technologies</span>
          <span>{clock}</span>
        </div>
      </div>
      <div className="login-panel">
        <div className="login-box">
          <h2>Sign in</h2>
          <div className="sub">Enter your work email and password.</div>
          <div className={`login-error${error ? " show" : ""}`}>{error || "Invalid email or password. Please try again."}</div>
          <form onSubmit={onSubmit}>
            <Field label="Email">
              <input type="email" placeholder="you@company.com" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Field label="Password">
              <input type="password" placeholder="••••••••" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </Field>
            <button type="submit" className="btn btn-primary btn-block" disabled={busy}>Sign in</button>
          </form>
          <div className="subtle-note" style={{ textAlign: "center", marginTop: "1rem" }}>Forgot your password? Ask your manager or admin to reset it for you.</div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// FORCED PASSWORD RESET SCREEN
// ============================================================
export function ForcedResetScreen({ onDone }) {
  const { completeForcedReset } = useAuth();
  const { showToast } = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      await completeForcedReset(current, next);
      showToast("Password set — welcome in!");
      onDone();
    } catch (err) {
      setError(err.message || "Could not update password");
    }
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh", alignItems: "center", justifyContent: "center", background: "var(--paper)" }}>
      <div className="login-box" style={{ maxWidth: "24rem" }}>
        <h2>Choose a new password</h2>
        <div className="sub">Your administrator set a temporary password. Please set your own before continuing.</div>
        <div className={`login-error${error ? " show" : ""}`}>{error}</div>
        <form onSubmit={onSubmit}>
          <Field label="Temporary password">
            <input type="password" required value={current} onChange={(e) => setCurrent(e.target.value)} />
          </Field>
          <Field label="New password">
            <input type="password" placeholder="At least 8 characters" required minLength={8} value={next} onChange={(e) => setNext(e.target.value)} />
          </Field>
          <button type="submit" className="btn btn-primary btn-block">Continue</button>
        </form>
      </div>
    </div>
  );
}

// ============================================================
// DASHBOARD
// ============================================================
