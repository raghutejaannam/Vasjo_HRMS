import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import * as api from "../../api.js";
import {
  useAuth, useModal, useToast, AuditToggle, ResetPasswordButton, can, isApprover,
  PageHead, Card, StatCard, Stamp, EmptyRow, BarChart, Field,
  PageLoading, PayrollStagePath, EmployeePicker,
  WEEKDAYS, MONTH_NAMES, initials, fmtDate, fmtDateTime, stampClass,
  fmtMoney, fmtMoneyDec, mondayOf, weekDates, toISODate, addWeeks,
  leaveTypeName, debounce,
  NAV_ICONS,
} from "../../components.jsx";

export function EmployeeLifecycleAdminPage() {
  const { showToast, showError } = useToast();
  const [employees, setEmployees] = useState(null);
  const [userId, setUserId] = useState("");
  const [profile, setProfile] = useState(null);
  const [tab, setTab] = useState("timeline");
  const [transferForm, setTransferForm] = useState({ dept: "", title: "", managerId: "", location: "" });
  const [probationForm, setProbationForm] = useState({ startDate: "", durationDays: "90" });
  const [docForm, setDocForm] = useState({ docType: "", filePath: "", issueDate: "", expiryDate: "", localFile: null });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    (async () => { try { const u = await api.getUsers(500); setEmployees(u.items || u || []); } catch (err) { showError(err); } })();
  }, []);

  useEffect(() => {
    if (!userId) { setProfile(null); return; }
    (async () => { try { setProfile(await api.getLifecycleProfile(Number(userId))); } catch (err) { showError(err); } })();
  }, [userId, reloadKey]);

  async function doTransfer(kind) {
    try {
      if (kind === "dept") await api.transferDepartment(Number(userId), { newDept: transferForm.dept });
      if (kind === "title") await api.changeDesignation(Number(userId), { newTitle: transferForm.title });
      if (kind === "manager") await api.changeManager(Number(userId), { newManagerId: Number(transferForm.managerId) });
      if (kind === "location") await api.changeLocation(Number(userId), { newLocation: transferForm.location });
      showToast("Updated");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not update", true); }
  }

  async function doStartProbation(e) {
    e.preventDefault();
    try {
      await api.startProbation(Number(userId), { startDate: probationForm.startDate || undefined, durationDays: Number(probationForm.durationDays) });
      showToast("Probation started");
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not start probation", true); }
  }
  async function doConfirmProbation(id) {
    try { await api.confirmProbation(id); showToast("Probation confirmed"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not confirm", true); }
  }

  async function doUploadDoc(e) {
    e.preventDefault();
    try {
      if (!docForm.localFile && !docForm.filePath.trim()) throw new Error("Choose a local file or enter a file URL/path");
      if (docForm.localFile) {
        await api.uploadEmployeeDocumentLocal(Number(userId), docForm.localFile, docForm);
        showToast("Document uploaded");
      } else {
        await api.uploadEmployeeDocument(Number(userId), docForm);
        showToast("Document recorded");
      }
      setDocForm({ docType: "", filePath: "", issueDate: "", expiryDate: "", localFile: null });
      const picker = document.getElementById("lifecycle-doc-file");
      if (picker) picker.value = "";
      setReloadKey((k) => k + 1);
    } catch (err) { showToast(err.message || "Could not save document", true); }
  }

  async function doCompleteTask(id) {
    try { await api.completeChecklistTask(id); showToast("Task completed"); setReloadKey((k) => k + 1); }
    catch (err) { showToast(err.message || "Could not complete task", true); }
  }

  return (
    <>
      <PageHead eyebrow="Lifecycle" title="Employee Lifecycle" sub="Transfers, promotions, probation, documents and onboarding checklist." />
      <Card title="Select Employee">
        <select className="input-sm" value={userId} onChange={(e) => setUserId(e.target.value)}>
          <option value="">Select…</option>
          {(employees || []).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>
      </Card>

      {!userId ? null : !profile ? <PageLoading /> : (
        <>
          <div className="stat-grid" style={{ marginTop: "1rem" }}>
            <StatCard label="Lifecycle Status" value={profile.lifecycleStatus} />
            <StatCard label="Onboarding Tasks" value={`${profile.onboardingTasks.filter((t) => t.status === "completed").length}/${profile.onboardingTasks.length}`} />
            <StatCard label="Active Probation" value={profile.activeProbation ? "Yes" : "No"} />
            <StatCard label="Documents on File" value={profile.documents.length} />
          </div>

          <div style={{ display: "flex", gap: "0.5rem", margin: "1rem 0" }}>
            {["timeline", "transfer", "probation", "documents", "checklist"].map((t) => (
              <button key={t} className={`btn btn-sm ${tab === t ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>
            ))}
          </div>

          {tab === "timeline" ? (
            <Card title="History">
              <table>
                <thead><tr><th>Date</th><th>Event</th><th>From</th><th>To</th></tr></thead>
                <tbody>
                  {profile.events.length === 0 ? <EmptyRow colSpan={4}>No history yet.</EmptyRow> : profile.events.map((e) => (
                    <tr key={e.id}><td>{fmtDate(e.effective_date)}</td><td>{e.event_type.replace(/_/g, " ")}</td><td>{e.previous_value || "—"}</td><td>{e.new_value || "—"}</td></tr>
                  ))}
                </tbody>
              </table>
            </Card>
          ) : null}

          {tab === "transfer" ? (
            <Card title="Transfers & Promotion">
              <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
                <div style={{ display: "flex", gap: "0.4rem", alignItems: "flex-end" }}>
                  <Field label="Department"><input className="input-sm" value={transferForm.dept} onChange={(e) => setTransferForm({ ...transferForm, dept: e.target.value })} /></Field>
                  <button className="btn btn-ghost btn-sm" onClick={() => doTransfer("dept")}>Transfer</button>
                </div>
                <div style={{ display: "flex", gap: "0.4rem", alignItems: "flex-end" }}>
                  <Field label="Designation"><input className="input-sm" value={transferForm.title} onChange={(e) => setTransferForm({ ...transferForm, title: e.target.value })} /></Field>
                  <button className="btn btn-ghost btn-sm" onClick={() => doTransfer("title")}>Change</button>
                </div>
                <div style={{ display: "flex", gap: "0.4rem", alignItems: "flex-end" }}>
                  <Field label="Manager ID"><input className="input-sm" value={transferForm.managerId} onChange={(e) => setTransferForm({ ...transferForm, managerId: e.target.value })} /></Field>
                  <button className="btn btn-ghost btn-sm" onClick={() => doTransfer("manager")}>Change</button>
                </div>
                <div style={{ display: "flex", gap: "0.4rem", alignItems: "flex-end" }}>
                  <Field label="Location"><input className="input-sm" value={transferForm.location} onChange={(e) => setTransferForm({ ...transferForm, location: e.target.value })} /></Field>
                  <button className="btn btn-ghost btn-sm" onClick={() => doTransfer("location")}>Change</button>
                </div>
              </div>
            </Card>
          ) : null}

          {tab === "probation" ? (
            <Card title="Probation">
              {profile.activeProbation ? (
                <div style={{ marginBottom: "0.8rem" }}>
                  <div>Started {fmtDate(profile.activeProbation.start_date)}, expected end {fmtDate(profile.activeProbation.expected_end_date)}</div>
                  <button className="btn btn-primary btn-sm" style={{ marginTop: "0.4rem" }} onClick={() => doConfirmProbation(profile.activeProbation.id)}>Confirm Probation</button>
                </div>
              ) : (
                <form onSubmit={doStartProbation} style={{ display: "flex", gap: "0.5rem", alignItems: "flex-end" }}>
                  <Field label="Start Date"><input type="date" className="input-sm" value={probationForm.startDate} onChange={(e) => setProbationForm({ ...probationForm, startDate: e.target.value })} /></Field>
                  <Field label="Duration (days)"><input type="number" className="input-sm" value={probationForm.durationDays} onChange={(e) => setProbationForm({ ...probationForm, durationDays: e.target.value })} /></Field>
                  <button className="btn btn-primary btn-sm" type="submit">Start Probation</button>
                </form>
              )}
            </Card>
          ) : null}

          {tab === "documents" ? (
            <Card title="Documents">
              <form onSubmit={doUploadDoc} style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "flex-end", marginBottom: "0.8rem" }}>
                <Field label="Document Type"><input className="input-sm" value={docForm.docType} onChange={(e) => setDocForm({ ...docForm, docType: e.target.value })} required /></Field>
                <Field label="File Path/URL"><input className="input-sm" value={docForm.filePath} onChange={(e) => setDocForm({ ...docForm, filePath: e.target.value })} placeholder="Optional when uploading local file" /></Field>
                <Field label="Upload from Local"><input id="lifecycle-doc-file" className="input-sm" type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx,.csv,.txt" onChange={(e) => setDocForm({ ...docForm, localFile: e.target.files?.[0] || null })} /></Field>
                <Field label="Issue Date"><input type="date" className="input-sm" value={docForm.issueDate} onChange={(e) => setDocForm({ ...docForm, issueDate: e.target.value })} /></Field>
                <Field label="Expiry Date"><input type="date" className="input-sm" value={docForm.expiryDate} onChange={(e) => setDocForm({ ...docForm, expiryDate: e.target.value })} /></Field>
                <button className="btn btn-primary btn-sm" type="submit">Add / Upload</button>
              </form>
              <table>
                <thead><tr><th>Type</th><th>Issued</th><th>Expires</th><th>File</th></tr></thead>
                <tbody>
                  {profile.documents.length === 0 ? <EmptyRow colSpan={4}>No documents on file.</EmptyRow> : profile.documents.map((d) => (
                    <tr key={d.id}>
                      <td>{d.doc_type}</td><td>{d.issue_date ? fmtDate(d.issue_date) : "—"}</td><td>{d.expiry_date ? fmtDate(d.expiry_date) : "—"}</td>
                      <td>{d.file_path ? <button type="button" className="btn btn-ghost btn-sm" onClick={() => window.open(api.employeeDocumentOpenUrl(d.id), "_blank", "noopener,noreferrer")}>Open</button> : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          ) : null}

          {tab === "checklist" ? (
            <Card title="Onboarding Checklist">
              <table>
                <thead><tr><th>Task</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  {profile.onboardingTasks.length === 0 ? <EmptyRow colSpan={3}>No checklist tasks.</EmptyRow> : profile.onboardingTasks.map((t) => (
                    <tr key={t.id}>
                      <td>{t.label}</td><td><Stamp status={t.status === "completed" ? "approved" : "pending"} label={t.status} /></td>
                      <td>{t.status === "pending" ? <button className="btn btn-ghost btn-sm" onClick={() => doCompleteTask(t.id)}>Mark Done</button> : null}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          ) : null}
        </>
      )}
    </>
  );
}

