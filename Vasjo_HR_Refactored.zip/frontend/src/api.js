// Compatibility re-export — API client lives in services/api.js
export * from './services/api.js';
