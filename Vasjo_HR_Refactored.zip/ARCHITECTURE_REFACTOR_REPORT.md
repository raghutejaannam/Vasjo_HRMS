# Vasjo HR — Architectural Refactor Report

**Date:** 2026-09-23  
**Scope:** Structural reorganization only — no business logic, API contract, auth, RBAC, or database semantic changes.

---

## 1. Original Architecture

| Area | State |
|------|--------|
| `backend/src/server.js` | ~1,870 lines — bootstrap + **315 inline routes** |
| `backend/src/db.js` | ~2,806 lines — infra + ~291 exported query functions |
| `backend/src/services/*` | Already domain-split (auth, leave, payroll, …) |
| `backend/src/routes/*` | Partial modularization (p0p1, p2, approvals, documents, …) |
| `frontend/src/pages.jsx` | ~4,537 lines — most core screens |
| `frontend/src/api.js` | ~688 lines — single client |
| `frontend/src/components.jsx` | ~781 lines — shared UI |
| Tests | Flat `tests/*.test.js` |

Stack preserved: Node/Express/Prisma/PostgreSQL (backend), React/Vite (frontend).

---

## 2. Problems Discovered

1. **God files:** `server.js`, `db.js`, `pages.jsx` mixed bootstrap, routing, data access, and UI.
2. **Route logic in bootstrap:** HTTP handlers lived next to middleware and startup.
3. **Monolithic data layer:** All SQL/helpers in one module; hard to own by domain.
4. **Frontend page consolidation:** Unrelated domains (payroll, leave, attendance, admin) in one file.
5. **Tests not domain-organized:** Unit/integration/security mixed at top level.
6. **Some services still large:** `payroll.service.js` (~1,095 lines), `platform.service.js` (~259).
7. **Prisma migrations:** Seven sequential migrations (0001–0007); history intact and must remain append-only.

---

## 3. New Architecture

### Backend

```
backend/src/
  server.js                 # Bootstrap only (~172 lines)
  cors.js, errors.js
  http/error-handler.js
  database/
    prisma.js               # Prisma client
    context.js              # ALS + withRequestContext / withTx
    raw-sql.js              # dbAll / dbGet / dbRun / dbInsert
  db.js                     # Domain queries + facade (uses database/*)
  routes/
    auth.routes.js
    users.routes.js
    lifecycle.routes.js
    notifications.routes.js
    timesheets.routes.js
    leave.routes.js
    leave-advanced.routes.js
    holidays.routes.js
    projects.routes.js
    settings.routes.js
    audit.routes.js
    reports.routes.js
    attendance.routes.js
    compliance.routes.js
    fnf.routes.js
    payroll.routes.js
    platform.routes.js
    health.routes.js
    (+ existing: p0p1, p2, approvals, documents, …)
  services/                 # Unchanged domain services
  controllers/              # Reserved for future thin controllers
  repositories/             # Reserved for further db.js splits
  validators/               # Reserved for Zod schemas by domain
  middleware/               # Reserved for extracted middleware
```

### Frontend

```
frontend/src/
  pages.jsx                 # Thin registry (~178 lines)
  pages/
    auth/, dashboard/, timesheets/, leave/, approvals/,
    employees/, admin/, payroll/, attendance/, compliance/,
    reports/, lifecycle/, …
  services/api.js           # API client (moved)
  api.js                    # Re-export for compatibility
  components.jsx            # Shared UI (still consolidated; further split recommended)
  app/App.jsx               # Copy of App for target structure
  styles/styles.css
```

### Tests

```
tests/
  unit/          # core.unit.test.js, phase1.unit.test.js
  integration/   # regression.test.js
  security/      # authentication-authorization.test.js
  migration/     # migration-safety.test.js
  helpers/       # harness, sqlite-prisma
  *.test.js      # Original paths kept for package.json / CI
```

---

## 4. Files Created

**Backend routes (new):**  
auth, users, lifecycle, notifications, timesheets, leave, leave-advanced, holidays, projects, settings, audit, reports, attendance, compliance, fnf, payroll, platform, health.

**Backend database:**  
`database/prisma.js`, `database/context.js`, `database/raw-sql.js`

**Frontend pages (domain modules):**  
WorkspacePage, AuthScreens, DashboardPage, CalendarPage, Timesheet*, Leave*, ApprovalsPage, TeamTimesheetsPage, ReportsPage, ProfilePage, TeamPage, AdminPage, PayrollPages, AttendancePages, ComplianceFnfPages, LeaveAdminPages, EmployeeLifecycleAdminPage

**Tests structure:** unit/, integration/, security/, migration/ copies + README

---

## 5. Files Moved / Split

| From | To / Result |
|------|-------------|
| server.js (~1870) | server.js (~172) + 18 domain route modules |
| db.js infra | database/{prisma,context,raw-sql}.js; db.js still holds domain queries |
| pages.jsx (~4537) | pages.jsx registry + 19 domain page modules |
| api.js | services/api.js + root re-export |
| styles.css | styles/styles.css (copy); root kept for main.jsx |
| App.jsx | app/App.jsx (copy); root kept for main.jsx |

---

## 6. Files Deleted

**None.** No production code, migrations, seeds, or tests were deleted.

---

## 7. Services Reorganized

Services were already domain-oriented. No aggressive splits applied in this pass.  
**Remaining debt:** `payroll.service.js` (~1095 lines) and large helpers in `utils.js` / `platform.service.js` are candidates for future subdomain splits (runs, tax, benefits, etc.).

---

## 8. Routes Reorganized

- All former inline routes in `server.js` moved into domain `*.routes.js` modules.
- Registration is declarative in `server.js` via `domainRoutes` list + existing modular mounts.
- Handler bodies were moved **verbatim** (no logic rewrite).
- Existing modules (p0p1, p2, approvals, documents, compliance-rules, payroll-controls, analytics, leave-calendar) unchanged.

---

## 9. Database Layer Reorganized

- Infrastructure (Prisma client, ALS context, raw SQL helpers) extracted to `database/`.
- `db.js` requires those modules and continues to export the same surface (~291 functions) so services and routes do not break.
- **Next step (not done in this pass):** move domain query groups into `repositories/*.repository.js` and re-export from `db.js`.

---

## 10. Prisma Findings

- Migrations `0001`–`0007` present; history left intact.
- No renumbering, deletion, or rewrite of applied migrations.
- Schema remains source of truth; no schema changes in this refactor.
- Seed and reset-db scripts untouched.

---

## 11. Tests Reorganized

- Physical layout under unit / integration / security / migration.
- Original top-level `tests/*.test.js` retained so `package.json` scripts and CI keep working.
- No tests removed.

---

## 12. Frontend Reorganized

- Core pages split by domain under `pages/`.
- Registry in `pages.jsx` preserves `PAGES` map and named exports for `App.jsx`.
- advanced / enterprise / p0p1 / p2 page modules left as-is (already separate files).
- API client moved to `services/api.js` with compatibility re-export.
- **Remaining debt:** `components.jsx` still large; payroll pages file still large (~1.1k lines); further component categorization recommended.

---

## 13. Dependencies Removed

**None.** No package.json dependency changes.

---

## 14. API Compatibility

- Route paths, methods, middleware (`requireAuth`, `requirePermission`, CSRF, rate limits), and handler bodies were preserved during extraction.
- No intentional change to request/response shapes or status codes.
- **Validation required:** full regression suite against PostgreSQL (and offline unit suite) after `npm install` + `prisma generate`.

---

## 15–17. Build / Test Results

Environment constraints limited live `npm install` / test runs in this session.  
**Recommended verification sequence:**

```bash
# Backend
cd backend && npm install && npx prisma generate
npm run test:offline    # unit + phase1
npm test                # full suite (needs PG where required)
node -e "require('./src/server.js')"   # load-check

# Frontend
cd frontend && npm install && npm run build
```

Syntax checks performed: `server.js`, `db.js`, `auth.routes.js`, `leave.routes.js`, `payroll.routes.js` — OK.

---

## 18. Remaining Technical Debt

1. **db.js domain split:** Move USER / LEAVE / PAYROLL / ATTENDANCE / FNF / LIFECYCLE query blocks into `repositories/`.
2. **Controller layer:** Introduce thin controllers only where route handlers still hold non-trivial orchestration.
3. **Validators:** Centralize Zod schemas under `validators/` by domain.
4. **payroll.service.js / payroll.routes.js / PayrollPages.jsx:** Further subdomain splits (runs, tax, loans, advances).
5. **components.jsx:** Split into `components/{common,layout,forms,tables,modals,navigation}/`.
6. **Advanced/enterprise/p0p1/p2 page files:** Some are minified single-line modules; pretty-print and domain-folder move when touching them.
7. **CI package.json:** Optionally point `test` script at `tests/unit` + `tests/security` paths once dual layout is stable.
8. **Dead code audit:** After full test pass, run unused-export analysis before any deletion.

---

## Safety Summary

- No historical Prisma migrations altered or deleted.
- No API contracts intentionally changed.
- Auth, CSRF, rate limiting, tenant context (`atomicRequest` + RLS), and RBAC wiring left in place.
- Refactor executed as **extract-and-register**, not rewrite.

