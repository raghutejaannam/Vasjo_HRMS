'use strict';
// Document Center API. NOTE: static paths (/types, /expiring, /upload,
// /import/url) are registered BEFORE '/:id' so the parameter route cannot
// shadow them (this ordering bug made the Document Center page fail to load).
const crypto = require('node:crypto');
const authz = require('../services/authorization.service');
const documents = require('../services/document.service');
const storage = require('../services/storage.service');
const enterprise = require('../services/enterprise.service');
const db = require('../db');
const { asyncHandler } = require('../http/error-handler');
const { ValidationError, BusinessRuleError, ConflictError } = require('../errors');

const asInt = (v, name) => { const n = Number.parseInt(v, 10); if (!Number.isInteger(n)) throw new ValidationError(`${name} must be an integer`); return n; };

module.exports = function registerDocumentRoutes(app, { requireAuth }) {
  const ctx = authz.contextFrom; const P = authz.requirePermission;

  app.get('/api/documents/types', requireAuth, P('document.read'), asyncHandler(async (req, res) => res.json({ types: await documents.listDocumentTypes(ctx(req)) })));
  app.post('/api/documents/types', requireAuth, P('admin.configure'), asyncHandler(async (req, res) => res.status(201).json(await documents.ensureDocumentType(ctx(req), req.body || {}))));
  app.get('/api/documents/expiring', requireAuth, P('document.read'), asyncHandler(async (req, res) => res.json({ documents: await documents.expiringDocuments(ctx(req), req.query.daysAhead === undefined ? 30 : Number(req.query.daysAhead)) })));

  app.get('/api/documents', requireAuth, P('document.read'), asyncHandler(async (req, res) => {
    const owner = req.query.ownerUserId ? asInt(req.query.ownerUserId, 'ownerUserId') : undefined;
    res.json({ documents: await documents.listDocuments(ctx(req), { ownerUserId: owner, module: req.query.module, resourceId: req.query.resourceId, status: req.query.status, search: req.query.search }) });
  }));

  app.post('/api/documents/upload', requireAuth, P('document.upload'), asyncHandler(async (req, res) => {
    const c = ctx(req);
    const buffer = Buffer.isBuffer(req.body) ? req.body : null;
    if (!buffer) throw new ValidationError('Binary request body required (Content-Type: application/octet-stream)');
    const originalFilename = documents.sanitizeFilename(req.query.filename);
    const documentTypeId = req.query.documentTypeId ? asInt(req.query.documentTypeId, 'documentTypeId') : null;
    await documents.validateUpload(c, { filename: originalFilename, size: buffer.length, documentTypeId });
    const mimeType = String(req.headers['x-file-mime'] || 'application/octet-stream').slice(0, 120);
    const scan = await storage.scanBuffer(buffer, originalFilename);
    if (scan.status !== 'clean') throw new BusinessRuleError(scan.reason || 'File failed malware scan', 'MALWARE_DETECTED');
    const ownerUserId = req.query.ownerUserId ? asInt(req.query.ownerUserId, 'ownerUserId') : c.actorId;
    if (ownerUserId !== c.actorId && !authz.hasPermission(c.user, 'document.verify')) return res.status(403).json({ error: 'Forbidden', code: 'FORBIDDEN' });
    const checksum = storage.sha256(buffer);
    const dup = await documents.findDuplicate(c, checksum, ownerUserId);
    if (dup) throw new ConflictError('Duplicate document', 'DUPLICATE_DOCUMENT');
    const doc = await documents.createDocumentRecord(c, { documentTypeId, name: originalFilename, ownerUserId, linkedModule: req.query.module, linkedResourceId: req.query.resourceId, expiresOn: req.query.expiresOn });
    const objectKey = `tenant/${c.tenantId}/documents/${doc.id}/${crypto.randomUUID()}-${crypto.createHash('sha256').update(originalFilename).digest('hex').slice(0, 12)}`;
    await storage.putObject({ objectKey, buffer, contentType: mimeType });
    await documents.addDocumentVersion(c, { documentId: doc.id, objectKey, checksum, sizeBytes: buffer.length, mimeType, source: 'local', originalFilename });
    res.status(201).json({ documentId: doc.id, checksum, version: 1 });
  }));

  app.get('/api/documents/:id', requireAuth, P('document.read'), asyncHandler(async (req, res) => {
    const d = await documents.getAccessibleDocument(ctx(req), req.params.id);
    d.versions = await documents.listDocumentVersions(ctx(req), req.params.id);
    delete d.object_key; // storage reference is internal
    res.json(d);
  }));

  app.post('/api/documents/:id/versions', requireAuth, P('document.upload'), asyncHandler(async (req, res) => {
    const c = ctx(req);
    const buffer = Buffer.isBuffer(req.body) ? req.body : null;
    if (!buffer) throw new ValidationError('Binary request body required');
    const d = await documents.getAccessibleDocument(c, req.params.id);
    const name = documents.sanitizeFilename(req.query.filename || d.original_filename || 'replacement');
    await documents.validateUpload(c, { filename: name, size: buffer.length, documentTypeId: d.document_type_id });
    const mimeType = String(req.headers['x-file-mime'] || d.mime_type || 'application/octet-stream').slice(0, 120);
    const scan = await storage.scanBuffer(buffer, name);
    if (scan.status !== 'clean') throw new BusinessRuleError(scan.reason || 'File failed malware scan', 'MALWARE_DETECTED');
    const checksum = storage.sha256(buffer);
    const dup = await documents.findDuplicate(c, checksum, d.owner_user_id);
    if (dup) throw new ConflictError('Duplicate document version', 'DUPLICATE_DOCUMENT');
    const objectKey = `tenant/${c.tenantId}/documents/${d.id}/${crypto.randomUUID()}`;
    await storage.putObject({ objectKey, buffer, contentType: mimeType });
    const v = await documents.addDocumentVersion(c, { documentId: d.id, objectKey, checksum, sizeBytes: buffer.length, mimeType, source: 'local', originalFilename: name, uploadReason: req.query.reason });
    res.status(201).json({ versionId: v.id, versionNo: v.version_no });
  }));

  // Returns { url } for signed storage, otherwise streams the bytes.
  app.get('/api/documents/:id/download', requireAuth, P('document.read'), asyncHandler(async (req, res) => {
    const c = ctx(req);
    const d = await documents.getAccessibleDocument(c, req.params.id);
    if (!d.object_key) throw new BusinessRuleError('Document has no stored file', 'NO_FILE');
    await enterprise.audit(c, 'document.download', 'document', d.id, null, { versionId: d.current_version_id });
    const signed = storage.getDownloadUrl(d.object_key, 120);
    if (signed) return res.json({ url: signed, expiresIn: 120 });
    const buf = await storage.getObject({ objectKey: d.object_key });
    res.setHeader('Content-Type', d.mime_type || 'application/octet-stream');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Disposition', `attachment; filename="${String(d.original_filename || 'document').replace(/["\r\n]/g, '')}"`);
    return res.send(buf);
  }));

  app.delete('/api/documents/:id', requireAuth, P('document.read'), asyncHandler(async (req, res) => res.json(await documents.archiveDocument(ctx(req), req.params.id))));
  app.post('/api/documents/:id/verify', requireAuth, P('document.verify'), asyncHandler(async (req, res) => res.json(await documents.verifyDocument(ctx(req), req.params.id, req.body?.status, req.body?.reason))));
  app.post('/api/documents/:id/restore/:versionId', requireAuth, P('document.verify'), asyncHandler(async (req, res) => res.json(await documents.restoreVersion(ctx(req), req.params.id, req.params.versionId, req.body?.reason))));
  app.post('/api/documents/:id/link', requireAuth, P('document.upload'), asyncHandler(async (req, res) => { await documents.linkDocument(ctx(req), { documentId: req.params.id, resourceType: req.body?.resourceType, resourceId: req.body?.resourceId }); res.json({ ok: true }); }));
};
