'use strict';

// Canonical backend service bundle. Domain implementations live here and are
// exposed by service name for the server, seed script, and tests.
const factories = {
  "utils": function (require, module, exports) {
// src/utils.js — genuinely shared helpers used across the backend.
// Ported as-is from the original src/db.js / src/server.js (SQLite/custom-HTTP
// version) — logic unchanged, only relocated.

// parseInt(x) || fallback is a common trap: it silently replaces a legitimate
// 0 with the fallback, since 0 is falsy in JS. Settings like escalation_days
// or timesheet_lock_weeks can validly be 0 (e.g. "escalate immediately",
// "no grace period"), so this checks for NaN specifically instead.
function numSetting(value, fallback) {
  const n = parseFloat(value);
  return Number.isNaN(n) ? fallback : n;
}

// Produces the exact same 'YYYY-MM-DD HH:MM:SS' (UTC) text SQLite's
// datetime('now') used to produce. Stored in TEXT columns and returned
// verbatim to the frontend, so the format must not change.
function nowStr() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

// Same format, offset by a number of days (used for escalation windows and
// other "older than N days" comparisons that used to be
// datetime('now', '-N days') in SQLite).
function nowStrOffsetDays(days) {
  const d = new Date(Date.now() + days * 86400000);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

function todayStr() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

function csvEscape(val) {
  if (val === null || val === undefined) return '';
  const s = String(val);
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function genericCsv(rows) {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  return [headers.join(','), ...rows.map(r => headers.map(h => csvEscape(r[h])).join(','))].join('\n');
}

function daysInYear(year) {
  return ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) ? 366 : 365;
}

// Prorate annual leave from the employee's joining date. A missing joining
// date keeps the configured annual entitlement unchanged.
function proratedAnnualLeave(joinedDate, annualDays, year) {
  if (!joinedDate || !annualDays) return Number(annualDays || 0);
  const joined = new Date(joinedDate + 'T00:00:00');
  if (Number.isNaN(joined.getTime())) return Number(annualDays || 0);
  const start = new Date(year, 0, 1);
  const end = new Date(year, 11, 31);
  if (joined > end) return 0;
  const effectiveStart = joined > start ? joined : start;
  const eligibleDays = Math.floor((end - effectiveStart) / 86400000) + 1;
  return Math.round((annualDays * eligibleDays / daysInYear(year)) * 2) / 2;
}

function businessDaysBetween(fromStr, toStr) {
  const from = new Date(fromStr + 'T00:00:00');
  const to = new Date(toStr + 'T00:00:00');
  let count = 0;
  const d = new Date(from);
  while (d <= to) {
    const day = d.getDay();
    if (day !== 0 && day !== 6) count++;
    d.setDate(d.getDate() + 1);
  }
  return count;
}

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

// Converts "HH:MM" (24-hour, what <input type="time"> sends) to minutes since
// midnight. Returns null if not a valid time string.
function parseTimeToMinutes(t) {
  if (!t || typeof t !== 'string') return null;
  const m = TIME_RE.exec(t.trim());
  if (!m) return null;
  return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
}

// The only place that turns an in_time/out_time pair into decimal hours.
// Server-side is the source of truth — never trusts client-computed hours —
// so a tampered or buggy client can't inflate a timesheet.
function computeRowHours(inTime, outTime) {
  const inMin = parseTimeToMinutes(inTime);
  const outMin = parseTimeToMinutes(outTime);
  if (inMin === null || outMin === null) return 0;
  const diff = (outMin - inMin) / 60;
  return diff > 0 ? Math.round(diff * 100) / 100 : 0;
}

// A row counts as "provided" if the person has started filling it in at all —
// used to tell "empty placeholder row" apart from "row with a real mistake".
function rowHasContent(e) {
  return !!(e.inTime || e.outTime || (e.note && e.note.trim()));
}

function validateEntriesBasic(entries) {
  for (const e of entries) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(e.date)) {
      const err = new Error(`Invalid date: ${e.date}`);
      err.code = 'INVALID_DATE';
      throw err;
    }
    if (!rowHasContent(e)) continue; // blank row, nothing to validate
    const inMin = parseTimeToMinutes(e.inTime);
    const outMin = parseTimeToMinutes(e.outTime);
    if (inMin === null || outMin === null) {
      const err = new Error(`Both In Time and Out Time are required for ${e.date}`);
      err.code = 'INCOMPLETE_TIME_ROW';
      throw err;
    }
    if (outMin <= inMin) {
      const err = new Error(`Out Time must be after In Time on ${e.date}`);
      err.code = 'INVALID_TIME_RANGE';
      throw err;
    }
    const hours = (outMin - inMin) / 60;
    if (hours > 24) {
      const err = new Error(`That's more than 24 hours in a single entry on ${e.date}`);
      err.code = 'INVALID_HOURS';
      throw err;
    }
  }
}

function validateEntriesForSubmit(entries) {
  validateEntriesBasic(entries);
}

// ---------------------------------------------------------------------------
// SAFE ARITHMETIC FORMULA EVALUATOR — used by salary components whose
// calculation_type is 'formula' (e.g. "monthlyBasic*0.4 + 500"). This is a
// hand-rolled recursive-descent parser over +,-,*,/,(),numbers and a
// whitelisted set of variable names — never eval()/Function() on
// user-supplied text, since formulas are admin-entered but still untrusted
// input as far as code execution is concerned.
// ---------------------------------------------------------------------------

function evaluateArithmeticFormula(formula, variables = {}) {
  const src = String(formula || '').trim();
  if (!src) throw new Error('Empty formula');
  let pos = 0;

  function peek() { return src[pos]; }
  function isDigit(c) { return c >= '0' && c <= '9'; }
  function isIdentStart(c) { return /[A-Za-z_]/.test(c); }
  function isIdentChar(c) { return /[A-Za-z0-9_]/.test(c); }
  function skipWs() { while (pos < src.length && /\s/.test(src[pos])) pos++; }

  function parseNumber() {
    let start = pos;
    while (pos < src.length && (isDigit(src[pos]) || src[pos] === '.')) pos++;
    const text = src.slice(start, pos);
    if (!text || Number.isNaN(Number(text))) throw new Error(`Invalid number near "${text}" in formula`);
    return Number(text);
  }

  function parseIdentifier() {
    let start = pos;
    while (pos < src.length && isIdentChar(src[pos])) pos++;
    const name = src.slice(start, pos);
    if (!(name in variables)) throw new Error(`Unknown variable "${name}" in formula`);
    return Number(variables[name]) || 0;
  }

  function parseFactor() {
    skipWs();
    const c = peek();
    if (c === '(') {
      pos++;
      const v = parseExpr();
      skipWs();
      if (peek() !== ')') throw new Error('Missing closing parenthesis in formula');
      pos++;
      return v;
    }
    if (c === '-') { pos++; return -parseFactor(); }
    if (c === '+') { pos++; return parseFactor(); }
    if (c !== undefined && isDigit(c)) return parseNumber();
    if (c !== undefined && isIdentStart(c)) return parseIdentifier();
    throw new Error(`Unexpected character "${c}" in formula`);
  }

  function parseTerm() {
    let v = parseFactor();
    skipWs();
    while (peek() === '*' || peek() === '/') {
      const op = peek(); pos++;
      const rhs = parseFactor();
      v = op === '*' ? v * rhs : v / rhs;
      skipWs();
    }
    return v;
  }

  function parseExpr() {
    let v = parseTerm();
    skipWs();
    while (peek() === '+' || peek() === '-') {
      const op = peek(); pos++;
      const rhs = parseTerm();
      v = op === '+' ? v + rhs : v - rhs;
      skipWs();
    }
    return v;
  }

  const result = parseExpr();
  skipWs();
  if (pos !== src.length) throw new Error(`Unexpected trailing text in formula near position ${pos}`);
  if (!Number.isFinite(result)) throw new Error('Formula did not evaluate to a finite number');
  return result;
}

// Evaluates a salary component's conditional_rule JSON, e.g.
// {"variable":"monthlyBasic","operator":">","threshold":50000,"thenValue":2000,"elseValue":1000}
// operator is one of > >= < <= ==. Returns thenValue or elseValue.
function evaluateConditionalRule(ruleJson, variables = {}) {
  const rule = typeof ruleJson === 'string' ? JSON.parse(ruleJson) : ruleJson;
  const left = Number(variables[rule.variable]) || 0;
  const threshold = Number(rule.threshold) || 0;
  let matched;
  switch (rule.operator) {
    case '>': matched = left > threshold; break;
    case '>=': matched = left >= threshold; break;
    case '<': matched = left < threshold; break;
    case '<=': matched = left <= threshold; break;
    case '==': matched = left === threshold; break;
    default: throw new Error(`Unknown conditional operator "${rule.operator}"`);
  }
  return Number(matched ? rule.thenValue : rule.elseValue) || 0;
}

// Reducing-balance EMI (equated monthly instalment) for employee loans.
// annualRatePercent === 0 -> simple equal principal instalments.
function computeEmi(principal, annualRatePercent, tenureMonths) {
  principal = Number(principal) || 0;
  tenureMonths = Math.max(1, Math.round(Number(tenureMonths) || 1));
  const rate = Number(annualRatePercent) || 0;
  if (rate <= 0) return Math.round((principal / tenureMonths) * 100) / 100;
  const r = rate / 12 / 100;
  const emi = (principal * r * Math.pow(1 + r, tenureMonths)) / (Math.pow(1 + r, tenureMonths) - 1);
  return Math.round(emi * 100) / 100;
}

// Completed years of service for gratuity purposes (Payment of Gratuity
// Act, 1972 convention: a "year" with 6+ completed months counts as a full
// year of service).
function yearsOfService(joinedDateStr, asOfDateStr) {
  const joined = new Date((joinedDateStr || '') + 'T00:00:00');
  const asOf = new Date((asOfDateStr || todayStr()) + 'T00:00:00');
  if (Number.isNaN(joined.getTime()) || Number.isNaN(asOf.getTime()) || asOf < joined) return 0;
  let years = asOf.getUTCFullYear() - joined.getUTCFullYear();
  let months = asOf.getUTCMonth() - joined.getUTCMonth();
  let days = asOf.getUTCDate() - joined.getUTCDate();
  if (days < 0) months -= 1;
  if (months < 0) { years -= 1; months += 12; }
  if (months >= 6) years += 1;
  return Math.max(0, years);
}

module.exports = {
  numSetting,
  nowStr,
  nowStrOffsetDays,
  todayStr,
  csvEscape,
  genericCsv,
  daysInYear,
  proratedAnnualLeave,
  businessDaysBetween,
  parseTimeToMinutes,
  computeRowHours,
  rowHasContent,
  validateEntriesBasic,
  validateEntriesForSubmit,
  evaluateArithmeticFormula,
  evaluateConditionalRule,
  computeEmi,
  yearsOfService,
};

  },
  "integrationAdapters": function (require, module, exports) {
'use strict';

/**
 * P3 Integration Hub adapter boundary.
 * Vendor-specific behavior must live here rather than inside HR domain modules.
 * Adapters intentionally fail closed when credentials/configuration are absent.
 */

class IntegrationAdapter {
  constructor(provider) { this.provider = provider; }
  async test(context) { return { ok: false, provider: this.provider, message: 'Adapter not configured' }; }
  async push(context, payload) { return { ok: false, provider: this.provider, message: 'Outbound adapter not configured' }; }
  async pull(context, options = {}) { return { ok: false, provider: this.provider, message: 'Inbound adapter not configured', options }; }
  async disconnect(context) { return { ok: true, provider: this.provider, disconnected: true }; }
}

const PROVIDERS = ['microsoft-entra','google-workspace','google-drive','sharepoint','onedrive','teams','slack','tally','erp','banks','biometric','email','sms'];
const adapters = Object.fromEntries(PROVIDERS.map(provider => [provider, new IntegrationAdapter(provider)]));

function getAdapter(provider) {
  const key = String(provider || '').trim().toLowerCase();
  return adapters[key] || new IntegrationAdapter(key || 'unknown');
}

function listAdapters() {
  return PROVIDERS.map(provider => ({ provider, supported: true, configured: false }));
}

module.exports = { IntegrationAdapter, getAdapter, listAdapters };

  },
  "auth": function (require, module, exports) {
// src/auth.js — authentication middleware, session handling, password
// hashing/verification, and role checks. Ported behavior-for-behavior from
// the original src/db.js (session/password sections) and src/server.js
// (the auth-related request handling), now as Express middleware.

const crypto = require('node:crypto');
const db = require('./db');
const { nowStr } = require('./utils');

// ---------------------------------------------------------------------------
// PASSWORD HELPERS (unchanged: scrypt, same params, same output shape)
// ---------------------------------------------------------------------------

function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

function verifyPassword(password, hash, salt) {
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  const a = Buffer.from(check, 'hex');
  const b = Buffer.from(hash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// Used both by seed data (real onboarded users get a unique temp password
// each, not a shared default) and by admin/manager-initiated password reset.
const TEMP_PW_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'; // no ambiguous chars
function generateTempPassword() {
  let out = '';
  const bytes = crypto.randomBytes(10);
  for (let i = 0; i < 10; i++) out += TEMP_PW_CHARS[bytes[i] % TEMP_PW_CHARS.length];
  return out;
}

// ---------------------------------------------------------------------------
// SESSIONS
// ---------------------------------------------------------------------------

const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

async function createSession(userId, tenantId) {
  const tenant = tenantId || (await db.dbGet("SELECT tenant_id FROM tenant_memberships WHERE user_id=? AND status='active' ORDER BY tenant_id LIMIT 1", [userId]))?.tenant_id || 1;
  const token = crypto.randomBytes(32).toString('hex');
  const csrfToken = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();
  await db.dbRun('INSERT INTO sessions (token, csrf_token, user_id, expires_at, tenant_id) VALUES (?, ?, ?, ?, ?)', [token, csrfToken, userId, expiresAt, tenant]);
  return { token, csrfToken };
}

async function getSessionUser(token) {
  if (!token) return null;
  const row = await db.authLookup((tx) => db.dbGet(`
    SELECT s.expires_at, s.csrf_token, s.tenant_id AS session_tenant_id, u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?
  `, [token], tx));
  if (!row) return null;
  if (new Date(row.expires_at) < new Date()) {
    await db.dbRun('DELETE FROM sessions WHERE token = ?', [token]);
    return null;
  }
  if (!['active', 1, true].includes(row.active)) return null;
  const csrfToken = row.csrf_token;
  row.tenant_id = row.session_tenant_id;
  delete row.password_hash;
  delete row.password_salt;
  delete row.expires_at;
  delete row.csrf_token;
  delete row.session_tenant_id;
  row._csrfToken = csrfToken;
  return row;
}

async function deleteSession(token) {
  await db.dbRun('DELETE FROM sessions WHERE token = ?', [token]);
}

async function deleteAllSessionsForUser(userId) {
  await db.dbRun('DELETE FROM sessions WHERE user_id = ?', [userId]);
}

// ---------------------------------------------------------------------------
// LOGIN RATE LIMITING (in-memory — resets on server restart, same as before)
// ---------------------------------------------------------------------------

const loginAttempts = new Map(); // email -> { count, lockedUntil }
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

function checkLoginLock(email) {
  const rec = loginAttempts.get(email.toLowerCase());
  if (!rec) return { locked: false };
  if (rec.lockedUntil && rec.lockedUntil > Date.now()) {
    return { locked: true, retryAfterMs: rec.lockedUntil - Date.now() };
  }
  return { locked: false };
}

function recordLoginFailure(email) {
  const key = email.toLowerCase();
  const rec = loginAttempts.get(key) || { count: 0, lockedUntil: 0 };
  rec.count += 1;
  if (rec.count >= MAX_ATTEMPTS) {
    rec.lockedUntil = Date.now() + LOCKOUT_MS;
    rec.count = 0;
  }
  loginAttempts.set(key, rec);
}

function clearLoginFailures(email) {
  loginAttempts.delete(email.toLowerCase());
}


async function listSessions(userId, currentToken) {
  const rows = await db.dbAll('SELECT token,created_at,expires_at FROM sessions WHERE user_id=? ORDER BY created_at DESC',[userId]);
  return rows.map(r=>({ ...r, current: r.token===currentToken, token: `${r.token.slice(0,8)}…` }));
}
async function revokeSession(token,userId) { await db.dbRun('DELETE FROM sessions WHERE token=? AND user_id=?',[token,userId]); }

// ---------------------------------------------------------------------------
// ADMIN/MANAGER-INITIATED PASSWORD RESET
// ---------------------------------------------------------------------------

async function adminResetPassword(userId) {
  const tempPassword = generateTempPassword();
  const pw = hashPassword(tempPassword);
  await db.dbRun('UPDATE users SET password_hash = ?, password_salt = ?, must_reset_password = 1 WHERE id = ?', [pw.hash, pw.salt, userId]);
  await deleteAllSessionsForUser(userId);
  return tempPassword;
}

async function changePassword(userId, currentPassword, newPassword) {
  const user = await db.dbGet('SELECT * FROM users WHERE id = ?', [userId]);
  if (!verifyPassword(currentPassword, user.password_hash, user.password_salt)) {
    const err = new Error('Current password is incorrect');
    err.code = 'BAD_CURRENT_PASSWORD';
    throw err;
  }
  const pw = hashPassword(newPassword);
  await db.dbRun('UPDATE users SET password_hash = ?, password_salt = ?, must_reset_password = 0 WHERE id = ?', [pw.hash, pw.salt, userId]);
}


async function enrichEnterpriseIdentity(user) {
  if (!user?.tenant_id) return user;
  const rows = await db.dbAll('SELECT DISTINCT p.code FROM user_roles ur JOIN roles r ON r.id=ur.role_id JOIN role_permissions rp ON rp.role_id=r.id JOIN permissions p ON p.id=rp.permission_id WHERE ur.tenant_id=? AND ur.user_id=?',[user.tenant_id,user.id]);
  if (rows.length) user.permissions = rows.map(r=>r.code);
  else {
    const fallback = {
      admin:['employee.*','lifecycle.*','document.read','document.upload','document.verify','workflow.manage','workflow.act','audit.read','reports.read','admin.configure','payroll.read','payroll.calculate','payroll.review','payroll.approve','payroll.lock'],
      manager:['employee.read','document.read','document.upload','workflow.act','leave.approve','timesheet.approve','reports.read'],
      employee:['document.self','document.read','document.upload'],
    };
    user.permissions = fallback[user.role] || fallback.employee;
  }
  const tenant = await db.dbGet('SELECT id,name,timezone,locale,currency,country,status,subscription_plan FROM tenants WHERE id=?',[user.tenant_id]);
  user.tenant = tenant || { id:user.tenant_id };
  return user;
}

// ---------------------------------------------------------------------------
// EXPRESS MIDDLEWARE
// ---------------------------------------------------------------------------

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  header.split(';').forEach(pair => {
    const idx = pair.indexOf('=');
    if (idx === -1) return;
    const k = pair.slice(0, idx).trim();
    const v = pair.slice(idx + 1).trim();
    out[k] = decodeURIComponent(v);
  });
  return out;
}

const MUTATING_METHODS = new Set(['POST', 'PATCH', 'PUT', 'DELETE']);
// endpoints exempt from CSRF because they run before a session exists
const CSRF_EXEMPT = new Set(['/api/login']);

// Resolves req.session = { token, user } for every request. Does not itself
// reject unauthenticated requests — /api/login and /api/me (GET) need to run
// without one. requireAuth below enforces the actual "must be signed in" gate.
async function attachSession(req, res, next) {
  try {
    const cookies = parseCookies(req);
    const token = cookies.session;
    const user = await getSessionUser(token);
    if (user) await enrichEnterpriseIdentity(user);
    req.session = { token, user };
    next();
  } catch (e) {
    next(e);
  }
}

function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) return res.status(401).json({ error: 'Not signed in' });
  next();
}

// CSRF check for mutating requests — same header/cookie double-submit scheme
// as before.
function csrfProtection(req, res, next) {
  if (MUTATING_METHODS.has(req.method) && !CSRF_EXEMPT.has(req.path)) {
    const user = req.session && req.session.user;
    const csrfHeader = req.headers['x-csrf-token'];
    if (!user || !csrfHeader || csrfHeader !== user._csrfToken) {
      return res.status(403).json({ error: 'Invalid or missing CSRF token' });
    }
  }
  next();
}

function requireRole(user, roles) {
  return !!(user && roles.includes(user.role));
}

// Express middleware factory: requireRoleMw(['admin']) etc.
function requireRoleMw(roles) {
  return (req, res, next) => {
    if (!requireRole(req.session.user, roles)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
}

module.exports = {
  hashPassword,
  verifyPassword,
  generateTempPassword,
  createSession,
  getSessionUser,
  deleteSession,
  deleteAllSessionsForUser,
  listSessions,
  revokeSession,
  enrichEnterpriseIdentity,
  checkLoginLock,
  recordLoginFailure,
  clearLoginFailures,
  adminResetPassword,
  changePassword,
  parseCookies,
  attachSession,
  requireAuth,
  csrfProtection,
  requireRole,
  requireRoleMw,
  MUTATING_METHODS,
  CSRF_EXEMPT,
};

  },
  "attendance": function (require, module, exports) {
// src/attendance.js — BLOCK 2: Advanced Attendance Management
//
// Daily check-in/check-out, shift assignment, attendance correction
// ("regularization") requests, the monthly attendance calendar, and the
// summary payroll.js consumes for loss-of-pay (LOP) calculation.
//
// Deliberately requires only db.js and utils.js (not payroll.js), so
// payroll.js can safely require this module without a circular dependency.

const db = require('./db');
const { nowStr, todayStr } = require('./utils');

function roundMoney(n) { return Math.round((Number(n) || 0) * 100) / 100; }

function daysInMonthUTC(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function minutesBetween(aStr, bStr) {
  // Both are 'YYYY-MM-DD HH:MM:SS' UTC strings (see utils.nowStr).
  const a = new Date(aStr.replace(' ', 'T') + 'Z');
  const b = new Date(bStr.replace(' ', 'T') + 'Z');
  return Math.round((b - a) / 60000);
}

function minutesSinceMidnight(timeHHMM) {
  const [h, m] = String(timeHHMM).split(':').map(Number);
  return h * 60 + m;
}

// ---------------------------------------------------------------------------
// SHIFTS
// ---------------------------------------------------------------------------

async function createShift(data) {
  if (!data.code || !data.name || !data.startTime || !data.endTime) {
    throw new Error('code, name, startTime and endTime are required');
  }
  return db.createShift(data);
}

async function assignShift({ userId, shiftId, effectiveFrom, createdBy }) {
  const shift = await db.getShift(shiftId);
  if (!shift) throw new Error('Shift not found');
  return db.assignShift(userId, shiftId, effectiveFrom || todayStr(), createdBy);
}

async function resolveShiftForUser(userId, date) {
  const assigned = await db.getShiftForUserOnDate(userId, date);
  if (assigned) return assigned;
  // No explicit assignment — fall back to whichever active shift was
  // created first, so a freshly-seeded company always has a working
  // default instead of every check-in failing for lack of a shift.
  const shifts = await db.listShifts(true);
  return shifts[0] || null;
}

// ---------------------------------------------------------------------------
// CHECK-IN / CHECK-OUT
// ---------------------------------------------------------------------------

async function checkIn(userId, timestamp) {
  timestamp = timestamp || nowStr();
  const date = timestamp.slice(0, 10);
  const existing = await db.getAttendanceRecord(userId, date);
  if (existing && existing.check_in_at) throw new Error('Already checked in today');

  const shift = await resolveShiftForUser(userId, date);
  let lateMinutes = 0;
  if (shift) {
    const shiftStartMinutes = minutesSinceMidnight(shift.start_time);
    const [, hh, mm] = timestamp.match(/(\d{2}):(\d{2}):\d{2}$/) || [null, '00', '00'];
    const checkInMinutes = Number(hh) * 60 + Number(mm);
    lateMinutes = Math.max(0, checkInMinutes - shiftStartMinutes - (shift.grace_period_minutes || 0));
  }

  await db.upsertAttendanceRecord({
    userId, date, shiftId: shift ? shift.id : null, checkInAt: timestamp,
    status: 'present', workedMinutes: 0, lateMinutes, earlyLeaveMinutes: 0, source: 'check_in_out',
  });
  return { date, checkInAt: timestamp, lateMinutes, shift: shift ? shift.code : null };
}

async function checkOut(userId, timestamp) {
  timestamp = timestamp || nowStr();
  const date = timestamp.slice(0, 10);
  const existing = await db.getAttendanceRecord(userId, date);
  if (!existing || !existing.check_in_at) throw new Error('No check-in found for today — check in first');
  if (existing.check_out_at) throw new Error('Already checked out today');

  const shift = existing.shift_id ? await db.getShift(existing.shift_id) : await resolveShiftForUser(userId, date);
  const grossMinutes = Math.max(0, minutesBetween(existing.check_in_at, timestamp));
  const workedMinutes = Math.max(0, grossMinutes - (shift ? shift.break_minutes || 0 : 0));

  let earlyLeaveMinutes = 0;
  let status = 'present';
  if (shift) {
    const shiftEndMinutes = minutesSinceMidnight(shift.end_time);
    const [, hh, mm] = timestamp.match(/(\d{2}):(\d{2}):\d{2}$/) || [null, '00', '00'];
    const checkOutMinutes = Number(hh) * 60 + Number(mm);
    earlyLeaveMinutes = Math.max(0, shiftEndMinutes - checkOutMinutes);
    if (workedMinutes < shift.half_day_min_minutes) status = 'absent';
    else if (workedMinutes < shift.full_day_min_minutes) status = 'half_day';
    else status = 'present';
  }

  await db.upsertAttendanceRecord({
    userId, date, shiftId: shift ? shift.id : existing.shift_id, checkInAt: existing.check_in_at, checkOutAt: timestamp,
    status, workedMinutes, lateMinutes: existing.late_minutes, earlyLeaveMinutes, source: 'check_in_out',
  });
  return { date, checkOutAt: timestamp, workedMinutes, earlyLeaveMinutes, status };
}

// ---------------------------------------------------------------------------
// MANUAL / ADMIN MARKING (WFH, on-duty, holiday, absent, leave, etc.)
// ---------------------------------------------------------------------------

const MANUAL_STATUSES = ['present', 'absent', 'half_day', 'wfh', 'on_duty', 'holiday', 'weekly_off', 'leave'];

async function markAttendance({ userId, date, status, actorId, notes }) {
  if (!MANUAL_STATUSES.includes(status)) throw new Error(`status must be one of: ${MANUAL_STATUSES.join(', ')}`);
  await db.upsertAttendanceRecord({ userId, date, status, source: 'manual', markedBy: actorId, notes });
  return db.getAttendanceRecord(userId, date);
}

// ---------------------------------------------------------------------------
// CORRECTION / REGULARIZATION REQUESTS
// ---------------------------------------------------------------------------

async function requestCorrection({ userId, date, requestedCheckInAt, requestedCheckOutAt, requestedStatus, reason }) {
  if (!reason || !reason.trim()) throw new Error('A reason is required for an attendance correction request');
  if (!requestedCheckInAt && !requestedCheckOutAt && !requestedStatus) {
    throw new Error('Provide a requested check-in/check-out time or a requested status');
  }
  const existing = await db.getAttendanceRecord(userId, date);
  return db.createAttendanceCorrectionRequest({
    userId, date, attendanceRecordId: existing ? existing.id : null,
    requestedCheckInAt, requestedCheckOutAt, requestedStatus, reason: reason.trim(),
  });
}

async function decideCorrection(requestId, decision, actorId) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const request = await db.getAttendanceCorrectionRequest(requestId);
  if (!request) throw new Error('Correction request not found');
  if (request.status !== 'pending') throw new Error('This correction request has already been decided');

  await db.decideAttendanceCorrectionRequest(requestId, decision, actorId);

  if (decision === 'approved') {
    if (request.requested_status) {
      await markAttendance({ userId: request.user_id, date: request.date, status: request.requested_status, actorId, notes: `Regularized: ${request.reason}` });
    } else {
      // Recompute worked time the same way check-out would, using the
      // employee's own check-in if only check-out was corrected (or vice
      // versa), so a regularized day gets the same downstream treatment as
      // a normal check-in/check-out pair.
      const existing = await db.getAttendanceRecord(request.user_id, request.date);
      const checkInAt = request.requested_check_in_at || (existing ? existing.check_in_at : null);
      const checkOutAt = request.requested_check_out_at || (existing ? existing.check_out_at : null);
      const shift = (existing && existing.shift_id) ? await db.getShift(existing.shift_id) : await resolveShiftForUser(request.user_id, request.date);

      let workedMinutes = existing ? existing.worked_minutes : 0;
      let status = existing ? existing.status : 'present';
      if (checkInAt && checkOutAt) {
        const grossMinutes = Math.max(0, minutesBetween(checkInAt, checkOutAt));
        workedMinutes = Math.max(0, grossMinutes - (shift ? shift.break_minutes || 0 : 0));
        status = !shift ? 'present' : workedMinutes < shift.half_day_min_minutes ? 'absent' : workedMinutes < shift.full_day_min_minutes ? 'half_day' : 'present';
      }
      await db.upsertAttendanceRecord({
        userId: request.user_id, date: request.date, shiftId: shift ? shift.id : null,
        checkInAt, checkOutAt, status, workedMinutes,
        lateMinutes: existing ? existing.late_minutes : 0, earlyLeaveMinutes: existing ? existing.early_leave_minutes : 0,
        source: 'regularization', markedBy: actorId, notes: `Regularized: ${request.reason}`,
      });
    }
  }
  return db.getAttendanceCorrectionRequest(requestId);
}

// ---------------------------------------------------------------------------
// MONTHLY CALENDAR
// ---------------------------------------------------------------------------

async function getMonthlyCalendar(userId, year, month) {
  const totalDays = daysInMonthUTC(year, month);
  const monthStart = `${year}-${String(month).padStart(2, '0')}-01`;
  const monthEnd = `${year}-${String(month).padStart(2, '0')}-${String(totalDays).padStart(2, '0')}`;

  const [holidays, weeklyOffDays, records] = await Promise.all([
    db.getHolidaysInRange(monthStart, monthEnd),
    db.getWeeklyOffDays(),
    db.listAttendanceRecordsForUserInRange(userId, monthStart, monthEnd),
  ]);
  const holidaySet = new Set(holidays.map(h => h.holiday_date));
  const recordByDate = new Map(records.map(r => [r.date, r]));
  const today = todayStr();

  const days = [];
  for (let d = 1; d <= totalDays; d++) {
    const date = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dow = new Date(date + 'T00:00:00Z').getUTCDay();
    const record = recordByDate.get(date);
    let status;
    if (record) status = record.status;
    else if (holidaySet.has(date)) status = 'holiday';
    else if (weeklyOffDays.includes(dow)) status = 'weekly_off';
    else if (date < today) status = 'absent'; // past working day, no record and no manual marking
    else status = 'pending';

    days.push({
      date, status,
      checkInAt: record ? record.check_in_at : null,
      checkOutAt: record ? record.check_out_at : null,
      workedMinutes: record ? record.worked_minutes : 0,
      lateMinutes: record ? record.late_minutes : 0,
      earlyLeaveMinutes: record ? record.early_leave_minutes : 0,
      isHoliday: holidaySet.has(date),
      isWeeklyOff: weeklyOffDays.includes(dow),
    });
  }
  return { year, month, days };
}

// ---------------------------------------------------------------------------
// PAYROLL INTEGRATION — the summary payroll.js's getAttendanceForPayroll
// consumes. Returns null if this employee has zero attendance records for
// the month (attendance module not yet adopted for them), so the caller can
// fall back to its legacy leave-based LOP logic and nothing breaks for
// companies still ramping up on Block 2.
// ---------------------------------------------------------------------------

const PAID_STATUSES = new Set(['present', 'wfh', 'on_duty', 'leave']);

async function computeAttendanceSummaryForPayroll(userId, year, month) {
  const totalDays = daysInMonthUTC(year, month);
  const monthStart = `${year}-${String(month).padStart(2, '0')}-01`;
  const monthEnd = `${year}-${String(month).padStart(2, '0')}-${String(totalDays).padStart(2, '0')}`;

  const records = await db.listAttendanceRecordsForUserInRange(userId, monthStart, monthEnd);
  if (records.length === 0) return null;

  const [holidays, weeklyOffDays] = await Promise.all([db.getHolidaysInRange(monthStart, monthEnd), db.getWeeklyOffDays()]);
  const holidaySet = new Set(holidays.map(h => h.holiday_date));
  const recordByDate = new Map(records.map(r => [r.date, r]));
  const today = todayStr();

  let workingDays = 0;
  let paidDays = 0;
  for (let d = 1; d <= totalDays; d++) {
    const date = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    if (date > today && date > monthEnd) continue; // never happens given monthEnd bound, kept for clarity
    const dow = new Date(date + 'T00:00:00Z').getUTCDay();
    if (holidaySet.has(date) || weeklyOffDays.includes(dow)) continue; // not a working day
    workingDays++;
    const record = recordByDate.get(date);
    if (!record) { continue; } // no record on a working day = LOP (0 paid weight)
    if (PAID_STATUSES.has(record.status)) paidDays += 1;
    else if (record.status === 'half_day') paidDays += 0.5;
    // 'absent' contributes 0; 'holiday'/'weekly_off' shouldn't appear on a working day but are ignored defensively
  }

  const lopDays = Math.max(0, roundMoney(workingDays - paidDays));
  return { workingDays, paidDays: roundMoney(paidDays), lopDays };
}

module.exports = {
  createShift,
  assignShift,
  resolveShiftForUser,
  checkIn,
  checkOut,
  markAttendance,
  requestCorrection,
  decideCorrection,
  getMonthlyCalendar,
  computeAttendanceSummaryForPayroll,
  MANUAL_STATUSES,
};

  },
  "compliance": function (require, module, exports) {
// src/compliance.js — BLOCK 5: Tax & Compliance reporting
//
// Most of Block 5's spec (tax declarations, proof upload, HR verification,
// approve/reject/resubmit, previous-employer income, old-vs-new regime
// comparison, monthly TDS) already existed in db.js/payroll.js/server.js
// before this file was written. This module is the genuinely-missing
// reporting layer on top of that data: the annual tax statement, Form 16 /
// Form 24Q data preparation, and PF/ESI/PT/statutory-register compliance
// reports — all derived from payroll_details, tax_declarations and the
// employee record, with no new source-of-truth tables needed beyond one
// column (users.esi_number).

const db = require('./db');
const payroll = require('./payroll');

function roundMoney(n) { return Math.round((Number(n) || 0) * 100) / 100; }

// ---------------------------------------------------------------------------
// EMPLOYER STATUTORY INFO (stored in the existing settings key/value table)
// ---------------------------------------------------------------------------

const EMPLOYER_INFO_DEFAULTS = {
  company_name: 'Not configured', company_pan: 'Not configured', company_tan: 'Not configured',
  pf_establishment_code: 'Not configured', esi_establishment_code: 'Not configured', company_address: 'Not configured',
};

async function getEmployerStatutoryInfo() {
  const settings = await db.getSettings();
  const out = {};
  for (const key of Object.keys(EMPLOYER_INFO_DEFAULTS)) out[key] = settings[key] || EMPLOYER_INFO_DEFAULTS[key];
  return out;
}
async function updateEmployerStatutoryInfo(patch) {
  const allowed = {};
  for (const key of Object.keys(EMPLOYER_INFO_DEFAULTS)) if (patch[key] !== undefined) allowed[key] = patch[key];
  await db.updateSettings(allowed);
  return getEmployerStatutoryInfo();
}

// ---------------------------------------------------------------------------
// QUARTER HELPERS (Indian financial year: Apr–Jun / Jul–Sep / Oct–Dec / Jan–Mar)
// ---------------------------------------------------------------------------

const QUARTER_MONTH_OFFSETS = { Q1: [3, 4, 5], Q2: [6, 7, 8], Q3: [9, 10, 11], Q4: [0, 1, 2] };

function quarterMonths(financialYear, quarter) {
  const offsets = QUARTER_MONTH_OFFSETS[quarter];
  if (!offsets) throw new Error('quarter must be one of Q1, Q2, Q3, Q4');
  const fyStartYear = Number(financialYear.start_date.slice(0, 4));
  return offsets.map((monthIndex0) => {
    // Q4's months (Jan-Mar) fall in the calendar year AFTER the FY's start year.
    const year = monthIndex0 < 3 ? fyStartYear + 1 : fyStartYear;
    return `${year}-${String(monthIndex0 + 1).padStart(2, '0')}`;
  });
}

// ---------------------------------------------------------------------------
// ANNUAL TAX STATEMENT
// ---------------------------------------------------------------------------

async function getAnnualTaxStatement(userId, financialYearId) {
  const fy = await db.getFinancialYear(financialYearId);
  if (!fy) throw new Error('Financial year not found');

  const [rows, prevEmployer, selected, approvedDeductions] = await Promise.all([
    db.getPayrollDetailsForUserInFinancialYear(userId, financialYearId),
    db.getPreviousEmployerIncome(userId, financialYearId),
    db.getEmployeeTaxRegime(userId, financialYearId),
    payroll.getApprovedTaxDeductions(userId, financialYearId),
  ]);
  const regime = selected ? await db.getTaxRegime(selected.tax_regime_id) : await db.getDefaultTaxRegime(financialYearId);
  if (!regime) throw new Error('No tax regime configured for this financial year');

  const monthlyBreakdown = rows.map(r => ({
    payrollMonth: r.payroll_month, grossEarning: r.gross_earning, basicEarning: r.basic_earning,
    pfEmployeeDeduction: r.pf_employee_deduction, professionalTaxDeduction: r.professional_tax_deduction,
    tdsDeduction: r.tds_deduction, netSalary: r.net_salary,
  }));

  const sum = (key) => roundMoney(rows.reduce((s, r) => s + Number(r[key] || 0), 0));
  const currentEmployerGross = sum('gross_earning');
  const currentEmployerTds = sum('tds_deduction');
  const currentEmployerPf = sum('pf_employee_deduction');
  const currentEmployerPt = sum('professional_tax_deduction');

  const prevGross = prevEmployer ? Number(prevEmployer.gross_income) : 0;
  const prevTds = prevEmployer ? Number(prevEmployer.tds_deducted) : 0;
  const prevPt = prevEmployer ? Number(prevEmployer.professional_tax_paid) : 0;

  const totalAnnualGross = roundMoney(currentEmployerGross + prevGross);
  const totalTdsDeducted = roundMoney(currentEmployerTds + prevTds);

  const { taxableIncome, annualTax } = await payroll.calculateTaxLiability(regime.id, totalAnnualGross, approvedDeductions);
  const balance = roundMoney(annualTax - totalTdsDeducted); // positive = additional tax due, negative = refund due

  return {
    userId, financialYearId, financialYearName: fy.name,
    regime: { id: regime.id, code: regime.code, name: regime.name },
    currentEmployer: { grossIncome: currentEmployerGross, tdsDeducted: currentEmployerTds, pfDeducted: currentEmployerPf, ptDeducted: currentEmployerPt },
    previousEmployer: prevEmployer ? { name: prevEmployer.previous_employer_name, grossIncome: prevGross, tdsDeducted: prevTds, professionalTaxPaid: prevPt } : null,
    totalAnnualGross, approvedDeductions, taxableIncome, annualTaxComputed: annualTax,
    totalTdsDeducted, balance, balanceType: balance > 0 ? 'additional_tax_due' : balance < 0 ? 'refund_due' : 'settled',
    monthlyBreakdown,
  };
}

// ---------------------------------------------------------------------------
// FORM 16 DATA PREPARATION (Part A + Part B)
// ---------------------------------------------------------------------------

async function getForm16Data(userId, financialYearId) {
  const [statement, employerInfo, user, rows] = await Promise.all([
    getAnnualTaxStatement(userId, financialYearId),
    getEmployerStatutoryInfo(),
    db.findUserById(userId),
    db.getPayrollDetailsForUserInFinancialYear(userId, financialYearId),
  ]);
  const fy = await db.getFinancialYear(financialYearId);

  const quarterlyTds = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
  for (const quarter of ['Q1', 'Q2', 'Q3', 'Q4']) {
    const months = new Set(quarterMonths(fy, quarter));
    quarterlyTds[quarter] = roundMoney(rows.filter(r => months.has(r.payroll_month)).reduce((s, r) => s + Number(r.tds_deduction || 0), 0));
  }

  return {
    partA: {
      employer: { name: employerInfo.company_name, pan: employerInfo.company_pan, tan: employerInfo.company_tan, address: employerInfo.company_address },
      employee: { name: user.name, pan: user.pan || 'Not on file', employeeCode: user.employee_code },
      financialYear: fy.name, assessmentYear: `${Number(fy.start_date.slice(0, 4)) + 1}-${String((Number(fy.start_date.slice(0, 4)) + 2)).slice(-2)}`,
      period: { from: fy.start_date, to: fy.end_date },
      quarterlyTdsSummary: quarterlyTds,
      totalTdsDeposited: statement.totalTdsDeducted,
    },
    partB: {
      grossSalary: statement.totalAnnualGross,
      standardDeduction: null, // resolved inside calculateTaxLiability; surfaced separately below for statement clarity
      chapterVIADeductions: statement.approvedDeductions,
      taxableIncome: statement.taxableIncome,
      taxComputed: statement.annualTaxComputed,
      regime: statement.regime,
      totalTdsDeducted: statement.totalTdsDeducted,
      balance: statement.balance,
      balanceType: statement.balanceType,
    },
  };
}

// ---------------------------------------------------------------------------
// FORM 24Q DATA PREPARATION (quarterly TDS return — all employees)
// ---------------------------------------------------------------------------

async function getForm24QData(financialYearId, quarter) {
  const fy = await db.getFinancialYear(financialYearId);
  if (!fy) throw new Error('Financial year not found');
  const months = quarterMonths(fy, quarter);
  const rows = await db.getPayrollDetailsForMonths(financialYearId, months);

  const byUser = new Map();
  for (const r of rows) {
    if (!byUser.has(r.user_id)) {
      byUser.set(r.user_id, {
        userId: r.user_id, name: r.user_name, pan: r.pan || 'Not on file', employeeCode: r.employee_code,
        totalGrossPaid: 0, totalTdsDeducted: 0, monthly: [],
      });
    }
    const entry = byUser.get(r.user_id);
    entry.totalGrossPaid = roundMoney(entry.totalGrossPaid + Number(r.gross_earning || 0));
    entry.totalTdsDeducted = roundMoney(entry.totalTdsDeducted + Number(r.tds_deduction || 0));
    entry.monthly.push({ payrollMonth: r.payroll_month, grossPaid: r.gross_earning, tdsDeducted: r.tds_deduction });
  }
  const deductees = [...byUser.values()].sort((a, b) => a.name.localeCompare(b.name));
  const employerInfo = await getEmployerStatutoryInfo();

  return {
    financialYearId, financialYearName: fy.name, quarter, months,
    employer: { name: employerInfo.company_name, tan: employerInfo.company_tan },
    deducteeCount: deductees.length,
    totalGrossPaid: roundMoney(deductees.reduce((s, d) => s + d.totalGrossPaid, 0)),
    totalTdsDeducted: roundMoney(deductees.reduce((s, d) => s + d.totalTdsDeducted, 0)),
    deductees,
  };
}

// ---------------------------------------------------------------------------
// PF COMPLIANCE REPORT
// ---------------------------------------------------------------------------

const PF_WAGE_CEILING = 15000;
const EPS_RATE = 0.0833; // Employees' Pension Scheme, out of the employer's 12%
const PF_RATE = 0.12;

async function getPfComplianceReport(financialYearId, payrollMonth) {
  const rows = await db.getPayrollDetailsForMonths(financialYearId, [payrollMonth]);
  const employerInfo = await getEmployerStatutoryInfo();

  const employees = rows.map(r => {
    const pfWage = Math.min(Number(r.basic_earning || 0), PF_WAGE_CEILING);
    const employeePf = roundMoney(r.pf_employee_deduction); // actual amount withheld in payroll
    // Employer-side PF isn't tracked as a separate payroll_details column
    // (the payroll engine only withholds the employee share) — this is a
    // statutory estimate computed from the same wage base for compliance
    // filing purposes, split into EPS/EPF the way EPFO requires.
    const employerPfTotal = roundMoney(pfWage * PF_RATE);
    const employerEps = roundMoney(pfWage * EPS_RATE);
    const employerEpf = roundMoney(employerPfTotal - employerEps);
    return {
      employeeCode: r.employee_code, name: r.user_name, uan: r.uan || 'Not on file', pfNumber: r.pf_number || 'Not on file',
      pfWage, employeePf, employerEps, employerEpf, employerPfTotal, totalRemittance: roundMoney(employeePf + employerPfTotal),
    };
  });

  return {
    financialYearId, payrollMonth, establishmentCode: employerInfo.pf_establishment_code,
    employeeCount: employees.length,
    totals: {
      employeePf: roundMoney(employees.reduce((s, e) => s + e.employeePf, 0)),
      employerPfTotal: roundMoney(employees.reduce((s, e) => s + e.employerPfTotal, 0)),
      totalRemittance: roundMoney(employees.reduce((s, e) => s + e.totalRemittance, 0)),
    },
    employees,
  };
}

// ---------------------------------------------------------------------------
// ESI COMPLIANCE REPORT
// ---------------------------------------------------------------------------

const ESI_WAGE_CEILING = 21000;
const ESI_EMPLOYEE_RATE = 0.0075;
const ESI_EMPLOYER_RATE = 0.0325;

// Advisory only — ESI is not currently withheld by the payroll engine
// itself (Block 4 didn't add it as a live deduction), so this report is
// computed independently from gross wages for compliance filing/decision
// purposes. If the company is ESI-registered, the natural next step is to
// add ESI as a real fixed-deduction salary component the same way PF/PT
// already are, so it actually gets withheld each payroll run.
async function getEsiComplianceReport(financialYearId, payrollMonth) {
  const rows = await db.getPayrollDetailsForMonths(financialYearId, [payrollMonth]);
  const employerInfo = await getEmployerStatutoryInfo();

  const employees = rows.map(r => {
    const gross = Number(r.gross_earning || 0);
    const eligible = gross > 0 && gross <= ESI_WAGE_CEILING;
    const employeeEsi = eligible ? roundMoney(gross * ESI_EMPLOYEE_RATE) : 0;
    const employerEsi = eligible ? roundMoney(gross * ESI_EMPLOYER_RATE) : 0;
    return {
      employeeCode: r.employee_code, name: r.user_name, esiNumber: r.esi_number || 'Not on file',
      grossWage: gross, eligible, employeeEsi, employerEsi, totalRemittance: roundMoney(employeeEsi + employerEsi),
    };
  });

  return {
    financialYearId, payrollMonth, establishmentCode: employerInfo.esi_establishment_code,
    wageCeiling: ESI_WAGE_CEILING, advisory: true,
    eligibleCount: employees.filter(e => e.eligible).length,
    totals: {
      employeeEsi: roundMoney(employees.reduce((s, e) => s + e.employeeEsi, 0)),
      employerEsi: roundMoney(employees.reduce((s, e) => s + e.employerEsi, 0)),
      totalRemittance: roundMoney(employees.reduce((s, e) => s + e.totalRemittance, 0)),
    },
    employees,
  };
}

// ---------------------------------------------------------------------------
// PT COMPLIANCE REPORT
// ---------------------------------------------------------------------------

async function getPtComplianceReport(financialYearId, payrollMonth) {
  const rows = await db.getPayrollDetailsForMonths(financialYearId, [payrollMonth]);
  const employees = rows.map(r => ({
    employeeCode: r.employee_code, name: r.user_name, location: r.location || 'Not on file',
    grossWage: r.gross_earning, professionalTaxDeducted: r.professional_tax_deduction,
  }));

  const byLocation = new Map();
  for (const e of employees) {
    const key = e.location;
    byLocation.set(key, roundMoney((byLocation.get(key) || 0) + Number(e.professionalTaxDeducted || 0)));
  }

  return {
    financialYearId, payrollMonth,
    employeeCount: employees.length,
    totalProfessionalTax: roundMoney(employees.reduce((s, e) => s + Number(e.professionalTaxDeducted || 0), 0)),
    byLocation: [...byLocation.entries()].map(([location, total]) => ({ location, total })),
    employees,
  };
}

// ---------------------------------------------------------------------------
// STATUTORY WAGE REGISTER (combined register for compliance inspection)
// ---------------------------------------------------------------------------

async function getStatutoryWageRegister(financialYearId, payrollMonth) {
  const rows = await db.getPayrollDetailsForMonths(financialYearId, [payrollMonth]);
  const employees = rows.map(r => ({
    employeeCode: r.employee_code, name: r.user_name, designation: r.title, department: r.dept,
    uan: r.uan || 'Not on file', pan: r.pan || 'Not on file',
    workingDays: r.working_days, paidDays: r.paid_days, lopDays: r.lop_days,
    basicEarning: r.basic_earning, grossEarning: r.gross_earning,
    pfEmployeeDeduction: r.pf_employee_deduction, professionalTaxDeduction: r.professional_tax_deduction,
    tdsDeduction: r.tds_deduction, netSalary: r.net_salary,
  })).sort((a, b) => a.name.localeCompare(b.name));

  return { financialYearId, payrollMonth, employeeCount: employees.length, employees };
}

module.exports = {
  getEmployerStatutoryInfo,
  updateEmployerStatutoryInfo,
  quarterMonths,
  getAnnualTaxStatement,
  getForm16Data,
  getForm24QData,
  getPfComplianceReport,
  getEsiComplianceReport,
  getPtComplianceReport,
  getStatutoryWageRegister,
};

  },
  "fnf": function (require, module, exports) {
// src/fnf.js — BLOCK 6: Full & Final Settlement
//
// Target flow (from the spec): Employee Exit -> Final Attendance -> Salary
// -> Leave Encashment -> Bonus -> Gratuity -> Reimbursements -> Loan
// Outstanding -> Advance -> Asset Recovery -> Final Settlement -> Statement.
//
// Employee Lifecycle (Block 1) hasn't been built yet, so this module owns a
// minimal resignation/exit record (employee_separations) itself rather than
// depending on an exit workflow that doesn't exist — see the migration
// comment for why that's deliberately narrow in scope.

const db = require('./db');
const payroll = require('./payroll');
const lifecycle = require('./lifecycle');

function roundMoney(n) { return Math.round((Number(n) || 0) * 100) / 100; }

function daysBetweenInclusive(fromStr, toStr) {
  const from = new Date(fromStr + 'T00:00:00Z');
  const to = new Date(toStr + 'T00:00:00Z');
  return Math.round((to - from) / 86400000) + 1;
}

async function resolveFinancialYearForDate(dateStr) {
  const years = await db.listFinancialYears();
  const match = years.find(y => y.start_date <= dateStr && dateStr <= y.end_date);
  return match || await db.getActiveFinancialYear();
}

// ---------------------------------------------------------------------------
// RESIGNATION / SEPARATION
// ---------------------------------------------------------------------------

async function initiateSeparation({ userId, resignationDate, lastWorkingDate, noticePeriodRequiredDays, reason, initiatedBy }) {
  if (!resignationDate || !lastWorkingDate) throw new Error('resignationDate and lastWorkingDate are required');
  if (lastWorkingDate < resignationDate) throw new Error('lastWorkingDate cannot be before resignationDate');
  const existing = await db.getActiveSeparationForUser(userId);
  if (existing) throw new Error('This employee already has an active resignation/separation in progress');
  return db.createSeparation({ userId, resignationDate, lastWorkingDate, noticePeriodRequiredDays: noticePeriodRequiredDays || 0, reason, initiatedBy });
}

async function decideSeparationRequest(id, decision, actorId) {
  if (!['approved', 'withdrawn'].includes(decision)) throw new Error('decision must be approved or withdrawn');
  const separation = await db.getSeparation(id);
  if (!separation) throw new Error('Separation record not found');
  if (separation.status !== 'pending') throw new Error('This separation request has already been decided');
  await db.decideSeparation(id, decision, actorId);
  if (decision === 'approved') {
    await lifecycle.onSeparationApproved(separation.user_id, id, actorId);
  }
  return db.getSeparation(id);
}

// ---------------------------------------------------------------------------
// SETTLEMENT GENERATION
// ---------------------------------------------------------------------------

async function generateSettlement(employeeSeparationId, preparedBy, overrides = {}) {
  const separation = await db.getSeparation(employeeSeparationId);
  if (!separation) throw new Error('Separation record not found');
  if (separation.status !== 'approved') throw new Error('The separation must be approved before a settlement can be generated');

  const existing = await db.getFnfSettlementBySeparation(employeeSeparationId);
  if (existing && existing.status !== 'draft') {
    throw new Error(`A settlement already exists for this separation (status: ${existing.status}) — it can only be regenerated while in draft`);
  }

  const userId = separation.user_id;
  const fy = await resolveFinancialYearForDate(separation.last_working_date);
  if (!fy) throw new Error('No financial year configured for the last working date');

  const structure = await db.getActiveSalaryStructure(userId, fy.id);
  const components = structure ? await db.getStructureComponents(structure.id) : [];
  const monthlyGross = roundMoney(components.filter(c => c.type === 'earning').reduce((s, c) => s + Number(c.amount || 0), 0));
  const perDaySalary = roundMoney(monthlyGross / 26); // same /26 convention used elsewhere (leave encashment, notice recovery)

  // -- Notice period recovery -----------------------------------------
  const servedDays = Math.max(0, daysBetweenInclusive(separation.resignation_date, separation.last_working_date) - 1);
  const noticeShortfallDays = Math.max(0, separation.notice_period_required_days - servedDays);
  const noticeRecoveryAmount = roundMoney(perDaySalary * noticeShortfallDays);

  // -- Unpaid salary for the final (likely partial) month --------------
  const lastWorkingMonth = separation.last_working_date.slice(0, 7);
  const alreadyPayrolled = await db.dbGet(`
    SELECT 1 AS found FROM payroll_details pd JOIN payroll_runs pr ON pr.id = pd.payroll_run_id
    WHERE pd.user_id = ? AND pr.payroll_month = ? AND pr.status IN ('approved','locked','disbursed') LIMIT 1
  `, [userId, lastWorkingMonth]);
  let unpaidSalaryDays = 0;
  if (!alreadyPayrolled) {
    const monthStart = `${lastWorkingMonth}-01`;
    const [holidays, weeklyOffDays] = await Promise.all([db.getHolidaysInRange(monthStart, separation.last_working_date), db.getWeeklyOffDays()]);
    const holidaySet = new Set(holidays.map(h => h.holiday_date));
    const lastDay = Number(separation.last_working_date.slice(8, 10));
    for (let d = 1; d <= lastDay; d++) {
      const dateStr = `${lastWorkingMonth}-${String(d).padStart(2, '0')}`;
      const dow = new Date(dateStr + 'T00:00:00Z').getUTCDay();
      if (holidaySet.has(dateStr) || weeklyOffDays.includes(dow)) continue;
      unpaidSalaryDays++;
    }
  }
  const unpaidSalaryAmount = roundMoney(perDaySalary * unpaidSalaryDays);

  // -- Leave encashment (all remaining balance, across all leave types) -
  const year = Number(fy.start_date.slice(0, 4));
  const balances = await db.dbAll('SELECT * FROM leave_balances WHERE user_id = ? AND year = ?', [userId, year]);
  const leaveEncashmentDays = roundMoney(balances.reduce((s, b) => s + Math.max(0, Number(b.total_days) - Number(b.used_days)), 0));
  const leaveEncashmentAmount = roundMoney(perDaySalary * leaveEncashmentDays);

  // -- Gratuity ----------------------------------------------------------
  const gratuity = await payroll.calculateGratuity(userId, fy.id, separation.last_working_date);

  // -- Loan / advance recovery (full outstanding balance recovered at exit)
  const [activeLoans, recoveringAdvances] = await Promise.all([
    db.listActiveLoansForUser(userId), db.listRecoveringAdvancesForUser(userId),
  ]);
  const loanRecoveryAmount = roundMoney(activeLoans.reduce((s, l) => s + Number(l.outstanding_balance), 0));
  const advanceRecoveryAmount = roundMoney(recoveringAdvances.reduce((s, a) => s + Number(a.outstanding_balance), 0));

  // -- Manually-entered lines (bonus, reimbursements, asset recovery, other)
  const bonusAmount = roundMoney(overrides.bonusAmount || 0);
  const reimbursementsAmount = roundMoney(overrides.reimbursementsAmount || 0);
  const assetRecoveryAmount = roundMoney(overrides.assetRecoveryAmount || 0);
  const otherDeductionsAmount = roundMoney(overrides.otherDeductionsAmount || 0);
  const otherDeductionsNotes = overrides.otherDeductionsNotes || null;

  const totalEarnings = roundMoney(unpaidSalaryAmount + leaveEncashmentAmount + bonusAmount + gratuity.gratuityAmount + reimbursementsAmount);
  const totalDeductions = roundMoney(noticeRecoveryAmount + loanRecoveryAmount + advanceRecoveryAmount + assetRecoveryAmount + otherDeductionsAmount);
  const finalPayable = roundMoney(totalEarnings - totalDeductions);

  const lineItems = {
    userId, employeeSeparationId, unpaidSalaryDays, unpaidSalaryAmount, noticeRecoveryDays: noticeShortfallDays, noticeRecoveryAmount,
    leaveEncashmentDays, leaveEncashmentAmount, bonusAmount, gratuityAmount: gratuity.gratuityAmount, reimbursementsAmount,
    loanRecoveryAmount, advanceRecoveryAmount, assetRecoveryAmount, otherDeductionsAmount, otherDeductionsNotes,
    totalEarnings, totalDeductions, finalPayable, preparedBy,
  };

  if (existing) {
    await db.updateFnfSettlementLineItems(existing.id, lineItems);
    return db.getFnfSettlement(existing.id);
  }
  const info = await db.createFnfSettlement(lineItems);
  return db.getFnfSettlement(info.lastInsertRowid);
}

// ---------------------------------------------------------------------------
// APPROVAL / PAYOUT WORKFLOW
// ---------------------------------------------------------------------------

async function submitSettlementForApproval(settlementId) {
  const settlement = await db.getFnfSettlement(settlementId);
  if (!settlement) throw new Error('Settlement not found');
  if (settlement.status !== 'draft') throw new Error('Only a draft settlement can be submitted for approval');
  await db.submitFnfSettlementForApproval(settlementId);
  return db.getFnfSettlement(settlementId);
}

async function decideSettlement(settlementId, decision, actorId) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const settlement = await db.getFnfSettlement(settlementId);
  if (!settlement) throw new Error('Settlement not found');
  if (settlement.status !== 'pending_approval') throw new Error('This settlement is not pending approval');
  await db.decideFnfSettlement(settlementId, decision === 'approved' ? 'approved' : 'draft', actorId);
  return db.getFnfSettlement(settlementId);
}

async function markSettlementPaid(settlementId, actorId) {
  const settlement = await db.getFnfSettlement(settlementId);
  if (!settlement) throw new Error('Settlement not found');
  if (settlement.status !== 'approved') throw new Error('Only an approved settlement can be marked paid');

  return db.withTx(async (tx) => {
    const [activeLoans, recoveringAdvances] = await Promise.all([
      db.listActiveLoansForUser(settlement.user_id, tx), db.listRecoveringAdvancesForUser(settlement.user_id, tx),
    ]);
    for (const loan of activeLoans) {
      await db.applyLoanRepayment(loan.id, {
        amount: loan.outstanding_balance, principalComponent: loan.outstanding_balance, interestComponent: 0,
        balanceAfter: 0, payrollMonth: 'FNF', payrollDetailId: null,
      }, tx);
    }
    for (const advance of recoveringAdvances) {
      await db.applyAdvanceRecovery(advance.id, { amount: advance.outstanding_balance, balanceAfter: 0, payrollMonth: 'FNF', payrollDetailId: null }, tx);
    }
    await db.markFnfSettlementPaid(settlementId, tx);
    await db.markSeparationExited(settlement.employee_separation_id, tx);
    await db.deactivateUser(settlement.user_id, tx);
    await lifecycle.onSettlementPaid(settlement.user_id, actorId, tx);
    return db.getFnfSettlement(settlementId, tx);
  });
}

// ---------------------------------------------------------------------------
// SETTLEMENT STATEMENT
// ---------------------------------------------------------------------------

async function getSettlementStatement(settlementId) {
  const settlement = await db.getFnfSettlement(settlementId);
  if (!settlement) throw new Error('Settlement not found');
  const [separation, user] = await Promise.all([db.getSeparation(settlement.employee_separation_id), db.findUserById(settlement.user_id)]);
  return {
    settlement,
    separation,
    employee: { name: user.name, employeeCode: user.employee_code, dept: user.dept, title: user.title, pan: user.pan },
    earnings: [
      { label: 'Unpaid Salary', days: settlement.unpaid_salary_days, amount: settlement.unpaid_salary_amount },
      { label: 'Leave Encashment', days: settlement.leave_encashment_days, amount: settlement.leave_encashment_amount },
      { label: 'Bonus', amount: settlement.bonus_amount },
      { label: 'Gratuity', amount: settlement.gratuity_amount },
      { label: 'Reimbursements', amount: settlement.reimbursements_amount },
    ],
    deductions: [
      { label: 'Notice Period Shortfall Recovery', days: settlement.notice_recovery_days, amount: settlement.notice_recovery_amount },
      { label: 'Loan Recovery', amount: settlement.loan_recovery_amount },
      { label: 'Advance Recovery', amount: settlement.advance_recovery_amount },
      { label: 'Asset Recovery', amount: settlement.asset_recovery_amount },
      { label: 'Other Deductions', amount: settlement.other_deductions_amount, notes: settlement.other_deductions_notes },
    ],
    totalEarnings: settlement.total_earnings, totalDeductions: settlement.total_deductions, finalPayable: settlement.final_payable,
  };
}

module.exports = {
  initiateSeparation,
  decideSeparationRequest,
  generateSettlement,
  submitSettlementForApproval,
  decideSettlement,
  markSettlementPaid,
  getSettlementStatement,
};

  },
  "leave": function (require, module, exports) {
// src/leave.js — BLOCK 3: Advanced Leave Management
//
// The basic leave system (leave types, balances, single-approver apply/
// decide/cancel) already existed in db.js before this file. This module
// adds the "advanced" layer on top: per-employee/department policy
// overrides, eligibility waiting periods, sandwich-leave day counting,
// hour-based leave, comp-off, multi-level approval, monthly accrual,
// year-end carry-forward + expiry, and team leave calendar/conflict views.

const db = require('./db');
const { nowStr, todayStr } = require('./utils');

function roundMoney(n) { return Math.round((Number(n) || 0) * 100) / 100; }

function daysBetweenInclusive(fromStr, toStr) {
  const from = new Date(fromStr + 'T00:00:00Z');
  const to = new Date(toStr + 'T00:00:00Z');
  return Math.round((to - from) / 86400000) + 1;
}

async function nextLeaveApplicationId() {
  // Mirrors the ID scheme the existing basic leave flow uses elsewhere in
  // db.js (short prefixed IDs) closely enough for our purposes without
  // depending on an internal counter — collisions are astronomically
  // unlikely and the column has no uniqueness requirement beyond primary key.
  return `LV${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 1000)}`;
}

// ---------------------------------------------------------------------------
// POLICY RESOLUTION
// ---------------------------------------------------------------------------

async function getEffectiveLeavePolicy(userId, leaveTypeId) {
  const policy = await db.resolveLeavePolicy(userId, leaveTypeId);
  if (policy) {
    return {
      source: policy.user_id ? 'employee' : 'department',
      annualDays: policy.annual_days, accrualMethod: policy.accrual_method, monthlyAccrualDays: policy.monthly_accrual_days,
      carryForwardEnabled: !!policy.carry_forward_enabled, maxCarryForwardDays: policy.max_carry_forward_days,
      carryForwardExpiryMonths: policy.carry_forward_expiry_months, minServiceDaysBeforeEligible: policy.min_service_days_before_eligible,
      allowNegativeBalance: !!policy.allow_negative_balance, maxNegativeDays: policy.max_negative_days,
      isSandwichLeave: !!policy.is_sandwich_leave, unit: policy.unit,
    };
  }
  const leaveType = await db.getLeaveType(leaveTypeId);
  if (!leaveType) throw new Error('Leave type not found');
  return {
    source: 'default', annualDays: leaveType.default_annual_days, accrualMethod: 'annual', monthlyAccrualDays: null,
    carryForwardEnabled: (leaveType.max_carry_forward_days || 0) > 0, maxCarryForwardDays: leaveType.max_carry_forward_days || 0,
    carryForwardExpiryMonths: 3, minServiceDaysBeforeEligible: 0, allowNegativeBalance: false, maxNegativeDays: 0,
    isSandwichLeave: false, unit: 'day',
  };
}

// ---------------------------------------------------------------------------
// DAY COUNTING (sandwich-aware)
// ---------------------------------------------------------------------------

async function computeLeaveDayCount(from, to, halfDay, isSandwichLeave) {
  if (halfDay) return { days: 0.5, isSandwich: false };
  if (isSandwichLeave) {
    // Sandwich rule: weekends/holidays that fall WITHIN the requested range
    // count as leave too (as opposed to normal leave, which only counts
    // working days and skips non-working days inside the range).
    return { days: daysBetweenInclusive(from, to), isSandwich: true };
  }
  const [holidays, weeklyOffDays] = await Promise.all([db.getHolidaysInRange(from, to), db.getWeeklyOffDays()]);
  const holidaySet = new Set(holidays.map(h => h.holiday_date));
  let count = 0;
  const totalDays = daysBetweenInclusive(from, to);
  const start = new Date(from + 'T00:00:00Z');
  for (let i = 0; i < totalDays; i++) {
    const d = new Date(start); d.setUTCDate(d.getUTCDate() + i);
    const dateStr = d.toISOString().slice(0, 10);
    const dow = d.getUTCDay();
    if (holidaySet.has(dateStr) || weeklyOffDays.includes(dow)) continue;
    count++;
  }
  return { days: count, isSandwich: false };
}

// ---------------------------------------------------------------------------
// ELIGIBILITY
// ---------------------------------------------------------------------------

async function checkEligibility(userId, leaveTypeId, policy) {
  if (!policy.minServiceDaysBeforeEligible) return;
  const user = await db.findUserById(userId);
  if (!user || !user.joined_date) return;
  const serviceDays = daysBetweenInclusive(user.joined_date, todayStr()) - 1;
  if (serviceDays < policy.minServiceDaysBeforeEligible) {
    throw new Error(`Not yet eligible for this leave type — requires ${policy.minServiceDaysBeforeEligible} days of service (${serviceDays} completed)`);
  }
}

// ---------------------------------------------------------------------------
// APPLY FOR LEAVE (advanced: policy-aware, sandwich, negative balance,
// hour-based, multi-level approval assignment)
// ---------------------------------------------------------------------------

async function applyForLeaveAdvanced({ userId, leaveTypeId, from, to, halfDay, hours, reason, requiredApprovalLevels }) {
  if (to < from) throw new Error('to date cannot be before from date');
  const policy = await getEffectiveLeavePolicy(userId, leaveTypeId);
  await checkEligibility(userId, leaveTypeId, policy);

  let days, unit = policy.unit, isSandwich = false;
  if (policy.unit === 'hour') {
    if (!(hours > 0)) throw new Error('hours is required for hour-based leave');
    days = hours;
  } else {
    const counted = await computeLeaveDayCount(from, to, halfDay, policy.isSandwichLeave);
    days = counted.days;
    isSandwich = counted.isSandwich;
  }
  if (days <= 0) throw new Error('The selected range contains no working days to apply leave for');

  const year = Number(from.slice(0, 4));
  const balance = await db.getLeaveBalanceRow(userId, leaveTypeId, year);
  const available = balance ? (Number(balance.total_days) + Number(balance.carried_forward_days || 0) - Number(balance.used_days)) : 0;
  const projectedRemaining = available - days;
  if (projectedRemaining < 0 && !policy.allowNegativeBalance) {
    throw new Error(`Insufficient leave balance — ${available} available, ${days} requested`);
  }
  if (projectedRemaining < 0 && policy.allowNegativeBalance && Math.abs(projectedRemaining) > policy.maxNegativeDays) {
    throw new Error(`This would exceed the maximum allowed negative balance of ${policy.maxNegativeDays} for this leave type`);
  }

  const levels = requiredApprovalLevels || (days > 5 ? 2 : 1); // longer leave defaults to a second approval level

  const id = await nextLeaveApplicationId();
  await db.dbRun(`
    INSERT INTO leave_applications (id, user_id, leave_type_id, from_date, to_date, days, unit, reason, applied_at, is_sandwich, required_approval_levels)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [id, userId, leaveTypeId, from, to, days, unit, reason || null, nowStr(), isSandwich ? 1 : 0, levels]);

  return { id, days, unit, isSandwich, requiredApprovalLevels: levels };
}

// ---------------------------------------------------------------------------
// MULTI-LEVEL APPROVAL
// ---------------------------------------------------------------------------

async function decideLeaveApplicationMultiLevel(applicationId, decision, actorId, comment) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const application = await db.getLeaveApplicationRow(applicationId);
  if (!application) throw new Error('Leave application not found');
  if (application.status !== 'pending') throw new Error('This leave application has already been decided');

  await db.createLeaveApproval({ leaveApplicationId: applicationId, level: application.current_approval_level, approverId: actorId, decision, comment });

  if (decision === 'rejected') {
    await db.dbRun(`UPDATE leave_applications SET status = 'rejected', decided_at = ?, decided_by = ?, last_comment = ? WHERE id = ?`,
      [nowStr(), actorId, comment || null, applicationId]);
    return { status: 'rejected' };
  }

  if (application.current_approval_level < application.required_approval_levels) {
    await db.advanceLeaveApprovalLevel(applicationId);
    return { status: 'pending', nextLevel: application.current_approval_level + 1 };
  }

  // Final level approved — commit the balance deduction (or comp-off redemption).
  return db.withTx(async (tx) => {
    const year = Number(application.from_date.slice(0, 4));
    if (application.comp_off_id) {
      await db.markCompOffUsed(application.comp_off_id, applicationId, tx);
    } else {
      const balance = await db.getLeaveBalanceRow(application.user_id, application.leave_type_id, year, tx);
      const newUsed = roundMoney((balance ? Number(balance.used_days) : 0) + Number(application.days));
      if (balance) await db.upsertLeaveBalance(application.user_id, application.leave_type_id, year, { used_days: newUsed }, tx);
      else await db.upsertLeaveBalance(application.user_id, application.leave_type_id, year, { total_days: 0, used_days: newUsed }, tx);
    }
    await db.dbRun(`UPDATE leave_applications SET status = 'approved', decided_at = ?, decided_by = ?, last_comment = ? WHERE id = ?`,
      [nowStr(), actorId, comment || null, applicationId], tx);
    return { status: 'approved' };
  });
}

// ---------------------------------------------------------------------------
// COMP-OFF
// ---------------------------------------------------------------------------

async function requestCompOff({ userId, workedDate, earnedDays, reason }) {
  if (!workedDate) throw new Error('workedDate is required');
  return db.createCompOffRequest({ userId, workedDate, earnedDays: earnedDays || 1, reason });
}

async function decideCompOffRequest(id, decision, actorId, expiryMonths) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const compOff = await db.getCompOff(id);
  if (!compOff) throw new Error('Comp-off request not found');
  if (compOff.status !== 'pending') throw new Error('This comp-off request has already been decided');
  await db.decideCompOff(id, decision, actorId, expiryMonths);
  return db.getCompOff(id);
}

const COMP_OFF_LEAVE_TYPE_NAME = 'Comp Off';

async function ensureCompOffLeaveType() {
  const types = await db.listLeaveTypes(false);
  const existing = types.find(t => t.name === COMP_OFF_LEAVE_TYPE_NAME);
  if (existing) return existing.id;
  return db.createLeaveType(COMP_OFF_LEAVE_TYPE_NAME, 0, 0);
}

async function redeemCompOff({ userId, compOffId, date }) {
  const compOff = await db.getCompOff(compOffId);
  if (!compOff) throw new Error('Comp-off credit not found');
  if (compOff.user_id !== userId) throw new Error('This comp-off credit does not belong to this employee');
  if (compOff.status !== 'approved') throw new Error('This comp-off credit is not available to redeem');
  if (compOff.expires_on && compOff.expires_on < todayStr()) throw new Error('This comp-off credit has expired');

  const leaveTypeId = await ensureCompOffLeaveType();
  const id = await nextLeaveApplicationId();
  const days = compOff.earned_days;
  await db.dbRun(`
    INSERT INTO leave_applications (id, user_id, leave_type_id, from_date, to_date, days, unit, reason, applied_at, comp_off_id, required_approval_levels)
    VALUES (?, ?, ?, ?, ?, ?, 'day', ?, ?, ?, 1)
  `, [id, userId, leaveTypeId, date, date, days, `Comp-off redemption for ${compOff.worked_date}`, nowStr(), compOffId]);

  return { id, days };
}

// ---------------------------------------------------------------------------
// MONTHLY ACCRUAL
// ---------------------------------------------------------------------------

async function runMonthlyAccrual(year, month) {
  const combos = await db.listActiveUsersWithLeaveType();
  let accrued = 0;
  for (const combo of combos) {
    const policy = await getEffectiveLeavePolicy(combo.user_id, combo.leave_type_id);
    if (policy.accrualMethod !== 'monthly' || !(policy.monthlyAccrualDays > 0)) continue;

    // Don't accrue leave for months before the employee joined.
    if (combo.joined_date) {
      const joinedYm = combo.joined_date.slice(0, 7);
      const targetYm = `${year}-${String(month).padStart(2, '0')}`;
      if (joinedYm > targetYm) continue;
    }

    const balance = await db.getLeaveBalanceRow(combo.user_id, combo.leave_type_id, year);
    const newTotal = roundMoney((balance ? Number(balance.total_days) : 0) + policy.monthlyAccrualDays);
    if (balance) await db.upsertLeaveBalance(combo.user_id, combo.leave_type_id, year, { total_days: newTotal });
    else await db.upsertLeaveBalance(combo.user_id, combo.leave_type_id, year, { total_days: newTotal, used_days: 0 });
    accrued++;
  }
  return { year, month, accrualsApplied: accrued };
}

// ---------------------------------------------------------------------------
// YEAR-END CARRY-FORWARD + EXPIRY
// ---------------------------------------------------------------------------

async function runYearEndCarryForward(fromYear, toYear) {
  const combos = await db.listActiveUsersWithLeaveType();
  let processed = 0;
  for (const combo of combos) {
    const policy = await getEffectiveLeavePolicy(combo.user_id, combo.leave_type_id);
    if (!policy.carryForwardEnabled) continue;

    const fromBalance = await db.getLeaveBalanceRow(combo.user_id, combo.leave_type_id, fromYear);
    if (!fromBalance) continue;
    const unused = roundMoney(Number(fromBalance.total_days) - Number(fromBalance.used_days));
    if (unused <= 0) continue;
    const carryForward = Math.min(unused, policy.maxCarryForwardDays);
    if (carryForward <= 0) continue;

    const expiresOn = new Date(Date.UTC(toYear, 0, 1));
    expiresOn.setUTCMonth(expiresOn.getUTCMonth() + policy.carryForwardExpiryMonths);
    const expiresOnStr = expiresOn.toISOString().slice(0, 10);

    const toBalance = await db.getLeaveBalanceRow(combo.user_id, combo.leave_type_id, toYear);
    const baseTotal = toBalance ? Number(toBalance.total_days) : policy.annualDays;
    await db.upsertLeaveBalance(combo.user_id, combo.leave_type_id, toYear, {
      total_days: roundMoney(baseTotal + carryForward), carried_forward_days: carryForward, carry_forward_expires_on: expiresOnStr,
    });
    processed++;
  }
  return { fromYear, toYear, employeesProcessed: processed };
}

// Deducts any carried-forward days that expired without being used. Assumes
// carry-forward is drawn down first (a common, simple convention) — if
// used_days hasn't yet consumed the full carried-forward amount by the
// expiry date, the unused remainder is removed from the balance.
async function expireCarriedForwardLeave(asOfDate) {
  const today = asOfDate || todayStr();
  const stale = await db.dbAll(`
    SELECT * FROM leave_balances WHERE carried_forward_days > 0 AND carry_forward_expires_on IS NOT NULL AND carry_forward_expires_on < ?
  `, [today]);
  let expired = 0;
  for (const bal of stale) {
    const unusedCarryForward = Math.max(0, Number(bal.carried_forward_days) - Number(bal.used_days));
    if (unusedCarryForward <= 0) { await db.upsertLeaveBalance(bal.user_id, bal.leave_type_id, bal.year, { carried_forward_days: 0 }); continue; }
    const newTotal = roundMoney(Number(bal.total_days) - unusedCarryForward);
    await db.upsertLeaveBalance(bal.user_id, bal.leave_type_id, bal.year, { total_days: Math.max(0, newTotal), carried_forward_days: 0 });
    expired++;
  }
  return { expiredCount: expired };
}

// ---------------------------------------------------------------------------
// TEAM LEAVE CALENDAR / CONFLICT DETECTION
// ---------------------------------------------------------------------------

async function getTeamLeaveCalendar(userIds, from, to) {
  return db.getLeaveCalendarRange(userIds, from, to);
}

async function getLeaveConflicts(userIds, from, to, excludeApplicationId) {
  return db.countOverlappingApprovedLeave(userIds, from, to, excludeApplicationId);
}

module.exports = {
  getEffectiveLeavePolicy,
  computeLeaveDayCount,
  checkEligibility,
  applyForLeaveAdvanced,
  decideLeaveApplicationMultiLevel,
  requestCompOff,
  decideCompOffRequest,
  redeemCompOff,
  runMonthlyAccrual,
  runYearEndCarryForward,
  expireCarriedForwardLeave,
  getTeamLeaveCalendar,
  getLeaveConflicts,
};

  },
  "lifecycle": function (require, module, exports) {
// src/lifecycle.js — BLOCK 1: Advanced Employee Lifecycle
//
// Target lifecycle: Candidate -> Offer -> Onboarding -> Probation ->
// Confirmed -> Active -> Promotion/Transfer -> Resignation -> Notice Period
// -> Full & Final -> Exited. This system doesn't model pre-hire stages
// (Candidate/Offer — that's applicant-tracking scope, not HRIS scope); the
// lifecycle here starts the moment a user account is created. Resignation,
// notice period, and Full & Final are already owned by src/fnf.js (Block 6)
// — this module hooks into that (see the two integration functions at the
// bottom) rather than re-implementing it.

const db = require('./db');
const { nowStr, todayStr } = require('./utils');

const TRANSFERABLE_FIELDS = {
  department_transfer: { userField: 'dept', dbColumn: 'dept' },
  designation_change: { userField: 'title', dbColumn: 'title' },
  manager_change: { userField: 'manager_id', dbColumn: 'manager_id' },
  location_change: { userField: 'location', dbColumn: 'location' },
};

// ---------------------------------------------------------------------------
// ONBOARDING
// ---------------------------------------------------------------------------

async function initializeLifecycle(userId, actorId) {
  const user = await db.findUserById(userId);
  if (!user) throw new Error('User not found');
  await db.updateLifecycleStatus(userId, 'onboarding');
  await db.createLifecycleEvent({ userId, eventType: 'joined', newValue: user.joined_date || todayStr(), effectiveDate: user.joined_date || todayStr(), recordedBy: actorId });
  const tasksCreated = await generateChecklist(userId, 'onboarding');
  return { userId, status: 'onboarding', tasksCreated };
}

async function generateChecklist(userId, type, employeeSeparationId) {
  const templates = await db.listChecklistTemplateItems(type);
  for (const t of templates) {
    await db.createChecklistTask({ userId, employeeSeparationId, templateItemId: t.id, type, label: t.label });
  }
  return templates.length;
}

async function completeOnboarding(userId, actorId, notes) {
  await db.updateLifecycleStatus(userId, 'active');
  await db.createLifecycleEvent({ userId, eventType: 'status_change', previousValue: 'onboarding', newValue: 'active', effectiveDate: todayStr(), notes, recordedBy: actorId });
  return { userId, status: 'active' };
}

// ---------------------------------------------------------------------------
// TRANSFERS (department / designation / manager / location)
// ---------------------------------------------------------------------------

async function recordTransfer(eventType, { userId, newValue, effectiveDate, actorId, notes }) {
  const mapping = TRANSFERABLE_FIELDS[eventType];
  if (!mapping) throw new Error(`Unknown transfer event type: ${eventType}`);
  const user = await db.findUserById(userId);
  if (!user) throw new Error('User not found');
  const previousValue = user[mapping.userField] != null ? String(user[mapping.userField]) : null;

  await db.updateUserAdmin(userId, { [mapping.dbColumn]: newValue });
  await db.createLifecycleEvent({
    userId, eventType, previousValue, newValue: newValue != null ? String(newValue) : null,
    effectiveDate: effectiveDate || todayStr(), notes, recordedBy: actorId,
  });
  return { userId, eventType, previousValue, newValue };
}

const transferDepartment = (args) => recordTransfer('department_transfer', { ...args, newValue: args.newDept });
const changeDesignation = (args) => recordTransfer('designation_change', { ...args, newValue: args.newTitle });
const changeManager = (args) => recordTransfer('manager_change', { ...args, newValue: args.newManagerId });
const changeLocation = (args) => recordTransfer('location_change', { ...args, newValue: args.newLocation });

async function promoteEmployee({ userId, newTitle, newDept, effectiveDate, actorId, notes }) {
  const user = await db.findUserById(userId);
  if (!user) throw new Error('User not found');
  const previousValue = JSON.stringify({ title: user.title, dept: user.dept });
  const patch = {};
  if (newTitle) patch.title = newTitle;
  if (newDept) patch.dept = newDept;
  if (!Object.keys(patch).length) throw new Error('Provide at least a newTitle or newDept for a promotion');
  await db.updateUserAdmin(userId, patch);
  const newValue = JSON.stringify({ title: newTitle || user.title, dept: newDept || user.dept });
  await db.createLifecycleEvent({ userId, eventType: 'promotion', previousValue, newValue, effectiveDate: effectiveDate || todayStr(), notes, recordedBy: actorId });
  return { userId, previousValue: JSON.parse(previousValue), newValue: JSON.parse(newValue) };
}

// ---------------------------------------------------------------------------
// PROBATION
// ---------------------------------------------------------------------------

async function startProbation({ userId, startDate, durationDays, actorId, notes }) {
  const existing = await db.getActiveProbationForUser(userId);
  if (existing) throw new Error('This employee already has an active probation record');
  const start = startDate || todayStr();
  const expected = new Date(start + 'T00:00:00Z');
  expected.setUTCDate(expected.getUTCDate() + (durationDays || 90));
  const expectedEndDate = expected.toISOString().slice(0, 10);

  const id = await db.createProbationRecord({ userId, startDate: start, expectedEndDate, notes });
  await db.updateLifecycleStatus(userId, 'probation');
  await db.createLifecycleEvent({ userId, eventType: 'probation_started', newValue: expectedEndDate, effectiveDate: start, notes, recordedBy: actorId });
  return { id, userId, startDate: start, expectedEndDate };
}

async function confirmProbation(probationId, actorId, notes) {
  const record = await db.getProbationRecord(probationId);
  if (!record) throw new Error('Probation record not found');
  if (record.status === 'confirmed') throw new Error('This probation has already been confirmed');
  await db.confirmProbationRecord(probationId, actorId);
  await db.updateLifecycleStatus(record.user_id, 'active');
  await db.createLifecycleEvent({ userId: record.user_id, eventType: 'probation_confirmed', effectiveDate: todayStr(), notes, recordedBy: actorId });
  return db.getProbationRecord(probationId);
}

async function extendProbation(probationId, newEndDate, actorId, notes) {
  const record = await db.getProbationRecord(probationId);
  if (!record) throw new Error('Probation record not found');
  if (record.status === 'confirmed') throw new Error('Cannot extend a probation that has already been confirmed');
  if (newEndDate <= record.expected_end_date) throw new Error('The extended date must be after the current expected end date');
  await db.extendProbationRecord(probationId, newEndDate, notes);
  await db.createLifecycleEvent({ userId: record.user_id, eventType: 'probation_extended', previousValue: record.expected_end_date, newValue: newEndDate, effectiveDate: todayStr(), notes, recordedBy: actorId });
  return db.getProbationRecord(probationId);
}

// ---------------------------------------------------------------------------
// DOCUMENTS
// ---------------------------------------------------------------------------

async function uploadDocument({ userId, docType, filePath, issueDate, expiryDate, uploadedBy }) {
  if (!docType) throw new Error('docType is required');
  return db.createEmployeeDocument({ userId, docType, filePath, issueDate, expiryDate, uploadedBy });
}

async function getExpiringDocuments(daysAhead) {
  return db.listExpiringDocuments(daysAhead || 30);
}

// ---------------------------------------------------------------------------
// CHECKLIST TASKS
// ---------------------------------------------------------------------------

async function completeChecklistTask(taskId, actorId, notes) {
  return db.completeChecklistTask(taskId, actorId, notes);
}

// ---------------------------------------------------------------------------
// EXIT INTERVIEW
// ---------------------------------------------------------------------------

async function recordExitInterview({ employeeSeparationId, conductedBy, reasonForLeaving, feedback, wouldRehire, rating }) {
  const existing = await db.getExitInterview(employeeSeparationId);
  if (existing) throw new Error('An exit interview has already been recorded for this separation');
  return db.createExitInterview({ employeeSeparationId, conductedBy, reasonForLeaving, feedback, wouldRehire, rating });
}

// ---------------------------------------------------------------------------
// TIMELINE / PROFILE
// ---------------------------------------------------------------------------

async function getEmployeeLifecycleProfile(userId) {
  const [user, events, probation, documents, onboardingTasks] = await Promise.all([
    db.findUserById(userId), db.listLifecycleEventsForUser(userId), db.getActiveProbationForUser(userId),
    db.listDocumentsForUser(userId), db.listChecklistTasksForUser(userId, 'onboarding'),
  ]);
  if (!user) throw new Error('User not found');
  return {
    userId, lifecycleStatus: user.lifecycle_status, events, activeProbation: probation, documents, onboardingTasks,
  };
}

// ---------------------------------------------------------------------------
// INTEGRATION WITH BLOCK 6 (fnf.js) — separation approval / settlement paid
// ---------------------------------------------------------------------------

// Called from fnf.js when a separation is approved: moves the employee into
// notice_period and generates the offboarding checklist for that separation.
async function onSeparationApproved(userId, employeeSeparationId, actorId) {
  await db.updateLifecycleStatus(userId, 'notice_period');
  await db.createLifecycleEvent({ userId, eventType: 'resigned', effectiveDate: todayStr(), recordedBy: actorId });
  const tasksCreated = await generateChecklist(userId, 'offboarding', employeeSeparationId);
  return { tasksCreated };
}

// Called from fnf.js when a settlement is marked paid: the terminal lifecycle event.
async function onSettlementPaid(userId, actorId, client) {
  await db.updateLifecycleStatus(userId, 'exited', client);
  await db.createLifecycleEvent({ userId, eventType: 'exited', effectiveDate: todayStr(), recordedBy: actorId }, client);
}

module.exports = {
  initializeLifecycle,
  generateChecklist,
  completeOnboarding,
  transferDepartment,
  changeDesignation,
  changeManager,
  changeLocation,
  promoteEmployee,
  startProbation,
  confirmProbation,
  extendProbation,
  uploadDocument,
  getExpiringDocuments,
  completeChecklistTask,
  recordExitInterview,
  getEmployeeLifecycleProfile,
  onSeparationApproved,
  onSettlementPaid,
};

  },
  "payroll": function (require, module, exports) {
// src/payroll.js — payroll & tax calculation engine.
//
// Everything here is calculation/orchestration: CTC breakdown, income-tax
// slab calculation for both regimes, monthly TDS projection, the full
// monthly payroll run, salary revisions/hikes, and payslip data preparation.
// Pure data access (CRUD) lives in db.js; this module calls into db.js for
// reads/writes and focuses on the arithmetic and business rules.
//
// Ported from the payroll section of the original src/db.js. Formulas are
// unchanged; only the data-access calls were adapted to the new async/Prisma
// data layer.

const db = require('./db');
const attendance = require('./attendance');
const { nowStr, todayStr, evaluateArithmeticFormula, evaluateConditionalRule, computeEmi, yearsOfService } = require('./utils');

// ---------------------------------------------------------------------------
// SMALL MATH/DATE HELPERS
// ---------------------------------------------------------------------------

function roundMoney(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function dateOnly(d) {
  return d.toISOString().slice(0, 10);
}

function maxDate(a, b) {
  return a > b ? a : b;
}
function minDate(a, b) {
  return a < b ? a : b;
}

function daysInMonthUTC(year, month /* 1-12 */) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function parsePayrollMonth(payrollMonth) {
  // 'YYYY-MM'
  const [y, m] = payrollMonth.split('-').map(Number);
  return { year: y, month: m };
}

// ---------------------------------------------------------------------------
// STATUTORY TAX RULE DEFAULTS — used to backfill tax_rules/tax_slabs for a
// financial year the first time it's needed, so payroll never breaks just
// because the tax master data wasn't hand-entered for a new FY yet.
// (India FY24-25 / AY25-26 defaults; admins can override via the tax
// configuration screens which write straight to tax_rules/tax_slabs.)
// ---------------------------------------------------------------------------

const OLD_REGIME_SLABS = [
  { minIncome: 0, maxIncome: 250000, rate: 0 },
  { minIncome: 250000, maxIncome: 500000, rate: 5 },
  { minIncome: 500000, maxIncome: 1000000, rate: 20 },
  { minIncome: 1000000, maxIncome: null, rate: 30 },
];
const NEW_REGIME_SLABS = [
  { minIncome: 0, maxIncome: 300000, rate: 0 },
  { minIncome: 300000, maxIncome: 600000, rate: 5 },
  { minIncome: 600000, maxIncome: 900000, rate: 10 },
  { minIncome: 900000, maxIncome: 1200000, rate: 15 },
  { minIncome: 1200000, maxIncome: 1500000, rate: 20 },
  { minIncome: 1500000, maxIncome: null, rate: 30 },
];
const OLD_REGIME_RULES = {
  standard_deduction: { value: 50000, type: 'amount', description: 'Standard deduction' },
  rebate_87a_limit: { value: 500000, type: 'amount', description: 'Sec 87A rebate eligibility limit (taxable income)' },
  rebate_87a_amount: { value: 12500, type: 'amount', description: 'Sec 87A max rebate amount' },
  cess_rate: { value: 4, type: 'percentage', description: 'Health & education cess' },
};
const NEW_REGIME_RULES = {
  standard_deduction: { value: 75000, type: 'amount', description: 'Standard deduction' },
  rebate_87a_limit: { value: 700000, type: 'amount', description: 'Sec 87A rebate eligibility limit (taxable income)' },
  rebate_87a_amount: { value: 25000, type: 'amount', description: 'Sec 87A max rebate amount' },
  cess_rate: { value: 4, type: 'percentage', description: 'Health & education cess' },
};

async function ensureStatutoryTaxRules(financialYearId) {
  let regimes = await db.listTaxRegimes(financialYearId);
  if (!regimes.length) {
    const oldInfo = await db.insertTaxRegime(financialYearId, 'old', 'Old Tax Regime', false);
    const newInfo = await db.insertTaxRegime(financialYearId, 'new', 'New Tax Regime', true);
    regimes = [
      { id: oldInfo.lastInsertRowid, code: 'old' },
      { id: newInfo.lastInsertRowid, code: 'new' },
    ];
  }
  for (const regime of regimes) {
    const slabs = await db.listTaxSlabs(regime.id);
    if (!slabs.length) {
      const slabDefs = regime.code === 'new' ? NEW_REGIME_SLABS : OLD_REGIME_SLABS;
      let order = 0;
      for (const s of slabDefs) await db.insertTaxSlab(regime.id, s.minIncome, s.maxIncome, s.rate, order++);
    }
    const rules = await db.listTaxRules(regime.id);
    if (!rules.length) {
      const ruleDefs = regime.code === 'new' ? NEW_REGIME_RULES : OLD_REGIME_RULES;
      for (const [key, r] of Object.entries(ruleDefs)) await db.upsertTaxRule(regime.id, key, r.value, r.type, r.description);
    }
  }
  const limits = await db.listDeductionLimits(financialYearId);
  if (!limits.length) {
    await db.upsertDeductionLimit(financialYearId, '80C', 'Section 80C', 150000);
    await db.upsertDeductionLimit(financialYearId, '80D', 'Section 80D (Medical Insurance)', 25000);
    await db.upsertDeductionLimit(financialYearId, '80CCD1B', 'Section 80CCD(1B) NPS', 50000);
  }
  return regimes;
}

// ---------------------------------------------------------------------------
// INCOME TAX CALCULATION FOR A GIVEN REGIME
// ---------------------------------------------------------------------------

// annualTaxableIncome: gross annual income minus standard deduction and (for
// the old regime) approved Chapter VI-A deductions — the caller is
// responsible for arriving at this figure; this function only applies slabs,
// cess and the Section 87A rebate.
async function calculateTaxForRegime(taxRegimeId, annualTaxableIncome) {
  const slabs = await db.listTaxSlabs(taxRegimeId);
  const rules = await db.listTaxRules(taxRegimeId);
  const ruleMap = {};
  rules.forEach(r => { ruleMap[r.rule_key] = r.rule_value; });

  const income = Math.max(0, annualTaxableIncome);
  let tax = 0;
  for (const slab of slabs) {
    const min = slab.min_income;
    const max = slab.max_income === null || slab.max_income === undefined ? Infinity : slab.max_income;
    if (income <= min) continue;
    const slabAmount = Math.min(income, max) - min;
    if (slabAmount > 0) tax += slabAmount * (slab.rate / 100);
  }

  const rebateLimit = ruleMap.rebate_87a_limit;
  const rebateAmount = ruleMap.rebate_87a_amount;
  if (rebateLimit !== undefined && income <= rebateLimit) {
    tax = Math.max(0, tax - (rebateAmount || tax));
  }

  const cessRate = ruleMap.cess_rate !== undefined ? ruleMap.cess_rate : 4;
  const cess = tax * (cessRate / 100);
  return roundMoney(tax + cess);
}

// Full annual tax liability for an employee under a given regime, given
// their annualized gross salary income and (old regime only) approved
// deductions declared for the FY.
async function calculateTaxLiability(taxRegimeId, annualGrossIncome, approvedDeductions) {
  const rules = await db.listTaxRules(taxRegimeId);
  const ruleMap = {};
  rules.forEach(r => { ruleMap[r.rule_key] = r.rule_value; });
  const standardDeduction = ruleMap.standard_deduction || 0;

  const regime = await db.getTaxRegime(taxRegimeId);
  const isOldRegime = regime && regime.code === 'old';

  let taxableIncome = annualGrossIncome - standardDeduction;
  if (isOldRegime) taxableIncome -= (approvedDeductions || 0);
  taxableIncome = Math.max(0, roundMoney(taxableIncome));

  const annualTax = await calculateTaxForRegime(taxRegimeId, taxableIncome);
  return { taxableIncome, annualTax };
}

// ---------------------------------------------------------------------------
// PROJECTIONS USED TO SPREAD THE ANNUAL TAX LIABILITY ACROSS REMAINING MONTHS
// ---------------------------------------------------------------------------

function getRemainingPayrollMonths(financialYear, payrollMonth) {
  const fyStart = new Date(financialYear.start_date + 'T00:00:00');
  const fyEnd = new Date(financialYear.end_date + 'T00:00:00');
  const { year, month } = parsePayrollMonth(payrollMonth);
  const current = new Date(Date.UTC(year, month - 1, 1));
  let count = 0;
  const cursor = new Date(Date.UTC(fyStart.getUTCFullYear(), fyStart.getUTCMonth(), 1));
  while (cursor <= fyEnd) {
    if (cursor >= current) count++;
    cursor.setUTCMonth(cursor.getUTCMonth() + 1);
  }
  return Math.max(1, count);
}

async function getPriorPayrollTDS(userId, financialYearId, beforePayrollMonth) {
  const row = await db.dbGet(`
    SELECT COALESCE(SUM(pd.tds_deduction), 0) AS total
    FROM payroll_details pd
    JOIN payroll_runs pr ON pr.id = pd.payroll_run_id
    WHERE pd.user_id = ? AND pr.financial_year_id = ? AND pr.payroll_month < ?
      AND pr.status IN ('approved', 'locked', 'disbursed')
  `, [userId, financialYearId, beforePayrollMonth]);
  return Number(row.total);
}

// Projects the employee's full-FY gross salary income for tax purposes: what
// they've already earned (approved payroll months before this one) plus the
// remaining months at their current monthly CTC-derived gross rate.
async function getProjectedFYSalaryIncomeForPreview(userId, financialYear, payrollMonth, currentMonthGross) {
  const priorGross = await db.dbGet(`
    SELECT COALESCE(SUM(pd.gross_earning), 0) AS total
    FROM payroll_details pd
    JOIN payroll_runs pr ON pr.id = pd.payroll_run_id
    WHERE pd.user_id = ? AND pr.financial_year_id = ? AND pr.payroll_month < ?
      AND pr.status IN ('approved', 'locked', 'disbursed')
  `, [userId, financialYear.id, payrollMonth]);

  const remainingMonths = getRemainingPayrollMonths(financialYear, payrollMonth);
  const projectedRemaining = currentMonthGross * remainingMonths;

  const prevEmployer = await db.getPreviousEmployerIncome(userId, financialYear.id);
  const prevGross = prevEmployer ? prevEmployer.gross_income : 0;
  const prevTds = prevEmployer ? prevEmployer.tds_deducted : 0;

  return {
    projectedAnnualGross: roundMoney(Number(priorGross.total) + projectedRemaining + prevGross),
    previousEmployerTds: prevTds,
  };
}

async function getApprovedTaxDeductions(userId, financialYearId) {
  return db.getApprovedDeclarationsTotal(userId, financialYearId);
}

// Rough annualized gross salary income for an employee, used for the tax
// regime comparison/summary screens (self-service, informational only — the
// authoritative per-month figure used to actually withhold TDS is computed
// in getMonthlyTDS/calculateMonthlyPayroll from real payroll data).
async function getEmployeeAnnualGrossEstimate(userId, financialYearId) {
  const structure = await db.getActiveSalaryStructure(userId, financialYearId);
  if (!structure) return 0;
  const components = await db.getStructureComponents(structure.id);
  const annualEarnings = components
    .filter((c) => c.type === 'earning')
    .reduce((sum, c) => sum + Number(c.amount || 0), 0) * 12;
  return roundMoney(annualEarnings || Number(structure.annual_ctc || 0));
}

// Tax liability under every active regime for the FY, for the employee's
// self-service "compare regimes" screen.
async function compareTaxRegimesForEmployee(userId, financialYearId) {
  const [regimes, annualGrossIncome, approvedDeductions] = await Promise.all([
    db.listTaxRegimes(financialYearId),
    getEmployeeAnnualGrossEstimate(userId, financialYearId),
    getApprovedTaxDeductions(userId, financialYearId),
  ]);
  const comparison = [];
  for (const regime of regimes) {
    const { taxableIncome, annualTax } = await calculateTaxLiability(regime.id, annualGrossIncome, approvedDeductions);
    comparison.push({
      taxRegimeId: regime.id, name: regime.name, code: regime.code,
      annualGrossIncome, taxableIncome, annualTax,
    });
  }
  return comparison;
}

// Tax liability under the employee's currently-selected regime for the FY
// (falls back to the FY's default regime if none has been selected yet).
async function getEmployeeTaxSummary(userId, financialYearId) {
  const selected = await db.getEmployeeTaxRegime(userId, financialYearId);
  const regime = selected
    ? await db.getTaxRegime(selected.tax_regime_id)
    : await db.getDefaultTaxRegime(financialYearId);
  if (!regime) return { taxLiability: null, regime: null };
  const [annualGrossIncome, approvedDeductions] = await Promise.all([
    getEmployeeAnnualGrossEstimate(userId, financialYearId),
    getApprovedTaxDeductions(userId, financialYearId),
  ]);
  const { taxableIncome, annualTax } = await calculateTaxLiability(regime.id, annualGrossIncome, approvedDeductions);
  return { taxLiability: annualTax, taxableIncome, annualGrossIncome, regime };
}

// ---------------------------------------------------------------------------
// MONTHLY TDS
// ---------------------------------------------------------------------------

async function getMonthlyTDS(userId, financialYear, payrollMonth, currentMonthGross, taxRegimeId) {
  const { projectedAnnualGross, previousEmployerTds } = await getProjectedFYSalaryIncomeForPreview(userId, financialYear, payrollMonth, currentMonthGross);
  const approvedDeductions = await getApprovedTaxDeductions(userId, financialYear.id);
  const { taxableIncome, annualTax } = await calculateTaxLiability(taxRegimeId, projectedAnnualGross, approvedDeductions);

  const priorTds = await getPriorPayrollTDS(userId, financialYear.id, payrollMonth);
  const alreadyDeducted = roundMoney(priorTds + previousEmployerTds);
  const remainingLiability = Math.max(0, roundMoney(annualTax - alreadyDeducted));
  const remainingMonths = getRemainingPayrollMonths(financialYear, payrollMonth);
  const monthlyTds = roundMoney(remainingLiability / remainingMonths);

  return {
    taxableIncome,
    annualTaxableIncome: taxableIncome,
    annualTax,
    tdsAlreadyDeducted: alreadyDeducted,
    remainingTaxLiability: remainingLiability,
    monthlyTds,
  };
}

// ---------------------------------------------------------------------------
// SALARY STRUCTURE — CTC BREAKDOWN
// ---------------------------------------------------------------------------

// Splits an annual CTC into the standard component set (Basic, HRA,
// Allowances, PF employer contribution, etc.) using each active component's
// calculation_type/calculation_value from salary_components, unless the
// caller supplies explicit per-component overrides.
async function populateDefaultStructureComponents(structureId, annualCtc, basicSalary, overrides = {}, client) {
  const components = await db.listSalaryComponents(true);
  const monthlyCtc = annualCtc / 12;
  const monthlyBasic = basicSalary / 12;

  for (const c of components) {
    if (overrides[c.code] !== undefined) {
      await db.insertStructureComponent(structureId, c.id, roundMoney(overrides[c.code]), true, client);
      continue;
    }
    let amount = 0;
    const formulaVars = { monthlyBasic, monthlyCtc, basic: monthlyBasic, ctc: monthlyCtc, annualCtc, basicSalary };
    if (c.code === 'BASIC') {
      amount = monthlyBasic;
    } else if (c.calculation_type === 'percentage_of_basic' && c.calculation_value != null) {
      amount = monthlyBasic * (c.calculation_value / 100);
    } else if (c.calculation_type === 'percentage_of_ctc' && c.calculation_value != null) {
      amount = monthlyCtc * (c.calculation_value / 100);
    } else if (c.calculation_type === 'fixed_amount' && c.calculation_value != null) {
      amount = c.calculation_value;
    } else if (c.calculation_type === 'formula' && c.formula) {
      try {
        amount = evaluateArithmeticFormula(c.formula, formulaVars);
      } catch (e) {
        throw new Error(`Salary component "${c.code}" has an invalid formula: ${e.message}`);
      }
    } else if (c.calculation_type === 'conditional' && c.conditional_rule) {
      try {
        amount = evaluateConditionalRule(c.conditional_rule, formulaVars);
      } catch (e) {
        throw new Error(`Salary component "${c.code}" has an invalid conditional rule: ${e.message}`);
      }
    } else if (c.type === 'earning' && c.code === 'HRA') {
      amount = monthlyBasic * 0.4; // fallback: 40% of basic, non-metro default
    } else {
      continue; // no rule and no override -> component simply isn't part of this structure
    }
    await db.insertStructureComponent(structureId, c.id, roundMoney(amount), false, client);
  }
}

// Creates a new salary structure in 'draft' status. It intentionally does
// NOT touch any existing active structure — the employee's current active
// structure keeps driving payroll until an admin explicitly activates this
// draft via activateSalaryStructure(), which is the point superseding
// happens. This matches the UI's draft -> review/edit components -> activate
// workflow (a structure is editable via saveSalaryStructureComponents while
// still in draft).
async function createSalaryStructure({ userId, financialYearId, effectiveFrom, annualCtc, basicSalary, createdBy, componentOverrides }) {
  annualCtc = roundMoney(annualCtc);
  basicSalary = roundMoney(basicSalary != null ? basicSalary : annualCtc * 0.4);
  const monthlyCtc = roundMoney(annualCtc / 12);

  return db.withTx(async (tx) => {
    const info = await db.insertSalaryStructureRow({
      userId, financialYearId, effectiveFrom, annualCtc, monthlyCtc, basicSalary, status: 'draft', createdBy,
    }, tx);
    await populateDefaultStructureComponents(info.lastInsertRowid, annualCtc, basicSalary, componentOverrides || {}, tx);
    await db.logPayrollAudit('salary_structure', info.lastInsertRowid, 'created', createdBy, null, { annualCtc, basicSalary, effectiveFrom }, tx);
    return info.lastInsertRowid;
  });
}

// Activates a draft salary structure: supersedes any other currently-active
// structure for the same employee/FY, then flips this one to 'active'.
async function activateSalaryStructureFull(structureId, actorId) {
  return db.withTx(async (tx) => {
    const structure = await db.getSalaryStructureById(structureId);
    if (!structure) throw new Error('Salary structure not found');
    await db.supersedeActiveStructures(structure.user_id, structure.financial_year_id, structure.effective_from, tx);
    await db.activateSalaryStructure(structureId, tx);
    await db.logPayrollAudit('salary_structure', structureId, 'activated', actorId, null, null, tx);
  });
}

async function setSalaryStructureComponents(structureId, componentAmounts, actorId) {
  return db.withTx(async (tx) => {
    const structure = await db.getSalaryStructureById(structureId);
    if (!structure) throw new Error('Salary structure not found');
    for (const [componentId, amount] of Object.entries(componentAmounts)) {
      await db.insertStructureComponent(structureId, Number(componentId), roundMoney(amount), true, tx);
    }
    const components = await db.getStructureComponents(structureId, tx);
    const monthlyCtc = components.reduce((sum, c) => sum + (c.type === 'earning' ? c.amount : 0), 0);
    await db.logPayrollAudit('salary_structure', structureId, 'components_updated', actorId, null, componentAmounts, tx);
    return monthlyCtc;
  });
}

// A salary hike/revision: closes out the old structure, opens a new one, and
// records the delta for reporting (salary_revisions). newAnnualCtc can be
// given directly, or derived from the employee's current active CTC plus a
// hikePercentage or hikeAmount (the admin UI lets the caller use whichever
// of the three is most convenient, and only ever sends one of them).
async function giveSalaryHike({ userId, financialYearId, newAnnualCtc, newBasicSalary, hikePercentage, hikeAmount, effectiveDate, revisionType, reason, notes, approvedBy, componentOverrides, isRetroactive }) {
  return db.withTx(async (tx) => {
    const previous = await db.getActiveSalaryStructure(userId, financialYearId);
    if (newAnnualCtc == null) {
      if (!previous) throw new Error('No active salary structure found for this employee — enter the new annual CTC directly');
      if (hikePercentage != null) newAnnualCtc = Number(previous.annual_ctc) * (1 + Number(hikePercentage) / 100);
      else if (hikeAmount != null) newAnnualCtc = Number(previous.annual_ctc) + Number(hikeAmount);
      else throw new Error('Provide a hike percentage, hike amount, or new annual CTC');
    }
    newAnnualCtc = roundMoney(newAnnualCtc);
    newBasicSalary = roundMoney(newBasicSalary != null ? newBasicSalary : newAnnualCtc * 0.4);
    const newMonthlyCtc = roundMoney(newAnnualCtc / 12);

    await db.supersedeActiveStructures(userId, financialYearId, effectiveDate, tx);
    const info = await db.insertSalaryStructureRow({
      userId, financialYearId, effectiveFrom: effectiveDate, annualCtc: newAnnualCtc, monthlyCtc: newMonthlyCtc, basicSalary: newBasicSalary,
      status: 'active', createdBy: approvedBy,
    }, tx);
    await populateDefaultStructureComponents(info.lastInsertRowid, newAnnualCtc, newBasicSalary, componentOverrides || {}, tx);

    const computedHikeAmount = previous ? roundMoney(newAnnualCtc - previous.annual_ctc) : null;
    const computedHikePercentage = previous && previous.annual_ctc ? roundMoney((computedHikeAmount / previous.annual_ctc) * 100) : null;

    const revisionId = await db.insertSalaryRevision({
      userId,
      salaryStructureId: info.lastInsertRowid,
      previousAnnualCtc: previous ? previous.annual_ctc : null,
      newAnnualCtc,
      previousMonthlyCtc: previous ? previous.monthly_ctc : null,
      newMonthlyCtc,
      previousBasicSalary: previous ? previous.basic_salary : null,
      newBasicSalary,
      hikePercentage: computedHikePercentage,
      hikeAmount: computedHikeAmount,
      effectiveDate,
      revisionType: revisionType || 'annual_appraisal',
      reason,
      notes,
      isRetroactive: !!isRetroactive,
      approvedBy,
    }, tx);

    let arrearsGenerated = [];
    if (isRetroactive && previous) {
      arrearsGenerated = await generateArrearsForRetroactiveRevision({
        userId, financialYearId, effectiveDate,
        previousMonthlyCtc: Number(previous.monthly_ctc), newMonthlyCtc,
        revisionId: revisionId.lastInsertRowid, tx,
      });
    }

    await db.logPayrollAudit('salary_structure', info.lastInsertRowid, 'salary_hike', approvedBy,
      previous ? { annualCtc: previous.annual_ctc } : null, { annualCtc: newAnnualCtc, hikeAmount: computedHikeAmount, hikePercentage: computedHikePercentage }, tx);

    return { id: info.lastInsertRowid, newCtc: newAnnualCtc, hikePercentage: computedHikePercentage, hikeAmount: computedHikeAmount, arrearsGenerated };
  });
}

async function updateEmployeeCompensation(userId, financialYearId, patch, actorId) {
  const structure = await db.getActiveSalaryStructure(userId, financialYearId);
  if (!structure) throw new Error('No active salary structure found for this employee/financial year');
  return giveSalaryHike({
    userId,
    financialYearId,
    newAnnualCtc: patch.annualCtc != null ? patch.annualCtc : structure.annual_ctc,
    newBasicSalary: patch.basicSalary,
    effectiveDate: patch.effectiveDate || nowStr().slice(0, 10),
    revisionType: patch.revisionType || 'mid_year_correction',
    reason: patch.reason,
    notes: patch.notes,
    approvedBy: actorId,
    componentOverrides: patch.componentOverrides,
  });
}

// ---------------------------------------------------------------------------
// ATTENDANCE-BASED PRORATION (LOP) FOR A PAYROLL MONTH
// ---------------------------------------------------------------------------

async function getAttendanceForPayroll(userId, year, month) {
  // Prefer real attendance data (Block 2) when this employee has any
  // recorded attendance for the month — it gives an accurate LOP figure
  // driven by actual check-in/check-out and manual marking history.
  const fromAttendance = await attendance.computeAttendanceSummaryForPayroll(userId, year, month);
  if (fromAttendance) return fromAttendance;

  // No attendance records for this employee/month yet (attendance module
  // not adopted for them) — fall back to the original design: working days
  // are derived from weekends + company holidays, and LOP is intentionally
  // NOT auto-derived from timesheets or leave gaps (timesheets track
  // project hours, not attendance). It defaults to 0 unless the payroll
  // admin records it via a variable deduction, or the employee is later
  // switched onto the attendance module above.
  const totalDays = daysInMonthUTC(year, month);
  const monthStart = `${year}-${String(month).padStart(2, '0')}-01`;
  const monthEnd = `${year}-${String(month).padStart(2, '0')}-${String(totalDays).padStart(2, '0')}`;

  const holidays = await db.getHolidaysInRange(monthStart, monthEnd);
  const holidaySet = new Set(holidays.map(h => h.holiday_date));

  let workingDays = 0;
  for (let d = 1; d <= totalDays; d++) {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const day = new Date(dateStr + 'T00:00:00').getUTCDay();
    if (day === 0 || day === 6) continue;
    if (holidaySet.has(dateStr)) continue;
    workingDays++;
  }

  return { workingDays, paidDays: workingDays, lopDays: 0 };
}

// ---------------------------------------------------------------------------
// FULL MONTHLY PAYROLL CALCULATION FOR ONE EMPLOYEE
// ---------------------------------------------------------------------------

async function calculateMonthlyPayroll(userId, financialYear, payrollMonth, client) {
  const { year, month } = parsePayrollMonth(payrollMonth);
  const monthEndStr = `${year}-${String(month).padStart(2, '0')}-${String(daysInMonthUTC(year, month)).padStart(2, '0')}`;

  const structure = await db.getSalaryStructureAsOf(userId, monthEndStr);
  if (!structure) {
    return { error: 'NO_SALARY_STRUCTURE', message: 'No active salary structure found for this payroll month' };
  }

  const components = await db.getStructureComponents(structure.id);
  const earning = (code) => {
    const c = components.find(x => x.code === code);
    return c ? c.amount : 0;
  };

  const basicEarning = earning('BASIC');
  const hraEarning = earning('HRA');
  const otherEarningComponents = components.filter(c => c.type === 'earning' && !['BASIC', 'HRA'].includes(c.code));
  const allowancesEarning = otherEarningComponents.reduce((sum, c) => sum + c.amount, 0);

  const { workingDays, paidDays, lopDays } = await getAttendanceForPayroll(userId, year, month);
  const prorationFactor = workingDays > 0 ? paidDays / workingDays : 1;

  const variableDeductions = await db.listVariableDeductions(userId, payrollMonth);
  const variableEarningRows = variableDeductions.filter(v => {
    const comp = components.find(c => c.component_id === v.component_id) || v;
    return v.type === 'earning';
  });

  const overtimeEarning = 0; // overtime pay-out is handled via variable_deductions with an OVERTIME earning component, if configured
  const bonusEarning = variableDeductions.filter(v => v.code === 'BONUS').reduce((s, v) => s + v.amount, 0);
  const reimbursementEarning = components.filter(c => c.type === 'reimbursement').reduce((s, c) => s + c.amount, 0);
  const otherEarning = variableDeductions.filter(v => v.code && v.code !== 'BONUS' && db_isEarningCode(v.code)).reduce((s, v) => s + v.amount, 0);

  // Arrears from retroactive salary revisions — paid out as a one-time
  // earning the next time payroll runs for this employee.
  const pendingArrears = await db.listPendingArrearsForUser(userId, client);
  const arrearsPlan = pendingArrears.map(a => ({ arrearsId: a.id, amount: a.amount }));
  const arrearsEarning = roundMoney(pendingArrears.reduce((s, a) => s + Number(a.amount), 0));

  // Approved-but-unpaid leave encashment requests — paid out the same way.
  const approvedEncashments = await db.listApprovedUnpaidEncashmentsForUser(userId, client);
  const encashmentPlan = approvedEncashments.map(e => ({ encashmentId: e.id, amount: e.amount }));
  const leaveEncashmentEarning = roundMoney(approvedEncashments.reduce((s, e) => s + Number(e.amount), 0));

  const grossEarningFull = roundMoney(basicEarning + hraEarning + allowancesEarning + reimbursementEarning);
  const grossEarning = roundMoney(grossEarningFull * prorationFactor + bonusEarning + overtimeEarning + otherEarning + arrearsEarning + leaveEncashmentEarning);

  // Fixed statutory/company deductions
  const fixedDeductions = await db.listFixedDeductions(userId, structure.financial_year_id);
  const pfEmployeeDeduction = roundMoney((fixedDeductions.find(f => f.code === 'PF_EMPLOYEE') || { amount: Math.min(basicEarning, 15000) * 0.12 }).amount * prorationFactor);
  const professionalTaxDeduction = roundMoney((fixedDeductions.find(f => f.code === 'PT') || { amount: grossEarning > 15000 ? 200 : 0 }).amount);
  const insuranceDeduction = roundMoney((fixedDeductions.find(f => f.code === 'INSURANCE') || { amount: 0 }).amount);
  const otherFixedDeduction = roundMoney(fixedDeductions.filter(f => !['PF_EMPLOYEE', 'PT', 'INSURANCE'].includes(f.code)).reduce((s, f) => s + f.amount, 0));

  const variableDeductionsTotal = roundMoney(variableDeductions.filter(v => v.code && !db_isEarningCode(v.code) && v.code !== 'BONUS').reduce((s, v) => s + v.amount, 0));

  // Loans — one EMI per active loan, split into principal/interest via the
  // reducing-balance method, capped so a loan never goes below zero balance.
  const activeLoans = await db.listActiveLoansForUser(userId, client);
  const loanPlan = [];
  let loanDeduction = 0;
  for (const loan of activeLoans) {
    const monthlyRate = (Number(loan.interest_rate_annual) || 0) / 12 / 100;
    const interestComponent = roundMoney(loan.outstanding_balance * monthlyRate);
    let emi = Number(loan.emi_amount) || 0;
    let principalComponent = roundMoney(emi - interestComponent);
    if (principalComponent > loan.outstanding_balance) {
      // final instalment — pay off exactly what's left instead of overshooting
      principalComponent = loan.outstanding_balance;
      emi = roundMoney(principalComponent + interestComponent);
    }
    const balanceAfter = roundMoney(Math.max(0, loan.outstanding_balance - principalComponent));
    loanPlan.push({ loanId: loan.id, amount: emi, principalComponent, interestComponent, balanceAfter });
    loanDeduction += emi;
  }
  loanDeduction = roundMoney(loanDeduction);

  // Salary advances — flat monthly recovery amount until the balance clears.
  const recoveringAdvances = await db.listRecoveringAdvancesForUser(userId, client);
  const advancePlan = [];
  let advanceRecoveryDeduction = 0;
  for (const advance of recoveringAdvances) {
    const recoveryAmount = Math.min(Number(advance.monthly_recovery_amount) || 0, advance.outstanding_balance);
    const balanceAfter = roundMoney(Math.max(0, advance.outstanding_balance - recoveryAmount));
    advancePlan.push({ advanceId: advance.id, amount: roundMoney(recoveryAmount), balanceAfter });
    advanceRecoveryDeduction += recoveryAmount;
  }
  advanceRecoveryDeduction = roundMoney(advanceRecoveryDeduction);

  const taxRegimeSelection = await db.getEmployeeTaxRegime(userId, structure.financial_year_id);
  const taxRegime = taxRegimeSelection
    ? await db.getTaxRegime(taxRegimeSelection.tax_regime_id)
    : await db.getDefaultTaxRegime(structure.financial_year_id);

  const annualizedGrossForTax = roundMoney((basicEarning + hraEarning + allowancesEarning) * 12);
  const tds = await getMonthlyTDS(userId, financialYear, payrollMonth, annualizedGrossForTax / 12, taxRegime.id);

  const totalDeductions = roundMoney(pfEmployeeDeduction + professionalTaxDeduction + insuranceDeduction + otherFixedDeduction + variableDeductionsTotal + tds.monthlyTds + loanDeduction + advanceRecoveryDeduction);
  const netSalary = roundMoney(grossEarning - totalDeductions);

  const exceptions = [];
  if (netSalary < 0) exceptions.push({ code: 'NEGATIVE_NET', message: 'Net salary computed as negative', severity: 'error' });
  if (!taxRegimeSelection) exceptions.push({ code: 'NO_REGIME_SELECTED', message: 'Employee has not selected a tax regime; used FY default', severity: 'warning' });
  if (lopDays > 0) exceptions.push({ code: 'LOP_APPLIED', message: `${lopDays} day(s) of loss-of-pay applied`, severity: 'info' });
  if (loanDeduction > 0) exceptions.push({ code: 'LOAN_EMI_APPLIED', message: `Loan EMI of ${loanDeduction} deducted`, severity: 'info' });
  if (advanceRecoveryDeduction > 0) exceptions.push({ code: 'ADVANCE_RECOVERY_APPLIED', message: `Salary advance recovery of ${advanceRecoveryDeduction} deducted`, severity: 'info' });
  if (arrearsEarning > 0) exceptions.push({ code: 'ARREARS_PAID', message: `Arrears of ${arrearsEarning} paid out`, severity: 'info' });
  if (leaveEncashmentEarning > 0) exceptions.push({ code: 'LEAVE_ENCASHMENT_PAID', message: `Leave encashment of ${leaveEncashmentEarning} paid out`, severity: 'info' });

  return {
    salaryStructureId: structure.id,
    basicEarning: roundMoney(basicEarning * prorationFactor),
    hraEarning: roundMoney(hraEarning * prorationFactor),
    allowancesEarning: roundMoney(allowancesEarning * prorationFactor),
    variableEarning: roundMoney(otherEarning),
    overtimeEarning: roundMoney(overtimeEarning),
    bonusEarning: roundMoney(bonusEarning),
    reimbursementEarning: roundMoney(reimbursementEarning * prorationFactor),
    otherEarning: 0,
    arrearsEarning,
    leaveEncashmentEarning,
    grossEarning,
    pfEmployeeDeduction,
    professionalTaxDeduction,
    insuranceDeduction,
    otherFixedDeduction,
    variableDeductionsTotal,
    loanDeduction,
    advanceRecoveryDeduction,
    tdsDeduction: tds.monthlyTds,
    totalDeductions,
    taxableIncome: tds.taxableIncome,
    annualTaxableIncome: tds.annualTaxableIncome,
    annualTax: tds.annualTax,
    monthlyTds: tds.monthlyTds,
    tdsAlreadyDeducted: tds.tdsAlreadyDeducted,
    remainingTaxLiability: tds.remainingTaxLiability,
    netSalary,
    workingDays,
    paidDays,
    lopDays,
    exceptions,
    loanPlan,
    advancePlan,
    arrearsPlan,
    encashmentPlan,
  };
}

function db_isEarningCode(code) {
  return ['BONUS', 'OVERTIME', 'ARREARS', 'REIMBURSEMENT'].includes(code);
}

// ---------------------------------------------------------------------------
// FULL PAYROLL RUN — ALL EMPLOYEES FOR A MONTH
// ---------------------------------------------------------------------------

async function calculatePayrollRun(financialYearId, payrollMonth, actorId) {
  const financialYear = await db.getFinancialYear(financialYearId);
  if (!financialYear) throw new Error('Financial year not found');
  await ensureStatutoryTaxRules(financialYearId);

  return db.withTx(async (tx) => {
    const run = await db.getOrCreatePayrollRun(financialYearId, payrollMonth, tx);
    if (run.status === 'locked' || run.status === 'disbursed') {
      throw new Error(`Payroll run for ${payrollMonth} is already ${run.status} and cannot be recalculated`);
    }
    await db.reversePayrollSideEffectsForRun(run.id, tx);
    await db.clearPayrollDetailsForRun(run.id, tx);

    const employees = await db.dbAll("SELECT id FROM users WHERE active = 'active' AND role != 'admin'", [], tx);
    let totalGross = 0, totalDeductions = 0, totalTds = 0, totalNet = 0, calculated = 0;

    for (const emp of employees) {
      const result = await calculateMonthlyPayroll(emp.id, financialYear, payrollMonth, tx);
      if (result.error) {
        await db.addPayrollException(run.id, emp.id, result.error, result.message, 'error', tx);
        continue;
      }
      const info = await db.insertPayrollDetail({ payrollRunId: run.id, userId: emp.id, ...result }, tx);
      const payrollDetailId = info.lastInsertRowid;
      for (const ex of result.exceptions) {
        await db.addPayrollException(run.id, emp.id, ex.code, ex.message, ex.severity, tx);
      }
      for (const p of result.loanPlan) {
        await db.applyLoanRepayment(p.loanId, { amount: p.amount, principalComponent: p.principalComponent, interestComponent: p.interestComponent, balanceAfter: p.balanceAfter, payrollMonth, payrollDetailId }, tx);
      }
      for (const p of result.advancePlan) {
        await db.applyAdvanceRecovery(p.advanceId, { amount: p.amount, balanceAfter: p.balanceAfter, payrollMonth, payrollDetailId }, tx);
      }
      for (const p of result.arrearsPlan) {
        await db.markArrearsPaid(p.arrearsId, payrollDetailId, tx);
      }
      for (const p of result.encashmentPlan) {
        await db.markLeaveEncashmentPaid(p.encashmentId, payrollDetailId, tx);
      }
      totalGross += result.grossEarning;
      totalDeductions += result.totalDeductions;
      totalTds += result.tdsDeduction;
      totalNet += result.netSalary;
      calculated++;
    }

    await db.updatePayrollRunTotals(run.id, {
      totalEmployees: calculated,
      totalGross: roundMoney(totalGross),
      totalDeductions: roundMoney(totalDeductions),
      totalTds: roundMoney(totalTds),
      totalNet: roundMoney(totalNet),
    }, tx);
    await db.setPayrollRunStatus(run.id, 'calculated', actorId, tx);
    await db.logPayrollAudit('payroll_run', run.id, 'calculated', actorId, null, { totalEmployees: calculated, payrollMonth }, tx);

    return db.getPayrollRun(run.id, tx);
  });
}

async function reviewPayrollRun(payrollRunId, actorId) {
  await db.setPayrollRunStatus(payrollRunId, 'reviewed', actorId);
  await db.logPayrollAudit('payroll_run', payrollRunId, 'reviewed', actorId);
}

async function approvePayrollRun(payrollRunId, actorId) {
  return db.withTx(async (tx) => {
    const details = await db.dbAll('SELECT id FROM payroll_details WHERE payroll_run_id = ?', [payrollRunId], tx);
    for (const d of details) await db.updatePayrollDetailStatus(d.id, 'approved', actorId, tx);
    await db.setPayrollRunStatus(payrollRunId, 'approved', actorId, tx);
    await db.logPayrollAudit('payroll_run', payrollRunId, 'approved', actorId, null, null, tx);
  });
}

async function lockPayrollRun(payrollRunId, actorId) {
  await db.setPayrollRunStatus(payrollRunId, 'locked', actorId);
  await db.logPayrollAudit('payroll_run', payrollRunId, 'locked', actorId);
}

// ---------------------------------------------------------------------------
// PAYROLL ADJUSTMENTS (post-calculation correction workflow)
// ---------------------------------------------------------------------------

const ADJUSTMENT_FIELD_MAP = {
  earning: 'other_earning',
  deduction: 'other_fixed_deduction',
  tds: 'tds_deduction',
};

async function requestPayrollAdjustment(payrollDetailId, adjustmentType, amount, reason, requestedBy) {
  return db.createPayrollAdjustment({ payrollDetailId, adjustmentType, amount, reason, requestedBy });
}

async function decidePayrollAdjustment(adjustmentId, decision, actorId) {
  return db.withTx(async (tx) => {
    const adjustments = await db.dbAll('SELECT * FROM payroll_adjustments WHERE id = ?', [adjustmentId], tx);
    const adj = adjustments[0];
    if (!adj) throw new Error('Adjustment not found');
    if (adj.status !== 'pending') throw new Error('This adjustment has already been decided');

    await db.decidePayrollAdjustment(adjustmentId, decision === 'approve' ? 'approved' : 'rejected', actorId, tx);
    if (decision === 'approve') {
      const field = ADJUSTMENT_FIELD_MAP[adj.adjustment_type] || 'other_earning';
      await db.applyPayrollAdjustmentToDetail(adj.payroll_detail_id, field, adj.amount, tx);
    }
    await db.logPayrollAudit('payroll_adjustment', adjustmentId, decision, actorId, null, { amount: adj.amount }, tx);
  });
}

// ---------------------------------------------------------------------------
// PAYSLIP DATA PREPARATION (PDF byte generation lives in reports.js)
// ---------------------------------------------------------------------------

async function preparePayslipData(payrollDetailId) {
  const detail = await db.getPayrollDetail(payrollDetailId);
  if (!detail) throw new Error('Payroll detail not found');
  const run = await db.getPayrollRun(detail.payroll_run_id);
  const user = await db.findUserById(detail.user_id);
  const financialYear = await db.getFinancialYear(run.financial_year_id);
  const structure = detail.salary_structure_id ? await db.getSalaryStructureById(detail.salary_structure_id) : null;
  const components = structure ? await db.getStructureComponents(structure.id) : [];
  const settings = await db.getSettings();

  return { detail, run, user, financialYear, components, settings };
}

async function generatePayslipRecord(payrollDetailId, generatedBy, pdfPath) {
  const detail = await db.getPayrollDetail(payrollDetailId);
  if (!detail) throw new Error('Payroll detail not found');
  const run = await db.getPayrollRun(detail.payroll_run_id);
  return db.withTx(async (tx) => {
    const payslip = await db.createPayslip(payrollDetailId, detail.user_id, run.payroll_month, pdfPath, generatedBy, tx);
    await db.logPayrollAudit('payslip', payslip.id, 'generated', generatedBy, null, { payrollDetailId }, tx);
    return payslip;
  });
}

// ---------------------------------------------------------------------------
// ARREARS FROM RETROACTIVE SALARY REVISIONS
// ---------------------------------------------------------------------------

// When a revision is backdated over months whose payroll has already been
// approved/locked, this creates one arrears_payments row per already-settled
// month equal to the change in monthly CTC, prorated by that month's actual
// paid-day ratio. This is a deliberate simplification (a true component-by-
// component recompute of each historical month under the new structure
// would need each month's exact original inputs re-run) but it is the same
// approximation payroll teams commonly use for arrears — the delta is
// transparent, auditable per month via arrears_payments, and paid out
// automatically the next time payroll runs for the employee.
async function generateArrearsForRetroactiveRevision({ userId, financialYearId, effectiveDate, previousMonthlyCtc, newMonthlyCtc, revisionId, tx }) {
  const delta = roundMoney(newMonthlyCtc - (previousMonthlyCtc || 0));
  const created = [];
  if (delta === 0) return created;
  const fromMonth = effectiveDate.slice(0, 7);
  const currentMonth = nowStr().slice(0, 7);
  const settledMonths = await db.listSettledPayrollMonthsForUser(userId, financialYearId, fromMonth, currentMonth, tx);
  for (const m of settledMonths) {
    const ratio = m.working_days > 0 ? m.paid_days / m.working_days : 1;
    const amount = roundMoney(delta * ratio);
    if (amount === 0) continue;
    const info = await db.createArrearsPayment({
      userId, salaryRevisionId: revisionId, forPayrollMonth: m.payroll_month, amount,
      reason: `Arrears for retroactive salary revision effective ${effectiveDate}`,
    }, tx);
    created.push({ id: info.lastInsertRowid, forPayrollMonth: m.payroll_month, amount });
  }
  return created;
}

// ---------------------------------------------------------------------------
// GRATUITY (Payment of Gratuity Act, 1972 convention) — a compute-on-demand
// liability/estimate, not a disbursement. Actual gratuity payout happens as
// part of full & final settlement at exit (a separate module); this gives
// admins and employees a running estimate for CTC/liability visibility.
// ---------------------------------------------------------------------------

const GRATUITY_ELIGIBILITY_YEARS = 5;
const GRATUITY_STATUTORY_CAP = 2000000; // ₹20,00,000 statutory ceiling (Payment of Gratuity Act)

async function calculateGratuity(userId, financialYearId, asOfDate) {
  const user = await db.findUserById(userId);
  if (!user) throw new Error('Employee not found');
  const asOf = asOfDate || todayStr();
  const years = yearsOfService(user.joined_date, asOf);

  const fy = financialYearId ? await db.getFinancialYear(financialYearId) : await db.getActiveFinancialYear();
  const structure = fy ? await db.getSalaryStructureAsOf(userId, asOf) : null;
  let lastDrawnBasic = 0;
  if (structure) {
    const components = await db.getStructureComponents(structure.id);
    const basic = components.find(c => c.code === 'BASIC');
    lastDrawnBasic = basic ? basic.amount : 0;
  }

  const eligible = years >= GRATUITY_ELIGIBILITY_YEARS;
  const rawAmount = eligible ? roundMoney((lastDrawnBasic * 15 * years) / 26) : 0;
  const gratuityAmount = Math.min(rawAmount, GRATUITY_STATUTORY_CAP);

  return {
    userId,
    joinedDate: user.joined_date,
    asOfDate: asOf,
    yearsOfService: years,
    eligible,
    eligibilityThresholdYears: GRATUITY_ELIGIBILITY_YEARS,
    lastDrawnBasic,
    rawAmount,
    gratuityAmount: roundMoney(gratuityAmount),
    statutoryCapApplied: rawAmount > GRATUITY_STATUTORY_CAP,
  };
}

// ---------------------------------------------------------------------------
// LOANS — request / approve / disburse
// ---------------------------------------------------------------------------

async function requestLoan({ userId, principalAmount, interestRateAnnual, tenureMonths, purpose }) {
  if (!(principalAmount > 0)) throw new Error('Principal amount must be greater than zero');
  if (!(tenureMonths >= 1)) throw new Error('Tenure must be at least 1 month');
  return db.createLoan({ userId, principalAmount: roundMoney(principalAmount), interestRateAnnual: interestRateAnnual || 0, tenureMonths, purpose });
}

async function decideLoanRequest(loanId, decision, actorId) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const loan = await db.getLoan(loanId);
  if (!loan) throw new Error('Loan not found');
  if (loan.status !== 'pending') throw new Error('This loan request has already been decided');
  await db.decideLoan(loanId, decision, actorId);
  await db.logPayrollAudit('loan', loanId, decision, actorId);
  return db.getLoan(loanId);
}

async function disburseLoanFull(loanId, actorId) {
  const loan = await db.getLoan(loanId);
  if (!loan) throw new Error('Loan not found');
  if (loan.status !== 'approved') throw new Error('Only an approved loan can be disbursed');
  const emi = computeEmi(loan.principal_amount, loan.interest_rate_annual, loan.tenure_months);
  return db.withTx(async (tx) => {
    await db.disburseLoan(loanId, emi, tx);
    await db.logPayrollAudit('loan', loanId, 'disbursed', actorId, null, { emiAmount: emi }, tx);
    return db.getLoan(loanId, tx);
  });
}

// ---------------------------------------------------------------------------
// SALARY ADVANCES — request / approve
// ---------------------------------------------------------------------------

async function requestSalaryAdvance({ userId, amount, reason, recoveryMonths }) {
  if (!(amount > 0)) throw new Error('Advance amount must be greater than zero');
  return db.createSalaryAdvance({ userId, amount: roundMoney(amount), reason, recoveryMonths: recoveryMonths || 1 });
}

async function decideSalaryAdvanceRequest(advanceId, decision, actorId, recoveryMonths, monthlyRecoveryAmount) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const advance = await db.getSalaryAdvance(advanceId);
  if (!advance) throw new Error('Salary advance request not found');
  if (advance.status !== 'pending') throw new Error('This advance request has already been decided');
  await db.decideSalaryAdvance(advanceId, decision, actorId, recoveryMonths, monthlyRecoveryAmount);
  await db.logPayrollAudit('salary_advance', advanceId, decision, actorId);
  return db.getSalaryAdvance(advanceId);
}

// ---------------------------------------------------------------------------
// LEAVE ENCASHMENT — request / approve
// ---------------------------------------------------------------------------

async function requestLeaveEncashment({ userId, leaveTypeId, financialYearId, days }) {
  if (!(days > 0)) throw new Error('Days to encash must be greater than zero');
  const year = (await db.getFinancialYear(financialYearId)).start_date.slice(0, 4);
  const balance = await db.dbGet('SELECT * FROM leave_balances WHERE user_id = ? AND leave_type_id = ? AND year = ?', [userId, leaveTypeId, Number(year)]);
  const available = balance ? Number(balance.total_days) - Number(balance.used_days) : 0;
  if (days > available) throw new Error(`Only ${available} day(s) available to encash for this leave type`);

  const structure = await db.getActiveSalaryStructure(userId, financialYearId);
  if (!structure) throw new Error('No active salary structure found — cannot compute encashment value');
  const components = await db.getStructureComponents(structure.id);
  const basic = components.find(c => c.code === 'BASIC');
  const monthlyBasic = basic ? basic.amount : 0;
  const perDayAmount = roundMoney(monthlyBasic / 26);
  const amount = roundMoney(perDayAmount * days);

  return db.withTx(async (tx) => {
    const info = await db.createLeaveEncashmentRequest({ userId, leaveTypeId, financialYearId, days, perDayAmount, amount }, tx);
    return { id: info.lastInsertRowid, days, perDayAmount, amount };
  });
}

async function decideLeaveEncashmentRequest(encashmentId, decision, actorId) {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('decision must be approved or rejected');
  const enc = await db.getLeaveEncashment(encashmentId);
  if (!enc) throw new Error('Leave encashment request not found');
  if (enc.status !== 'pending') throw new Error('This encashment request has already been decided');
  return db.withTx(async (tx) => {
    await db.decideLeaveEncashment(encashmentId, decision, actorId, tx);
    if (decision === 'approved') {
      // Deduct from the leave balance immediately (payout happens on the
      // next payroll run); rejecting leaves the balance untouched.
      const year = (await db.getFinancialYear(enc.financial_year_id)).start_date.slice(0, 4);
      await db.dbRun('UPDATE leave_balances SET used_days = used_days + ? WHERE user_id = ? AND leave_type_id = ? AND year = ?',
        [enc.days, enc.user_id, enc.leave_type_id, Number(year)], tx);
    }
    await db.logPayrollAudit('leave_encashment', encashmentId, decision, actorId, null, null, tx);
    return db.getLeaveEncashment(encashmentId, tx);
  });
}

// ---------------------------------------------------------------------------
// MONTH-TO-MONTH PAYROLL COMPARISON & VARIANCE REPORT
// ---------------------------------------------------------------------------

async function comparePayrollMonths(financialYearId, monthA, monthB) {
  const [detailsA, detailsB] = await Promise.all([
    db.getPayrollDetailsByMonth(financialYearId, monthA),
    db.getPayrollDetailsByMonth(financialYearId, monthB),
  ]);
  const byUserA = new Map(detailsA.map(d => [d.user_id, d]));
  const byUserB = new Map(detailsB.map(d => [d.user_id, d]));
  const userIds = new Set([...byUserA.keys(), ...byUserB.keys()]);

  const employees = [];
  for (const userId of userIds) {
    const a = byUserA.get(userId);
    const b = byUserB.get(userId);
    employees.push({
      userId,
      userName: (a || b).user_name,
      grossA: a ? a.gross_earning : 0,
      grossB: b ? b.gross_earning : 0,
      grossDelta: roundMoney((b ? b.gross_earning : 0) - (a ? a.gross_earning : 0)),
      netA: a ? a.net_salary : 0,
      netB: b ? b.net_salary : 0,
      netDelta: roundMoney((b ? b.net_salary : 0) - (a ? a.net_salary : 0)),
      tdsA: a ? a.tds_deduction : 0,
      tdsB: b ? b.tds_deduction : 0,
      tdsDelta: roundMoney((b ? b.tds_deduction : 0) - (a ? a.tds_deduction : 0)),
      presentInA: !!a,
      presentInB: !!b,
    });
  }
  employees.sort((x, y) => x.userName.localeCompare(y.userName));

  const totals = (rows, key) => roundMoney(rows.reduce((s, r) => s + Number(r[key] || 0), 0));
  return {
    monthA, monthB,
    totals: {
      grossA: totals(detailsA, 'gross_earning'), grossB: totals(detailsB, 'gross_earning'),
      netA: totals(detailsA, 'net_salary'), netB: totals(detailsB, 'net_salary'),
      tdsA: totals(detailsA, 'tds_deduction'), tdsB: totals(detailsB, 'tds_deduction'),
      headcountA: detailsA.length, headcountB: detailsB.length,
    },
    employees,
  };
}

async function payrollVarianceReport(financialYearId, monthA, monthB, thresholdPercent) {
  const threshold = thresholdPercent != null ? Number(thresholdPercent) : 10;
  const comparison = await comparePayrollMonths(financialYearId, monthA, monthB);
  const flagged = comparison.employees
    .filter(e => e.presentInA && e.presentInB)
    .map(e => {
      const pctChange = e.netA ? roundMoney((e.netDelta / e.netA) * 100) : (e.netB ? 100 : 0);
      return { ...e, pctChange };
    })
    .filter(e => Math.abs(e.pctChange) >= threshold)
    .sort((x, y) => Math.abs(y.pctChange) - Math.abs(x.pctChange));

  const newJoiners = comparison.employees.filter(e => !e.presentInA && e.presentInB);
  const dropped = comparison.employees.filter(e => e.presentInA && !e.presentInB);

  return { monthA, monthB, thresholdPercent: threshold, flagged, newJoiners, dropped, totals: comparison.totals };
}

module.exports = {
  compareTaxRegimesForEmployee,
  getEmployeeTaxSummary,
  activateSalaryStructureFull,
  roundMoney,
  dateOnly,
  maxDate,
  minDate,
  daysInMonthUTC,
  ensureStatutoryTaxRules,
  calculateTaxForRegime,
  calculateTaxLiability,
  getRemainingPayrollMonths,
  getPriorPayrollTDS,
  getProjectedFYSalaryIncomeForPreview,
  getApprovedTaxDeductions,
  getMonthlyTDS,
  populateDefaultStructureComponents,
  createSalaryStructure,
  setSalaryStructureComponents,
  giveSalaryHike,
  updateEmployeeCompensation,
  getAttendanceForPayroll,
  calculateMonthlyPayroll,
  calculatePayrollRun,
  reviewPayrollRun,
  approvePayrollRun,
  lockPayrollRun,
  requestPayrollAdjustment,
  decidePayrollAdjustment,
  preparePayslipData,
  generatePayslipRecord,
  generateArrearsForRetroactiveRevision,
  calculateGratuity,
  requestLoan,
  decideLoanRequest,
  disburseLoanFull,
  requestSalaryAdvance,
  decideSalaryAdvanceRequest,
  requestLeaveEncashment,
  decideLeaveEncashmentRequest,
  comparePayrollMonths,
  payrollVarianceReport,
};

  },
  "reports": function (require, module, exports) {
// src/reports.js — report aggregation, CSV export, and the payslip PDF
// builder. Ported from the reporting section of src/db.js and the
// hand-rolled PDF writer that used to live in src/server.js.
//
// NOTE on the PDF builder: the original server.js built payslip PDFs with a
// hand-written, dependency-free PDF byte writer (raw content stream +
// manual xref table). That exact drawing-command sequence was not
// available to re-transcribe verbatim during this migration, so the
// version below is a faithful re-implementation — same payslip fields and a
// comparable single-page layout, produced with the same
// no-external-dependency approach — rather than a byte-for-byte port. If
// pixel-identical output matters (e.g. for a template already distributed
// to employees), diff a sample payslip from the old and new backends and
// adjust the coordinates below.

const db = require('./db');
const { csvEscape, genericCsv } = require('./utils');

// ---------------------------------------------------------------------------
// CSV EXPORTS
// ---------------------------------------------------------------------------

function timesheetsToCsv(rows) {
  const header = ['id', 'user_name', 'week_start', 'status', 'total_hours', 'overtime_hours', 'submitted_at', 'decided_at'];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push(header.map(h => csvEscape(r[h])).join(','));
  }
  return lines.join('\n');
}

function leaveToCsv(rows) {
  const header = ['id', 'user_name', 'from_date', 'to_date', 'days', 'status', 'reason', 'applied_at', 'decided_at'];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push(header.map(h => csvEscape(r[h])).join(','));
  }
  return lines.join('\n');
}

function payrollDetailsToCsv(rows) {
  const header = ['user_name', 'employee_code', 'basic_earning', 'hra_earning', 'allowances_earning', 'gross_earning',
    'pf_employee_deduction', 'professional_tax_deduction', 'tds_deduction', 'total_deductions', 'net_salary', 'status'];
  const lines = [header.join(',')];
  for (const r of rows) lines.push(header.map(h => csvEscape(r[h])).join(','));
  return lines.join('\n');
}

function reportRowsToCsv(rows) {
  return genericCsv(rows);
}

// ---------------------------------------------------------------------------
// REPORT AGGREGATIONS
// ---------------------------------------------------------------------------

async function reportProjectHours(from, to) {
  // The UI expects one row per project + employee with an `hours` field.
  // The previous PostgreSQL port grouped only by project and returned
  // `timesheet_count`, which made the report render blank/incorrect data.
  return db.dbAll(`
    SELECT p.name AS project_name, u.name AS user_name,
      COALESCE(SUM(te.hours), 0) AS hours
    FROM timesheet_entries te
    JOIN timesheets t ON t.id = te.timesheet_id AND t.status = 'approved'
    JOIN users u ON u.id = t.user_id
    LEFT JOIN projects p ON p.id = te.project_id
    WHERE te.entry_date BETWEEN ? AND ?
    GROUP BY p.id, p.name, u.id, u.name
    ORDER BY hours DESC, u.name, p.name
  `, [from, to]);
}

async function reportEmployeeUtilization(from, to, managerScope) {
  let where = "WHERE u.active = 'active' AND t.status = 'approved' AND t.week_start BETWEEN ? AND ?";
  let params = [from, to];
  if (managerScope && managerScope.length) {
    where += ` AND u.manager_id IN (${managerScope.map(() => '?').join(',')})`;
    params = [...params, ...managerScope];
  }

  const rows = await db.dbAll(`
    SELECT u.name AS user_name, u.dept,
      COALESCE(SUM(t.total_hours), 0) AS total_hours,
      COALESCE(SUM(t.overtime_hours), 0) AS overtime_hours,
      COUNT(t.id) AS weeks_submitted
    FROM users u
    JOIN timesheets t ON t.user_id = u.id
    ${where}
    GROUP BY u.id, u.name, u.dept
    ORDER BY total_hours DESC
  `, params);

  // Calculate utilization against expected working hours in the selected
  // calendar range. This keeps the report meaningful for partial months.
  const settings = await db.getSettings();
  const hoursPerDay = Number(settings.standard_hours_per_day) || 8;
  const start = new Date(`${from}T00:00:00`);
  const end = new Date(`${to}T00:00:00`);
  let workingDays = 0;
  if (!Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && start <= end) {
    for (const d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const day = d.getDay();
      if (day !== 0 && day !== 6) workingDays++;
    }
  }
  const expectedHours = Math.max(workingDays * hoursPerDay, 1);
  return rows.map((row) => ({
    ...row,
    utilization_pct: Math.round((Number(row.total_hours || 0) / expectedHours) * 10000) / 100,
  }));
}

async function reportLeaveUsage(year, managerScope) {
  let where = 'WHERE lb.year = ?';
  let params = [year];
  if (managerScope && managerScope.length) {
    where += ` AND u.manager_id IN (${managerScope.map(() => '?').join(',')})`;
    params = [...params, ...managerScope];
  }

  return db.dbAll(`
    SELECT u.name AS user_name, lt.name AS type_name,
      lb.total_days, lb.used_days,
      COALESCE((
        SELECT SUM(la.days)
        FROM leave_applications la
        WHERE la.user_id = lb.user_id
          AND la.leave_type_id = lb.leave_type_id
          AND la.status = 'pending'
          AND substr(la.from_date, 1, 4) = CAST(lb.year AS TEXT)
      ), 0) AS pending_days,
      (lb.total_days - lb.used_days) AS remaining_days
    FROM leave_balances lb
    JOIN users u ON u.id = lb.user_id
    JOIN leave_types lt ON lt.id = lb.leave_type_id
    ${where}
    ORDER BY u.name, lt.name
  `, params);
}

async function reportTimesheetCompliance(from, to, managerScope) {
  let where = "WHERE u.active = 'active'";
  let params = [];
  if (managerScope && managerScope.length) {
    where += ` AND u.manager_id IN (${managerScope.map(() => '?').join(',')})`;
    params = managerScope;
  }

  // Compliance is a per-employee report. The UI needs email + a status for
  // the selected week/range, not aggregate counts.
  return db.dbAll(`
    SELECT u.name AS user_name, u.email,
      COALESCE(
        (
          SELECT t.status
          FROM timesheets t
          WHERE t.user_id = u.id
            AND t.week_start BETWEEN ? AND ?
          ORDER BY t.week_start DESC
          LIMIT 1
        ),
        'not submitted'
      ) AS status
    FROM users u
    ${where}
    ORDER BY u.name
  `, [from, to, ...params]);
}

async function reportPendingApprovals(managerScope) {
  let tsWhere = "WHERE t.status = 'pending'";
  let lvWhere = "WHERE l.status = 'pending'";
  let params = [];
  if (managerScope && managerScope.length) {
    const placeholders = managerScope.map(() => '?').join(',');
    tsWhere += ` AND u.manager_id IN (${placeholders})`;
    lvWhere += ` AND u.manager_id IN (${placeholders})`;
    params = managerScope;
  }

  const timesheets = await db.dbAll(`
    SELECT t.id, u.name AS user_name, m.name AS manager_name,
      t.week_start, t.submitted_at, t.escalated
    FROM timesheets t
    JOIN users u ON u.id = t.user_id
    LEFT JOIN users m ON m.id = u.manager_id
    ${tsWhere}
    ORDER BY t.submitted_at
  `, params);

  const leave = await db.dbAll(`
    SELECT l.id, u.name AS user_name, m.name AS manager_name,
      l.from_date, l.to_date, l.applied_at, l.escalated
    FROM leave_applications l
    JOIN users u ON u.id = l.user_id
    LEFT JOIN users m ON m.id = u.manager_id
    ${lvWhere}
    ORDER BY l.applied_at
  `, params);

  const now = Date.now();
  const daysSince = (ts) => (ts
    ? Math.max(0, Math.floor((now - new Date(String(ts).replace(' ', 'T') + 'Z').getTime()) / 86400000))
    : 0);
  timesheets.forEach((t) => { t.days_pending = daysSince(t.submitted_at); });
  leave.forEach((l) => { l.days_pending = daysSince(l.applied_at); });
  return { timesheets, leave };
}

async function reportPayrollSummary(payrollRunId) {
  const run = await db.getPayrollRun(payrollRunId);
  const details = await db.listPayrollDetails(payrollRunId);
  return { run, details };
}

// ---------------------------------------------------------------------------
// MINIMAL, DEPENDENCY-FREE PDF WRITER (Helvetica text + simple lines/rects)
// ---------------------------------------------------------------------------

class PdfDoc {
  constructor(widthPt = 595, heightPt = 842) {
    this.width = widthPt;
    this.height = heightPt;
    this.content = [];
  }

  text(x, y, str, { size = 10, bold = false, align = 'left' } = {}) {
    const font = bold ? '/F2' : '/F1';
    const escaped = pdfEscape(str);
    let xPos = x;
    const strLen = String(str == null ? '' : str).length;
    if (align === 'right') xPos = x - strLen * size * 0.5;
    else if (align === 'center') xPos = x - (strLen * size * 0.5) / 2;
    this.content.push(`BT ${font} ${size} Tf ${xPos.toFixed(2)} ${(this.height - y).toFixed(2)} Td (${escaped}) Tj ET`);
  }

  line(x1, y1, x2, y2, width = 0.6) {
    this.content.push(`${width} w ${x1.toFixed(2)} ${(this.height - y1).toFixed(2)} m ${x2.toFixed(2)} ${(this.height - y2).toFixed(2)} l S`);
  }

  rect(x, y, w, h, { fill = false, stroke = true } = {}) {
    const op = fill && stroke ? 'B' : fill ? 'f' : 'S';
    this.content.push(`${x.toFixed(2)} ${(this.height - y - h).toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re ${op}`);
  }

  build() {
    const streamText = this.content.join('\n');
    const streamLen = Buffer.byteLength(streamText, 'utf8');

    const objs = [];
    objs.push('<< /Type /Catalog /Pages 2 0 R >>'); // 1
    objs.push('<< /Type /Pages /Kids [3 0 R] /Count 1 >>'); // 2
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${this.width} ${this.height}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`); // 3
    objs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'); // 4
    objs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>'); // 5
    objs.push(`<< /Length ${streamLen} >>\nstream\n${streamText}\nendstream`); // 6

    let out = '%PDF-1.4\n';
    const offsets = [0];
    for (let i = 0; i < objs.length; i++) {
      offsets.push(Buffer.byteLength(out, 'utf8'));
      out += `${i + 1} 0 obj\n${objs[i]}\nendobj\n`;
    }
    const xrefStart = Buffer.byteLength(out, 'utf8');
    out += `xref\n0 ${objs.length + 1}\n`;
    out += '0000000000 65535 f \n';
    for (let i = 1; i <= objs.length; i++) {
      out += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    }
    out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
    return Buffer.from(out, 'latin1');
  }
}

function pdfEscape(str) {
  return String(str == null ? '' : str).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function moneyPdf(value) {
  const n = Number(value) || 0;
  return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function datePdf(value) {
  if (!value) return '-';
  return String(value).slice(0, 10);
}

function monthLabelPdf(payrollMonth) {
  const [y, m] = payrollMonth.split('-').map(Number);
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return `${months[m - 1]} ${y}`;
}

// data: { detail, run, user, financialYear, components, settings } — see
// payroll.preparePayslipData().
function buildPayslipPdf(data) {
  const { detail, run, user, settings } = data;
  const doc = new PdfDoc();
  const companyName = (settings && settings.company_name) || 'Vasjo Technologies';

  doc.text(40, 50, companyName, { size: 16, bold: true });
  doc.text(40, 68, 'Payslip', { size: 11 });
  doc.text(555, 50, monthLabelPdf(run.payroll_month), { size: 11, align: 'right' });
  doc.line(40, 80, 555, 80);

  doc.text(40, 105, 'Employee Name:', { size: 9, bold: true });
  doc.text(160, 105, user.name, { size: 9 });
  doc.text(320, 105, 'Employee Code:', { size: 9, bold: true });
  doc.text(430, 105, user.employee_code || '-', { size: 9 });

  doc.text(40, 122, 'Department:', { size: 9, bold: true });
  doc.text(160, 122, user.dept || '-', { size: 9 });
  doc.text(320, 122, 'PAN:', { size: 9, bold: true });
  doc.text(430, 122, user.pan || '-', { size: 9 });

  doc.text(40, 139, 'Bank Account:', { size: 9, bold: true });
  doc.text(160, 139, user.bank_account_no || '-', { size: 9 });
  doc.text(320, 139, 'UAN:', { size: 9, bold: true });
  doc.text(430, 139, user.uan || '-', { size: 9 });

  doc.line(40, 155, 555, 155);

  let y = 180;
  doc.text(40, y, 'Earnings', { size: 10, bold: true });
  doc.text(320, y, 'Deductions', { size: 10, bold: true });
  y += 20;

  const earningsRows = [
    ['Basic', detail.basic_earning],
    ['HRA', detail.hra_earning],
    ['Allowances', detail.allowances_earning],
    ['Variable Pay', detail.variable_earning],
    ['Overtime', detail.overtime_earning],
    ['Bonus', detail.bonus_earning],
    ['Reimbursements', detail.reimbursement_earning],
    ['Other Earnings', detail.other_earning],
  ].filter(r => Number(r[1]) > 0);

  const deductionRows = [
    ['Provident Fund', detail.pf_employee_deduction],
    ['Professional Tax', detail.professional_tax_deduction],
    ['Insurance', detail.insurance_deduction],
    ['Other Deductions', detail.other_fixed_deduction],
    ['Variable Deductions', detail.variable_deductions_total],
    ['Income Tax (TDS)', detail.tds_deduction],
  ].filter(r => Number(r[1]) > 0);

  const rowCount = Math.max(earningsRows.length, deductionRows.length);
  for (let i = 0; i < rowCount; i++) {
    if (earningsRows[i]) {
      doc.text(40, y, earningsRows[i][0], { size: 9 });
      doc.text(300, y, moneyPdf(earningsRows[i][1]), { size: 9, align: 'right' });
    }
    if (deductionRows[i]) {
      doc.text(320, y, deductionRows[i][0], { size: 9 });
      doc.text(555, y, moneyPdf(deductionRows[i][1]), { size: 9, align: 'right' });
    }
    y += 16;
  }

  y += 10;
  doc.line(40, y, 555, y);
  y += 20;
  doc.text(40, y, 'Gross Earnings', { size: 9, bold: true });
  doc.text(300, y, moneyPdf(detail.gross_earning), { size: 9, bold: true, align: 'right' });
  doc.text(320, y, 'Total Deductions', { size: 9, bold: true });
  doc.text(555, y, moneyPdf(detail.total_deductions), { size: 9, bold: true, align: 'right' });

  y += 30;
  doc.rect(40, y - 14, 515, 26);
  doc.text(50, y + 4, 'Net Salary', { size: 11, bold: true });
  doc.text(545, y + 4, `Rs. ${moneyPdf(detail.net_salary)}`, { size: 11, bold: true, align: 'right' });

  y += 45;
  doc.text(40, y, `Paid Days: ${detail.paid_days} / ${detail.working_days}  |  Loss of Pay Days: ${detail.lop_days}`, { size: 8 });
  y += 30;
  doc.text(40, y, 'This is a system-generated payslip and does not require a signature.', { size: 7 });

  return doc.build();
}

module.exports = {
  timesheetsToCsv,
  leaveToCsv,
  payrollDetailsToCsv,
  genericCsv,
  reportRowsToCsv,
  reportProjectHours,
  reportEmployeeUtilization,
  reportLeaveUsage,
  reportTimesheetCompliance,
  reportPendingApprovals,
  reportPayrollSummary,
  buildPayslipPdf,
  moneyPdf,
  datePdf,
  monthLabelPdf,
};

  },
  "enterprise": function (require, module, exports) {
const crypto = require('node:crypto');
const db = require('./db');
const { nowStr } = require('./utils');

const BUILTIN_ROLE_PERMISSIONS = {
  'HR Admin':['employee.*','lifecycle.*','document.read','document.upload','document.verify','workflow.manage','workflow.act','audit.read','reports.read','admin.configure','recruitment.read','recruitment.write','performance.read','performance.write','learning.read','learning.write','benefits.read','benefits.write','expense.read','expense.write','asset.read','asset.write','helpdesk.read','helpdesk.write','integration.manage','analytics.read','ai.assistant','ai.document','ai.payroll'],
  'Payroll Admin':['payroll.read','payroll.calculate','payroll.review','payroll.approve','payroll.lock','document.read','document.upload','workflow.act','audit.read','reports.read','analytics.read','ai.payroll'],
  'Payroll Reviewer':['payroll.read','payroll.review','payroll.approve','document.read','workflow.act','audit.read','reports.read','analytics.read'],
  'Manager':['employee.read','document.read','document.upload','workflow.act','leave.approve','timesheet.approve','reports.read','performance.read','performance.write','learning.read','benefits.read','expense.read','expense.write','asset.read','helpdesk.read','analytics.read'],
  'Employee':['document.self','document.read','document.upload','performance.read','performance.write','learning.read','learning.write','benefits.read','benefits.write','expense.read','expense.write','asset.read','helpdesk.read','helpdesk.write','analytics.read','ai.assistant'],
  'Auditor':['audit.read','reports.read','document.read','analytics.read'],
  'Finance':['expense.read','expense.write','payroll.read','payroll.approve','reports.read','analytics.read','workflow.act'],
};

function safeJson(v) { try { return v == null ? null : JSON.stringify(v); } catch { return null; } }
async function audit(ctx, action, resourceType, resourceId, before, after, outcome='success') {
  const req = ctx?.req;
  await db.dbRun(`INSERT INTO audit_events (tenant_id,actor_id,action,resource_type,resource_id,before_json,after_json,timestamp,request_id,ip,user_agent,outcome)
                  VALUES (?,?,?,?,?,?::jsonb,?::jsonb,?,?,?,?,?)`, [ctx.tenantId, ctx.actorId || null, action, resourceType, resourceId == null ? null : String(resourceId), safeJson(before), safeJson(after), nowStr(), req?.requestId || null, req?.ip || null, req?.get?.('user-agent') || null, outcome]);
}

async function getTenantByUser(userId) { return db.dbGet('SELECT tm.tenant_id, t.* FROM tenant_memberships tm JOIN tenants t ON t.id=tm.tenant_id WHERE tm.user_id=? AND tm.status=\'active\' ORDER BY tm.tenant_id LIMIT 1',[userId]); }
async function getMembership(userId, tenantId) { return db.dbGet('SELECT * FROM tenant_memberships WHERE user_id=? AND tenant_id=? AND status=\'active\'',[userId,tenantId]); }
async function ensureMembership(userId, tenantId, role) {
  await db.dbRun(`INSERT INTO tenant_memberships(tenant_id,user_id,role,status,created_at) VALUES (?,?,?,?,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET role=EXCLUDED.role,status='active'`,[tenantId,userId,role||'employee', 'active', nowStr()]);
}
async function permissionsForUser(userId, tenantId) {
  const rows = await db.dbAll(`SELECT DISTINCT p.code FROM user_roles ur JOIN roles r ON r.id=ur.role_id JOIN role_permissions rp ON rp.role_id=r.id JOIN permissions p ON p.id=rp.permission_id WHERE ur.tenant_id=? AND ur.user_id=?`,[tenantId,userId]);
  if (rows.length) return rows.map(r=>r.code);
  const m = await getMembership(userId,tenantId);
  const roleMap = {admin:['HR Admin','Payroll Admin'],manager:['Manager'],employee:['Employee']};
  return [...new Set((roleMap[m?.role]||['Employee']).flatMap(r=>BUILTIN_ROLE_PERMISSIONS[r]||[]))];
}
function hasPermission(user, permission) {
  if (user?.role === 'admin') return true;
  const ps = user?.permissions || [];
  if (ps.includes(permission)) return true;
  const [resource] = permission.split('.');
  return ps.includes(`${resource}.*`) || ps.includes('*');
}
function requirePermission(permission) {
  return (req,res,next) => {
    if (!req.session?.user) return res.status(401).json({error:'Not signed in'});
    if (!hasPermission(req.session.user,permission)) return res.status(403).json({error:'Missing permission', permission});
    next();
  };
}

async function listAudit(ctx,{entityType,entityId,limit=200}={}) {
  const where=[]; const p=[ctx.tenantId]; where.push('ae.tenant_id=?');
  if(entityType){where.push('ae.resource_type=?');p.push(entityType)}
  if(entityId){where.push('ae.resource_id=?');p.push(String(entityId))}
  p.push(Math.min(Math.max(Number(limit)||200,1),500));
  return db.dbAll(`SELECT ae.*,u.name actor_name FROM audit_events ae LEFT JOIN users u ON u.id=ae.actor_id WHERE ${where.join(' AND ')} ORDER BY ae.id DESC LIMIT ?`,p);
}

async function listFeatureFlags(ctx){ return db.dbAll('SELECT * FROM feature_flags WHERE tenant_id=? ORDER BY key',[ctx.tenantId]); }
async function setFeatureFlag(ctx,key,enabled,config={}) {
  await db.dbRun(`INSERT INTO feature_flags(tenant_id,key,enabled,config_json,updated_at) VALUES (?,?,?,?::jsonb,?) ON CONFLICT(tenant_id,key) DO UPDATE SET enabled=EXCLUDED.enabled,config_json=EXCLUDED.config_json,updated_at=EXCLUDED.updated_at`,[ctx.tenantId,key,enabled?1:0,JSON.stringify(config),nowStr()]);
  await audit(ctx,'feature_flag.updated','feature_flag',key,null,{enabled:!!enabled,config});
  return db.dbGet('SELECT * FROM feature_flags WHERE tenant_id=? AND key=?',[ctx.tenantId,key]);
}
async function listRoles(ctx){ return db.dbAll(`SELECT r.*, COALESCE(json_agg(p.code) FILTER (WHERE p.code IS NOT NULL),'[]') permissions FROM roles r LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE r.tenant_id=? GROUP BY r.id ORDER BY r.name`,[ctx.tenantId]); }
async function upsertRole(ctx,{name,description,permissionCodes=[]}) {
  const role=await db.dbGet(`INSERT INTO roles(tenant_id,name,description,is_system,created_at) VALUES (?,?,?,0,?) ON CONFLICT(tenant_id,name) DO UPDATE SET description=EXCLUDED.description RETURNING id,*`,[ctx.tenantId,name,description||null,nowStr()]);
  await db.dbRun('DELETE FROM role_permissions WHERE role_id=?',[role.id]);
  for(const code of permissionCodes){const p=await db.dbGet('SELECT id FROM permissions WHERE code=?',[code]); if(p) await db.dbRun('INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?) ON CONFLICT DO NOTHING',[role.id,p.id]);}
  await audit(ctx,'role.updated','role',role.id,null,{name,permissionCodes}); return role;
}

async function listDocumentTypes(ctx){return db.dbAll('SELECT * FROM document_types WHERE tenant_id=? ORDER BY name',[ctx.tenantId]);}
async function ensureDocumentType(ctx,{name,code,required=false,expiryEnabled=false,expiryReminders,sensitive=false,verificationPolicy='hr',allowedExtensions}){
  const row=await db.dbGet(`INSERT INTO document_types(tenant_id,name,code,required,expiry_enabled,expiry_reminders,verification_policy,sensitive,allowed_extensions,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,name) DO UPDATE SET code=EXCLUDED.code RETURNING *`,[ctx.tenantId,name,code||null,required?1:0,expiryEnabled?1:0,expiryReminders||'90,60,30,15,7,1,0',verificationPolicy,sensitive?1:0,allowedExtensions||'pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv',nowStr()]);
  return row;
}

async function createDocumentRecord(ctx,meta){
  const id=crypto.randomUUID();
  const doc=await db.dbGet(`INSERT INTO documents(id,tenant_id,document_type_id,name,status,verification_status,owner_user_id,linked_module,linked_resource_id,expires_on,retention_until,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[id,ctx.tenantId,meta.documentTypeId||null,meta.name,'pending_verification','pending',meta.ownerUserId||null,meta.linkedModule||null,meta.linkedResourceId==null?null:String(meta.linkedResourceId),meta.expiresOn||null,meta.retentionUntil||null,ctx.actorId,nowStr(),nowStr()]);
  return doc;
}
async function addDocumentVersion(ctx,{documentId,objectKey,checksum,sizeBytes,mimeType,source,sourceReference,originalFilename,uploadReason,malwareStatus='clean'}){
  const current=await db.dbGet('SELECT COALESCE(MAX(version_no),0) n FROM document_versions WHERE tenant_id=? AND document_id=?',[ctx.tenantId,documentId]);
  const versionNo=Number(current.n||0)+1; const id=crypto.randomUUID();
  const ver=await db.dbGet(`INSERT INTO document_versions(id,tenant_id,document_id,version_no,object_key,checksum_sha256,size_bytes,mime_type,source,source_reference,original_filename,uploaded_by,upload_reason,malware_status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[id,ctx.tenantId,documentId,versionNo,objectKey,checksum,Number(sizeBytes),mimeType,source,sourceReference||null,originalFilename,ctx.actorId,uploadReason||null,malwareStatus,nowStr()]);
  await db.dbRun('UPDATE documents SET current_version_id=?,updated_at=?,status=?,verification_status=? WHERE tenant_id=? AND id=?',[id,nowStr(),'pending_verification','pending',ctx.tenantId,documentId]);
  await db.dbRun('INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,version_id,created_at,metadata_json) VALUES(?,?,?,?,?,? ,?::jsonb)',[ctx.tenantId,documentId,ctx.actorId,'upload',id,nowStr(),JSON.stringify({source,versionNo})]);
  await audit(ctx,'document.upload','document',documentId,null,{versionId:id,versionNo,source,checksum});
  return ver;
}
async function listDocuments(ctx,{ownerUserId,module,resourceId,status,search}={}) {
  const w=['d.tenant_id=?']; const p=[ctx.tenantId];
  if(ownerUserId){w.push('d.owner_user_id=?');p.push(ownerUserId)} if(module){w.push('d.linked_module=?');p.push(module)} if(resourceId){w.push('d.linked_resource_id=?');p.push(String(resourceId))} if(status){w.push('d.status=?');p.push(status)} if(search){w.push('d.name ILIKE ?');p.push(`%${search}%`)}
  return db.dbAll(`SELECT d.*,dv.version_no,dv.size_bytes,dv.mime_type,dv.source,dv.original_filename,dv.checksum_sha256,dt.name document_type_name FROM documents d LEFT JOIN document_versions dv ON dv.id=d.current_version_id LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE ${w.join(' AND ')} ORDER BY d.updated_at DESC`,p);
}
async function getDocument(ctx,id){return db.dbGet(`SELECT d.*,dv.object_key,dv.version_no,dv.size_bytes,dv.mime_type,dv.source,dv.original_filename,dv.checksum_sha256,dv.uploaded_by,dv.created_at version_created_at,dt.name document_type_name FROM documents d LEFT JOIN document_versions dv ON dv.id=d.current_version_id LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE d.tenant_id=? AND d.id=?`,[ctx.tenantId,id]);}
async function listDocumentVersions(ctx,id){return db.dbAll(`SELECT * FROM document_versions WHERE tenant_id=? AND document_id=? ORDER BY version_no DESC`,[ctx.tenantId,id]);}
async function linkDocument(ctx,{documentId,resourceType,resourceId}){await db.dbRun(`INSERT INTO document_links(tenant_id,document_id,resource_type,resource_id,created_at) VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING`,[ctx.tenantId,documentId,resourceType,String(resourceId),nowStr()]); await audit(ctx,'document.link','document',documentId,null,{resourceType,resourceId});}
async function verifyDocument(ctx,id,status,reason){if(!['verified','rejected'].includes(status))throw new Error('Invalid verification status'); if(status==='rejected'&&!reason)throw new Error('Rejection reason is required'); const before=await getDocument(ctx,id); if(!before)throw new Error('Document not found'); await db.dbRun(`UPDATE documents SET verification_status=?,status=?,updated_at=? WHERE tenant_id=? AND id=?`,[status,status==='verified'?'verified':'rejected',nowStr(),ctx.tenantId,id]); await db.dbRun(`INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,reason,created_at) VALUES(?,?,?,?,?,?)`,[ctx.tenantId,id,ctx.actorId,status,reason||null,nowStr()]); await audit(ctx,`document.${status}`,'document',id,before,{verificationStatus:status,reason}); return getDocument(ctx,id);}
async function restoreVersion(ctx,id,versionId,reason){const d=await getDocument(ctx,id); const v=await db.dbGet('SELECT * FROM document_versions WHERE tenant_id=? AND document_id=? AND id=?',[ctx.tenantId,id,versionId]); if(!d||!v)throw new Error('Document/version not found'); await db.dbRun('UPDATE documents SET current_version_id=?,updated_at=? WHERE tenant_id=? AND id=?',[versionId,nowStr(),ctx.tenantId,id]); await db.dbRun(`INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,version_id,reason,created_at) VALUES(?,?,?,?,?,?,?)`,[ctx.tenantId,id,ctx.actorId,'restore',versionId,reason||null,nowStr()]); await audit(ctx,'document.version.restore','document',id,d,{versionId,reason}); return getDocument(ctx,id);}
async function expiringDocuments(ctx,daysAhead=30){const rows=await db.dbAll(`SELECT d.*,dv.original_filename,dt.name document_type_name FROM documents d LEFT JOIN document_versions dv ON dv.id=d.current_version_id LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE d.tenant_id=? AND d.expires_on IS NOT NULL AND d.expires_on <= to_char((CURRENT_DATE + (? * INTERVAL '1 day')),'YYYY-MM-DD') ORDER BY d.expires_on`,[ctx.tenantId,daysAhead]); return rows;}

async function listWorkflows(ctx){return db.dbAll(`SELECT w.*,COUNT(s.id)::int step_count FROM workflow_definitions w LEFT JOIN workflow_steps s ON s.workflow_id=w.id WHERE w.tenant_id=? GROUP BY w.id ORDER BY w.module,w.name`,[ctx.tenantId]);}
async function createWorkflow(ctx,{module,name,triggerEvent,active=true,steps=[]}){const w=await db.dbGet(`INSERT INTO workflow_definitions(tenant_id,module,name,trigger_event,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,module,name,triggerEvent,active?1:0,nowStr(),nowStr()]); for(const st of steps){await db.dbRun(`INSERT INTO workflow_steps(tenant_id,workflow_id,step_no,approval_mode,approver_type,approver_value,condition_json,sla_hours,escalation_type,escalation_value) VALUES(?,?,?,?,?,?,?::jsonb,?,?,?)`,[ctx.tenantId,w.id,st.stepNo,st.approvalMode||'sequential',st.approverType,st.approverValue||null,JSON.stringify(st.condition||{}),st.slaHours||null,st.escalationType||null,st.escalationValue||null]);} await audit(ctx,'workflow.created','workflow',w.id,null,{module,name,steps:steps.length}); return w;}
async function getWorkflow(ctx,id){const w=await db.dbGet('SELECT * FROM workflow_definitions WHERE tenant_id=? AND id=?',[ctx.tenantId,id]); if(!w)return null; w.steps=await db.dbAll('SELECT * FROM workflow_steps WHERE tenant_id=? AND workflow_id=? ORDER BY step_no',[ctx.tenantId,id]); return w;}
async function startWorkflow(ctx,{workflowId,module,resourceId,dueAt,initiatedBy}){const w=await getWorkflow(ctx,workflowId);if(!w||!w.active)throw new Error('Workflow not active'); const i=await db.dbGet(`INSERT INTO workflow_instances(tenant_id,workflow_id,module,resource_id,status,current_step,initiated_by,due_at,created_at) VALUES(?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,workflowId,module,String(resourceId),'pending',1,initiatedBy||ctx.actorId,dueAt||null,nowStr()]); await audit(ctx,'workflow.started','workflow_instance',i.id,null,{resourceId,module});return i;}
async function listWorkflowInstances(ctx,{status,module,assigneeId}={}){const w=['wi.tenant_id=?'];const p=[ctx.tenantId];if(status){w.push('wi.status=?');p.push(status)}if(module){w.push('wi.module=?');p.push(module)}const rows=await db.dbAll(`SELECT wi.*,wf.name workflow_name,wf.module FROM workflow_instances wi JOIN workflow_definitions wf ON wf.id=wi.workflow_id WHERE ${w.join(' AND ')} ORDER BY wi.created_at DESC`,p);if(assigneeId){/* assignee resolution is computed per current step below */}return rows;}
function resolveApprover(step,user,ctx){ if(step.approverType==='user') return Number(step.approverValue)===Number(user.id); if(step.approverType==='manager') return true; if(step.approverType==='role') return (user.permissions||[]).includes(step.approverValue)|| (user.role==='admin'&&step.approverValue==='admin'); return false; }
async function actWorkflow(ctx, instanceId, action, comment) {
  const i = await db.dbGet('SELECT wi.*,wf.name workflow_name,wf.module FROM workflow_instances wi JOIN workflow_definitions wf ON wf.id=wi.workflow_id WHERE wi.tenant_id=? AND wi.id=?',[ctx.tenantId,instanceId]);
  if (!i) throw new Error('Workflow instance not found');
  if (!['approve','reject','return','cancel'].includes(action)) throw new Error('Invalid workflow action');
  if (i.status !== 'pending') throw new Error('Workflow is no longer pending');
  const step = await db.dbGet('SELECT * FROM workflow_steps WHERE tenant_id=? AND workflow_id=? AND step_no=?',[ctx.tenantId,i.workflow_id,i.current_step]);
  if (!step) throw new Error('Workflow step not found');
  if (step.approverType === 'user' && Number(step.approverValue) !== Number(ctx.actorId)) throw new Error('You are not an approver for this step');
  if (step.approverType === 'role' && !hasPermission(ctx.req.session.user,step.approverValue)) throw new Error('You are not an approver for this step');
  await db.withTx(async()=>{
    await db.dbRun('INSERT INTO workflow_actions(tenant_id,instance_id,step_no,actor_id,action,comment,acted_at) VALUES(?,?,?,?,?,?,?)',[ctx.tenantId,instanceId,i.current_step,ctx.actorId,action,comment||null,nowStr()]);
    if (action === 'approve') {
      const next = await db.dbGet('SELECT step_no FROM workflow_steps WHERE tenant_id=? AND workflow_id=? AND step_no>? ORDER BY step_no LIMIT 1',[ctx.tenantId,i.workflow_id,i.current_step]);
      if (next) await db.dbRun('UPDATE workflow_instances SET current_step=? WHERE tenant_id=? AND id=?',[next.step_no,ctx.tenantId,instanceId]);
      else await db.dbRun("UPDATE workflow_instances SET status='approved',completed_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,instanceId]);
    } else {
      const status = action === 'cancel' ? 'cancelled' : action === 'return' ? 'returned' : 'rejected';
      await db.dbRun('UPDATE workflow_instances SET status=?,completed_at=? WHERE tenant_id=? AND id=?',[status,nowStr(),ctx.tenantId,instanceId]);
    }
  });
  await audit(ctx,`workflow.${action}`,'workflow_instance',instanceId,null,{action,comment});
  return db.dbGet('SELECT * FROM workflow_instances WHERE tenant_id=? AND id=?',[ctx.tenantId,instanceId]);
}

async function listNotifications(ctx){return db.dbAll('SELECT * FROM notifications WHERE tenant_id=? AND user_id=? ORDER BY id DESC LIMIT 100',[ctx.tenantId,ctx.actorId]);}
async function createNotification(ctx,userId,type,title,message,metadata={}){await db.dbRun(`INSERT INTO notifications(tenant_id,user_id,type,title,message,read,created_at) VALUES(?,?,?,?,?,0,?)`,[ctx.tenantId,userId,type,title||type,message,nowStr()]);}

async function documentExpirySweep(ctx) {
  const docs = await db.dbAll(`SELECT d.id,d.owner_user_id,d.name,d.expires_on FROM documents d WHERE d.tenant_id=? AND d.expires_on IS NOT NULL AND d.expires_on <= to_char((CURRENT_DATE + INTERVAL '90 day'),'YYYY-MM-DD') AND d.status <> 'archived'`,[ctx.tenantId]);
  const reminders = [90,60,30,15,7,1,0]; const results=[];
  for (const d of docs) {
    const days = Math.ceil((new Date(`${d.expires_on}T00:00:00Z`) - new Date(`${new Date().toISOString().slice(0,10)}T00:00:00Z`))/86400000);
    const hit = reminders.includes(days) ? days : (days < 0 ? -1 : null); if(hit===null) continue;
    if(d.owner_user_id) await createNotification(ctx,d.owner_user_id,'document.expiry','Document expiry reminder',`${d.name} ${hit<0?'has expired':`expires in ${hit} day(s)`}.`);
    results.push({documentId:d.id,daysRemaining:days});
  }
  return results;
}

async function orgTree(ctx){return db.dbAll(`SELECT o.*,p.name parent_name FROM organizations o LEFT JOIN organizations p ON p.id=o.parent_id WHERE o.tenant_id=? ORDER BY o.kind,o.name`,[ctx.tenantId]);}
async function upsertOrg(ctx,data){const row=await db.dbGet(`INSERT INTO organizations(tenant_id,parent_id,kind,code,name,active,effective_from,effective_to,created_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,kind,code) DO UPDATE SET parent_id=EXCLUDED.parent_id,name=EXCLUDED.name,active=EXCLUDED.active,effective_from=EXCLUDED.effective_from,effective_to=EXCLUDED.effective_to RETURNING *`,[ctx.tenantId,data.parentId||null,data.kind,data.code||`${data.kind}-${Date.now()}`,data.name,data.active===false?0:1,data.effectiveFrom||null,data.effectiveTo||null,nowStr()]);await audit(ctx,'organization.upsert','organization',row.id,null,row);return row;}
async function positions(ctx){return db.dbAll(`SELECT p.*,jg.code grade_code,jg.name grade_name,cc.code cost_center_code FROM positions p LEFT JOIN job_grades jg ON jg.id=p.grade_id LEFT JOIN cost_centers cc ON cc.id=p.cost_center_id WHERE p.tenant_id=? ORDER BY p.title`,[ctx.tenantId]);}
async function upsertPosition(ctx,data){const row=await db.dbGet(`INSERT INTO positions(tenant_id,position_code,title,grade_id,department_id,cost_center_id,location,manager_id,status,budget_amount,effective_from,effective_to) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,position_code) DO UPDATE SET title=EXCLUDED.title,grade_id=EXCLUDED.grade_id,department_id=EXCLUDED.department_id,cost_center_id=EXCLUDED.cost_center_id,location=EXCLUDED.location,manager_id=EXCLUDED.manager_id,status=EXCLUDED.status,budget_amount=EXCLUDED.budget_amount,effective_from=EXCLUDED.effective_from,effective_to=EXCLUDED.effective_to RETURNING *`,[ctx.tenantId,data.positionCode,data.title,data.gradeId||null,data.departmentId||null,data.costCenterId||null,data.location||null,data.managerId||null,data.status||'open',data.budgetAmount==null?null:Number(data.budgetAmount),data.effectiveFrom||null,data.effectiveTo||null]);return row;}
async function recordEmployeeHistory(ctx,userId,fieldName,oldValue,newValue,effectiveFrom,reason){const current=await db.dbGet('SELECT * FROM employee_history WHERE tenant_id=? AND user_id=? AND field_name=? AND effective_to IS NULL ORDER BY effective_from DESC LIMIT 1',[ctx.tenantId,userId,fieldName]); if(current) await db.dbRun('UPDATE employee_history SET effective_to=? WHERE tenant_id=? AND id=?',[effectiveFrom,ctx.tenantId,current.id]); await db.dbRun('INSERT INTO employee_history(tenant_id,user_id,field_name,old_value,new_value,effective_from,reason,changed_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)',[ctx.tenantId,userId,fieldName,oldValue==null?null:String(oldValue),newValue==null?null:String(newValue),effectiveFrom,reason||null,ctx.actorId,nowStr()]);await audit(ctx,'employee.history.record','employee',userId,current,{fieldName,oldValue,newValue,effectiveFrom,reason});}
async function getEmployeeHistory(ctx,userId){return db.dbAll('SELECT * FROM employee_history WHERE tenant_id=? AND user_id=? ORDER BY effective_from DESC,id DESC',[ctx.tenantId,userId]);}
async function orgChart(ctx){const users=await db.dbAll(`SELECT u.id,u.name,u.title,u.dept,u.manager_id,u.location,u.lifecycle_status,eo.position_id,eo.organization_id FROM users u LEFT JOIN employee_org_assignments eo ON eo.user_id=u.id AND eo.tenant_id=u.tenant_id AND eo.effective_to IS NULL WHERE u.tenant_id=? AND u.active='active' ORDER BY u.name`,[ctx.tenantId]);return users;}
async function assignEmployeeOrg(ctx,data){await db.dbRun(`UPDATE employee_org_assignments SET effective_to=? WHERE tenant_id=? AND user_id=? AND effective_to IS NULL`,[data.effectiveFrom,ctx.tenantId,data.userId]); const row=await db.dbGet(`INSERT INTO employee_org_assignments(tenant_id,user_id,organization_id,position_id,primary_manager_id,dotted_line_manager_id,work_arrangement,worker_type,employment_type,effective_from) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,data.userId,data.organizationId||null,data.positionId||null,data.primaryManagerId||null,data.dottedLineManagerId||null,data.workArrangement||null,data.workerType||null,data.employmentType||null,data.effectiveFrom]);await audit(ctx,'employee.org_assignment','employee',data.userId,null,row);return row;}

async function payrollPrechecks(ctx,runId){const issues=[]; const users=await db.dbAll("SELECT COUNT(*) n FROM users WHERE tenant_id=? AND active='active'",[ctx.tenantId]); if(Number(users[0]?.n||0)===0) issues.push({category:'employee',code:'NO_ACTIVE_EMPLOYEES',message:'No active employees found',severity:'error'}); await db.dbRun('DELETE FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=?',[ctx.tenantId,runId]); for(const x of issues) await db.dbRun(`INSERT INTO payroll_prechecks(tenant_id,payroll_run_id,category,code,message,severity,status,created_at) VALUES(?,?,?,?,?,?,?,?)`,[ctx.tenantId,runId,x.category,x.code,x.message,x.severity,'open',nowStr()]); return db.dbAll('SELECT * FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=? ORDER BY id',[ctx.tenantId,runId]);}
async function saveReconciliation(ctx,runId,data){const r=await db.dbGet(`INSERT INTO payroll_reconciliations(tenant_id,payroll_run_id,gross_total,net_total,employer_cost_total,bank_total,journal_total,status,notes,reconciled_by,reconciled_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,runId,data.grossTotal||0,data.netTotal||0,data.employerCostTotal||0,data.bankTotal||0,data.journalTotal||0,data.status||'pending',data.notes||null,ctx.actorId,data.status==='reconciled'?nowStr():null,nowStr()]);await audit(ctx,'payroll.reconciliation','payroll_run',runId,null,r);return r;}
async function listPayrollControls(ctx,runId){const [checks,recon]=await Promise.all([db.dbAll('SELECT * FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=? ORDER BY severity DESC,id',[ctx.tenantId,runId]),db.dbAll('SELECT * FROM payroll_reconciliations WHERE tenant_id=? AND payroll_run_id=? ORDER BY id DESC',[ctx.tenantId,runId])]);return {checks,reconciliation:recon[0]||null};}
async function listComplianceRules(ctx,ruleType){return db.dbAll('SELECT * FROM compliance_rules WHERE tenant_id=? AND (? IS NULL OR rule_type=?) ORDER BY rule_type,effective_from DESC',[ctx.tenantId,ruleType||null,ruleType||null]);}
async function upsertComplianceRule(ctx,d){const row=await db.dbGet(`INSERT INTO compliance_rules(tenant_id,rule_type,jurisdiction,employee_category,effective_from,effective_to,value,formula,source_reference,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,d.ruleType,d.jurisdiction||null,d.employeeCategory||null,d.effectiveFrom,d.effectiveTo||null,d.value==null?null:Number(d.value),d.formula||null,d.sourceReference||null,d.active===false?0:1,nowStr()]);await audit(ctx,'compliance_rule.created','compliance_rule',row.id,null,row);return row;}
async function listNotificationTemplates(ctx){ return db.dbAll('SELECT * FROM notification_templates WHERE tenant_id=? ORDER BY code,channel',[ctx.tenantId]); }
async function ensureNotificationTemplate(ctx,data){
  return db.dbGet(`INSERT INTO notification_templates(tenant_id,code,subject,body,channel) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,code,channel) DO UPDATE SET subject=EXCLUDED.subject,body=EXCLUDED.body RETURNING *`,[ctx.tenantId,data.code,data.subject,data.body,data.channel||'in_app']);
}

async function seedBuiltins(ctx){await ensureNotificationTemplate(ctx,{code:'document.expiry',subject:'Document expiry reminder',body:'{{name}} is due to expire on {{expires_on}}.',channel:'in_app'}); const defs=[['Leave','Leave approval','leave.application.created',[{stepNo:1,approverType:'manager',slaHours:48},{stepNo:2,approverType:'role',approverValue:'document.verify',slaHours:72}]],['Timesheet','Timesheet approval','timesheet.submitted',[{stepNo:1,approverType:'manager',slaHours:48}]],['Payroll','Payroll maker-checker','payroll.pending_approval',[{stepNo:1,approverType:'role',approverValue:'payroll.review',slaHours:24},{stepNo:2,approverType:'role',approverValue:'payroll.approve',slaHours:24}]],['Document','Document verification','document.uploaded',[{stepNo:1,approverType:'role',approverValue:'document.verify',slaHours:72}]]];for(const [m,n,t,steps] of defs){const ex=await db.dbGet('SELECT id FROM workflow_definitions WHERE tenant_id=? AND module=? AND name=?',[ctx.tenantId,m,n]);if(!ex)await createWorkflow(ctx,{module:m,name:n,triggerEvent:t,steps});}}

module.exports={BUILTIN_ROLE_PERMISSIONS,getTenantByUser,getMembership,ensureMembership,permissionsForUser,hasPermission,requirePermission,audit,listAudit,listFeatureFlags,setFeatureFlag,listRoles,upsertRole,listDocumentTypes,ensureDocumentType,createDocumentRecord,addDocumentVersion,listDocuments,getDocument,listDocumentVersions,linkDocument,verifyDocument,restoreVersion,expiringDocuments,listWorkflows,createWorkflow,getWorkflow,startWorkflow,listWorkflowInstances,actWorkflow,createNotification,orgTree,upsertOrg,positions,upsertPosition,recordEmployeeHistory,getEmployeeHistory,orgChart,assignEmployeeOrg,payrollPrechecks,saveReconciliation,listPayrollControls,listComplianceRules,upsertComplianceRule,seedBuiltins,documentExpirySweep,ensureNotificationTemplate,listNotificationTemplates};

  },
  "platform": function (require, module, exports) {
const crypto = require('node:crypto');
const db = require('./db');
const enterprise = require('./enterprise');
const { nowStr } = require('./utils');
const { getAdapter, listAdapters } = require('./integrationAdapters');

function asId(v){ const n=Number(v); return Number.isInteger(n)?n:null; }
function isoNow(){ return new Date().toISOString(); }
function json(v){ return JSON.stringify(v ?? {}); }
async function userName(id){ const u=await db.dbGet('SELECT id,name,email,manager_id,role FROM users WHERE id=?',[id]); return u; }
async function isAdmin(ctx){ const u=await userName(ctx.actorId); return ['admin'].includes(u?.role) || enterprise.hasPermission({permissions:ctx.permissions||[]},'admin.configure'); }
async function canSeeUser(ctx,userId){
  if(Number(userId)===Number(ctx.actorId)) return true;
  const admin=await isAdmin(ctx); if(admin) return true;
  const u=await userName(userId); return Number(u?.manager_id)===Number(ctx.actorId);
}
async function audit(ctx, action, type, id, before, after){ return enterprise.audit(ctx,action,type,id,before,after); }

// ---------------------------------------------------------------------------
// Recruitment / ATS
// ---------------------------------------------------------------------------
async function listRequisitions(ctx){
  return db.dbAll(`SELECT r.*,d.name department_name,u.name hiring_manager_name,p.title position_title,
    (SELECT COUNT(*) FROM candidates c WHERE c.requisition_id=r.id AND c.tenant_id=r.tenant_id) candidate_count
    FROM job_requisitions r LEFT JOIN departments d ON d.id=r.department_id AND d.tenant_id=r.tenant_id
    LEFT JOIN users u ON u.id=r.hiring_manager_id AND u.tenant_id=r.tenant_id
    LEFT JOIN positions p ON p.id=r.position_id AND p.tenant_id=r.tenant_id
    WHERE r.tenant_id=? ORDER BY r.created_at DESC`,[ctx.tenantId]);
}
async function saveRequisition(ctx,d){
  if(!d.title || !d.code) throw Object.assign(new Error('code and title are required'),{code:'VALIDATION_ERROR',httpStatus:422});
  const row=await db.dbGet(`INSERT INTO job_requisitions(tenant_id,code,title,department_id,position_id,hiring_manager_id,openings,budget_amount,status,description,target_join_date,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET title=EXCLUDED.title,department_id=EXCLUDED.department_id,position_id=EXCLUDED.position_id,hiring_manager_id=EXCLUDED.hiring_manager_id,openings=EXCLUDED.openings,budget_amount=EXCLUDED.budget_amount,status=EXCLUDED.status,description=EXCLUDED.description,target_join_date=EXCLUDED.target_join_date,updated_at=EXCLUDED.updated_at RETURNING *`,
    [ctx.tenantId,d.code,d.title,asId(d.departmentId),asId(d.positionId),asId(d.hiringManagerId),Math.max(1,Number(d.openings)||1),d.budgetAmount==null?null:Number(d.budgetAmount),d.status||'draft',d.description||null,d.targetJoinDate||null,ctx.actorId,nowStr(),nowStr()]);
  await audit(ctx,'recruitment.requisition.save','job_requisition',row.id,null,row); return row;
}
async function listCandidates(ctx,filters={}){
  const w=['c.tenant_id=?']; const p=[ctx.tenantId];
  if(filters.stage){w.push('c.stage=?');p.push(filters.stage)} if(filters.search){w.push('(c.first_name ILIKE ? OR c.last_name ILIKE ? OR c.email ILIKE ?)');const q=`%${filters.search}%`;p.push(q,q,q)}
  return db.dbAll(`SELECT c.*,r.code requisition_code,r.title requisition_title FROM candidates c LEFT JOIN job_requisitions r ON r.id=c.requisition_id AND r.tenant_id=c.tenant_id WHERE ${w.join(' AND ')} ORDER BY c.updated_at DESC`,p);
}
async function createCandidate(ctx,d){
  if(!d.firstName) throw Object.assign(new Error('firstName is required'),{code:'VALIDATION_ERROR',httpStatus:422});
  const row=await db.dbGet(`INSERT INTO candidates(tenant_id,requisition_id,first_name,last_name,email,phone,source,current_company,current_title,stage,status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [ctx.tenantId,asId(d.requisitionId),d.firstName,d.lastName||null,d.email||null,d.phone||null,d.source||'direct',d.currentCompany||null,d.currentTitle||null,d.stage||'applied','active',d.notes||null,nowStr(),nowStr()]);
  await db.dbRun(`INSERT INTO candidate_stage_history(tenant_id,candidate_id,from_stage,to_stage,changed_by,reason,created_at) VALUES(?,?,?,?,?,?,?)`,[ctx.tenantId,row.id,null,row.stage,ctx.actorId,'candidate created',nowStr()]);
  await audit(ctx,'recruitment.candidate.create','candidate',row.id,null,row); return row;
}
async function moveCandidate(ctx,id,stage,reason){
  const c=await db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!c) throw Object.assign(new Error('Candidate not found'),{code:'NOT_FOUND',httpStatus:404});
  const allowed=['applied','screening','shortlisted','interview','offer','accepted','joined','rejected']; if(!allowed.includes(stage)) throw Object.assign(new Error('Invalid candidate stage'),{code:'VALIDATION_ERROR',httpStatus:422});
  await db.dbRun('UPDATE candidates SET stage=?,status=?,updated_at=? WHERE tenant_id=? AND id=?',[stage,['rejected'].includes(stage)?'rejected':'active',nowStr(),ctx.tenantId,c.id]);
  await db.dbRun('INSERT INTO candidate_stage_history(tenant_id,candidate_id,from_stage,to_stage,changed_by,reason,created_at) VALUES(?,?,?,?,?,?,?)',[ctx.tenantId,c.id,c.stage,stage,ctx.actorId,reason||null,nowStr()]);
  await audit(ctx,'recruitment.candidate.stage','candidate',c.id,{stage:c.stage},{stage}); return db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,c.id]);
}
async function scheduleInterview(ctx,d){
  const row=await db.dbGet(`INSERT INTO interviews(tenant_id,candidate_id,scheduled_at,duration_minutes,interviewer_id,mode,location,status,created_at) VALUES(?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.candidateId),d.scheduledAt,Math.max(15,Number(d.durationMinutes)||45),asId(d.interviewerId),d.mode||'online',d.location||null,'scheduled',nowStr()]);
  await audit(ctx,'recruitment.interview.schedule','interview',row.id,null,row); return row;
}
async function listInterviews(ctx){return db.dbAll(`SELECT i.*,c.first_name||' '||COALESCE(c.last_name,'') candidate_name,u.name interviewer_name FROM interviews i JOIN candidates c ON c.id=i.candidate_id AND c.tenant_id=i.tenant_id LEFT JOIN users u ON u.id=i.interviewer_id AND u.tenant_id=i.tenant_id WHERE i.tenant_id=? ORDER BY i.scheduled_at`,[ctx.tenantId]);}
async function createOffer(ctx,d){
  const row=await db.dbGet(`INSERT INTO offers(tenant_id,candidate_id,offer_date,joining_date,annual_ctc,status,document_id,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.candidateId),d.offerDate||nowStr().slice(0,10),d.joiningDate||null,d.annualCtc==null?null:Number(d.annualCtc),d.status||'draft',d.documentId||null,ctx.actorId,nowStr()]);
  await audit(ctx,'recruitment.offer.create','offer',row.id,null,row); return row;
}
async function recruitmentAnalytics(ctx){
  const funnel=await db.dbAll(`SELECT stage,COUNT(*)::int count FROM candidates WHERE tenant_id=? GROUP BY stage ORDER BY stage`,[ctx.tenantId]);
  const time=await db.dbGet(`SELECT COALESCE(AVG((o.joining_date::date-c.created_at::timestamp::date)),0) avg_days FROM offers o JOIN candidates c ON c.id=o.candidate_id AND c.tenant_id=o.tenant_id WHERE o.tenant_id=? AND o.joining_date IS NOT NULL`,[ctx.tenantId]);
  return {funnel,avgDaysToJoin:Number(time?.avg_days||0)};
}

// ---------------------------------------------------------------------------
// Performance / goals
// ---------------------------------------------------------------------------
async function listCycles(ctx){return db.dbAll('SELECT * FROM performance_cycles WHERE tenant_id=? ORDER BY start_date DESC',[ctx.tenantId]);}
async function saveCycle(ctx,d){
  const row=await db.dbGet(`INSERT INTO performance_cycles(tenant_id,name,start_date,end_date,self_review_due,manager_review_due,status,rating_scale,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,d.name,d.startDate,d.endDate,d.selfReviewDue||null,d.managerReviewDue||null,d.status||'draft',d.ratingScale||'1-5',ctx.actorId,nowStr()]);
  await audit(ctx,'performance.cycle.create','performance_cycle',row.id,null,row); return row;
}
async function listGoals(ctx,userId){
  const target=asId(userId)||ctx.actorId; if(!(await canSeeUser(ctx,target))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  return db.dbAll(`SELECT g.*,pc.name cycle_name,u.name user_name FROM performance_goals g JOIN performance_cycles pc ON pc.id=g.cycle_id AND pc.tenant_id=g.tenant_id JOIN users u ON u.id=g.user_id AND u.tenant_id=g.tenant_id WHERE g.tenant_id=? AND g.user_id=? ORDER BY g.due_date NULLS LAST,g.id DESC`,[ctx.tenantId,target]);
}
async function saveGoal(ctx,d){
  const target=asId(d.userId)||ctx.actorId; if(!(await canSeeUser(ctx,target))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  const row=await db.dbGet(`INSERT INTO performance_goals(tenant_id,cycle_id,user_id,parent_goal_id,level,title,description,metric,target_value,weight,progress,status,due_date,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.cycleId),target,asId(d.parentGoalId),d.level||'employee',d.title,d.description||null,d.metric||null,d.targetValue==null?null:String(d.targetValue),Number(d.weight)||0,Number(d.progress)||0,d.status||'open',d.dueDate||null,ctx.actorId,nowStr(),nowStr()]);
  await audit(ctx,'performance.goal.create','performance_goal',row.id,null,row); return row;
}
async function saveReview(ctx,d){
  const target=asId(d.revieweeId)||ctx.actorId; if(!(await canSeeUser(ctx,target)) && Number(d.reviewerId||ctx.actorId)!==ctx.actorId) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  const reviewer=asId(d.reviewerId)||ctx.actorId;
  const row=await db.dbGet(`INSERT INTO performance_reviews(tenant_id,cycle_id,reviewee_id,reviewer_id,review_type,status,rating,comments,submitted_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,cycle_id,reviewee_id,reviewer_id,review_type) DO UPDATE SET status=EXCLUDED.status,rating=EXCLUDED.rating,comments=EXCLUDED.comments,submitted_at=EXCLUDED.submitted_at RETURNING *`,[ctx.tenantId,asId(d.cycleId),target,reviewer,d.reviewType||'self',d.status||'submitted',d.rating==null?null:Number(d.rating),d.comments||null,(d.status||'submitted')==='submitted'?nowStr():null,nowStr()]);
  await audit(ctx,'performance.review.save','performance_review',row.id,null,row); return row;
}
async function listReviews(ctx,userId){const target=asId(userId); const w=['r.tenant_id=?'];const p=[ctx.tenantId]; if(target){if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});w.push('r.reviewee_id=?');p.push(target)} else if(!(await isAdmin(ctx))){w.push('(r.reviewee_id=? OR r.reviewer_id=?)');p.push(ctx.actorId,ctx.actorId)} return db.dbAll(`SELECT r.*,pc.name cycle_name,ru.name reviewer_name,ee.name reviewee_name FROM performance_reviews r JOIN performance_cycles pc ON pc.id=r.cycle_id LEFT JOIN users ru ON ru.id=r.reviewer_id LEFT JOIN users ee ON ee.id=r.reviewee_id WHERE ${w.join(' AND ')} ORDER BY r.created_at DESC`,p);}
async function listFeedback(ctx,userId){const target=asId(userId);const w=['f.tenant_id=?'];const p=[ctx.tenantId];if(target)w.push('f.reviewee_id=?'),p.push(target);else if(!(await isAdmin(ctx)))w.push('(f.reviewee_id=? OR f.reviewer_id=?)'),p.push(ctx.actorId,ctx.actorId);return db.dbAll(`SELECT f.*,ru.name reviewer_name,ee.name reviewee_name,pc.name cycle_name FROM feedback_entries f JOIN performance_cycles pc ON pc.id=f.cycle_id LEFT JOIN users ru ON ru.id=f.reviewer_id LEFT JOIN users ee ON ee.id=f.reviewee_id WHERE ${w.join(' AND ')} ORDER BY f.created_at DESC`,p);}
async function savePip(ctx,d){const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO performance_pips(tenant_id,user_id,start_date,end_date,objective,actions,success_criteria,status,outcome,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,d.startDate,d.endDate||null,d.objective,d.actions||null,d.successCriteria||null,d.status||'open',d.outcome||null,ctx.actorId,nowStr()]);await audit(ctx,'performance.pip.create','performance_pip',row.id,null,row);return row;}

// ---------------------------------------------------------------------------
// Learning
// ---------------------------------------------------------------------------
async function listCourses(ctx){return db.dbAll('SELECT * FROM learning_courses WHERE tenant_id=? ORDER BY title',[ctx.tenantId]);}
async function saveCourse(ctx,d){const row=await db.dbGet(`INSERT INTO learning_courses(tenant_id,code,title,description,mandatory,duration_hours,provider,active,created_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,mandatory=EXCLUDED.mandatory,duration_hours=EXCLUDED.duration_hours,provider=EXCLUDED.provider,active=EXCLUDED.active RETURNING *`,[ctx.tenantId,d.code,d.title,d.description||null,d.mandatory?1:0,d.durationHours==null?null:Number(d.durationHours),d.provider||null,d.active===false?0:1,nowStr()]);await audit(ctx,'learning.course.save','learning_course',row.id,null,row);return row;}
async function enroll(ctx,courseId,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_enrollments(tenant_id,course_id,user_id,status,enrolled_at) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,course_id,user_id) DO UPDATE SET status=EXCLUDED.status RETURNING *`,[ctx.tenantId,asId(courseId),target,'enrolled',nowStr()]);await audit(ctx,'learning.enroll','learning_enrollment',row.id,null,row);return row;}
async function completeEnrollment(ctx,id,score){const row=await db.dbGet('SELECT * FROM learning_enrollments WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!row)throw Object.assign(new Error('Enrollment not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await canSeeUser(ctx,row.user_id)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});await db.dbRun(`UPDATE learning_enrollments SET status='completed',completed_at=?,score=? WHERE tenant_id=? AND id=?`,[nowStr(),score==null?null:Number(score),ctx.tenantId,row.id]);await audit(ctx,'learning.complete','learning_enrollment',row.id,{status:row.status},{status:'completed',score:score==null?null:Number(score)});return db.dbGet('SELECT * FROM learning_enrollments WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);}
async function listEnrollments(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll(`SELECT e.*,c.code,c.title,c.mandatory,c.provider FROM learning_enrollments e JOIN learning_courses c ON c.id=e.course_id AND c.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.user_id=? ORDER BY e.enrolled_at DESC`,[ctx.tenantId,target]);}
async function saveCertification(ctx,d){const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_certifications(tenant_id,user_id,course_id,name,certificate_number,issued_on,expires_on,status,document_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,asId(d.courseId),d.name,d.certificateNumber||null,d.issuedOn||null,d.expiresOn||null,'active',d.documentId||null,nowStr()]);await audit(ctx,'learning.certification.save','learning_certification',row.id,null,row);return row;}
async function saveSkill(ctx,d){const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_skills(tenant_id,user_id,skill,proficiency,target_proficiency,development_plan,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id,skill) DO UPDATE SET proficiency=EXCLUDED.proficiency,target_proficiency=EXCLUDED.target_proficiency,development_plan=EXCLUDED.development_plan,updated_at=EXCLUDED.updated_at RETURNING *`,[ctx.tenantId,target,d.skill,Math.min(5,Math.max(1,Number(d.proficiency)||1)),Math.min(5,Math.max(1,Number(d.targetProficiency)||3)),d.developmentPlan||null,nowStr()]);await audit(ctx,'learning.skill.save','learning_skill',row.id,null,row);return row;}

// ---------------------------------------------------------------------------
// Benefits
// ---------------------------------------------------------------------------
async function listBenefitPlans(ctx){return db.dbAll('SELECT * FROM benefit_plans WHERE tenant_id=? ORDER BY name',[ctx.tenantId]);}
async function saveBenefitPlan(ctx,d){const row=await db.dbGet(`INSERT INTO benefit_plans(tenant_id,code,name,benefit_type,employee_contribution,employer_contribution,coverage_amount,enrollment_start,enrollment_end,active,created_at) VALUES(?,?,?,?,?::numeric,?::numeric,?::numeric,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET name=EXCLUDED.name,benefit_type=EXCLUDED.benefit_type,employee_contribution=EXCLUDED.employee_contribution,employer_contribution=EXCLUDED.employer_contribution,coverage_amount=EXCLUDED.coverage_amount,enrollment_start=EXCLUDED.enrollment_start,enrollment_end=EXCLUDED.enrollment_end,active=EXCLUDED.active RETURNING *`,[ctx.tenantId,d.code,d.name,d.benefitType,d.employeeContribution||0,d.employerContribution||0,d.coverageAmount==null?null:Number(d.coverageAmount),d.enrollmentStart||null,d.enrollmentEnd||null,d.active===false?0:1,nowStr()]);await audit(ctx,'benefit.plan.save','benefit_plan',row.id,null,row);return row;}
async function enrollBenefit(ctx,planId,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const plan=await db.dbGet('SELECT * FROM benefit_plans WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(planId)]);if(!plan)throw Object.assign(new Error('Benefit plan not found'),{httpStatus:404,code:'NOT_FOUND'});const today=nowStr().slice(0,10);if(plan.enrollment_start&&today<plan.enrollment_start)throw Object.assign(new Error('Benefit enrollment has not opened yet'),{httpStatus:409,code:'ENROLLMENT_CLOSED'});if(plan.enrollment_end&&today>plan.enrollment_end)throw Object.assign(new Error('Benefit enrollment window is closed'),{httpStatus:409,code:'ENROLLMENT_CLOSED'});const row=await db.dbGet(`INSERT INTO benefit_enrollments(tenant_id,plan_id,user_id,status,enrolled_on,payroll_deduction,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,plan_id,user_id) DO UPDATE SET status=EXCLUDED.status,payroll_deduction=EXCLUDED.payroll_deduction RETURNING *`,[ctx.tenantId,plan.id,target,'enrolled',today,Number(plan.employee_contribution)||0,nowStr()]);await audit(ctx,'benefit.enroll','benefit_enrollment',row.id,null,row);return row;}
async function listBenefitsForUser(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const [plans,enrollments,deps]=await Promise.all([listBenefitPlans(ctx),db.dbAll(`SELECT e.*,p.code,p.name,p.benefit_type,p.coverage_amount,p.employer_contribution FROM benefit_enrollments e JOIN benefit_plans p ON p.id=e.plan_id AND p.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.user_id=?`,[ctx.tenantId,target]),db.dbAll('SELECT * FROM benefit_dependents WHERE tenant_id=? AND user_id=? ORDER BY name',[ctx.tenantId,target])]);return {plans,enrollments,dependents:deps};}
async function saveDependent(ctx,d){const target=asId(d.userId)||ctx.actorId;if(Number(target)!==Number(ctx.actorId) && !(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbGet(`INSERT INTO benefit_dependents(tenant_id,user_id,name,relationship,date_of_birth,beneficiary_percent,created_at) VALUES(?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,d.name,d.relationship,d.dateOfBirth||null,Number(d.beneficiaryPercent)||0,nowStr()]);}

// ---------------------------------------------------------------------------
// Expenses
// ---------------------------------------------------------------------------
async function listExpenses(ctx,filters={}){const w=['c.tenant_id=?'];const p=[ctx.tenantId];if(filters.userId){if(!(await canSeeUser(ctx,filters.userId)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});w.push('c.user_id=?');p.push(asId(filters.userId));}else if(!(await isAdmin(ctx)))w.push('c.user_id=?'),p.push(ctx.actorId);if(filters.status){w.push('c.status=?');p.push(filters.status);}return db.dbAll(`SELECT c.*,u.name employee_name,(SELECT COALESCE(SUM(el.amount),0) FROM expense_lines el WHERE el.claim_id=c.id AND el.tenant_id=c.tenant_id) computed_total FROM expense_claims c LEFT JOIN users u ON u.id=c.user_id WHERE ${w.join(' AND ')} ORDER BY c.created_at DESC`,p);}
async function createExpense(ctx,d){const userId=asId(d.userId)||ctx.actorId;if(Number(userId)!==Number(ctx.actorId)&&!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const claimNo=d.claimNo||`EXP-${Date.now()}`;const manager=(await userName(userId))?.manager_id||null;const row=await db.dbGet(`INSERT INTO expense_claims(tenant_id,claim_no,user_id,claim_date,currency,total_amount,status,manager_id,reimbursement_status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,claimNo,userId,d.claimDate||nowStr().slice(0,10),d.currency||'INR',0,'draft',manager,'pending',d.notes||null,nowStr(),nowStr()]);
  for(const l of (d.lines||[])){await db.dbRun(`INSERT INTO expense_lines(tenant_id,claim_id,expense_date,category,merchant,amount,description,document_id) VALUES(?,?,?,?,?,?,?,?)`,[ctx.tenantId,row.id,l.expenseDate||row.claim_date,l.category||'other',l.merchant||null,Number(l.amount)||0,l.description||null,l.documentId||null]);}
  await recalcExpense(ctx,row.id);return db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);}
async function recalcExpense(ctx,id){const t=await db.dbGet('SELECT COALESCE(SUM(amount),0) total FROM expense_lines WHERE tenant_id=? AND claim_id=?',[ctx.tenantId,asId(id)]);await db.dbRun('UPDATE expense_claims SET total_amount=?,updated_at=? WHERE tenant_id=? AND id=?',[Number(t?.total||0),nowStr(),ctx.tenantId,asId(id)]);return t;}
async function addExpenseLine(ctx,id,l){const claim=await db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!claim)throw Object.assign(new Error('Claim not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await canSeeUser(ctx,claim.user_id)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO expense_lines(tenant_id,claim_id,expense_date,category,merchant,amount,description,document_id) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,claim.id,l.expenseDate||nowStr().slice(0,10),l.category||'other',l.merchant||null,Number(l.amount)||0,l.description||null,l.documentId||null]);await recalcExpense(ctx,claim.id);return row;}
async function submitExpense(ctx,id){const claim=await db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!claim)throw Object.assign(new Error('Claim not found'),{httpStatus:404,code:'NOT_FOUND'});if(Number(claim.user_id)!==Number(ctx.actorId)&&!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});if(Number(claim.total_amount)<=0)throw Object.assign(new Error('Expense claim must have a positive total'),{httpStatus:422,code:'VALIDATION_ERROR'});await db.dbRun("UPDATE expense_claims SET status='submitted',updated_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,claim.id]);return db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,claim.id]);}
async function decideExpense(ctx,id,decision,comment){const claim=await db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!claim)throw Object.assign(new Error('Claim not found'),{httpStatus:404,code:'NOT_FOUND'});const manager=Number(claim.manager_id)===Number(ctx.actorId);if(!manager&&!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});if(!['approved','rejected'].includes(decision))throw Object.assign(new Error('Invalid decision'),{httpStatus:422,code:'VALIDATION_ERROR'});await db.dbRun('UPDATE expense_claims SET status=?,notes=?,updated_at=? WHERE tenant_id=? AND id=?',[decision,comment||claim.notes,nowStr(),ctx.tenantId,claim.id]);await audit(ctx,`expense.${decision}`,'expense_claim',claim.id,{status:claim.status},{status:decision,comment});return db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,claim.id]);}
async function listExpenseLines(ctx,id){const c=await db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!c)throw Object.assign(new Error('Claim not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await canSeeUser(ctx,c.user_id)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll('SELECT * FROM expense_lines WHERE tenant_id=? AND claim_id=? ORDER BY expense_date,id',[ctx.tenantId,c.id]);}
async function listExpenseApprovals(ctx){
  const admin=await isAdmin(ctx);
  const where=admin?"c.status='submitted'":"c.status='submitted' AND c.manager_id=?";
  const params=admin?[ctx.tenantId]:[ctx.tenantId,ctx.actorId];
  return db.dbAll(`SELECT c.*,u.name employee_name,(SELECT COALESCE(SUM(el.amount),0) FROM expense_lines el WHERE el.claim_id=c.id AND el.tenant_id=c.tenant_id) computed_total FROM expense_claims c LEFT JOIN users u ON u.id=c.user_id WHERE c.tenant_id=? AND ${where} ORDER BY c.created_at DESC`,params);
}
async function listServiceRequestApprovals(ctx){
  const admin=await isAdmin(ctx);
  const where=admin?"t.status IN ('open','in_progress')":"t.status='open' AND r.manager_id=?";
  const params=admin?[ctx.tenantId]:[ctx.tenantId,ctx.actorId];
  return db.dbAll(`SELECT t.*,r.name requester_name,a.name assignee_name FROM service_tickets t LEFT JOIN users r ON r.id=t.requester_id LEFT JOIN users a ON a.id=t.assignee_id WHERE t.tenant_id=? AND ${where} ORDER BY CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,t.created_at DESC`,params);
}
async function decideServiceRequest(ctx,id,decision,comment){
  const ticket=await db.dbGet('SELECT t.*,u.manager_id FROM service_tickets t JOIN users u ON u.id=t.requester_id AND u.tenant_id=t.tenant_id WHERE t.tenant_id=? AND t.id=?',[ctx.tenantId,asId(id)]);
  if(!ticket)throw Object.assign(new Error('Request not found'),{httpStatus:404,code:'NOT_FOUND'});
  if(Number(ticket.manager_id)!==Number(ctx.actorId)&&!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  if(!['approve','reject'].includes(decision))throw Object.assign(new Error('Invalid decision'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const status=decision==='approve'?'in_progress':'rejected';
  await db.dbRun('UPDATE service_tickets SET status=?,resolution=?,updated_at=? WHERE tenant_id=? AND id=?',[status,comment||null,nowStr(),ctx.tenantId,ticket.id]);
  await audit(ctx,`helpdesk.request.${decision}`,'service_ticket',ticket.id,{status:ticket.status},{status,comment});
  return db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?',[ctx.tenantId,ticket.id]);
}


// ---------------------------------------------------------------------------
// Assets
// ---------------------------------------------------------------------------
async function listAssets(ctx){return db.dbAll(`SELECT a.*,u.name current_user FROM assets a LEFT JOIN asset_assignments aa ON aa.asset_id=a.id AND aa.tenant_id=a.tenant_id AND aa.returned_on IS NULL LEFT JOIN users u ON u.id=aa.user_id WHERE a.tenant_id=? ORDER BY a.asset_tag`,[ctx.tenantId]);}
async function saveAsset(ctx,d){const row=await db.dbGet(`INSERT INTO assets(tenant_id,asset_tag,category,name,serial_number,purchase_cost,warranty_until,condition,status,document_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,asset_tag) DO UPDATE SET category=EXCLUDED.category,name=EXCLUDED.name,serial_number=EXCLUDED.serial_number,purchase_cost=EXCLUDED.purchase_cost,warranty_until=EXCLUDED.warranty_until,condition=EXCLUDED.condition,status=EXCLUDED.status,document_id=EXCLUDED.document_id RETURNING *`,[ctx.tenantId,d.assetTag,d.category,d.name,d.serialNumber||null,d.purchaseCost==null?null:Number(d.purchaseCost),d.warrantyUntil||null,d.condition||'good',d.status||'available',d.documentId||null,nowStr()]);await audit(ctx,'asset.save','asset',row.id,null,row);return row;}
async function assignAsset(ctx,id,d){const asset=await db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!asset)throw Object.assign(new Error('Asset not found'),{httpStatus:404,code:'NOT_FOUND'});const userId=asId(d.userId);if(!userId)throw Object.assign(new Error('userId is required'),{httpStatus:422,code:'VALIDATION_ERROR'});await db.dbRun('UPDATE asset_assignments SET returned_on=? WHERE tenant_id=? AND asset_id=? AND returned_on IS NULL',[nowStr().slice(0,10),ctx.tenantId,asset.id]);const row=await db.dbGet(`INSERT INTO asset_assignments(tenant_id,asset_id,user_id,action,assigned_on,notes,created_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asset.id,userId,d.action||'issue',d.assignedOn||nowStr().slice(0,10),d.notes||null,ctx.actorId,nowStr()]);await db.dbRun("UPDATE assets SET status='assigned' WHERE tenant_id=? AND id=?",[ctx.tenantId,asset.id]);await audit(ctx,'asset.assign','asset',asset.id,{status:asset.status},{status:'assigned',userId});return row;}
async function returnAsset(ctx,id,d){const asset=await db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!asset)throw Object.assign(new Error('Asset not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE asset_assignments SET returned_on=? WHERE tenant_id=? AND asset_id=? AND returned_on IS NULL',[d.returnedOn||nowStr().slice(0,10),ctx.tenantId,asset.id]);await db.dbRun("UPDATE assets SET status='available',condition=? WHERE tenant_id=? AND id=?",[d.condition||asset.condition,ctx.tenantId,asset.id]);return db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asset.id]);}

// ---------------------------------------------------------------------------
// HR Service Desk
// ---------------------------------------------------------------------------
async function listTickets(ctx,filters={}){const w=['t.tenant_id=?'];const p=[ctx.tenantId];if(filters.status){w.push('t.status=?');p.push(filters.status)}if(filters.priority){w.push('t.priority=?');p.push(filters.priority)}if(!(await isAdmin(ctx)))w.push('(t.requester_id=? OR t.assignee_id=?)'),p.push(ctx.actorId,ctx.actorId);return db.dbAll(`SELECT t.*,r.name requester_name,a.name assignee_name FROM service_tickets t LEFT JOIN users r ON r.id=t.requester_id LEFT JOIN users a ON a.id=t.assignee_id WHERE ${w.join(' AND ')} ORDER BY CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,t.created_at DESC`,p);}
async function createTicket(ctx,d){const no=d.ticketNo||`HR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;const slaHours={low:72,medium:48,high:24,critical:4}[d.priority||'medium'];const due=new Date(Date.now()+slaHours*3600000).toISOString();const row=await db.dbGet(`INSERT INTO service_tickets(tenant_id,ticket_no,requester_id,category,subject,description,priority,status,assignee_id,sla_due_at,knowledge_url,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,no,ctx.actorId,d.category||'HR',d.subject,d.description||null,d.priority||'medium','open',asId(d.assigneeId),due,d.knowledgeUrl||null,nowStr(),nowStr()]);await audit(ctx,'helpdesk.ticket.create','service_ticket',row.id,null,row);return row;}
async function updateTicket(ctx,id,d){const t=await db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!t)throw Object.assign(new Error('Ticket not found'),{httpStatus:404,code:'NOT_FOUND'});const can=Number(t.requester_id)===Number(ctx.actorId)||Number(t.assignee_id||0)===Number(ctx.actorId)||(await isAdmin(ctx));if(!can)throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const status=d.status||t.status;const resolved=status==='resolved'||status==='closed';await db.dbRun(`UPDATE service_tickets SET status=?,assignee_id=?,priority=?,resolution=?,resolved_at=?,updated_at=? WHERE tenant_id=? AND id=?`,[status,asId(d.assigneeId) ?? t.assignee_id,d.priority||t.priority,d.resolution||t.resolution,resolved?nowStr():null,nowStr(),ctx.tenantId,t.id]);await audit(ctx,'helpdesk.ticket.update','service_ticket',t.id,{status:t.status},{status});return db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?',[ctx.tenantId,t.id]);}
async function addTicketNote(ctx,id,note,internal=true){const t=await db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!t)throw Object.assign(new Error('Ticket not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await canSeeUser(ctx,t.requester_id))&&Number(t.assignee_id||0)!==Number(ctx.actorId)&&!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbGet(`INSERT INTO service_ticket_notes(tenant_id,ticket_id,author_id,note,internal,created_at) VALUES(?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,t.id,ctx.actorId,note,internal?1:0,nowStr()]);}
async function ticketNotes(ctx,id){const t=await db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!t)throw Object.assign(new Error('Ticket not found'),{httpStatus:404,code:'NOT_FOUND'});return db.dbAll('SELECT n.*,u.name author_name FROM service_ticket_notes n LEFT JOIN users u ON u.id=n.author_id WHERE n.tenant_id=? AND n.ticket_id=? ORDER BY n.created_at',[ctx.tenantId,t.id]);}

// ---------------------------------------------------------------------------
// Integration hub / webhooks
// ---------------------------------------------------------------------------
function cryptoKey(){return crypto.createHash('sha256').update(process.env.APP_ENCRYPTION_KEY||'vasjo-dev-key').digest();}
function encryptSecret(v){const key=cryptoKey();const iv=crypto.randomBytes(12);const c=crypto.createCipheriv('aes-256-gcm',key,iv);const x=Buffer.concat([c.update(String(v),'utf8'),c.final()]);return `${iv.toString('base64url')}.${c.getAuthTag().toString('base64url')}.${x.toString('base64url')}`;}
function decryptSecret(v){if(!v)return null;const [ivB64,tagB64,dataB64]=String(v).split('.');const d=crypto.createDecipheriv('aes-256-gcm',cryptoKey(),Buffer.from(ivB64,'base64url'));d.setAuthTag(Buffer.from(tagB64,'base64url'));return Buffer.concat([d.update(Buffer.from(dataB64,'base64url')),d.final()]).toString('utf8');}
async function listIntegrations(ctx){const conns=await db.dbAll('SELECT id,provider,account_label,expires_at,scopes,status,updated_at FROM integration_connections WHERE tenant_id=? ORDER BY provider',[ctx.tenantId]);const jobs=await db.dbAll('SELECT * FROM integration_sync_jobs WHERE tenant_id=? ORDER BY created_at DESC LIMIT 50',[ctx.tenantId]);const subs=await db.dbAll('SELECT id,url,events_json,active,created_at FROM webhook_subscriptions WHERE tenant_id=? ORDER BY created_at DESC',[ctx.tenantId]);return {connections:conns,syncJobs:jobs,webhooks:subs,adapters:listAdapters()};}
async function saveWebhook(ctx,d){if(!/^https:\/\//i.test(String(d.url||'')))throw Object.assign(new Error('Webhook URL must use HTTPS'),{httpStatus:422,code:'VALIDATION_ERROR'});const secret=d.secret||crypto.randomBytes(24).toString('hex');const row=await db.dbGet(`INSERT INTO webhook_subscriptions(tenant_id,url,secret_enc,events_json,active,created_at) VALUES(?,?,?,?,?::jsonb,?) ON CONFLICT(tenant_id,url) DO UPDATE SET secret_enc=EXCLUDED.secret_enc,events_json=EXCLUDED.events_json,active=EXCLUDED.active RETURNING id,url,events_json,active,created_at`,[ctx.tenantId,d.url,encryptSecret(secret),json(d.events||[]),d.active===false?0:1,nowStr()]);await audit(ctx,'integration.webhook.save','webhook_subscription',row.id,null,{url:d.url,events:d.events||[]});return {...row,secret};}
async function disableWebhook(ctx,id){const before=await db.dbGet('SELECT * FROM webhook_subscriptions WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!before)throw Object.assign(new Error('Webhook not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE webhook_subscriptions SET active=0 WHERE tenant_id=? AND id=?',[ctx.tenantId,before.id]);await audit(ctx,'integration.webhook.disable','webhook_subscription',before.id,{active:before.active},{active:0});return {ok:true};}
async function createSyncJob(ctx,d){const key=d.idempotencyKey||crypto.randomUUID();const existing=await db.dbGet('SELECT * FROM integration_sync_jobs WHERE tenant_id=? AND idempotency_key=?',[ctx.tenantId,key]);if(existing)return existing;return db.dbGet(`INSERT INTO integration_sync_jobs(tenant_id,provider,direction,entity_type,status,idempotency_key,created_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,d.provider,d.direction||'outbound',d.entityType||'employee', 'queued',key,ctx.actorId,nowStr()]);}
async function testIntegration(ctx,provider){const adapter=getAdapter(provider);const row=await db.dbGet('SELECT id,provider,status,expires_at FROM integration_connections WHERE tenant_id=? AND provider=? AND status=\'active\' ORDER BY updated_at DESC LIMIT 1',[ctx.tenantId,provider]);if(!row)return {ok:false,provider,message:'No active connection',adapter:adapter.provider};return {ok:true,provider,message:'Connection record is active',expiresAt:row.expires_at,adapter:adapter.provider};}
async function removeIntegration(ctx,provider){await db.dbRun("UPDATE integration_connections SET status='revoked',updated_at=? WHERE tenant_id=? AND provider=?",[nowStr(),ctx.tenantId,provider]);await audit(ctx,'integration.disconnect','integration_connection',provider,null,{status:'revoked'});return {ok:true};}

// ---------------------------------------------------------------------------
// Analytics / reporting
// ---------------------------------------------------------------------------
async function analyticsOverview(ctx){
  const [wf,active,hires,exits,docs,exp,tickets,claims]=await Promise.all([
    db.dbGet("SELECT COUNT(*)::int n FROM workflow_instances WHERE tenant_id=? AND status='pending'",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM users WHERE tenant_id=? AND active='active'",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM users WHERE tenant_id=? AND joined_date >= to_char(current_date - interval '30 day','YYYY-MM-DD')",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM users WHERE tenant_id=? AND lifecycle_status='exited' AND updated_at >= to_char(current_date - interval '30 day','YYYY-MM-DD')",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM documents WHERE tenant_id=? AND expires_on BETWEEN to_char(current_date,'YYYY-MM-DD') AND to_char(current_date + interval '30 day','YYYY-MM-DD')",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM documents WHERE tenant_id=? AND expires_on < to_char(current_date,'YYYY-MM-DD') AND status<>'archived'",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM service_tickets WHERE tenant_id=? AND status NOT IN ('resolved','closed')",[ctx.tenantId]),
    db.dbGet("SELECT COUNT(*)::int n FROM expense_claims WHERE tenant_id=? AND status='submitted'",[ctx.tenantId])
  ]);
  const departments=await db.dbAll("SELECT dept,COUNT(*)::int count FROM users WHERE tenant_id=? AND active='active' GROUP BY dept ORDER BY count DESC",[ctx.tenantId]);
  const leave=await db.dbAll("SELECT status,COUNT(*)::int count FROM leave_applications WHERE tenant_id=? GROUP BY status",[ctx.tenantId]);
  return {workflowsPending:Number(wf?.n||0),headcount:Number(active?.n||0),hires30:Number(hires?.n||0),exits30:Number(exits?.n||0),docsExpiring30:Number(docs?.n||0),docsExpired:Number(exp?.n||0),openTickets:Number(tickets?.n||0),submittedExpenses:Number(claims?.n||0),departmentMix:departments,leaveStatus:leave};
}
async function saveReport(ctx,d){return db.dbGet(`INSERT INTO saved_reports(tenant_id,owner_id,name,area,filters_json,schedule,active,created_at,updated_at) VALUES(?,?,?,?,?::jsonb,?,?,?,?) RETURNING *`,[ctx.tenantId,ctx.actorId,d.name,d.area,json(d.filters),d.schedule||null,d.active===false?0:1,nowStr(),nowStr()]);}
async function listReports(ctx){return db.dbAll('SELECT * FROM saved_reports WHERE tenant_id=? AND (owner_id=? OR ?=1) ORDER BY updated_at DESC',[ctx.tenantId,ctx.actorId,(await isAdmin(ctx))?1:0]);}

// ---------------------------------------------------------------------------
// Mobile-optimized API contract
// ---------------------------------------------------------------------------
async function mobileHome(ctx){
  const [notifs,bals,timesheets,leave,expenses,tickets]=await Promise.all([
    db.dbAll('SELECT * FROM notifications WHERE tenant_id=? AND user_id=? ORDER BY created_at DESC LIMIT 10',[ctx.tenantId,ctx.actorId]),
    db.dbAll(`SELECT lb.*,lt.name type_name FROM leave_balances lb JOIN leave_types lt ON lt.id=lb.leave_type_id AND lt.tenant_id=lb.tenant_id WHERE lb.tenant_id=? AND lb.user_id=? AND lb.year=?`,[ctx.tenantId,ctx.actorId,new Date().getFullYear()]),
    db.dbAll('SELECT * FROM timesheets WHERE tenant_id=? AND user_id=? ORDER BY week_start DESC LIMIT 5',[ctx.tenantId,ctx.actorId]),
    db.dbAll('SELECT * FROM leave_applications WHERE tenant_id=? AND user_id=? ORDER BY applied_at DESC LIMIT 5',[ctx.tenantId,ctx.actorId]),
    db.dbAll("SELECT * FROM expense_claims WHERE tenant_id=? AND user_id=? ORDER BY created_at DESC LIMIT 5",[ctx.tenantId,ctx.actorId]),
    db.dbAll("SELECT * FROM service_tickets WHERE tenant_id=? AND requester_id=? ORDER BY created_at DESC LIMIT 5",[ctx.tenantId,ctx.actorId])
  ]);return {notifications:notifs,leaveBalances:bals,timesheets,leaveApplications:leave,expenses,tickets};
}

// ---------------------------------------------------------------------------
// AI: permission-aware deterministic assistant + document intelligence + payroll anomalies
// ---------------------------------------------------------------------------
function has(ctx,p){return enterprise.hasPermission({permissions:ctx.permissions||[]},p);}
async function aiAssistant(ctx,question){
  const q=String(question||'').trim(); if(!q)throw Object.assign(new Error('question is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const lower=q.toLowerCase(); let intent='help'; let result={answer:'I can answer workforce, leave, timesheet, document and payroll questions that your permissions allow.'};
  if(/on leave today|leave today/.test(lower)){
    intent='leave.today'; if(!has(ctx,'leave.approve')&&!has(ctx,'employee.*')&&!has(ctx,'reports.read')){
      const rows=await db.dbAll(`SELECT u.name,la.from_date,la.to_date,lt.name leave_type FROM leave_applications la JOIN users u ON u.id=la.user_id AND u.tenant_id=la.tenant_id JOIN leave_types lt ON lt.id=la.leave_type_id AND lt.tenant_id=la.tenant_id WHERE la.tenant_id=? AND la.status='approved' AND to_char(current_date,'YYYY-MM-DD') BETWEEN la.from_date AND la.to_date AND la.user_id=?`,[ctx.tenantId,ctx.actorId]);result={answer:rows.length?`You are on ${rows[0].leave_type} today.`:'You are not on approved leave today.',rows};
    } else {const rows=await db.dbAll(`SELECT u.name,la.from_date,la.to_date,lt.name leave_type FROM leave_applications la JOIN users u ON u.id=la.user_id AND u.tenant_id=la.tenant_id JOIN leave_types lt ON lt.id=la.leave_type_id AND lt.tenant_id=la.tenant_id WHERE la.tenant_id=? AND la.status='approved' AND to_char(current_date,'YYYY-MM-DD') BETWEEN la.from_date AND la.to_date ORDER BY u.name`,[ctx.tenantId]);result={answer:`${rows.length} employee(s) are on approved leave today.`,rows};}
  } else if(/documents? expire|expir.*document/.test(lower)){
    intent='documents.expiring'; if(!has(ctx,'document.read'))throw Object.assign(new Error('AI document access is not permitted'),{httpStatus:403,code:'FORBIDDEN'}); const rows=await db.dbAll("SELECT d.id,d.name,d.expires_on,u.name owner_name FROM documents d LEFT JOIN users u ON u.id=d.owner_user_id AND u.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.expires_on BETWEEN to_char(current_date,'YYYY-MM-DD') AND to_char(current_date + interval '30 day','YYYY-MM-DD') ORDER BY d.expires_on",[ctx.tenantId]);result={answer:`${rows.length} document(s) expire in the next 30 days.`,rows};
  } else if(/missing timesheet/.test(lower)){
    intent='timesheets.missing'; const target=await isAdmin(ctx)||has(ctx,'reports.read')?null:ctx.actorId; const rows=target?await db.dbAll(`SELECT u.name,u.id FROM users u WHERE u.tenant_id=? AND u.id=? AND NOT EXISTS (SELECT 1 FROM timesheets t WHERE t.tenant_id=u.tenant_id AND t.user_id=u.id AND t.week_start>=to_char(current_date - interval '21 day','YYYY-MM-DD'))`,[ctx.tenantId,target]):await db.dbAll(`SELECT u.name,u.id FROM users u WHERE u.tenant_id=? AND u.active='active' AND NOT EXISTS (SELECT 1 FROM timesheets t WHERE t.tenant_id=u.tenant_id AND t.user_id=u.id AND t.week_start>=to_char(current_date - interval '21 day','YYYY-MM-DD')) ORDER BY u.name`,[ctx.tenantId]);result={answer:`${rows.length} employee(s) have no timesheet in the last three weeks.`,rows};
  } else if(/headcount|workforce/.test(lower)){
    intent='workforce.headcount'; if(!has(ctx,'analytics.read')&&!has(ctx,'employee.*'))throw Object.assign(new Error('Workforce analytics permission is required'),{httpStatus:403,code:'FORBIDDEN'}); const r=await db.dbGet("SELECT COUNT(*)::int n FROM users WHERE tenant_id=? AND active='active'",[ctx.tenantId]); result={answer:`Current active headcount is ${Number(r.n||0)}.`,headcount:Number(r.n||0)};
  } else if(/payroll.*increase|why did payroll/.test(lower)){
    intent='payroll.explain'; if(!has(ctx,'ai.payroll')&&!has(ctx,'payroll.read'))throw Object.assign(new Error('Payroll intelligence permission is required'),{httpStatus:403,code:'FORBIDDEN'}); const r=await db.dbAll(`SELECT pr.id,pr.payroll_month,COALESCE(SUM(pd.gross_earning),0) gross_total,COALESCE(SUM(pd.net_salary),0) net_total FROM payroll_runs pr JOIN payroll_details pd ON pd.payroll_run_id=pr.id AND pd.tenant_id=pr.tenant_id WHERE pr.tenant_id=? GROUP BY pr.id,pr.payroll_month ORDER BY pr.payroll_month DESC LIMIT 2`,[ctx.tenantId]); const delta=r.length>1?Number(r[0].net_total)-Number(r[1].net_total):0; result={answer:r.length>1?`Latest net payroll changed by ₹${Math.round(delta).toLocaleString('en-IN')} versus the previous run.`:'Not enough payroll runs to compare.',runs:r};
  } else if(/missing|not.*complete/.test(lower)&&/attendance/.test(lower)){
    intent='attendance.missing'; const rows=await db.dbAll(`SELECT u.id,u.name FROM users u WHERE u.tenant_id=? AND u.active='active' AND NOT EXISTS (SELECT 1 FROM attendance_records ar WHERE ar.tenant_id=u.tenant_id AND ar.user_id=u.id AND ar.date=to_char(current_date,'YYYY-MM-DD')) ORDER BY u.name`,[ctx.tenantId]); result={answer:`${rows.length} active employee(s) have no attendance record today.`,rows};
  }
  await db.dbRun('INSERT INTO ai_queries(tenant_id,actor_id,question,intent,result_json,created_at) VALUES(?,?,?,?,?::jsonb,?)',[ctx.tenantId,ctx.actorId,q,intent,json(result),nowStr()]);
  await audit(ctx,'ai.query','ai_query',null,null,{intent,question:q}); return {intent,...result,explainability:{permissionChecked:true,tenantId:ctx.tenantId}};
}
async function getAiHistory(ctx){return db.dbAll('SELECT id,question,intent,created_at,result_json FROM ai_queries WHERE tenant_id=? AND actor_id=? ORDER BY created_at DESC LIMIT 50',[ctx.tenantId,ctx.actorId]);}
async function extractDocument(ctx,documentId){
  if(!has(ctx,'ai.document')&&!(await isAdmin(ctx)))throw Object.assign(new Error('Document AI permission is required'),{httpStatus:403,code:'FORBIDDEN'});
  const doc=await enterprise.getDocument(ctx,documentId); if(!doc)throw Object.assign(new Error('Document not found'),{httpStatus:404,code:'NOT_FOUND'});
  const classification=(doc.document_type_name||'unknown').toLowerCase();
  const fields={filename:doc.original_filename||doc.name,mimeType:doc.mime_type,sizeBytes:Number(doc.size_bytes||0)};
  const confidence=classification==='unknown'?0.55:0.85;
  const row=await db.dbGet(`INSERT INTO ai_document_extractions(tenant_id,document_id,status,extractor,classification,fields_json,confidence,created_at,updated_at) VALUES(?,?,?,?,?,?::jsonb,?,?,?) RETURNING *`,[ctx.tenantId,doc.id,'completed','metadata','document',json(fields),confidence,nowStr(),nowStr()]);
  await audit(ctx,'ai.document.extract','document',doc.id,null,{extractionId:row.id,classification,confidence}); return row;
}
async function confirmDocumentExtraction(ctx,id,d){const ex=await db.dbGet('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!ex)throw Object.assign(new Error('Extraction not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await isAdmin(ctx)))throw Object.assign(new Error('Only authorized reviewers can confirm extracted fields'),{httpStatus:403,code:'FORBIDDEN'});await db.dbRun('UPDATE ai_document_extractions SET fields_json=?::jsonb,confirmed_by=?,confirmed_at=?,updated_at=?,status=\'confirmed\' WHERE tenant_id=? AND id=?',[json(d.fields),ctx.actorId,nowStr(),nowStr(),ctx.tenantId,ex.id]);await audit(ctx,'ai.document.confirm','ai_document_extraction',ex.id,{status:ex.status},{status:'confirmed',fields:d.fields});return db.dbGet('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND id=?',[ctx.tenantId,ex.id]);}
async function listAiExtractions(ctx,documentId){return db.dbAll('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND (?::uuid IS NULL OR document_id=?::uuid) ORDER BY created_at DESC',[ctx.tenantId,documentId||null,documentId||null]);}
async function scanPayrollAnomalies(ctx,runId){
  if(!has(ctx,'ai.payroll')&&!has(ctx,'payroll.read'))throw Object.assign(new Error('Payroll intelligence permission is required'),{httpStatus:403,code:'FORBIDDEN'});
  const run=asId(runId); if(!run)throw Object.assign(new Error('runId is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  await db.dbRun('DELETE FROM ai_payroll_anomalies WHERE tenant_id=? AND payroll_run_id=?',[ctx.tenantId,run]);
  const rows=await db.dbAll(`SELECT pd.user_id,pd.gross_earning,pd.net_salary,pd.basic_earning,pr.payroll_month,u.name,u.bank_account_no FROM payroll_details pd JOIN payroll_runs pr ON pr.id=pd.payroll_run_id AND pr.tenant_id=pd.tenant_id JOIN users u ON u.id=pd.user_id AND u.tenant_id=pd.tenant_id WHERE pd.tenant_id=? AND pd.payroll_run_id=?`,[ctx.tenantId,run]);
  const prev=await db.dbGet(`SELECT pr.id FROM payroll_runs pr WHERE pr.tenant_id=? AND pr.id<? ORDER BY pr.id DESC LIMIT 1`,[ctx.tenantId,run]);
  const prevMap={}; if(prev)for(const r of await db.dbAll('SELECT user_id,net_salary,gross_earning FROM payroll_details WHERE tenant_id=? AND payroll_run_id=?',[ctx.tenantId,prev.id]))prevMap[r.user_id]=r;
  for(const r of rows){const p=prevMap[r.user_id]; if(p&&Number(p.net_salary)>0){const delta=(Number(r.net_salary)-Number(p.net_salary))/Number(p.net_salary);if(Math.abs(delta)>=0.25){await db.dbRun(`INSERT INTO ai_payroll_anomalies(tenant_id,payroll_run_id,user_id,anomaly_type,severity,score,explanation,source_json,created_at) VALUES(?,?,?,?,?,?,?,?::jsonb,?)`,[ctx.tenantId,run,r.user_id,'net_pay_change',Math.abs(delta)>=0.5?'high':'medium',Math.min(1,Math.abs(delta)),`Net pay changed ${(delta*100).toFixed(1)}% versus the previous payroll run.`,json({previous:p.net_salary,current:r.net_salary}),nowStr()]);}}
    if(!r.bank_account_no)await db.dbRun(`INSERT INTO ai_payroll_anomalies(tenant_id,payroll_run_id,user_id,anomaly_type,severity,score,explanation,source_json,created_at) VALUES(?,?,?,?,?,?,?,?::jsonb,?)`,[ctx.tenantId,run,r.user_id,'missing_bank_account','high',1,'Employee has no bank account recorded.',json({}),nowStr()]);
  }
  return db.dbAll(`SELECT a.*,u.name user_name FROM ai_payroll_anomalies a LEFT JOIN users u ON u.id=a.user_id AND u.tenant_id=a.tenant_id WHERE a.tenant_id=? AND a.payroll_run_id=? ORDER BY a.score DESC`,[ctx.tenantId,run]);
}
async function reviewAnomaly(ctx,id,status,notes){const row=await db.dbGet('SELECT * FROM ai_payroll_anomalies WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!row)throw Object.assign(new Error('Anomaly not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE ai_payroll_anomalies SET status=?,reviewed_by=?,reviewed_at=?,explanation=? WHERE tenant_id=? AND id=?',[status||'reviewed',ctx.actorId,nowStr(),notes?`${row.explanation} Review: ${notes}`:row.explanation,ctx.tenantId,row.id]);await audit(ctx,'ai.payroll.review','ai_payroll_anomaly',row.id,{status:row.status},{status:status||'reviewed',notes});return db.dbGet('SELECT * FROM ai_payroll_anomalies WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);}


async function updateInterview(ctx,id,d){
  const row=await db.dbGet('SELECT * FROM interviews WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!row) throw Object.assign(new Error('Interview not found'),{httpStatus:404,code:'NOT_FOUND'});
  await db.dbRun(`UPDATE interviews SET status=?,feedback=?,rating=?,scheduled_at=?,duration_minutes=?,mode=?,location=? WHERE tenant_id=? AND id=?`,[d.status||row.status,d.feedback??row.feedback,d.rating==null?row.rating:Number(d.rating),d.scheduledAt||row.scheduled_at,Number(d.durationMinutes)||row.duration_minutes,d.mode||row.mode,d.location??row.location,ctx.tenantId,row.id]);
  return db.dbGet('SELECT * FROM interviews WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);
}
async function acceptOffer(ctx,id){
  const o=await db.dbGet('SELECT * FROM offers WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!o) throw Object.assign(new Error('Offer not found'),{httpStatus:404,code:'NOT_FOUND'});
  await db.dbRun("UPDATE offers SET status='accepted',accepted_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,o.id]);
  await moveCandidate(ctx,o.candidate_id,'accepted','Offer accepted');
  return db.dbGet('SELECT * FROM offers WHERE tenant_id=? AND id=?',[ctx.tenantId,o.id]);
}
async function convertCandidateToEmployee(ctx,id,d){
  if(!(await isAdmin(ctx))) throw Object.assign(new Error('Only HR administrators can convert candidates'),{httpStatus:403,code:'FORBIDDEN'});
  const c=await db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!c) throw Object.assign(new Error('Candidate not found'),{httpStatus:404,code:'NOT_FOUND'});
  const existing=c.email?await db.dbGet('SELECT id FROM users WHERE tenant_id=? AND lower(email)=lower(?)',[ctx.tenantId,c.email]):null; if(existing) return {userId:existing.id,existing:true};
  const email=c.email||d.email; if(!email) throw Object.assign(new Error('Candidate email is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const role=d.role||'employee'; const password=d.password||crypto.randomBytes(10).toString('base64url'); const {hashPassword}=require('./auth');const pw=hashPassword(password);
  const row=await db.dbGet(`INSERT INTO users(tenant_id,name,email,password_hash,password_salt,role,title,phone,joined_date,must_reset_password,active,avatar_color,created_at) VALUES(?,?,?,?,?,?,?,?,?,1,'active','#2F6F5E',?) RETURNING id,name,email`,[ctx.tenantId,`${c.first_name} ${c.last_name||''}`.trim(),email,pw.hash,pw.salt,role,c.current_title||null,c.phone||null,d.joinedDate||nowStr().slice(0,10),nowStr()]);
  await enterprise.ensureMembership(row.id,ctx.tenantId,role); await db.dbRun("UPDATE candidates SET stage='joined',status='hired',updated_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,c.id]); await audit(ctx,'recruitment.candidate.convert','candidate',c.id,{stage:c.stage},{stage:'joined',userId:row.id}); return {userId:row.id,existing:false,temporaryPassword:password};
}
async function calibrateRating(ctx,d){if(!(await isAdmin(ctx)))throw Object.assign(new Error('Calibration requires HR/admin permission'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO performance_calibrations(tenant_id,cycle_id,user_id,original_rating,calibrated_rating,notes,calibrated_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.cycleId),asId(d.userId),Number(d.originalRating),Number(d.calibratedRating),d.notes||null,ctx.actorId,nowStr()]);await audit(ctx,'performance.calibration','performance_calibration',row.id,null,row);return row;}
async function listCalibrations(ctx,cycleId){if(!(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll('SELECT c.*,u.name user_name FROM performance_calibrations c LEFT JOIN users u ON u.id=c.user_id AND u.tenant_id=c.tenant_id WHERE c.tenant_id=? AND (? IS NULL OR c.cycle_id=?) ORDER BY c.created_at DESC',[ctx.tenantId,cycleId||null,cycleId||null]);}
async function listCertifications(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll('SELECT c.*,lc.title course_title FROM learning_certifications c LEFT JOIN learning_courses lc ON lc.id=c.course_id AND lc.tenant_id=c.tenant_id WHERE c.tenant_id=? AND c.user_id=? ORDER BY c.expires_on NULLS LAST',[ctx.tenantId,target]);}
async function listAssetsForUser(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll(`SELECT a.*,aa.assigned_on,aa.returned_on,aa.notes FROM assets a JOIN asset_assignments aa ON aa.asset_id=a.id AND aa.tenant_id=a.tenant_id WHERE a.tenant_id=? AND aa.user_id=? ORDER BY aa.assigned_on DESC`,[ctx.tenantId,target]);}
async function executeSavedReport(ctx,id){const report=await db.dbGet('SELECT * FROM saved_reports WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!report)throw Object.assign(new Error('Report not found'),{httpStatus:404,code:'NOT_FOUND'});const area=report.area;let rows=[];if(area==='workforce')rows=await db.dbAll("SELECT dept,COUNT(*)::int headcount FROM users WHERE tenant_id=? AND active='active' GROUP BY dept ORDER BY headcount DESC",[ctx.tenantId]);else if(area==='attendance')rows=await db.dbAll("SELECT date attendance_date,COUNT(*)::int records FROM attendance_records WHERE tenant_id=? GROUP BY date ORDER BY date DESC LIMIT 90",[ctx.tenantId]);else if(area==='leave')rows=await db.dbAll('SELECT status,COUNT(*)::int count,SUM(days) days FROM leave_applications WHERE tenant_id=? GROUP BY status',[ctx.tenantId]);else if(area==='recruitment')rows=await db.dbAll('SELECT stage,COUNT(*)::int count FROM candidates WHERE tenant_id=? GROUP BY stage',[ctx.tenantId]);else if(area==='documents')rows=await db.dbAll('SELECT verification_status,COUNT(*)::int count FROM documents WHERE tenant_id=? GROUP BY verification_status',[ctx.tenantId]);else if(area==='support')rows=await db.dbAll('SELECT status,COUNT(*)::int count FROM service_tickets WHERE tenant_id=? GROUP BY status',[ctx.tenantId]);else rows=await db.dbAll('SELECT payroll_month,total_employees,total_gross,total_net,status FROM payroll_runs WHERE tenant_id=? ORDER BY payroll_month DESC LIMIT 24',[ctx.tenantId]);return {report,rows};}
async function publishEvent(ctx,eventType,payload){const eventId=crypto.randomUUID();const subs=await db.dbAll('SELECT * FROM webhook_subscriptions WHERE tenant_id=? AND active=1',[ctx.tenantId]);for(const s of subs){let events=[];try{events=JSON.parse(s.events_json||'[]')}catch{} if(events.length&&!events.includes(eventType))continue;await db.dbRun(`INSERT INTO webhook_deliveries(tenant_id,subscription_id,event_type,event_id,payload_json,status,created_at) VALUES(?,?,?,?,?::jsonb,'queued',?) ON CONFLICT(subscription_id,event_id) DO NOTHING`,[ctx.tenantId,s.id,eventType,eventId,json(payload),nowStr()]);}return {eventId,queued:subs.length};}
async function processWebhookDeliveries(ctx){const rows=await db.dbAll("SELECT d.*,s.url FROM webhook_deliveries d JOIN webhook_subscriptions s ON s.id=d.subscription_id AND s.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.status='queued' ORDER BY d.id LIMIT 25",[ctx.tenantId]);for(const d of rows){const attempt=Number(d.attempts||0)+1;try{const body=JSON.stringify(d.payload_json);const secret=decryptSecret((await db.dbGet('SELECT secret_enc FROM webhook_subscriptions WHERE tenant_id=? AND id=?',[ctx.tenantId,d.subscription_id]))?.secret_enc||'');const signature=crypto.createHmac('sha256',secret||'').update(body).digest('hex');const resp=await fetch(d.url,{method:'POST',headers:{'content-type':'application/json','x-vasjo-event':d.event_type,'x-vasjo-signature':signature},body});if(!resp.ok)throw new Error(`HTTP ${resp.status}`);await db.dbRun("UPDATE webhook_deliveries SET status='delivered',attempts=?,delivered_at=? WHERE tenant_id=? AND id=?",[attempt,nowStr(),ctx.tenantId,d.id]);}catch(e){await db.dbRun("UPDATE webhook_deliveries SET attempts=?,error=?,status=? WHERE tenant_id=? AND id=?",[attempt,String(e.message||e),attempt>=5?'failed':'queued',ctx.tenantId,d.id]);}}return {processed:rows.length};}

module.exports={
  listRequisitions,saveRequisition,listCandidates,createCandidate,moveCandidate,scheduleInterview,updateInterview,listInterviews,createOffer,acceptOffer,convertCandidateToEmployee,recruitmentAnalytics,
  listCycles,saveCycle,listGoals,saveGoal,saveReview,listReviews,listFeedback,savePip,calibrateRating,listCalibrations,
  listCourses,saveCourse,enroll,completeEnrollment,listEnrollments,saveCertification,listCertifications,saveSkill,
  listBenefitPlans,saveBenefitPlan,enrollBenefit,listBenefitsForUser,saveDependent,
  listExpenses,createExpense,addExpenseLine,submitExpense,decideExpense,listExpenseLines,listExpenseApprovals,
  listAssets,saveAsset,assignAsset,returnAsset,listAssetsForUser,
  listTickets,createTicket,updateTicket,addTicketNote,ticketNotes,listServiceRequestApprovals,decideServiceRequest,
  listIntegrations,saveWebhook,disableWebhook,createSyncJob,testIntegration,removeIntegration,
  analyticsOverview,saveReport,listReports,executeSavedReport,mobileHome,publishEvent,processWebhookDeliveries,
  aiAssistant,getAiHistory,extractDocument,confirmDocumentExtraction,listAiExtractions,scanPayrollAnomalies,reviewAnomaly,
};

  },
  "storage": function (require, module, exports) {
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');

function hmac(key, data, encoding) { return crypto.createHmac('sha256', key).update(data).digest(encoding); }
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function awsSigningKey(secret, date, region, service) {
  const kDate = hmac(`AWS4${secret}`, date);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  return hmac(kService, 'aws4_request');
}

function cfg() {
  return {
    driver: process.env.OBJECT_STORAGE_DRIVER || process.env.STORAGE_DRIVER || 'local',
    endpoint: process.env.S3_ENDPOINT,
    bucket: process.env.S3_BUCKET,
    region: process.env.S3_REGION || 'us-east-1',
    accessKey: process.env.S3_ACCESS_KEY_ID,
    secretKey: process.env.S3_SECRET_ACCESS_KEY,
    root: process.env.LOCAL_STORAGE_ROOT || process.env.STORAGE_ROOT || path.join(process.cwd(), 'private-storage'),
  };
}

function encodeKey(key) { return key.split('/').map(encodeURIComponent).join('/'); }

function s3Presign(method, key, expiresSeconds = 300, contentType) {
  const c = cfg();
  if (!c.endpoint || !c.bucket || !c.accessKey || !c.secretKey) throw new Error('S3 storage is not configured');
  const endpoint = new URL(c.endpoint);
  const host = endpoint.host;
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0,15) + 'Z';
  const dateStamp = amzDate.slice(0,8);
  const service = 's3';
  const scope = `${dateStamp}/${c.region}/${service}/aws4_request`;
  const credential = `${c.accessKey}/${scope}`;
  const canonicalUri = `${endpoint.pathname.replace(/\/$/,'')}/${encodeKey(c.bucket)}/${encodeKey(key)}`.replace(/\/+/g,'/');
  const params = new URLSearchParams({
    'X-Amz-Algorithm':'AWS4-HMAC-SHA256',
    'X-Amz-Credential':credential,
    'X-Amz-Date':amzDate,
    'X-Amz-Expires':String(expiresSeconds),
    'X-Amz-SignedHeaders': contentType ? 'content-type;host' : 'host',
  });
  const signedHeaders = contentType ? `content-type:${contentType}\nhost:${host}` : `host:${host}`;
  const canonicalHeaders = contentType ? `content-type:${contentType}\nhost:${host}\n` : `host:${host}\n`;
  const canonicalQuery = [...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
  const canonicalRequest = [method, canonicalUri, canonicalQuery, canonicalHeaders, contentType ? 'content-type;host' : 'host', 'UNSIGNED-PAYLOAD'].join('\n');
  const stringToSign = ['AWS4-HMAC-SHA256',amzDate,scope,sha256(canonicalRequest)].join('\n');
  const signature = hmac(awsSigningKey(c.secretKey,dateStamp,c.region,service), stringToSign, 'hex');
  params.set('X-Amz-Signature', signature);
  return `${endpoint.origin}${canonicalUri}?${params.toString()}`;
}

async function ensureRoot(root) { await fs.mkdir(root, { recursive:true, mode:0o700 }); }

async function putObject({ objectKey, buffer, contentType }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('PUT', objectKey, 600, contentType);
    const resp = await fetch(url, { method:'PUT', headers:{'content-type':contentType}, body:buffer });
    if (!resp.ok) throw new Error(`Object storage upload failed (${resp.status})`);
    return { objectKey };
  }
  await ensureRoot(c.root);
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  await fs.mkdir(path.dirname(target), {recursive:true, mode:0o700});
  await fs.writeFile(target, buffer, { mode:0o600 });
  return { objectKey };
}

async function getObject({ objectKey }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('GET', objectKey, 120);
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`Object storage download failed (${resp.status})`);
    return Buffer.from(await resp.arrayBuffer());
  }
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  return fs.readFile(target);
}

function getDownloadUrl(objectKey, expiresSeconds=120) {
  const c = cfg();
  if (c.driver === 's3') return s3Presign('GET', objectKey, expiresSeconds);
  return null;
}

async function deleteObject({ objectKey }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('DELETE', objectKey, 300);
    const resp = await fetch(url, { method:'DELETE' });
    if (!resp.ok && resp.status !== 404) throw new Error(`Object storage delete failed (${resp.status})`);
    return;
  }
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  await fs.rm(target, {force:true});
}

async function scanBuffer(buffer, originalName) {
  const allow = new Set(['pdf','jpg','jpeg','png','doc','docx','xls','xlsx','csv','txt']);
  const ext = String(path.extname(originalName).slice(1)).toLowerCase();
  if (!allow.has(ext)) return { status:'rejected', reason:'File type not allowed' };
  // Magic/signature checks for common dangerous or mismatched content.
  const sig = buffer.subarray(0,8).toString('hex').toLowerCase();
  if (sig.startsWith('4d5a')) return { status:'rejected', reason:'Executable content is not allowed' };
  if (ext === 'pdf' && !buffer.subarray(0,5).toString().startsWith('%PDF-')) return { status:'rejected', reason:'PDF signature mismatch' };
  if (['jpg','jpeg'].includes(ext) && !sig.startsWith('ffd8ff')) return { status:'rejected', reason:'JPEG signature mismatch' };
  if (ext === 'png' && sig !== '89504e470d0a1a0a') return { status:'rejected', reason:'PNG signature mismatch' };
  // Optional ClamAV integration. Fail closed only when explicitly required.
  if (process.env.CLAMAV_REQUIRED === 'true' && process.env.CLAMSCAN_BIN) {
    const { execFile } = require('node:child_process');
    const { promisify } = require('node:util');
    const exec = promisify(execFile);
    const os = require('node:os');
    const temp = path.join(os.tmpdir(), `vasjo-scan-${crypto.randomUUID()}`);
    try {
      await fs.writeFile(temp, buffer, {mode:0o600});
      const { stdout } = await exec(process.env.CLAMSCAN_BIN, ['--no-summary', temp], {timeout:30000});
      if (!/OK\s*$/.test(stdout)) return { status:'quarantined', reason:'Malware scan detected a threat' };
    } catch (e) {
      if (e.stdout && !/OK\s*$/.test(e.stdout)) return { status:'quarantined', reason:'Malware scan detected a threat' };
      throw new Error('Malware scanner unavailable');
    } finally { await fs.rm(temp,{force:true}); }
  }
  return { status:'clean' };
}

module.exports = { putObject, getObject, getDownloadUrl, deleteObject, scanBuffer, sha256, cfg };

  }
};

const cache = Object.create(null);
function load(name) {
  if (!cache[name]) {
    const module = { exports: {} };
    const localRequire = (request) => {
      if (request === './db') return require('./db');
      if (request.startsWith('./')) return load(request.slice(2));
      return require(request);
    };
    factories[name](localRequire, module, module.exports);
    cache[name] = module.exports;
  }
  return cache[name];
}

module.exports = new Proxy({}, {
  get(_target, property) {
    if (property === 'then') return undefined;
    if (!factories[property]) return undefined;
    return load(property);
  },
  ownKeys() { return Object.keys(factories); },
  getOwnPropertyDescriptor() { return { enumerable: true, configurable: true }; }
});
