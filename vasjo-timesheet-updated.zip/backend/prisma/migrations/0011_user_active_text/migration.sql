-- Store employee account status semantically instead of a numeric flag.
-- Existing 1/0 values are preserved as active/inactive.
ALTER TABLE users
  ALTER COLUMN active DROP DEFAULT,
  ALTER COLUMN active TYPE TEXT USING CASE WHEN active::text IN ('1','true','active') THEN 'active' ELSE 'inactive' END,
  ALTER COLUMN active SET DEFAULT 'active';

UPDATE users SET active = CASE WHEN active IN ('1','true','active') THEN 'active' ELSE 'inactive' END;
