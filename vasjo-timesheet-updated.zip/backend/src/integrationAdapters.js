'use strict';

/**
 * P3 Integration Hub adapter boundary.
 * Vendor-specific behavior must live here rather than inside HR domain modules.
 * Adapters intentionally fail closed when credentials/configuration are absent.
 */

class IntegrationAdapter {
  constructor(provider) { this.provider = provider; }
  async test(context) { return { ok: false, provider: this.provider, message: 'Adapter not configured' }; }
  async push(context, payload) { return { ok: false, provider: this.provider, message: 'Outbound adapter not configured' }; }
  async pull(context, options = {}) { return { ok: false, provider: this.provider, message: 'Inbound adapter not configured', options }; }
  async disconnect(context) { return { ok: true, provider: this.provider, disconnected: true }; }
}

const PROVIDERS = ['microsoft-entra','google-workspace','google-drive','sharepoint','onedrive','teams','slack','tally','erp','banks','biometric','email','sms'];
const adapters = Object.fromEntries(PROVIDERS.map(provider => [provider, new IntegrationAdapter(provider)]));

function getAdapter(provider) {
  const key = String(provider || '').trim().toLowerCase();
  return adapters[key] || new IntegrationAdapter(key || 'unknown');
}

function listAdapters() {
  return PROVIDERS.map(provider => ({ provider, supported: true, configured: false }));
}

module.exports = { IntegrationAdapter, getAdapter, listAdapters };
