const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');

function hmac(key, data, encoding) { return crypto.createHmac('sha256', key).update(data).digest(encoding); }
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function awsSigningKey(secret, date, region, service) {
  const kDate = hmac(`AWS4${secret}`, date);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  return hmac(kService, 'aws4_request');
}

function cfg() {
  return {
    driver: process.env.OBJECT_STORAGE_DRIVER || process.env.STORAGE_DRIVER || 'local',
    endpoint: process.env.S3_ENDPOINT,
    bucket: process.env.S3_BUCKET,
    region: process.env.S3_REGION || 'us-east-1',
    accessKey: process.env.S3_ACCESS_KEY_ID,
    secretKey: process.env.S3_SECRET_ACCESS_KEY,
    root: process.env.LOCAL_STORAGE_ROOT || process.env.STORAGE_ROOT || path.join(process.cwd(), 'private-storage'),
  };
}

function encodeKey(key) { return key.split('/').map(encodeURIComponent).join('/'); }

function s3Presign(method, key, expiresSeconds = 300, contentType) {
  const c = cfg();
  if (!c.endpoint || !c.bucket || !c.accessKey || !c.secretKey) throw new Error('S3 storage is not configured');
  const endpoint = new URL(c.endpoint);
  const host = endpoint.host;
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0,15) + 'Z';
  const dateStamp = amzDate.slice(0,8);
  const service = 's3';
  const scope = `${dateStamp}/${c.region}/${service}/aws4_request`;
  const credential = `${c.accessKey}/${scope}`;
  const canonicalUri = `${endpoint.pathname.replace(/\/$/,'')}/${encodeKey(c.bucket)}/${encodeKey(key)}`.replace(/\/+/g,'/');
  const params = new URLSearchParams({
    'X-Amz-Algorithm':'AWS4-HMAC-SHA256',
    'X-Amz-Credential':credential,
    'X-Amz-Date':amzDate,
    'X-Amz-Expires':String(expiresSeconds),
    'X-Amz-SignedHeaders': contentType ? 'content-type;host' : 'host',
  });
  const signedHeaders = contentType ? `content-type:${contentType}\nhost:${host}` : `host:${host}`;
  const canonicalHeaders = contentType ? `content-type:${contentType}\nhost:${host}\n` : `host:${host}\n`;
  const canonicalQuery = [...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
  const canonicalRequest = [method, canonicalUri, canonicalQuery, canonicalHeaders, contentType ? 'content-type;host' : 'host', 'UNSIGNED-PAYLOAD'].join('\n');
  const stringToSign = ['AWS4-HMAC-SHA256',amzDate,scope,sha256(canonicalRequest)].join('\n');
  const signature = hmac(awsSigningKey(c.secretKey,dateStamp,c.region,service), stringToSign, 'hex');
  params.set('X-Amz-Signature', signature);
  return `${endpoint.origin}${canonicalUri}?${params.toString()}`;
}

async function ensureRoot(root) { await fs.mkdir(root, { recursive:true, mode:0o700 }); }

async function putObject({ objectKey, buffer, contentType }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('PUT', objectKey, 600, contentType);
    const resp = await fetch(url, { method:'PUT', headers:{'content-type':contentType}, body:buffer });
    if (!resp.ok) throw new Error(`Object storage upload failed (${resp.status})`);
    return { objectKey };
  }
  await ensureRoot(c.root);
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  await fs.mkdir(path.dirname(target), {recursive:true, mode:0o700});
  await fs.writeFile(target, buffer, { mode:0o600 });
  return { objectKey };
}

async function getObject({ objectKey }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('GET', objectKey, 120);
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`Object storage download failed (${resp.status})`);
    return Buffer.from(await resp.arrayBuffer());
  }
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  return fs.readFile(target);
}

function getDownloadUrl(objectKey, expiresSeconds=120) {
  const c = cfg();
  if (c.driver === 's3') return s3Presign('GET', objectKey, expiresSeconds);
  return null;
}

async function deleteObject({ objectKey }) {
  const c = cfg();
  if (c.driver === 's3') {
    const url = s3Presign('DELETE', objectKey, 300);
    const resp = await fetch(url, { method:'DELETE' });
    if (!resp.ok && resp.status !== 404) throw new Error(`Object storage delete failed (${resp.status})`);
    return;
  }
  const target = path.resolve(c.root, objectKey);
  if (!target.startsWith(path.resolve(c.root) + path.sep)) throw new Error('Invalid object key');
  await fs.rm(target, {force:true});
}

async function scanBuffer(buffer, originalName) {
  const allow = new Set(['pdf','jpg','jpeg','png','doc','docx','xls','xlsx','csv','txt']);
  const ext = String(path.extname(originalName).slice(1)).toLowerCase();
  if (!allow.has(ext)) return { status:'rejected', reason:'File type not allowed' };
  // Magic/signature checks for common dangerous or mismatched content.
  const sig = buffer.subarray(0,8).toString('hex').toLowerCase();
  if (sig.startsWith('4d5a')) return { status:'rejected', reason:'Executable content is not allowed' };
  if (ext === 'pdf' && !buffer.subarray(0,5).toString().startsWith('%PDF-')) return { status:'rejected', reason:'PDF signature mismatch' };
  if (['jpg','jpeg'].includes(ext) && !sig.startsWith('ffd8ff')) return { status:'rejected', reason:'JPEG signature mismatch' };
  if (ext === 'png' && sig !== '89504e470d0a1a0a') return { status:'rejected', reason:'PNG signature mismatch' };
  // Optional ClamAV integration. Fail closed only when explicitly required.
  if (process.env.CLAMAV_REQUIRED === 'true' && process.env.CLAMSCAN_BIN) {
    const { execFile } = require('node:child_process');
    const { promisify } = require('node:util');
    const exec = promisify(execFile);
    const os = require('node:os');
    const temp = path.join(os.tmpdir(), `vasjo-scan-${crypto.randomUUID()}`);
    try {
      await fs.writeFile(temp, buffer, {mode:0o600});
      const { stdout } = await exec(process.env.CLAMSCAN_BIN, ['--no-summary', temp], {timeout:30000});
      if (!/OK\s*$/.test(stdout)) return { status:'quarantined', reason:'Malware scan detected a threat' };
    } catch (e) {
      if (e.stdout && !/OK\s*$/.test(e.stdout)) return { status:'quarantined', reason:'Malware scan detected a threat' };
      throw new Error('Malware scanner unavailable');
    } finally { await fs.rm(temp,{force:true}); }
  }
  return { status:'clean' };
}

module.exports = { putObject, getObject, getDownloadUrl, deleteObject, scanBuffer, sha256, cfg };
