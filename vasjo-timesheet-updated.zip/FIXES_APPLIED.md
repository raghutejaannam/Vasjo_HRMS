# Vasjo Timesheet Portal - Regression Fixes

## Known defects fixed

1. Leave Calendar team scope
   - Admin team calendar now returns all active tenant employees.
   - Manager team calendar handles an empty manager scope safely.

2. Payroll Dashboard
   - Fixed frontend/server response-shape mismatch.
   - Dashboard now receives `{ dashboard: ... }` as expected.

3. Payroll Runs
   - Fixed a concrete backend bug where the logged-in user ID was passed as the Prisma transaction client to `getOrCreatePayrollRun()`. This caused `client.$queryRaw is not a function`.

4. User status
   - `users.active` is migrated from numeric 1/0 to `active`/`inactive`.
   - Login, session validation, user filters, payroll employee selection, reports, analytics and UI status handling were updated.

5. Recruitment / ATS
   - Fixed PostgreSQL date arithmetic. `date - date` is used directly instead of `EXTRACT(EPOCH FROM integer)`.

6. Benefits
   - Employee/employer/coverage numeric values are explicitly cast to numeric in the PostgreSQL INSERT.
   - Frontend converts numeric inputs before submission.

7. Saved Reports
   - `filters_json` is explicitly cast to JSONB.

8. Workforce Analytics
   - User active-status filtering updated for the new semantic status.
   - Analytics queries return the expected dashboard shape.

9. Enterprise permissions
   - Admin users are treated as wildcard administrators (`*`) at permission-check time.
   - `/api/me` refreshes tenant permissions for existing sessions.

10. Employee Lifecycle Documents
    - Existing path/URL entry remains supported.
    - Added local binary upload endpoint with file validation/scanning and private storage.
    - Added browser-preview/open endpoint for uploaded lifecycle documents.

11. Learning
    - Added course assignment UI and employee selector.
    - Managers can assign to direct reports; admins can assign to any active employee.

12. Expenses / HR requests
    - Added Expense Approvals and HR Request Approvals tabs to the shared Approvals page.
    - Added manager/admin approval endpoints.

13. Asset Management
    - Asset tag is now an interactive assignment control.
    - Assignee column is present and assignment UI is available.

14. Compliance Rules
    - Existing routes are covered by admin wildcard permissions, removing the previous permission blocker.

15. Integration Hub
    - Google Drive and Microsoft OAuth Connect actions now work when configured.
    - When OAuth is not configured, the UI receives actionable server configuration instructions instead of a generic 503 failure.

16. AI
    - Fixed JSONB and UUID parameter handling for AI query/document/payroll persistence.
    - Payroll anomaly scanning and Document Intelligence persistence are now compatible with PostgreSQL types.

## Required deployment step

Run the new migration before starting the application against an existing PostgreSQL database:

```bash
cd backend
npx prisma migrate deploy
npx prisma generate
```

Then restart backend and frontend.

## Validation performed

- All backend `.js` files pass `node --check`.
- Frontend dependency installation/build could not be executed in this offline environment because the npm registry request timed out and the uploaded project did not include `node_modules`.
- Backend SQL was reviewed for the PostgreSQL type errors shown in the supplied screenshots, including numeric, JSONB, UUID and date-arithmetic cases.
