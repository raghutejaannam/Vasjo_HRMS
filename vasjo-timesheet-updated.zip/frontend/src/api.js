// ============================================================
// api.js — ALL backend communication lives here.
//
// This is a 1:1 port of the `api()` helper and every fetch call that used to
// live inline inside the old single-file HTML app. Endpoints, HTTP methods,
// request payloads and response shapes are UNCHANGED from the original app.
// The backend, database, auth and business logic (esp. payroll calculation)
// are untouched — React only calls these endpoints and displays what comes
// back. Nothing here computes payroll, tax, or leave balances itself.
// ============================================================

let csrfToken = null;

export function setCsrfToken(token) {
  csrfToken = token;
}

export function getCsrfToken() {
  return csrfToken;
}

/**
 * Low-level fetch wrapper — identical behavior to the original `api()`:
 * - always sends cookies (credentials: include)
 * - attaches X-CSRF-Token on non-GET requests once we have one
 * - throws an Error with `.status` set on non-2xx responses
 * - tolerates empty/non-JSON bodies (e.g. CSV/PDF download endpoints)
 */
async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (opts.method && opts.method !== "GET" && csrfToken) headers["X-CSRF-Token"] = csrfToken;
  const res = await fetch(path, { credentials: "include", ...opts, headers });
  let data = {};
  try {
    data = await res.json();
  } catch (e) {
    /* no body, e.g. CSV/PDF endpoints */
  }
  if (!res.ok) {
    const err = new Error(data.error || "Request failed");
    err.status = res.status;
    throw err;
  }
  return data;
}

export default api;

// ------------------------------------------------------------
// Auth
// ------------------------------------------------------------
export const login = (email, password) =>
  api("/api/login", { method: "POST", body: JSON.stringify({ email, password }) });

export const logout = () => api("/api/logout", { method: "POST" });

export const me = () => api("/api/me");

export const updateMe = (payload) => api("/api/me", { method: "PATCH", body: JSON.stringify(payload) });

export const changePassword = (currentPassword, newPassword) =>
  api("/api/change-password", { method: "POST", body: JSON.stringify({ currentPassword, newPassword }) });

// ------------------------------------------------------------
// Notifications
// ------------------------------------------------------------
export const getNotifications = () => api("/api/notifications");
export const markNotificationRead = (id) => api(`/api/notifications/${id}/read`, { method: "PATCH" });
export const markAllNotificationsRead = () => api("/api/notifications/read-all", { method: "PATCH" });

// ------------------------------------------------------------
// Settings / leave types / holidays / departments
// ------------------------------------------------------------
export const getSettings = () => api("/api/settings");
export const saveSettings = (payload) => api("/api/settings", { method: "PATCH", body: JSON.stringify(payload) });

export const getLeaveTypes = () => api("/api/leave-types");
export const addLeaveType = (payload) => api("/api/leave-types", { method: "POST", body: JSON.stringify(payload) });
export const updateLeaveType = (id, payload) => api(`/api/leave-types/${id}`, { method: "PATCH", body: JSON.stringify(payload) });

export const getHolidays = () => api("/api/holidays");
export const addHoliday = (payload) => api("/api/holidays", { method: "POST", body: JSON.stringify(payload) });
export const deleteHoliday = (id) => api(`/api/holidays/${id}`, { method: "DELETE" });

export const getDepartments = (all) => api(`/api/departments${all ? "?all=1" : ""}`);
export const addDepartment = (name) => api("/api/departments", { method: "POST", body: JSON.stringify({ name }) });
export const toggleDepartment = (id, active) => api(`/api/departments/${id}`, { method: "PATCH", body: JSON.stringify({ active }) });

// ------------------------------------------------------------
// Projects & tasks
// ------------------------------------------------------------
export const getProjects = (all) => api(`/api/projects${all ? "?all=1" : ""}`);
export const addProject = (payload) => api("/api/projects", { method: "POST", body: JSON.stringify(payload) });
export const toggleProject = (id, active) => api(`/api/projects/${id}`, { method: "PATCH", body: JSON.stringify({ active }) });
export const getProjectAssignments = (projectId) => api(`/api/projects/${projectId}/assignments`);
export const saveProjectAssignments = (projectId, userIds) =>
  api(`/api/projects/${projectId}/assignments`, { method: "PUT", body: JSON.stringify({ userIds }) });

export const getTasks = (all) => api(`/api/tasks${all ? "?all=1" : ""}`);
export const addTask = (projectId, name) => api("/api/tasks", { method: "POST", body: JSON.stringify({ projectId, name }) });

// ------------------------------------------------------------
// Timesheets
// ------------------------------------------------------------
export const getTimesheetByWeek = (weekStart) => api(`/api/timesheets?weekStart=${weekStart}`);
export const getMyTimesheets = () => api("/api/timesheets");
export const getMyTimesheetsPaged = (page, pageSize) => api(`/api/timesheets?page=${page}&pageSize=${pageSize}`);
export const getPendingTimesheets = () => api("/api/timesheets?all=1&status=pending");
export const getAllTimesheets = ({ page = 1, pageSize = 25, employeeId, status } = {}) => {
  let url = `/api/timesheets?all=1&page=${page}&pageSize=${pageSize}`;
  if (employeeId) url += `&employeeId=${employeeId}`;
  if (status) url += `&status=${status}`;
  return api(url);
};
export const saveTimesheet = (weekStart, entries, submit) =>
  api("/api/timesheets", { method: "POST", body: JSON.stringify({ weekStart, entries, submit }) });
export const decideTimesheet = (id, action, comment) =>
  api(`/api/timesheets/${id}`, { method: "PATCH", body: JSON.stringify({ action, comment }) });
export const bulkDecideTimesheets = (ids, action, comment) =>
  api("/api/timesheets/bulk-decide", { method: "POST", body: JSON.stringify({ ids, action, comment }) });
export const requestTimesheetCorrection = (id, reason) =>
  api(`/api/timesheets/${id}/request-correction`, { method: "POST", body: JSON.stringify({ reason }) });
export const decideTimesheetCorrection = (id, action, comment) =>
  api(`/api/timesheets/${id}/decide-correction`, { method: "PATCH", body: JSON.stringify({ action, comment }) });
export const getCorrectionRequests = () => api("/api/correction-requests");

// ------------------------------------------------------------
// Leave
// ------------------------------------------------------------
export const getMyLeaveApplications = () => api("/api/leave-applications");
export const getPendingLeaveApplications = () => api("/api/leave-applications?all=1&status=pending");
export const getTeamLeaveApplications = () => api("/api/leave-applications?team=1");
export const getLeaveBalances = () => api("/api/leave-balances");
export const applyForLeave = ({ leaveTypeId, from, to, reason, halfDay }) =>
  api("/api/leave-applications", { method: "POST", body: JSON.stringify({ leaveTypeId, from, to, reason, halfDay }) });
export const cancelLeaveApplication = (id) => api(`/api/leave-applications/${id}/cancel`, { method: "PATCH" });
export const decideLeaveApplication = (id, action, comment) =>
  api(`/api/leave-applications/${id}`, { method: "PATCH", body: JSON.stringify({ action, comment }) });
export const bulkDecideLeaveApplications = (ids, action, comment) =>
  api("/api/leave-applications/bulk-decide", { method: "POST", body: JSON.stringify({ ids, action, comment }) });

// ------------------------------------------------------------
// Team / users / admin
// ------------------------------------------------------------
export const getTeamMembers = () => api("/api/team-members");
export const getUsersFlat = () => api("/api/users/flat");
export const getUsers = (pageSize = 100) => api(`/api/users?pageSize=${pageSize}`);
export const getUser = (id) => api(`/api/users/${id}`);
export const updateUser = (id, payload) => api(`/api/users/${id}`, { method: "PATCH", body: JSON.stringify(payload) });
export const createUser = (payload) => api("/api/users", { method: "POST", body: JSON.stringify(payload) });
export const resetUserPassword = (id) => api(`/api/users/${id}/reset-password`, { method: "POST" });
export const importUsersCsv = (csv) => api("/api/users/import-csv", { method: "POST", body: JSON.stringify({ csv }) });

export const getAdminEmployees = ({ page = 1, pageSize = 50, search = "", department = "", status = "", sortBy = "name", sortDir = "asc" } = {}) =>
  api(`/api/admin/employees?pageSize=${pageSize}&page=${page}&search=${encodeURIComponent(search)}&department=${encodeURIComponent(department)}&status=${status}&sortBy=${sortBy}&sortDir=${sortDir}`);
export const getAdminDepartments = () => api("/api/admin/departments");
export const getEmployeeCompensation = (userId) => api(`/api/admin/employees/${userId}/compensation`);
export const getEmployeeSalaryRevisions = (userId) => api(`/api/admin/employees/${userId}/salary-revisions`);
export const giveEmployeeHike = (userId, payload) =>
  api(`/api/admin/employees/${userId}/hike`, { method: "POST", body: JSON.stringify(payload) });

// ------------------------------------------------------------
// Audit log
// ------------------------------------------------------------
export const getAuditLog = (entityType, entityId) => api(`/api/audit-log?entityType=${entityType}&entityId=${entityId}`);

// ------------------------------------------------------------
// Analytics
// ------------------------------------------------------------
export const getMyTrend = (weeks = 8) => api(`/api/analytics/my-trend?weeks=${weeks}`);
export const getTeamSummary = () => api("/api/analytics/team-summary");

// ------------------------------------------------------------
// Reports (JSON views; CSV export links are built directly against these
// same endpoints with &format=csv, or the dedicated .csv routes below)
// ------------------------------------------------------------
export const getProjectHoursReport = (from, to) => api(`/api/reports/project-hours?from=${from}&to=${to}`);
export const getUtilizationReport = (from, to) => api(`/api/reports/utilization?from=${from}&to=${to}`);
export const getLeaveUsageReport = (year) => api(`/api/reports/leave-usage?year=${year}`);
export const getComplianceReport = (weekStart) => api(`/api/reports/compliance?weekStart=${weekStart}`);
export const getPendingApprovalsReport = () => api("/api/reports/pending-approvals");
export const timesheetsCsvUrl = () => "/api/reports/timesheets.csv";
export const leaveCsvUrl = () => "/api/reports/leave.csv";
export const projectHoursCsvUrl = (from, to) => `/api/reports/project-hours?from=${from}&to=${to}&format=csv`;
export const utilizationCsvUrl = (from, to) => `/api/reports/utilization?from=${from}&to=${to}&format=csv`;
export const leaveUsageCsvUrl = (year) => `/api/reports/leave-usage?year=${year}&format=csv`;
export const complianceCsvUrl = (weekStart) => `/api/reports/compliance?weekStart=${weekStart}&format=csv`;

// ------------------------------------------------------------
// Payroll — financial years
// ------------------------------------------------------------
export const getFinancialYears = () => api("/api/payroll/financial-years");

// ------------------------------------------------------------
// Payroll — salary structures (admin builds these; frontend never computes
// CTC/PF/tax/gratuity/insurance math — it only sends amounts the admin typed
// and displays whatever the backend returns)
// ------------------------------------------------------------
export const getSalaryStructures = (userId) => api(`/api/payroll/salary-structures?userId=${userId}`);
export const getSalaryStructure = (id) => api(`/api/payroll/salary-structures/${id}`);
export const createSalaryStructure = (payload) =>
  api("/api/payroll/salary-structures", { method: "POST", body: JSON.stringify(payload) });
export const updateSalaryStructure = (id, payload) =>
  api(`/api/payroll/salary-structures/${id}`, { method: "PATCH", body: JSON.stringify(payload) });
export const saveSalaryStructureComponents = (id, components) =>
  api(`/api/payroll/salary-structures/${id}/components`, { method: "PUT", body: JSON.stringify({ components }) });
export const activateSalaryStructure = (id) => api(`/api/payroll/salary-structures/${id}/activate`, { method: "POST" });

// ------------------------------------------------------------
// Payroll — my tax regime / declarations (employee self-service)
// ------------------------------------------------------------
export const getMyTaxRegime = (financialYearId) => api(`/api/payroll/my-tax-regime?financialYearId=${financialYearId}`);
export const setMyTaxRegime = (financialYearId, taxRegimeId) =>
  api("/api/payroll/my-tax-regime", { method: "POST", body: JSON.stringify({ financialYearId, taxRegimeId }) });
export const compareMyTaxRegimes = (financialYearId) => api(`/api/payroll/my-tax-regime/compare?financialYearId=${financialYearId}`);
export const getTaxRegimes = (financialYearId) => api(`/api/payroll/tax-regimes?financialYearId=${financialYearId}`);
export const getTaxDeclarationSections = (financialYearId) => api(`/api/payroll/tax-declaration-sections?financialYearId=${financialYearId}`);
export const getMyTaxDeclarations = (financialYearId) => api(`/api/payroll/my-tax-declarations?financialYearId=${financialYearId}`);
export const createOrGetTaxDeclaration = (financialYearId, sectionId) =>
  api("/api/payroll/my-tax-declarations", { method: "POST", body: JSON.stringify({ financialYearId, sectionId }) });
export const addTaxDeclarationEntry = (declarationId, payload) =>
  api(`/api/payroll/tax-declarations/${declarationId}/entries`, { method: "POST", body: JSON.stringify(payload) });
export const deleteTaxDeclarationEntry = (entryId) => api(`/api/payroll/tax-entries/${entryId}`, { method: "DELETE" });
export const submitAllTaxDeclarations = (financialYearId) =>
  api("/api/payroll/my-tax-declarations/submit-all", { method: "POST", body: JSON.stringify({ financialYearId }) });
export const getMyTaxSummary = (financialYearId) => api(`/api/payroll/my-tax-summary?financialYearId=${financialYearId}`);

// ------------------------------------------------------------
// Payroll — payslips
// ------------------------------------------------------------
export const getMyPayslips = (financialYearId) => api(`/api/payroll/my-payslips?financialYearId=${financialYearId}`);
export const generatePayslip = (payrollDetailId) =>
  api("/api/payroll/payslips/generate", { method: "POST", body: JSON.stringify({ payrollDetailId }) });
export const payslipPdfUrl = (payslipId) => `/api/payroll/payslips/${payslipId}/pdf`;

// ------------------------------------------------------------
// Payroll — admin dashboard & runs
// ------------------------------------------------------------
export const getPayrollDashboard = (financialYearId) => api(`/api/payroll/dashboard?financialYearId=${financialYearId}`);
export const getPayrollRuns = (financialYearId) => api(`/api/payroll/runs?financialYearId=${financialYearId}`);
export const createPayrollRun = (financialYearId, payrollMonth) =>
  api("/api/payroll/runs", { method: "POST", body: JSON.stringify({ financialYearId, payrollMonth }) });
export const actOnPayrollRun = (runId, action) => api(`/api/payroll/runs/${runId}/${action}`, { method: "POST" });
export const deletePayrollRun = (runId) => api(`/api/payroll/runs/${runId}`, { method: "DELETE" });
export const getPayrollRunDetails = (runId) => api(`/api/payroll/runs/${runId}/details`);
export const getPayrollRunExceptions = (runId) => api(`/api/payroll/runs/${runId}/exceptions`);
export const resolvePayrollException = (exceptionId, notes) =>
  api(`/api/payroll/exceptions/${exceptionId}/resolve`, { method: "POST", body: JSON.stringify({ notes }) });

// ------------------------------------------------------------
// Payroll — employee loans
// ------------------------------------------------------------
export const getLoansForEmployee = (userId) => api(`/api/payroll/employees/${userId}/loans`);
export const requestLoan = (userId, payload) =>
  api(`/api/payroll/employees/${userId}/loans`, { method: "POST", body: JSON.stringify(payload) });
export const getAllLoans = (status) => api(`/api/payroll/loans${status ? `?status=${status}` : ""}`);
export const decideLoan = (loanId, decision) =>
  api(`/api/payroll/loans/${loanId}/decide`, { method: "POST", body: JSON.stringify({ decision }) });
export const disburseLoan = (loanId) => api(`/api/payroll/loans/${loanId}/disburse`, { method: "POST" });
export const getLoanRepayments = (loanId) => api(`/api/payroll/loans/${loanId}/repayments`);

// ------------------------------------------------------------
// Payroll — salary advances
// ------------------------------------------------------------
export const getAdvancesForEmployee = (userId) => api(`/api/payroll/employees/${userId}/advances`);
export const requestAdvance = (userId, payload) =>
  api(`/api/payroll/employees/${userId}/advances`, { method: "POST", body: JSON.stringify(payload) });
export const getAllAdvances = (status) => api(`/api/payroll/advances${status ? `?status=${status}` : ""}`);
export const decideAdvance = (advanceId, decision, recoveryMonths, monthlyRecoveryAmount) =>
  api(`/api/payroll/advances/${advanceId}/decide`, { method: "POST", body: JSON.stringify({ decision, recoveryMonths, monthlyRecoveryAmount }) });
export const getAdvanceRecoveries = (advanceId) => api(`/api/payroll/advances/${advanceId}/recoveries`);

// ------------------------------------------------------------
// Payroll — leave encashment
// ------------------------------------------------------------
export const getLeaveEncashmentsForEmployee = (userId) => api(`/api/payroll/employees/${userId}/leave-encashment`);
export const requestLeaveEncashment = (userId, payload) =>
  api(`/api/payroll/employees/${userId}/leave-encashment`, { method: "POST", body: JSON.stringify(payload) });
export const getAllLeaveEncashments = (status) => api(`/api/payroll/leave-encashment${status ? `?status=${status}` : ""}`);
export const decideLeaveEncashment = (id, decision) =>
  api(`/api/payroll/leave-encashment/${id}/decide`, { method: "POST", body: JSON.stringify({ decision }) });

// ------------------------------------------------------------
// Payroll — gratuity & arrears
// ------------------------------------------------------------
export const getGratuityEstimate = (userId, financialYearId) =>
  api(`/api/payroll/employees/${userId}/gratuity${financialYearId ? `?financialYearId=${financialYearId}` : ""}`);
export const getArrearsForEmployee = (userId) => api(`/api/payroll/employees/${userId}/arrears`);

// ------------------------------------------------------------
// Payroll — reports: month-to-month comparison & variance
// ------------------------------------------------------------
export const getPayrollComparisonReport = (financialYearId, monthA, monthB) =>
  api(`/api/payroll/reports/comparison?financialYearId=${financialYearId}&monthA=${monthA}&monthB=${monthB}`);
export const getPayrollVarianceReport = (financialYearId, monthA, monthB, threshold) =>
  api(`/api/payroll/reports/variance?financialYearId=${financialYearId}&monthA=${monthA}&monthB=${monthB}${threshold != null ? `&threshold=${threshold}` : ""}`);

// ------------------------------------------------------------
// Attendance — Block 2
// ------------------------------------------------------------
export const getShifts = (all) => api(`/api/attendance/shifts${all ? "?all=true" : ""}`);
export const createShift = (payload) => api("/api/attendance/shifts", { method: "POST", body: JSON.stringify(payload) });
export const updateShift = (id, payload) => api(`/api/attendance/shifts/${id}`, { method: "PUT", body: JSON.stringify(payload) });
export const assignShift = (userId, shiftId, effectiveFrom) =>
  api(`/api/attendance/employees/${userId}/shift`, { method: "POST", body: JSON.stringify({ shiftId, effectiveFrom }) });
export const getShiftHistory = (userId) => api(`/api/attendance/employees/${userId}/shift-history`);

export const getWeeklyOffDays = () => api("/api/attendance/weekly-off");
export const setWeeklyOffDays = (days) => api("/api/attendance/weekly-off", { method: "PUT", body: JSON.stringify({ days }) });

export const checkIn = () => api("/api/attendance/check-in", { method: "POST", body: JSON.stringify({}) });
export const checkOut = () => api("/api/attendance/check-out", { method: "POST", body: JSON.stringify({}) });
export const getTodayAttendance = () => api("/api/attendance/today");

export const markAttendance = (userId, payload) =>
  api(`/api/attendance/employees/${userId}/mark`, { method: "POST", body: JSON.stringify(payload) });

export const getAttendanceCalendar = (userId, year, month) =>
  api(`/api/attendance/employees/${userId}/calendar?year=${year}&month=${month}`);
export const getAttendanceForDay = (date) => api(`/api/attendance/day/${date}`);
export const getTeamAttendance = (from, to) => api(`/api/attendance/team?from=${from}&to=${to}`);

export const requestAttendanceCorrection = (userId, payload) =>
  api(`/api/attendance/employees/${userId}/correction`, { method: "POST", body: JSON.stringify(payload) });
export const getAttendanceCorrectionsForEmployee = (userId) => api(`/api/attendance/employees/${userId}/corrections`);
export const getAllAttendanceCorrections = (status) => api(`/api/attendance/corrections${status ? `?status=${status}` : ""}`);
export const decideAttendanceCorrection = (id, decision) =>
  api(`/api/attendance/corrections/${id}/decide`, { method: "POST", body: JSON.stringify({ decision }) });

// ------------------------------------------------------------
// Compliance — Block 5
// ------------------------------------------------------------
export const getEmployerStatutoryInfo = () => api("/api/compliance/employer-info");
export const updateEmployerStatutoryInfo = (payload) => api("/api/compliance/employer-info", { method: "PUT", body: JSON.stringify(payload) });

export const getAnnualTaxStatement = (userId, financialYearId) =>
  api(`/api/compliance/employees/${userId}/annual-tax-statement${financialYearId ? `?financialYearId=${financialYearId}` : ""}`);
export const getForm16 = (userId, financialYearId) =>
  api(`/api/compliance/employees/${userId}/form16${financialYearId ? `?financialYearId=${financialYearId}` : ""}`);
export const getForm24Q = (financialYearId, quarter) =>
  api(`/api/compliance/form24q?financialYearId=${financialYearId}&quarter=${quarter}`);
export const getPfComplianceReport = (financialYearId, payrollMonth) =>
  api(`/api/compliance/pf-report?financialYearId=${financialYearId}&payrollMonth=${payrollMonth}`);
export const getEsiComplianceReport = (financialYearId, payrollMonth) =>
  api(`/api/compliance/esi-report?financialYearId=${financialYearId}&payrollMonth=${payrollMonth}`);
export const getPtComplianceReport = (financialYearId, payrollMonth) =>
  api(`/api/compliance/pt-report?financialYearId=${financialYearId}&payrollMonth=${payrollMonth}`);
export const getStatutoryWageRegister = (financialYearId, payrollMonth) =>
  api(`/api/compliance/wage-register?financialYearId=${financialYearId}&payrollMonth=${payrollMonth}`);

// ------------------------------------------------------------
// Full & Final Settlement — Block 6
// ------------------------------------------------------------
export const initiateSeparation = (payload) => api("/api/fnf/separations", { method: "POST", body: JSON.stringify(payload) });
export const getSeparations = (status) => api(`/api/fnf/separations${status ? `?status=${status}` : ""}`);
export const getSeparation = (id) => api(`/api/fnf/separations/${id}`);
export const decideSeparation = (id, decision) =>
  api(`/api/fnf/separations/${id}/decide`, { method: "POST", body: JSON.stringify({ decision }) });

export const generateFnfSettlement = (separationId, overrides) =>
  api(`/api/fnf/separations/${separationId}/settlement`, { method: "POST", body: JSON.stringify(overrides || {}) });
export const getFnfSettlements = (status) => api(`/api/fnf/settlements${status ? `?status=${status}` : ""}`);
export const getFnfSettlement = (id) => api(`/api/fnf/settlements/${id}`);
export const getFnfSettlementStatement = (id) => api(`/api/fnf/settlements/${id}/statement`);
export const submitFnfSettlement = (id) => api(`/api/fnf/settlements/${id}/submit`, { method: "POST" });
export const decideFnfSettlement = (id, decision) =>
  api(`/api/fnf/settlements/${id}/decide`, { method: "POST", body: JSON.stringify({ decision }) });
export const markFnfSettlementPaid = (id) => api(`/api/fnf/settlements/${id}/mark-paid`, { method: "POST" });

// ------------------------------------------------------------
// Advanced Leave Management — Block 3
// ------------------------------------------------------------
export const getLeavePolicies = (leaveTypeId) => api(`/api/leave/policies?leaveTypeId=${leaveTypeId}`);
export const createLeavePolicy = (payload) => api("/api/leave/policies", { method: "POST", body: JSON.stringify(payload) });
export const updateLeavePolicy = (id, payload) => api(`/api/leave/policies/${id}`, { method: "PUT", body: JSON.stringify(payload) });
export const deleteLeavePolicy = (id) => api(`/api/leave/policies/${id}`, { method: "DELETE" });
export const getEffectiveLeavePolicy = (userId, leaveTypeId) => api(`/api/leave/effective-policy?userId=${userId}&leaveTypeId=${leaveTypeId}`);

export const applyForLeaveAdvanced = (payload) => api("/api/leave/applications-advanced", { method: "POST", body: JSON.stringify(payload) });
export const decideLeaveApplicationAdvanced = (id, decision, comment) =>
  api(`/api/leave/applications/${id}/decide-advanced`, { method: "POST", body: JSON.stringify({ decision, comment }) });
export const getLeaveApprovals = (id) => api(`/api/leave/applications/${id}/approvals`);

export const requestCompOff = (payload) => api("/api/leave/comp-offs", { method: "POST", body: JSON.stringify(payload) });
export const getMyCompOffs = () => api("/api/leave/comp-offs");
export const getAllCompOffs = (status) => api(`/api/leave/comp-offs/all${status ? `?status=${status}` : ""}`);
export const decideCompOff = (id, decision, expiryMonths) =>
  api(`/api/leave/comp-offs/${id}/decide`, { method: "POST", body: JSON.stringify({ decision, expiryMonths }) });
export const redeemCompOff = (id, date) => api(`/api/leave/comp-offs/${id}/redeem`, { method: "POST", body: JSON.stringify({ date }) });

export const runLeaveAccrual = (year, month) => api("/api/leave/accrual/run", { method: "POST", body: JSON.stringify({ year, month }) });
export const runCarryForwardExpiry = () => api("/api/leave/carry-forward-expiry/run", { method: "POST" });

export const getLeaveCalendar = (from, to, scope) => api(`/api/leave/calendar?from=${from}&to=${to}${scope ? `&scope=${scope}` : ""}`);
export const getLeaveConflicts = (from, to) => api(`/api/leave/conflicts?from=${from}&to=${to}`);

// ------------------------------------------------------------
// Advanced Employee Lifecycle — Block 1
// ------------------------------------------------------------
export const getLifecycleProfile = (userId) => api(`/api/lifecycle/employees/${userId}/profile`);
export const transferDepartment = (userId, payload) => api(`/api/lifecycle/employees/${userId}/transfer-department`, { method: "POST", body: JSON.stringify(payload) });
export const changeDesignation = (userId, payload) => api(`/api/lifecycle/employees/${userId}/change-designation`, { method: "POST", body: JSON.stringify(payload) });
export const changeManager = (userId, payload) => api(`/api/lifecycle/employees/${userId}/change-manager`, { method: "POST", body: JSON.stringify(payload) });
export const changeLocation = (userId, payload) => api(`/api/lifecycle/employees/${userId}/change-location`, { method: "POST", body: JSON.stringify(payload) });
export const promoteEmployee = (userId, payload) => api(`/api/lifecycle/employees/${userId}/promote`, { method: "POST", body: JSON.stringify(payload) });

export const startProbation = (userId, payload) => api(`/api/lifecycle/employees/${userId}/probation/start`, { method: "POST", body: JSON.stringify(payload) });
export const confirmProbation = (id, notes) => api(`/api/lifecycle/probation/${id}/confirm`, { method: "POST", body: JSON.stringify({ notes }) });
export const extendProbation = (id, newEndDate, notes) => api(`/api/lifecycle/probation/${id}/extend`, { method: "POST", body: JSON.stringify({ newEndDate, notes }) });

export const getEmployeeDocuments = (userId) => api(`/api/lifecycle/employees/${userId}/documents`);
export const uploadEmployeeDocument = (userId, payload) => api(`/api/lifecycle/employees/${userId}/documents`, { method: "POST", body: JSON.stringify(payload) });
export const uploadEmployeeDocumentLocal = (userId, file, meta = {}) => api(`/api/lifecycle/employees/${userId}/documents/upload`, { method: "POST", headers: { "Content-Type": "application/octet-stream", "X-File-Name": file.name, "X-File-Mime": file.type || "application/octet-stream", "X-Doc-Type": meta.docType || "Document", "X-Issue-Date": meta.issueDate || "", "X-Expiry-Date": meta.expiryDate || "" }, body: file });
export const employeeDocumentOpenUrl = (id) => `/api/lifecycle/documents/${id}/open`;

export const getChecklistTemplates = (type) => api(`/api/lifecycle/checklist/templates${type ? `?type=${type}` : ""}`);
export const createChecklistTemplate = (payload) => api("/api/lifecycle/checklist/templates", { method: "POST", body: JSON.stringify(payload) });
export const updateChecklistTemplate = (id, payload) => api(`/api/lifecycle/checklist/templates/${id}`, { method: "PUT", body: JSON.stringify(payload) });
export const getEmployeeChecklist = (userId, type) => api(`/api/lifecycle/employees/${userId}/checklist${type ? `?type=${type}` : ""}`);
export const completeChecklistTask = (id, notes) => api(`/api/lifecycle/checklist/tasks/${id}/complete`, { method: "POST", body: JSON.stringify({ notes }) });

export const recordExitInterview = (separationId, payload) => api(`/api/fnf/separations/${separationId}/exit-interview`, { method: "POST", body: JSON.stringify(payload) });
export const getExitInterview = (separationId) => api(`/api/fnf/separations/${separationId}/exit-interview`);
export const getSeparationChecklist = (separationId) => api(`/api/fnf/separations/${separationId}/checklist`);

// ------------------------------------------------------------
// P0/P1 enterprise foundation
// ------------------------------------------------------------
export const getEnterpriseMe = () => api('/api/enterprise/me');
export const getEnterpriseRoles = () => api('/api/enterprise/roles');
export const saveEnterpriseRole = (payload) => api('/api/enterprise/roles', { method:'PUT', body:JSON.stringify(payload) });
export const getFeatureFlags = () => api('/api/enterprise/feature-flags');
export const setFeatureFlag = (key, enabled, config={}) => api(`/api/enterprise/feature-flags/${encodeURIComponent(key)}`, { method:'PUT', body:JSON.stringify({enabled,config}) });
export const getEnterpriseAudit = (entityType='', entityId='') => api(`/api/enterprise/audit?${entityType?`entityType=${encodeURIComponent(entityType)}&`:''}${entityId?`entityId=${encodeURIComponent(entityId)}`:''}`);
export const getSessions = () => api('/api/auth/sessions');
export const revokeSession = (token) => api(`/api/auth/sessions/${encodeURIComponent(token)}`, { method:'DELETE' });
export const logoutAll = () => api('/api/auth/logout-all', { method:'POST' });

// Documents
export const getDocumentTypes = () => api('/api/documents/types');
export const createDocumentType = (payload) => api('/api/documents/types', { method:'POST', body:JSON.stringify(payload) });
export const getDocuments = (params={}) => {
  const q = new URLSearchParams(params).toString();
  return api(`/api/documents${q?`?${q}`:''}`);
};
export const getDocument = (id) => api(`/api/documents/${id}`);
export const uploadDocument = async ({file, documentTypeId, module, resourceId, ownerUserId, expiresOn}) => {
  const qs = new URLSearchParams({ filename:file.name });
  if (documentTypeId) qs.set('documentTypeId', documentTypeId);
  if (module) qs.set('module', module);
  if (resourceId) qs.set('resourceId', resourceId);
  if (ownerUserId) qs.set('ownerUserId', ownerUserId);
  if (expiresOn) qs.set('expiresOn', expiresOn);
  const res = await fetch(`/api/documents/upload?${qs}`, { method:'POST', credentials:'include', headers:{'X-CSRF-Token':csrfToken,'Content-Type':'application/octet-stream','X-File-Mime':file.type||'application/octet-stream'}, body:file });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) { const e = new Error(data.error||'Document upload failed'); e.status=res.status; throw e; }
  return data;
};
export const downloadDocument = (id) => api(`/api/documents/${id}/download`);
export const verifyDocument = (id, status, reason) => api(`/api/documents/${id}/verify`, {method:'POST',body:JSON.stringify({status,reason})});
export const restoreDocumentVersion = (id, versionId, reason) => api(`/api/documents/${id}/restore/${versionId}`, {method:'POST',body:JSON.stringify({reason})});
export const linkDocument = (id, resourceType, resourceId) => api(`/api/documents/${id}/link`, {method:'POST',body:JSON.stringify({resourceType,resourceId})});
export const getExpiringDocuments = (daysAhead=30) => api(`/api/documents/expiring?daysAhead=${daysAhead}`);
export const getIntegrationConnectUrl = (provider) => api(`/api/integrations/${provider}/connect-url`);
export const importDocumentFromUrl = (payload) => api('/api/documents/import/url',{method:'POST',body:JSON.stringify(payload)});
export const listIntegrationFiles = (provider, params={}) => api(`/api/integrations/${provider}/files${Object.keys(params).length?`?${new URLSearchParams(params)}`:''}`);

export const getNotificationTemplates = () => api('/api/notification-templates');
export const saveNotificationTemplate = (payload) => api('/api/notification-templates',{method:'PUT',body:JSON.stringify(payload)});

// Workflow
export const getWorkflows = () => api('/api/workflows');
export const getWorkflow = (id) => api(`/api/workflows/${id}`);
export const createWorkflow = (payload) => api('/api/workflows',{method:'POST',body:JSON.stringify(payload)});
export const startWorkflow = (id,payload) => api(`/api/workflows/${id}/start`,{method:'POST',body:JSON.stringify(payload)});
export const getWorkflowInstances = (params={}) => api(`/api/workflow-instances${Object.keys(params).length?`?${new URLSearchParams(params)}`:''}`);
export const actWorkflow = (id,action,comment) => api(`/api/workflow-instances/${id}/action`,{method:'POST',body:JSON.stringify({action,comment})});

// Core HR
export const getOrganizations = () => api('/api/organizations');
export const saveOrganization = (payload) => api('/api/organizations',{method:'PUT',body:JSON.stringify(payload)});
export const getPositions = () => api('/api/positions');
export const savePosition = (payload) => api('/api/positions',{method:'PUT',body:JSON.stringify(payload)});
export const getEmployeeHistory = (id) => api(`/api/employees/${id}/history`);
export const addEmployeeHistory = (id,payload) => api(`/api/employees/${id}/history`,{method:'POST',body:JSON.stringify(payload)});
export const saveEmployeeOrgAssignment = (id,payload) => api(`/api/employees/${id}/org-assignment`,{method:'POST',body:JSON.stringify(payload)});
export const getOrgChart = () => api('/api/org-chart');

// Payroll controls / compliance
export const getPayrollControls = (runId) => api(`/api/payroll/runs/${runId}/controls`);
export const runPayrollPrechecks = (runId) => api(`/api/payroll/runs/${runId}/prechecks`,{method:'POST'});
export const savePayrollReconciliation = (runId,payload) => api(`/api/payroll/runs/${runId}/reconciliation`,{method:'POST',body:JSON.stringify(payload)});
export const getComplianceRules = (ruleType='') => api(`/api/compliance/rules${ruleType?`?ruleType=${encodeURIComponent(ruleType)}`:''}`);
export const saveComplianceRule = (payload) => api('/api/compliance/rules',{method:'POST',body:JSON.stringify(payload)});

// ------------------------------------------------------------
// P2 Talent / Employee Services
// ------------------------------------------------------------
export const getRecruitmentRequisitions = () => api('/api/recruitment/requisitions');
export const saveRecruitmentRequisition = (payload) => api('/api/recruitment/requisitions', {method:'PUT', body:JSON.stringify(payload)});
export const getCandidates = (filters={}) => api(`/api/recruitment/candidates?stage=${encodeURIComponent(filters.stage||'')}&search=${encodeURIComponent(filters.search||'')}`);
export const createCandidate = (payload) => api('/api/recruitment/candidates', {method:'POST',body:JSON.stringify(payload)});
export const moveCandidateStage = (id, stage, reason) => api(`/api/recruitment/candidates/${id}/stage`, {method:'POST',body:JSON.stringify({stage,reason})});
export const getInterviews = () => api('/api/recruitment/interviews');
export const scheduleInterview = (payload) => api('/api/recruitment/interviews',{method:'POST',body:JSON.stringify(payload)});
export const createOffer = (payload) => api('/api/recruitment/offers',{method:'POST',body:JSON.stringify(payload)});
export const getRecruitmentAnalytics = () => api('/api/recruitment/analytics');

export const getPerformanceCycles = () => api('/api/performance/cycles');
export const createPerformanceCycle = (payload) => api('/api/performance/cycles',{method:'POST',body:JSON.stringify(payload)});
export const getPerformanceGoals = (userId) => api(`/api/performance/goals${userId?`?userId=${userId}`:''}`);
export const savePerformanceGoal = (payload) => api('/api/performance/goals',{method:'POST',body:JSON.stringify(payload)});
export const getPerformanceReviews = (userId) => api(`/api/performance/reviews${userId?`?userId=${userId}`:''}`);
export const savePerformanceReview = (payload) => api('/api/performance/reviews',{method:'POST',body:JSON.stringify(payload)});
export const getPerformanceFeedback = (userId) => api(`/api/performance/feedback${userId?`?userId=${userId}`:''}`);
export const createPip = (payload) => api('/api/performance/pips',{method:'POST',body:JSON.stringify(payload)});

export const getLearningCourses = () => api('/api/learning/courses');
export const saveLearningCourse = (payload) => api('/api/learning/courses',{method:'POST',body:JSON.stringify(payload)});
export const getLearningEnrollments = (userId) => api(`/api/learning/enrollments${userId?`?userId=${userId}`:''}`);
export const enrollLearning = (courseId,userId) => api('/api/learning/enrollments',{method:'POST',body:JSON.stringify({courseId,userId})});
export const completeLearningEnrollment = (id,score) => api(`/api/learning/enrollments/${id}/complete`,{method:'POST',body:JSON.stringify({score})});
export const saveCertification = (payload) => api('/api/learning/certifications',{method:'POST',body:JSON.stringify(payload)});
export const saveSkill = (payload) => api('/api/learning/skills',{method:'POST',body:JSON.stringify(payload)});

export const getBenefitPlans = () => api('/api/benefits/plans');
export const saveBenefitPlan = (payload) => api('/api/benefits/plans',{method:'POST',body:JSON.stringify(payload)});
export const getMyBenefits = (userId) => api(`/api/benefits/me${userId?`?userId=${userId}`:''}`);
export const enrollBenefit = (planId,userId) => api('/api/benefits/enroll',{method:'POST',body:JSON.stringify({planId,userId})});
export const saveDependent = (payload) => api('/api/benefits/dependents',{method:'POST',body:JSON.stringify(payload)});

export const getExpenses = (filters={}) => api(`/api/expenses?status=${encodeURIComponent(filters.status||'')}&userId=${encodeURIComponent(filters.userId||'')}`);
export const createExpense = (payload) => api('/api/expenses',{method:'POST',body:JSON.stringify(payload)});
export const addExpenseLine = (id,payload) => api(`/api/expenses/${id}/lines`,{method:'POST',body:JSON.stringify(payload)});
export const getExpenseLines = (id) => api(`/api/expenses/${id}/lines`);
export const submitExpense = (id) => api(`/api/expenses/${id}/submit`,{method:'POST'});
export const decideExpense = (id,decision,comment) => api(`/api/expenses/${id}/decide`,{method:'POST',body:JSON.stringify({decision,comment})});
export const getExpenseApprovals = () => api('/api/approvals/expenses');
export const decideExpenseApproval = (id,decision,comment) => api(`/api/approvals/expenses/${id}/decide`,{method:'POST',body:JSON.stringify({decision,comment})});

export const getAssets = () => api('/api/assets');
export const saveAsset = (payload) => api('/api/assets',{method:'POST',body:JSON.stringify(payload)});
export const assignAsset = (id,payload) => api(`/api/assets/${id}/assign`,{method:'POST',body:JSON.stringify(payload)});
export const returnAsset = (id,payload) => api(`/api/assets/${id}/return`,{method:'POST',body:JSON.stringify(payload)});

export const getTickets = (filters={}) => api(`/api/helpdesk/tickets?status=${encodeURIComponent(filters.status||'')}&priority=${encodeURIComponent(filters.priority||'')}`);
export const createTicket = (payload) => api('/api/helpdesk/tickets',{method:'POST',body:JSON.stringify(payload)});
export const updateTicket = (id,payload) => api(`/api/helpdesk/tickets/${id}`,{method:'PATCH',body:JSON.stringify(payload)});
export const getTicketNotes = (id) => api(`/api/helpdesk/tickets/${id}/notes`);
export const addTicketNote = (id,note,internal=true) => api(`/api/helpdesk/tickets/${id}/notes`,{method:'POST',body:JSON.stringify({note,internal})});
export const getHrRequestApprovals = () => api('/api/approvals/hr-requests');
export const decideHrRequestApproval = (id,decision,comment) => api(`/api/approvals/hr-requests/${id}/decide`,{method:'POST',body:JSON.stringify({decision,comment})});

// ------------------------------------------------------------
// P3 Integrations / analytics / mobile
// ------------------------------------------------------------
export const getIntegrationHub = () => api('/api/integration-hub');
export const createSyncJob = (payload) => api('/api/integration-hub/sync-jobs',{method:'POST',body:JSON.stringify(payload)});
export const testIntegration = (provider) => api(`/api/integration-hub/test/${encodeURIComponent(provider)}`,{method:'POST'});
export const disconnectIntegration = (provider) => api(`/api/integration-hub/disconnect/${encodeURIComponent(provider)}`,{method:'POST'});
export const saveWebhook = (payload) => api('/api/integration-hub/webhooks',{method:'POST',body:JSON.stringify(payload)});
export const disableWebhook = (id) => api(`/api/integration-hub/webhooks/${id}/disable`,{method:'POST'});
export const getEnterpriseAnalytics = () => api('/api/analytics/enterprise');
export const getSavedReports = () => api('/api/analytics/reports/saved');
export const saveReportDefinition = (payload) => api('/api/analytics/reports/saved',{method:'POST',body:JSON.stringify(payload)});
export const getMobileHome = () => api('/api/mobile/home');

// ------------------------------------------------------------
// P4 AI intelligence
// ------------------------------------------------------------
export const askAiAssistant = (question) => api('/api/ai/assistant/query',{method:'POST',body:JSON.stringify({question})});
export const getAiHistory = () => api('/api/ai/assistant/history');
export const extractAiDocument = (documentId) => api(`/api/ai/documents/${documentId}/extract`,{method:'POST'});
export const getAiDocumentExtractions = (documentId) => api(`/api/ai/documents/extractions${documentId?`?documentId=${encodeURIComponent(documentId)}`:''}`);
export const confirmAiExtraction = (id,fields) => api(`/api/ai/documents/extractions/${id}/confirm`,{method:'POST',body:JSON.stringify({fields})});
export const scanPayrollAnomalies = (runId) => api(`/api/ai/payroll/runs/${runId}/scan`,{method:'POST'});
export const getPayrollAnomalies = (runId) => api(`/api/ai/payroll/runs/${runId}/anomalies`);
export const reviewPayrollAnomaly = (id,status,notes) => api(`/api/ai/payroll/anomalies/${id}/review`,{method:'POST',body:JSON.stringify({status,notes})});
export const updateInterview = (id,payload) => api(`/api/recruitment/interviews/${id}`,{method:'PATCH',body:JSON.stringify(payload)});
export const acceptOffer = (id) => api(`/api/recruitment/offers/${id}/accept`,{method:'POST'});
export const convertCandidateToEmployee = (id,payload={}) => api(`/api/recruitment/candidates/${id}/convert`,{method:'POST',body:JSON.stringify(payload)});
export const getPerformanceCalibrations = (cycleId) => api(`/api/performance/calibrations${cycleId?`?cycleId=${cycleId}`:''}`);
export const calibratePerformanceRating = (payload) => api('/api/performance/calibrations',{method:'POST',body:JSON.stringify(payload)});
export const getLearningCertifications = (userId) => api(`/api/learning/certifications${userId?`?userId=${userId}`:''}`);
export const getMyAssets = (userId) => api(`/api/assets/me${userId?`?userId=${userId}`:''}`);
export const executeSavedReport = (id) => api(`/api/analytics/reports/saved/${id}/execute`);
export const publishIntegrationEvent = (eventType,payload) => api(`/api/integration-hub/events/${encodeURIComponent(eventType)}/publish`,{method:'POST',body:JSON.stringify(payload)});
export const processWebhookDeliveries = () => api('/api/integration-hub/webhooks/process',{method:'POST'});
