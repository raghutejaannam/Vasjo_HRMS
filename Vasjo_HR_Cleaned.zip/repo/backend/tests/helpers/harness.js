'use strict';
// Drives the REAL route modules + middleware (auth stub, requirePermission,
// atomicRequest, errorHandler) against the SQLite-backed database, without
// opening a socket. Routes are matched in registration order exactly like
// Express, so route-shadowing bugs are caught.
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { installFakePrisma, resetDatabase } = require('./sqlite-prisma');

process.env.LOCAL_STORAGE_ROOT = process.env.LOCAL_STORAGE_ROOT || fs.mkdtempSync(path.join(os.tmpdir(), 'vasjo-test-storage-'));
process.env.NODE_ENV = 'test';
installFakePrisma();
resetDatabase();

const db = require('../../src/db');
const services = require('../../src/services');
const { errorHandler, notFoundHandler, atomicRequest } = require('../../src/http/error-handler');

function makeApp() {
  const routes = [];
  const app = { _routes: routes };
  for (const m of ['get', 'post', 'put', 'patch', 'delete']) {
    app[m] = (p, ...handlers) => {
      const keys = []; const re = new RegExp('^' + p.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
      routes.push({ method: m.toUpperCase(), path: p, re, keys, handlers });
      return app;
    };
  }
  return app;
}

class FakeRes {
  constructor() { this.statusCode = 200; this.headers = {}; this.body = undefined; this._listeners = {}; this.finished = false; }
  status(c) { this.statusCode = c; return this; }
  setHeader(k, v) { this.headers[k.toLowerCase()] = v; }
  removeHeader(k) { delete this.headers[k.toLowerCase()]; }
  json(o) { this.setHeader('content-type', 'application/json'); return this.end(JSON.stringify(o)); }
  send(b) { return this.end(b); }
  once(ev, fn) { (this._listeners[ev] = this._listeners[ev] || []).push(fn); }
  end(b) { this.finished = true; this.body = b; (this._listeners.finish || []).forEach((f) => f()); return this; }
}

const requireAuth = (req, res, next) => (req.session && req.session.user ? next() : res.status(401).json({ error: 'Not signed in', code: 'UNAUTHENTICATED' }));

// user = enriched user row (see loadUser) or null for anonymous
async function call(app, method, url, { user = null, body, headers = {} } = {}) {
  const [pathname, qs] = url.split('?');
  const query = Object.fromEntries(new URLSearchParams(qs || ''));
  const route = app._routes.find((r) => r.method === method && r.re.test(pathname));
  const req = { method, url, originalUrl: url, query, body, headers, session: user ? { user } : {}, params: {}, requestId: 'test' };
  const res = new FakeRes();
  if (route) { const m = pathname.match(route.re); route.keys.forEach((k, i) => { req.params[k] = decodeURIComponent(m[i + 1]); }); }
  return new Promise((resolve) => {
    const finish = () => {
      let parsed = res.body;
      if (res.headers['content-type'] === 'application/json') { try { parsed = JSON.parse(res.body); } catch (e) { /* keep raw */ } }
      resolve({ status: res.statusCode, body: parsed, headers: res.headers, res });
    };
    res.once('finish', finish);
    const chain = route ? route.handlers : [notFoundHandler];
    const run = (i, err) => {
      if (err) return errorHandler(err, req, res, () => {});
      const h = chain[i]; if (!h) return notFoundHandler(req, res);
      try { h(req, res, (e) => run(i + 1, e)); } catch (e) { errorHandler(e, req, res, () => {}); }
    };
    const start = () => run(0);
    if (user) atomicRequest(db)(req, res, start); else start();
  });
}

// ---- fixtures ------------------------------------------------------------------
async function seed() {
  resetDatabase();
  const conn = require('./sqlite-prisma');
  await db.dbRun("INSERT INTO tenants(id,name,slug,status) VALUES(1,'Acme','acme','active')");
  await db.dbRun("INSERT INTO tenants(id,name,slug,status) VALUES(2,'Other Co','other','active')");
  await db.dbRun("INSERT INTO leave_types(tenant_id,name,default_annual_days,max_carry_forward_days,active) VALUES(1,'Casual',12,0,1)");
  await services.enterprise.ensureBuiltInRoles(1);
  await services.enterprise.ensureBuiltInRoles(2);
  const mk = async (name, email, role, extra = {}) => db.createUser({ name, email, role, tenantId: 1, joinedDate: '2024-01-15', ...extra });
  const ids = {};
  ids.admin = await mk('Ada Admin', 'admin@t.test', 'admin');
  ids.mgr = await mk('Mona Manager', 'mgr@t.test', 'manager', { dept: 'Engineering' });
  ids.mgr2 = await mk('Max Manager', 'mgr2@t.test', 'manager', { dept: 'Sales' });
  ids.emp = await mk('Eve Employee', 'emp@t.test', 'employee', { dept: 'Engineering', managerId: ids.mgr });
  ids.emp2 = await mk('Ed Employee', 'emp2@t.test', 'employee', { dept: 'Sales', managerId: ids.mgr2 });
  ids.orphan = await mk('Olga Orphan', 'orphan@t.test', 'employee', { dept: 'Engineering' }); // no manager
  ids.other = await db.createUser({ name: 'Tess Tenant2', email: 'x@other.test', role: 'admin', tenantId: 2, joinedDate: '2024-01-15' });
  return ids;
}
async function loadUser(id) {
  const u = await db.dbGet('SELECT * FROM users WHERE id=?', [id]);
  return services.auth.enrichEnterpriseIdentity({ ...u });
}

module.exports = { db, services, makeApp, requireAuth, call, seed, loadUser };
