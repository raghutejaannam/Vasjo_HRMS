'use strict';
// Test infrastructure: runs the REAL service SQL against an in-memory SQLite
// database whose schema is generated from prisma/schema.prisma, by standing in
// for @prisma/client. It catches wrong columns/tables, parameter-count
// mistakes, workflow/authorization logic errors and response shapes.
// It CANNOT catch PostgreSQL-only behaviour (uuid/boolean typing, RLS,
// planner differences) - see docs/PHASE1_REPORT.md for that residual risk.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = path.join(__dirname, '../../prisma/schema.prisma');

function parseSchema(text) {
  const modelNames = new Set([...text.matchAll(/^model (\w+)/gm)].map((m) => m[1]));
  const tables = []; let cur = null;
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\/\/.*$/, '');
    const m = line.match(/^model (\w+)/); if (m) { cur = { cols: [], table: null, uniques: [], pk: null }; continue; }
    if (!cur) continue;
    if (line.startsWith('}')) { if (cur.table) tables.push(cur); cur = null; continue; }
    const mp = line.match(/@@map\("(\w+)"\)/); if (mp) { cur.table = mp[1]; continue; }
    const mu = line.match(/@@unique\(\[([^\]]+)\]/); if (mu) { cur.uniques.push(mu[1].split(',').map((x) => x.trim())); continue; }
    const mi = line.match(/@@id\(\[([^\]]+)\]/); if (mi) { cur.pk = mi[1].split(',').map((x) => x.trim()); continue; }
    if (line.trim().startsWith('@@')) continue;
    const f = line.match(/^\s+(\w+)\s+([A-Za-z]+)(\?)?(\[\])?\s*(.*)$/);
    if (!f || modelNames.has(f[2]) || f[4] || /@relation/.test(line)) continue;
    const map = line.match(/@map\("(\w+)"\)/);
    cur.cols.push({ field: f[1], name: map ? map[1] : f[1], type: f[2], nullable: !!f[3], rest: f[5], isId: /@id\b/.test(line), unique: /@unique\b/.test(line) });
  }
  return tables;
}
function ddl(tables) {
  const out = [];
  for (const t of tables) {
    const defs = []; const compositePk = t.pk && t.pk.length;
    const nameOf = (field) => (t.cols.find((c) => c.field === field) || { name: field }).name;
    for (const c of t.cols) {
      const auto = /@default\(autoincrement\(\)\)/.test(c.rest);
      let sqlType = ({ Int: 'INTEGER', BigInt: 'INTEGER', Float: 'REAL', Decimal: 'NUMERIC', Boolean: 'INTEGER', String: 'TEXT', DateTime: 'TEXT', Json: 'TEXT' })[c.type] || 'TEXT';
      let def = `"${c.name}" ${sqlType}`;
      if (c.isId && !compositePk) def += auto ? ' PRIMARY KEY AUTOINCREMENT' : ' PRIMARY KEY';
      const d = c.rest.match(/@default\(([^)]*(?:\([^)]*\))?[^)]*)\)/);
      if (d && !auto) {
        const v = d[1].trim();
        if (v === 'false') def += ' DEFAULT 0'; else if (v === 'true') def += ' DEFAULT 1';
        else if (/^-?\d+(\.\d+)?$/.test(v)) def += ` DEFAULT ${v}`;
        else if (/^"[^"]*"$/.test(v)) def += ` DEFAULT '${v.slice(1, -1)}'`;
      }
      if (c.unique) def += ' UNIQUE';
      defs.push(def);
    }
    if (compositePk) defs.push(`PRIMARY KEY (${t.pk.map((f) => `"${nameOf(f)}"`).join(',')})`);
    for (const u of t.uniques) defs.push(`UNIQUE (${u.map((f) => `"${nameOf(f)}"`).join(',')})`);
    out.push(`CREATE TABLE "${t.table}" (${defs.join(', ')})`);
  }
  return out;
}

// Postgres -> SQLite dialect for the subset of SQL the services use.
function translate(sql) {
  return sql.replace(/::[a-zA-Z_]+(\[\])?/g, '').replace(/\bILIKE\b/gi, 'LIKE');
}
function bindValue(v) {
  if (v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v instanceof Date) return v.toISOString();
  if (typeof v === 'bigint') return Number(v);
  return v;
}

class FakePrismaClient {
  constructor() {
    this.db = FakePrismaClient.shared;
    this.$transaction = async (fn) => {
      this.db.exec('BEGIN');
      try { const r = await fn(this); this.db.exec('COMMIT'); return r; }
      catch (e) { this.db.exec('ROLLBACK'); throw e; }
    };
  }
  _sql(q, values) {
    if (Array.isArray(q)) return { text: q.reduce((a, s, i) => a + s + (i < values.length ? '?' : ''), ''), values };
    return { text: q.strings.reduce((a, s, i) => a + s + (i < q.values.length ? '?' : ''), ''), values: q.values };
  }
  async $queryRaw(q, ...v) {
    const { text, values } = this._sql(q, v);
    if (/set_config/i.test(text)) return [];
    return this.db.prepare(translate(text)).all(...values.map(bindValue)).map((r) => ({ ...r }));
  }
  async $executeRaw(q, ...v) {
    const { text, values } = this._sql(q, v);
    if (/set_config/i.test(text)) return 0;
    return Number(this.db.prepare(translate(text)).run(...values.map(bindValue)).changes);
  }
}
const FakePrisma = { sql: (strings, ...values) => ({ strings: [...strings], values }) };

let installed = false;
function installFakePrisma() {
  if (installed) return;
  installed = true;
  const orig = Module._load;
  Module._load = function (request, ...rest) {
    if (request === '@prisma/client') return { PrismaClient: FakePrismaClient, Prisma: FakePrisma };
    if (request === 'dotenv') return { config() {} };
    return orig.call(this, request, ...rest);
  };
}
function resetDatabase() {
  const conn = new DatabaseSync(':memory:');
  FakePrismaClient.shared = conn;
  for (const stmt of ddl(parseSchema(fs.readFileSync(SCHEMA, 'utf8')))) conn.exec(stmt);
  return conn;
}

module.exports = { installFakePrisma, resetDatabase, parseSchema, ddl, translate };
