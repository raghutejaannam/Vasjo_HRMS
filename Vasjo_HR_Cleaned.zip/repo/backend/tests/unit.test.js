// Consolidated offline domain unit tests.
// Each original test module is scoped independently so its mocks and helper
// declarations cannot collide while all test cases remain registered.

// ---------------------------------------------------------------------------
// Consolidated from attendance_block2_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/attendance_block2_unit.test.js
//
// Offline unit tests for Block 2 (Attendance Management): shift-aware
// check-in/check-out math, manual marking, correction/regularization
// requests, the monthly calendar builder, and computeAttendanceSummaryForPayroll
// (the function payroll.js's getAttendanceForPayroll now consults first).
//
// Same approach as tests/payroll_block4_unit.test.js: no real database or
// network — db.js functions are monkey-patched per test.
//
// Run with:  node --test tests/unit.test.js

const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const attendance = require('../src/services').attendance;

let patched = [];
function mock(name, fn) {
  patched.push([name, db[name]]);
  db[name] = fn;
}
afterEach(() => {
  for (const [name, original] of patched) db[name] = original;
  patched = [];
});

const SHIFT_9_TO_6 = {
  id: 1, code: 'GEN', start_time: '09:00', end_time: '18:00',
  grace_period_minutes: 10, break_minutes: 60, full_day_min_minutes: 480, half_day_min_minutes: 240,
};

// ---------------------------------------------------------------------------
// Check-in
// ---------------------------------------------------------------------------

test('checkIn records no late minutes when within the grace period', async () => {
  mock('getAttendanceRecord', async () => null);
  mock('getShiftForUserOnDate', async () => SHIFT_9_TO_6);
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });

  const result = await attendance.checkIn(1, '2026-06-01 09:08:00');
  assert.equal(result.lateMinutes, 0); // within 10-minute grace
  assert.equal(saved.status, 'present');
});

test('checkIn records late minutes beyond the shift start + grace period', async () => {
  mock('getAttendanceRecord', async () => null);
  mock('getShiftForUserOnDate', async () => SHIFT_9_TO_6);
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });

  const result = await attendance.checkIn(1, '2026-06-01 09:25:00');
  assert.equal(result.lateMinutes, 15); // 25 min late - 10 min grace
  assert.equal(saved.lateMinutes, 15);
});

test('checkIn refuses a second check-in on the same day', async () => {
  mock('getAttendanceRecord', async () => ({ check_in_at: '2026-06-01 09:00:00' }));
  await assert.rejects(() => attendance.checkIn(1, '2026-06-01 09:30:00'), /Already checked in/);
});

// ---------------------------------------------------------------------------
// Check-out
// ---------------------------------------------------------------------------

test('checkOut computes worked minutes net of the shift break and marks present for a full day', async () => {
  mock('getAttendanceRecord', async () => ({ check_in_at: '2026-06-01 09:00:00', check_out_at: null, shift_id: 1, late_minutes: 0 }));
  mock('getShift', async () => SHIFT_9_TO_6);
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });

  const result = await attendance.checkOut(1, '2026-06-01 18:30:00'); // 9.5h gross - 1h break = 8.5h = 510 min
  assert.equal(result.workedMinutes, 510);
  assert.equal(result.status, 'present');
  assert.equal(saved.status, 'present');
});

test('checkOut marks half_day when worked minutes fall between half-day and full-day thresholds', async () => {
  mock('getAttendanceRecord', async () => ({ check_in_at: '2026-06-01 09:00:00', check_out_at: null, shift_id: 1, late_minutes: 0 }));
  mock('getShift', async () => SHIFT_9_TO_6);
  mock('upsertAttendanceRecord', async () => {});

  // 09:00 -> 14:00 = 5h gross - 1h break = 4h = 240 min = exactly half-day threshold... use 14:30 for clearly half-day
  const result = await attendance.checkOut(1, '2026-06-01 14:30:00'); // 5.5h - 1h = 4.5h = 270 min
  assert.equal(result.status, 'half_day');
});

test('checkOut marks absent when worked minutes are below the half-day threshold', async () => {
  mock('getAttendanceRecord', async () => ({ check_in_at: '2026-06-01 09:00:00', check_out_at: null, shift_id: 1, late_minutes: 0 }));
  mock('getShift', async () => SHIFT_9_TO_6);
  mock('upsertAttendanceRecord', async () => {});

  const result = await attendance.checkOut(1, '2026-06-01 10:30:00'); // 1.5h gross, break not even fully taken
  assert.equal(result.status, 'absent');
});

test('checkOut refuses without a prior check-in, and refuses a second check-out', async () => {
  mock('getAttendanceRecord', async () => null);
  await assert.rejects(() => attendance.checkOut(1, '2026-06-01 18:00:00'), /No check-in found/);

  mock('getAttendanceRecord', async () => ({ check_in_at: '2026-06-01 09:00:00', check_out_at: '2026-06-01 18:00:00' }));
  await assert.rejects(() => attendance.checkOut(1, '2026-06-01 18:05:00'), /Already checked out/);
});

// ---------------------------------------------------------------------------
// Manual marking
// ---------------------------------------------------------------------------

test('markAttendance rejects an unknown status', async () => {
  await assert.rejects(() => attendance.markAttendance({ userId: 1, date: '2026-06-01', status: 'on_vacation', actorId: 9 }), /status must be one of/);
});

test('markAttendance accepts wfh and stores it with source=manual', async () => {
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });
  mock('getAttendanceRecord', async () => ({ status: 'wfh' }));
  await attendance.markAttendance({ userId: 1, date: '2026-06-01', status: 'wfh', actorId: 9, notes: 'Approved WFH' });
  assert.equal(saved.status, 'wfh');
  assert.equal(saved.source, 'manual');
  assert.equal(saved.markedBy, 9);
});

// ---------------------------------------------------------------------------
// Correction / regularization requests
// ---------------------------------------------------------------------------

test('requestCorrection requires a reason and at least one requested field', async () => {
  await assert.rejects(
    () => attendance.requestCorrection({ userId: 1, date: '2026-06-01', reason: '' }),
    /reason is required/
  );
  await assert.rejects(
    () => attendance.requestCorrection({ userId: 1, date: '2026-06-01', reason: 'Forgot to check out' }),
    /Provide a requested/
  );
});

test('decideCorrection refuses to re-decide an already-decided request', async () => {
  mock('getAttendanceCorrectionRequest', async () => ({ id: 1, status: 'approved' }));
  await assert.rejects(() => attendance.decideCorrection(1, 'approved', 9), /already been decided/);
});

test('decideCorrection with a requested status marks attendance directly', async () => {
  mock('getAttendanceCorrectionRequest', async () => ({
    id: 1, status: 'pending', user_id: 1, date: '2026-06-01', requested_status: 'wfh', reason: 'Worked from home',
  }));
  mock('decideAttendanceCorrectionRequest', async () => {});
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });
  await attendance.decideCorrection(1, 'approved', 9);
  assert.equal(saved.status, 'wfh');
  assert.equal(saved.source, 'manual'); // markAttendance always writes source: 'manual'
});

test('decideCorrection with requested check-in/out recomputes worked minutes and status', async () => {
  mock('getAttendanceCorrectionRequest', async () => ({
    id: 2, status: 'pending', user_id: 1, date: '2026-06-01',
    requested_check_in_at: '2026-06-01 09:00:00', requested_check_out_at: '2026-06-01 18:00:00',
    requested_status: null, reason: 'Forgot to check out, worked full day',
  }));
  mock('decideAttendanceCorrectionRequest', async () => {});
  mock('getAttendanceRecord', async () => ({ shift_id: 1, status: 'absent', worked_minutes: 0, late_minutes: 0, early_leave_minutes: 0 }));
  mock('getShift', async () => SHIFT_9_TO_6);
  let saved;
  mock('upsertAttendanceRecord', async (data) => { saved = data; });

  await attendance.decideCorrection(2, 'approved', 9);
  assert.equal(saved.workedMinutes, 480); // 9h gross - 1h break = 8h = 480 min
  assert.equal(saved.status, 'present');
  assert.equal(saved.source, 'regularization');
});

// ---------------------------------------------------------------------------
// Monthly calendar
// ---------------------------------------------------------------------------

test('getMonthlyCalendar classifies holidays, weekly-offs, recorded days and past-with-no-record as absent', async () => {
  mock('getHolidaysInRange', async () => [{ holiday_date: '2026-06-15' }]);
  mock('getWeeklyOffDays', async () => [0, 6]); // Sun, Sat
  mock('listAttendanceRecordsForUserInRange', async () => [
    { date: '2026-06-02', status: 'present', check_in_at: '2026-06-02 09:00:00', check_out_at: '2026-06-02 18:00:00', worked_minutes: 480, late_minutes: 0, early_leave_minutes: 0 },
  ]);

  const cal = await attendance.getMonthlyCalendar(1, 2026, 6);
  const byDate = Object.fromEntries(cal.days.map(d => [d.date, d]));
  assert.equal(byDate['2026-06-15'].status, 'holiday');
  assert.equal(byDate['2026-06-02'].status, 'present');
  // 2026-06-06 is a Saturday
  assert.equal(byDate['2026-06-06'].status, 'weekly_off');
  assert.equal(cal.days.length, 30);
});

// ---------------------------------------------------------------------------
// Payroll integration
// ---------------------------------------------------------------------------

test('computeAttendanceSummaryForPayroll returns null when the employee has no attendance records that month', async () => {
  mock('listAttendanceRecordsForUserInRange', async () => []);
  const result = await attendance.computeAttendanceSummaryForPayroll(1, 2026, 6);
  assert.equal(result, null);
});

test('computeAttendanceSummaryForPayroll: present/wfh/on_duty/leave count full, half_day counts half, absent counts zero', async () => {
  mock('getHolidaysInRange', async () => []);
  mock('getWeeklyOffDays', async () => [0, 6]);
  // June 2026: 1st is a Monday. Give it a small, fully-specified working set.
  mock('listAttendanceRecordsForUserInRange', async () => [
    { date: '2026-06-01', status: 'present' },
    { date: '2026-06-02', status: 'half_day' },
    { date: '2026-06-03', status: 'wfh' },
    { date: '2026-06-04', status: 'absent' },
    { date: '2026-06-05', status: 'on_duty' },
    // 2026-06-08 (a working day) has no record at all -> LOP
  ]);
  const result = await attendance.computeAttendanceSummaryForPayroll(1, 2026, 6);
  assert.ok(result.workingDays >= 5);
  assert.equal(result.paidDays, 1 + 0.5 + 1 + 0 + 1); // 3.5
  assert.equal(result.lopDays, result.workingDays - 3.5);
});
}

// ---------------------------------------------------------------------------
// Consolidated from compliance_block5_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/compliance_block5_unit.test.js
//
// Offline unit tests for Block 5 (Tax & Compliance): quarter-month mapping,
// annual tax statement reconciliation, Form 16/24Q data shaping, and the
// PF/ESI/PT/statutory wage register compliance reports.
//
// Run with:  node --test tests/unit.test.js

const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const services = require('../src/services');
const payroll = services.payroll;
const compliance = services.compliance;

let patched = [];
function mockDb(name, fn) { patched.push([db, name, db[name]]); db[name] = fn; }
function mockPayroll(name, fn) { patched.push([payroll, name, payroll[name]]); payroll[name] = fn; }
afterEach(() => {
  for (const [obj, name, original] of patched) obj[name] = original;
  patched = [];
});

// ---------------------------------------------------------------------------
// Quarter mapping
// ---------------------------------------------------------------------------

test('quarterMonths maps Indian FY quarters correctly, including the year rollover for Q4', () => {
  const fy = { start_date: '2026-04-01' };
  assert.deepEqual(compliance.quarterMonths(fy, 'Q1'), ['2026-04', '2026-05', '2026-06']);
  assert.deepEqual(compliance.quarterMonths(fy, 'Q2'), ['2026-07', '2026-08', '2026-09']);
  assert.deepEqual(compliance.quarterMonths(fy, 'Q3'), ['2026-10', '2026-11', '2026-12']);
  assert.deepEqual(compliance.quarterMonths(fy, 'Q4'), ['2027-01', '2027-02', '2027-03']);
});

test('quarterMonths rejects an invalid quarter', () => {
  assert.throws(() => compliance.quarterMonths({ start_date: '2026-04-01' }, 'Q5'), /quarter must be one of/);
});

// ---------------------------------------------------------------------------
// Employer statutory info
// ---------------------------------------------------------------------------

test('getEmployerStatutoryInfo falls back to defaults for unset settings', async () => {
  mockDb('getSettings', async () => ({ company_name: 'Acme Corp' }));
  const info = await compliance.getEmployerStatutoryInfo();
  assert.equal(info.company_name, 'Acme Corp');
  assert.equal(info.company_pan, 'Not configured');
});

// ---------------------------------------------------------------------------
// Annual tax statement
// ---------------------------------------------------------------------------

test('getAnnualTaxStatement reconciles computed tax against actual TDS deducted (current + previous employer)', async () => {
  mockDb('getFinancialYear', async () => ({ id: 1, name: 'FY 2026-27', start_date: '2026-04-01', end_date: '2027-03-31' }));
  mockDb('getPayrollDetailsForUserInFinancialYear', async () => ([
    { payroll_month: '2026-04', gross_earning: 100000, basic_earning: 40000, pf_employee_deduction: 4800, professional_tax_deduction: 200, tds_deduction: 8000, net_salary: 87000 },
    { payroll_month: '2026-05', gross_earning: 100000, basic_earning: 40000, pf_employee_deduction: 4800, professional_tax_deduction: 200, tds_deduction: 8000, net_salary: 87000 },
  ]));
  mockDb('getPreviousEmployerIncome', async () => ({ previous_employer_name: 'OldCo', gross_income: 200000, tds_deducted: 15000, professional_tax_paid: 400 }));
  mockDb('getEmployeeTaxRegime', async () => null);
  mockDb('getDefaultTaxRegime', async () => ({ id: 5, code: 'new', name: 'New Tax Regime' }));
  mockPayroll('getApprovedTaxDeductions', async () => 0);
  mockPayroll('calculateTaxLiability', async (regimeId, gross) => ({ taxableIncome: gross - 75000, annualTax: 40000 }));

  const statement = await compliance.getAnnualTaxStatement(1, 1);
  assert.equal(statement.totalAnnualGross, 400000); // 200000 current + 200000 previous
  assert.equal(statement.totalTdsDeducted, 31000); // 16000 current + 15000 previous
  assert.equal(statement.annualTaxComputed, 40000);
  assert.equal(statement.balance, 9000); // 40000 - 31000
  assert.equal(statement.balanceType, 'additional_tax_due');
});

test('getAnnualTaxStatement reports refund_due when TDS deducted exceeds computed liability', async () => {
  mockDb('getFinancialYear', async () => ({ id: 1, name: 'FY 2026-27', start_date: '2026-04-01', end_date: '2027-03-31' }));
  mockDb('getPayrollDetailsForUserInFinancialYear', async () => ([
    { payroll_month: '2026-04', gross_earning: 100000, tds_deduction: 30000, pf_employee_deduction: 0, professional_tax_deduction: 0, basic_earning: 0, net_salary: 0 },
  ]));
  mockDb('getPreviousEmployerIncome', async () => null);
  mockDb('getEmployeeTaxRegime', async () => ({ tax_regime_id: 5 }));
  mockDb('getTaxRegime', async () => ({ id: 5, code: 'old', name: 'Old Tax Regime' }));
  mockPayroll('getApprovedTaxDeductions', async () => 0);
  mockPayroll('calculateTaxLiability', async () => ({ taxableIncome: 20000, annualTax: 20000 }));

  const statement = await compliance.getAnnualTaxStatement(1, 1);
  assert.equal(statement.balance, -10000);
  assert.equal(statement.balanceType, 'refund_due');
});

// ---------------------------------------------------------------------------
// Form 24Q
// ---------------------------------------------------------------------------

test('getForm24QData aggregates gross paid and TDS per employee across the quarter', async () => {
  mockDb('getFinancialYear', async () => ({ id: 1, start_date: '2026-04-01' }));
  mockDb('getPayrollDetailsForMonths', async () => ([
    { user_id: 1, user_name: 'Asha', pan: 'ABCDE1234F', employee_code: 'E1', payroll_month: '2026-04', gross_earning: 100000, tds_deduction: 8000 },
    { user_id: 1, user_name: 'Asha', pan: 'ABCDE1234F', employee_code: 'E1', payroll_month: '2026-05', gross_earning: 100000, tds_deduction: 8000 },
    { user_id: 2, user_name: 'Ravi', pan: 'FGHIJ5678K', employee_code: 'E2', payroll_month: '2026-04', gross_earning: 80000, tds_deduction: 3000 },
  ]));
  mockDb('getSettings', async () => ({}));

  const data = await compliance.getForm24QData(1, 'Q1');
  assert.equal(data.deducteeCount, 2);
  const asha = data.deductees.find(d => d.userId === 1);
  assert.equal(asha.totalGrossPaid, 200000);
  assert.equal(asha.totalTdsDeducted, 16000);
  assert.equal(data.totalTdsDeducted, 19000);
});

// ---------------------------------------------------------------------------
// PF compliance report
// ---------------------------------------------------------------------------

test('getPfComplianceReport caps PF wage at the statutory ceiling and splits employer contribution into EPS/EPF', async () => {
  mockDb('getPayrollDetailsForMonths', async () => ([
    { employee_code: 'E1', user_name: 'Asha', uan: '1234', pf_number: 'PF1', basic_earning: 40000, pf_employee_deduction: 1800 },
  ]));
  mockDb('getSettings', async () => ({}));

  const report = await compliance.getPfComplianceReport(1, '2026-04');
  const emp = report.employees[0];
  assert.equal(emp.pfWage, 15000); // capped, even though basic is 40000
  assert.equal(emp.employerPfTotal, 1800); // 15000 * 0.12
  assert.equal(emp.employerEps, Math.round(15000 * 0.0833 * 100) / 100);
  assert.equal(Math.round((emp.employerEps + emp.employerEpf) * 100) / 100, emp.employerPfTotal);
});

// ---------------------------------------------------------------------------
// ESI compliance report
// ---------------------------------------------------------------------------

test('getEsiComplianceReport only computes contributions for employees under the wage ceiling', async () => {
  mockDb('getPayrollDetailsForMonths', async () => ([
    { employee_code: 'E1', user_name: 'Asha', esi_number: null, gross_earning: 18000 },
    { employee_code: 'E2', user_name: 'Ravi', esi_number: 'ESI2', gross_earning: 45000 },
  ]));
  mockDb('getSettings', async () => ({}));

  const report = await compliance.getEsiComplianceReport(1, '2026-04');
  const asha = report.employees.find(e => e.employeeCode === 'E1');
  const ravi = report.employees.find(e => e.employeeCode === 'E2');
  assert.equal(asha.eligible, true);
  assert.equal(asha.employeeEsi, Math.round(18000 * 0.0075 * 100) / 100);
  assert.equal(ravi.eligible, false);
  assert.equal(ravi.employeeEsi, 0);
  assert.equal(report.advisory, true);
});

// ---------------------------------------------------------------------------
// Statutory wage register
// ---------------------------------------------------------------------------

test('getStatutoryWageRegister returns one sorted row per employee with the compliance-relevant fields', async () => {
  mockDb('getPayrollDetailsForMonths', async () => ([
    { employee_code: 'E2', user_name: 'Ravi', title: 'Engineer', dept: 'Eng', uan: null, pan: 'X', working_days: 22, paid_days: 22, lop_days: 0, basic_earning: 30000, gross_earning: 60000, pf_employee_deduction: 1800, professional_tax_deduction: 200, tds_deduction: 1000, net_salary: 57000 },
    { employee_code: 'E1', user_name: 'Asha', title: 'Manager', dept: 'Eng', uan: '1', pan: 'Y', working_days: 22, paid_days: 21, lop_days: 1, basic_earning: 50000, gross_earning: 100000, pf_employee_deduction: 1800, professional_tax_deduction: 200, tds_deduction: 8000, net_salary: 90000 },
  ]));
  const register = await compliance.getStatutoryWageRegister(1, '2026-04');
  assert.equal(register.employeeCount, 2);
  assert.equal(register.employees[0].name, 'Asha'); // sorted alphabetically
  assert.equal(register.employees[1].name, 'Ravi');
});
}

// ---------------------------------------------------------------------------
// Consolidated from fnf_block6_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/fnf_block6_unit.test.js
//
// Offline unit tests for Block 6 (Full & Final Settlement): separation
// validation, settlement generation (notice recovery, unpaid salary, leave
// encashment, gratuity, loan/advance recovery), and the approval/payout
// workflow's state-machine guards.
//
// Run with:  node --test tests/unit.test.js

const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const services = require('../src/services');
const payroll = services.payroll;
const fnf = services.fnf;

let patched = [];
function mockDb(name, fn) { patched.push([db, name, db[name]]); db[name] = fn; }
function mockPayroll(name, fn) { patched.push([payroll, name, payroll[name]]); payroll[name] = fn; }
afterEach(() => {
  for (const [obj, name, original] of patched) obj[name] = original;
  patched = [];
});

// ---------------------------------------------------------------------------
// Separation initiation
// ---------------------------------------------------------------------------

test('initiateSeparation rejects a last working date before the resignation date', async () => {
  mockDb('getActiveSeparationForUser', async () => null);
  await assert.rejects(
    () => fnf.initiateSeparation({ userId: 1, resignationDate: '2026-06-10', lastWorkingDate: '2026-06-01', noticePeriodRequiredDays: 30, initiatedBy: 9 }),
    /cannot be before/
  );
});

test('initiateSeparation refuses a second active separation for the same employee', async () => {
  mockDb('getActiveSeparationForUser', async () => ({ id: 1, status: 'pending' }));
  await assert.rejects(
    () => fnf.initiateSeparation({ userId: 1, resignationDate: '2026-06-01', lastWorkingDate: '2026-07-01', noticePeriodRequiredDays: 30, initiatedBy: 9 }),
    /already has an active resignation/
  );
});

test('decideSeparationRequest refuses to re-decide', async () => {
  mockDb('getSeparation', async () => ({ id: 1, status: 'approved' }));
  await assert.rejects(() => fnf.decideSeparationRequest(1, 'approved', 9), /already been decided/);
});

// ---------------------------------------------------------------------------
// Settlement generation
// ---------------------------------------------------------------------------

function baseGenerateMocks(overrides = {}) {
  mockDb('getSeparation', async () => ({
    id: 1, user_id: 1, status: 'approved', resignation_date: '2026-05-01', last_working_date: '2026-05-31',
    notice_period_required_days: 30, ...overrides.separation,
  }));
  mockDb('getFnfSettlementBySeparation', async () => overrides.existing || null);
  mockDb('listFinancialYears', async () => [{ id: 1, start_date: '2026-04-01', end_date: '2027-03-31' }]);
  mockDb('getActiveFinancialYear', async () => ({ id: 1, start_date: '2026-04-01', end_date: '2027-03-31' }));
  mockDb('getActiveSalaryStructure', async () => ({ id: 10 }));
  mockDb('getStructureComponents', async () => overrides.components || [
    { type: 'earning', code: 'BASIC', amount: 40000 },
    { type: 'earning', code: 'HRA', amount: 16000 },
    { type: 'deduction', code: 'PF_EMPLOYEE', amount: 4800 },
  ]);
  mockDb('dbGet', overrides.dbGet || (async () => null)); // "already payrolled" check defaults to "not found"
  mockDb('getHolidaysInRange', async () => overrides.holidays || []);
  mockDb('getWeeklyOffDays', async () => [0, 6]);
  mockDb('dbAll', overrides.dbAll || (async () => [])); // leave_balances query
  mockPayroll('calculateGratuity', async () => overrides.gratuity || { gratuityAmount: 0, eligible: false });
  mockDb('listActiveLoansForUser', async () => overrides.loans || []);
  mockDb('listRecoveringAdvancesForUser', async () => overrides.advances || []);
  mockDb('createFnfSettlement', async (data) => { overrides.captured = data; return { id: 501 }; });
  mockDb('updateFnfSettlementLineItems', async (id, data) => { overrides.captured = data; });
  mockDb('getFnfSettlement', async () => overrides.captured);
}

test('generateSettlement refuses when the separation is not yet approved', async () => {
  mockDb('getSeparation', async () => ({ id: 1, status: 'pending' }));
  await assert.rejects(() => fnf.generateSettlement(1, 9), /must be approved/);
});

test('generateSettlement refuses to regenerate a non-draft settlement', async () => {
  mockDb('getSeparation', async () => ({ id: 1, status: 'approved' }));
  mockDb('getFnfSettlementBySeparation', async () => ({ id: 5, status: 'approved' }));
  await assert.rejects(() => fnf.generateSettlement(1, 9), /can only be regenerated while in draft/);
});

test('generateSettlement computes notice-period shortfall recovery when resignation notice was short', async () => {
  const ctx = {};
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9);
  // resignation 2026-05-01 -> last working 2026-05-31 = 30 days served (inclusive minus 1 for "served after giving notice")
  // servedDays = daysBetweenInclusive(05-01,05-31) - 1 = 31 - 1 = 30; required 30 -> shortfall 0
  assert.equal(ctx.captured.noticeRecoveryDays, 0);
  assert.equal(ctx.captured.noticeRecoveryAmount, 0);
});

test('generateSettlement recovers pay for a genuine notice-period shortfall', async () => {
  const ctx = {};
  Object.assign(ctx, { separation: { resignation_date: '2026-05-01', last_working_date: '2026-05-15', notice_period_required_days: 30 } });
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9);
  // served = daysBetween(05-01,05-15) - 1 = 15 - 1 = 14 days; required 30 -> shortfall 16 days
  const monthlyGross = 56000; // 40000 basic + 16000 hra
  const perDay = Math.round((monthlyGross / 26) * 100) / 100;
  assert.equal(ctx.captured.noticeRecoveryDays, 16);
  assert.equal(ctx.captured.noticeRecoveryAmount, Math.round(perDay * 16 * 100) / 100);
});

test('generateSettlement skips unpaid-salary calculation when the final month was already payrolled', async () => {
  const ctx = {};
  Object.assign(ctx, { dbGet: async () => ({ found: 1 }) }); // "already payrolled" check returns a row
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9);
  assert.equal(ctx.captured.unpaidSalaryDays, 0);
  assert.equal(ctx.captured.unpaidSalaryAmount, 0);
});

test('generateSettlement sums outstanding loan and advance balances into recovery lines', async () => {
  const ctx = {};
  Object.assign(ctx, {
    loans: [{ outstanding_balance: 20000 }, { outstanding_balance: 5000 }],
    advances: [{ outstanding_balance: 3000 }],
  });
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9);
  assert.equal(ctx.captured.loanRecoveryAmount, 25000);
  assert.equal(ctx.captured.advanceRecoveryAmount, 3000);
});

test('generateSettlement includes gratuity and honors manual overrides for bonus/reimbursements/asset recovery', async () => {
  const ctx = {};
  Object.assign(ctx, { gratuity: { gratuityAmount: 150000, eligible: true } });
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9, { bonusAmount: 10000, reimbursementsAmount: 2500, assetRecoveryAmount: 1000, otherDeductionsAmount: 500, otherDeductionsNotes: 'Laptop not returned' });
  assert.equal(ctx.captured.gratuityAmount, 150000);
  assert.equal(ctx.captured.bonusAmount, 10000);
  assert.equal(ctx.captured.reimbursementsAmount, 2500);
  assert.equal(ctx.captured.assetRecoveryAmount, 1000);
  assert.equal(ctx.captured.otherDeductionsNotes, 'Laptop not returned');
});

test('generateSettlement computes finalPayable as totalEarnings minus totalDeductions', async () => {
  const ctx = {};
  Object.assign(ctx, { gratuity: { gratuityAmount: 50000, eligible: true }, loans: [{ outstanding_balance: 10000 }] });
  baseGenerateMocks(ctx);
  await fnf.generateSettlement(1, 9, { bonusAmount: 5000 });
  const expected = Math.round((ctx.captured.totalEarnings - ctx.captured.totalDeductions) * 100) / 100;
  assert.equal(ctx.captured.finalPayable, expected);
});

// ---------------------------------------------------------------------------
// Approval / payout workflow guards
// ---------------------------------------------------------------------------

test('submitSettlementForApproval only allows a draft settlement to move forward', async () => {
  mockDb('getFnfSettlement', async () => ({ id: 1, status: 'pending_approval' }));
  await assert.rejects(() => fnf.submitSettlementForApproval(1), /Only a draft settlement/);
});

test('decideSettlement only allows deciding a settlement that is pending_approval', async () => {
  mockDb('getFnfSettlement', async () => ({ id: 1, status: 'draft' }));
  await assert.rejects(() => fnf.decideSettlement(1, 'approved', 9), /not pending approval/);
});

test('markSettlementPaid only allows finalizing an approved settlement', async () => {
  mockDb('getFnfSettlement', async () => ({ id: 1, status: 'pending_approval' }));
  await assert.rejects(() => fnf.markSettlementPaid(1, 9), /Only an approved settlement/);
});
}

// ---------------------------------------------------------------------------
// Consolidated from leave_block3_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/leave_block3_unit.test.js
//
// Offline unit tests for Block 3 (Advanced Leave Management). Same approach
// as the other *_unit.test.js files: db.js functions are monkey-patched per
// test, no real database or network needed.
//
// Run with:  node --test tests/unit.test.js

const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const leave = require('../src/services').leave;

let patched = [];
function mock(name, fn) { patched.push([name, db[name]]); db[name] = fn; }
afterEach(() => {
  for (const [name, original] of patched) db[name] = original;
  patched = [];
});

// ---------------------------------------------------------------------------
// Policy resolution
// ---------------------------------------------------------------------------

test('getEffectiveLeavePolicy prefers an employee-specific policy over department or default', async () => {
  mock('resolveLeavePolicy', async () => ({
    user_id: 5, annual_days: 30, accrual_method: 'annual', carry_forward_enabled: 1, max_carry_forward_days: 10,
    carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0,
    is_sandwich_leave: 0, unit: 'day',
  }));
  const policy = await leave.getEffectiveLeavePolicy(5, 1);
  assert.equal(policy.source, 'employee');
  assert.equal(policy.annualDays, 30);
});

test('getEffectiveLeavePolicy falls back to the leave type defaults when no policy row exists', async () => {
  mock('resolveLeavePolicy', async () => null);
  mock('getLeaveType', async () => ({ default_annual_days: 12, max_carry_forward_days: 0 }));
  const policy = await leave.getEffectiveLeavePolicy(5, 1);
  assert.equal(policy.source, 'default');
  assert.equal(policy.annualDays, 12);
  assert.equal(policy.carryForwardEnabled, false);
});

// ---------------------------------------------------------------------------
// Day counting
// ---------------------------------------------------------------------------

test('computeLeaveDayCount returns 0.5 for a half-day request regardless of policy', async () => {
  const result = await leave.computeLeaveDayCount('2026-06-01', '2026-06-01', true, false);
  assert.equal(result.days, 0.5);
});

test('computeLeaveDayCount skips weekends and holidays within the range under the normal (non-sandwich) rule', async () => {
  mock('getHolidaysInRange', async () => [{ holiday_date: '2026-06-03' }]); // Wednesday holiday
  mock('getWeeklyOffDays', async () => [0, 6]);
  // Mon 06-01 .. Sun 06-07: business days are Mon,Tue,Thu,Fri (Wed is holiday, Sat/Sun weekend) = 4
  const result = await leave.computeLeaveDayCount('2026-06-01', '2026-06-07', false, false);
  assert.equal(result.days, 4);
  assert.equal(result.isSandwich, false);
});

test('computeLeaveDayCount counts every calendar day under the sandwich rule', async () => {
  const result = await leave.computeLeaveDayCount('2026-06-01', '2026-06-07', false, true);
  assert.equal(result.days, 7); // all 7 days count, including the weekend
  assert.equal(result.isSandwich, true);
});

// ---------------------------------------------------------------------------
// Eligibility
// ---------------------------------------------------------------------------

test('checkEligibility rejects an application before the policy waiting period has elapsed', async () => {
  const today = new Date().toISOString().slice(0, 10);
  mock('findUserById', async () => ({ joined_date: today })); // joined today
  await assert.rejects(
    () => leave.checkEligibility(1, 1, { minServiceDaysBeforeEligible: 90 }),
    /Not yet eligible/
  );
});

test('checkEligibility passes when there is no waiting period configured', async () => {
  await leave.checkEligibility(1, 1, { minServiceDaysBeforeEligible: 0 }); // should not throw, no db calls needed
});

// ---------------------------------------------------------------------------
// Apply for leave (advanced)
// ---------------------------------------------------------------------------

function mockApplyBasics(overrides = {}) {
  mock('resolveLeavePolicy', async () => overrides.policy || null);
  mock('getLeaveType', async () => ({ default_annual_days: 12, max_carry_forward_days: 0 }));
  mock('findUserById', async () => ({ joined_date: '2020-01-01' }));
  mock('getHolidaysInRange', async () => []);
  mock('getWeeklyOffDays', async () => [0, 6]);
  mock('getLeaveBalanceRow', async () => overrides.balance !== undefined ? overrides.balance : { total_days: 12, used_days: 0, carried_forward_days: 0 });
  mock('dbRun', async () => {});
}

test('applyForLeaveAdvanced rejects a to-date before the from-date', async () => {
  await assert.rejects(
    () => leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-10', to: '2026-06-01' }),
    /cannot be before/
  );
});

test('applyForLeaveAdvanced rejects when balance is insufficient and negative balance is not allowed', async () => {
  mockApplyBasics({ balance: { total_days: 2, used_days: 0, carried_forward_days: 0 } });
  await assert.rejects(
    () => leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-01', to: '2026-06-05' }), // 5 business days (Mon-Fri)
    /Insufficient leave balance/
  );
});

test('applyForLeaveAdvanced allows going negative up to the policy cap when negative balance is enabled', async () => {
  mockApplyBasics({
    policy: { user_id: 1, annual_days: 12, accrual_method: 'annual', carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 1, max_negative_days: 3, is_sandwich_leave: 0, unit: 'day' },
    balance: { total_days: 2, used_days: 0, carried_forward_days: 0 },
  });
  const result = await leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-01', to: '2026-06-03' }); // 3 business days, balance 2 -> -1, within cap of 3
  assert.equal(result.days, 3);
});

test('applyForLeaveAdvanced rejects when negative balance would exceed the policy cap', async () => {
  mockApplyBasics({
    policy: { user_id: 1, annual_days: 12, accrual_method: 'annual', carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 1, max_negative_days: 1, is_sandwich_leave: 0, unit: 'day' },
    balance: { total_days: 0, used_days: 0, carried_forward_days: 0 },
  });
  await assert.rejects(
    () => leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-01', to: '2026-06-05' }), // 5 days requested, cap only allows 1 negative
    /maximum allowed negative balance/
  );
});

test('applyForLeaveAdvanced supports hour-based leave using the hours field', async () => {
  mockApplyBasics({
    policy: { user_id: 1, annual_days: 40, accrual_method: 'annual', carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0, is_sandwich_leave: 0, unit: 'hour' },
    balance: { total_days: 40, used_days: 0, carried_forward_days: 0 },
  });
  const result = await leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-01', to: '2026-06-01', hours: 4 });
  assert.equal(result.unit, 'hour');
  assert.equal(result.days, 4);
});

test('applyForLeaveAdvanced defaults to a second approval level for requests longer than 5 days', async () => {
  mockApplyBasics({ balance: { total_days: 20, used_days: 0, carried_forward_days: 0 } });
  const result = await leave.applyForLeaveAdvanced({ userId: 1, leaveTypeId: 1, from: '2026-06-01', to: '2026-06-10' }); // > 5 business days
  assert.equal(result.requiredApprovalLevels, 2);
});

// ---------------------------------------------------------------------------
// Multi-level approval
// ---------------------------------------------------------------------------

test('decideLeaveApplicationMultiLevel refuses to decide an already-decided application', async () => {
  mock('getLeaveApplicationRow', async () => ({ status: 'approved' }));
  await assert.rejects(() => leave.decideLeaveApplicationMultiLevel('LV1', 'approved', 9), /already been decided/);
});

test('decideLeaveApplicationMultiLevel rejects immediately without advancing levels', async () => {
  mock('getLeaveApplicationRow', async () => ({ status: 'pending', current_approval_level: 1, required_approval_levels: 2 }));
  mock('createLeaveApproval', async () => {});
  let advanced = false;
  mock('advanceLeaveApprovalLevel', async () => { advanced = true; });
  mock('dbRun', async () => {});
  const result = await leave.decideLeaveApplicationMultiLevel('LV1', 'rejected', 9, 'not enough coverage');
  assert.equal(result.status, 'rejected');
  assert.equal(advanced, false);
});

test('decideLeaveApplicationMultiLevel advances to the next level on approval when more levels remain', async () => {
  mock('getLeaveApplicationRow', async () => ({ status: 'pending', current_approval_level: 1, required_approval_levels: 2 }));
  mock('createLeaveApproval', async () => {});
  let advanced = false;
  mock('advanceLeaveApprovalLevel', async () => { advanced = true; });
  const result = await leave.decideLeaveApplicationMultiLevel('LV1', 'approved', 9);
  assert.equal(result.status, 'pending');
  assert.equal(result.nextLevel, 2);
  assert.equal(advanced, true);
});

test('decideLeaveApplicationMultiLevel commits the balance deduction on final-level approval', async () => {
  mock('getLeaveApplicationRow', async () => ({ id: 'LV1', status: 'pending', current_approval_level: 2, required_approval_levels: 2, user_id: 1, leave_type_id: 1, from_date: '2026-06-01', days: 3, comp_off_id: null }));
  mock('createLeaveApproval', async () => {});
  mock('getLeaveBalanceRow', async () => ({ id: 1, total_days: 12, used_days: 2 }));
  let capturedUsed;
  mock('upsertLeaveBalance', async (userId, leaveTypeId, year, data) => { capturedUsed = data.used_days; });
  mock('dbRun', async () => {});
  const result = await leave.decideLeaveApplicationMultiLevel('LV1', 'approved', 9);
  assert.equal(result.status, 'approved');
  assert.equal(capturedUsed, 5); // 2 + 3
});

// ---------------------------------------------------------------------------
// Comp-off
// ---------------------------------------------------------------------------

test('decideCompOffRequest refuses to re-decide', async () => {
  mock('getCompOff', async () => ({ status: 'approved' }));
  await assert.rejects(() => leave.decideCompOffRequest(1, 'approved', 9), /already been decided/);
});

test('redeemCompOff refuses a credit belonging to a different employee', async () => {
  mock('getCompOff', async () => ({ user_id: 2, status: 'approved' }));
  await assert.rejects(() => leave.redeemCompOff({ userId: 1, compOffId: 1, date: '2026-06-01' }), /does not belong/);
});

test('redeemCompOff refuses an expired credit', async () => {
  mock('getCompOff', async () => ({ user_id: 1, status: 'approved', expires_on: '2020-01-01' }));
  await assert.rejects(() => leave.redeemCompOff({ userId: 1, compOffId: 1, date: '2026-06-01' }), /expired/);
});

test('redeemCompOff refuses a credit that is not in approved status', async () => {
  mock('getCompOff', async () => ({ user_id: 1, status: 'pending' }));
  await assert.rejects(() => leave.redeemCompOff({ userId: 1, compOffId: 1, date: '2026-06-01' }), /not available to redeem/);
});

// ---------------------------------------------------------------------------
// Monthly accrual
// ---------------------------------------------------------------------------

test('runMonthlyAccrual only accrues for user/leave-type combos on a monthly-accrual policy', async () => {
  mock('listActiveUsersWithLeaveType', async () => ([
    { user_id: 1, dept: 'Eng', joined_date: '2020-01-01', leave_type_id: 1, default_annual_days: 12 },
    { user_id: 1, dept: 'Eng', joined_date: '2020-01-01', leave_type_id: 2, default_annual_days: 12 },
  ]));
  mock('resolveLeavePolicy', async (userId, leaveTypeId) => {
    if (leaveTypeId === 1) return { user_id: 1, annual_days: 12, accrual_method: 'monthly', monthly_accrual_days: 1, carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0, is_sandwich_leave: 0, unit: 'day' };
    return null; // leave type 2 has no policy -> defaults to 'annual' accrual, should be skipped
  });
  mock('getLeaveType', async () => ({ default_annual_days: 12, max_carry_forward_days: 0 }));
  mock('getLeaveBalanceRow', async () => ({ total_days: 5, used_days: 0 }));
  let upserted = 0;
  mock('upsertLeaveBalance', async () => { upserted++; });

  const result = await leave.runMonthlyAccrual(2026, 6);
  assert.equal(result.accrualsApplied, 1);
  assert.equal(upserted, 1);
});

test('runMonthlyAccrual skips months before the employee joined', async () => {
  mock('listActiveUsersWithLeaveType', async () => ([
    { user_id: 1, dept: 'Eng', joined_date: '2026-08-01', leave_type_id: 1, default_annual_days: 12 },
  ]));
  mock('resolveLeavePolicy', async () => ({ user_id: 1, annual_days: 12, accrual_method: 'monthly', monthly_accrual_days: 1, carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0, is_sandwich_leave: 0, unit: 'day' }));
  let upserted = 0;
  mock('upsertLeaveBalance', async () => { upserted++; });

  const result = await leave.runMonthlyAccrual(2026, 6); // joined August, running for June
  assert.equal(result.accrualsApplied, 0);
  assert.equal(upserted, 0);
});

// ---------------------------------------------------------------------------
// Carry-forward + expiry
// ---------------------------------------------------------------------------

test('runYearEndCarryForward caps the carried-forward amount at the policy maximum', async () => {
  mock('listActiveUsersWithLeaveType', async () => ([{ user_id: 1, dept: 'Eng', joined_date: '2020-01-01', leave_type_id: 1, default_annual_days: 12 }]));
  mock('resolveLeavePolicy', async () => ({ user_id: 1, annual_days: 12, accrual_method: 'annual', carry_forward_enabled: 1, max_carry_forward_days: 5, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0, is_sandwich_leave: 0, unit: 'day' }));
  mock('getLeaveBalanceRow', async (userId, typeId, year) => {
    if (year === 2026) return { total_days: 12, used_days: 2, carried_forward_days: 0 }; // 10 unused
    return null; // no 2027 balance yet
  });
  let captured;
  mock('upsertLeaveBalance', async (userId, typeId, year, data) => { captured = data; });

  await leave.runYearEndCarryForward(2026, 2027);
  assert.equal(captured.carried_forward_days, 5); // capped, even though 10 was unused
  assert.equal(captured.total_days, 17); // 12 default annual + 5 carried forward
});

test('runYearEndCarryForward skips employees with no carry-forward policy', async () => {
  mock('listActiveUsersWithLeaveType', async () => ([{ user_id: 1, dept: 'Eng', joined_date: '2020-01-01', leave_type_id: 1, default_annual_days: 12 }]));
  mock('resolveLeavePolicy', async () => ({ user_id: 1, annual_days: 12, accrual_method: 'annual', carry_forward_enabled: 0, max_carry_forward_days: 0, carry_forward_expiry_months: 3, min_service_days_before_eligible: 0, allow_negative_balance: 0, max_negative_days: 0, is_sandwich_leave: 0, unit: 'day' }));
  mock('getLeaveBalanceRow', async () => { throw new Error('should not be queried when carry-forward is disabled'); });
  const result = await leave.runYearEndCarryForward(2026, 2027);
  assert.equal(result.employeesProcessed, 0);
});

test('expireCarriedForwardLeave deducts unused carried-forward days past their expiry', async () => {
  mock('dbAll', async () => ([
    { user_id: 1, leave_type_id: 1, year: 2027, total_days: 17, used_days: 2, carried_forward_days: 5, carry_forward_expires_on: '2027-04-01' },
  ]));
  let captured;
  mock('upsertLeaveBalance', async (userId, typeId, year, data) => { captured = data; });

  const result = await leave.expireCarriedForwardLeave('2027-05-01');
  assert.equal(result.expiredCount, 1);
  assert.equal(captured.total_days, 14); // 17 - (5 unused carry-forward, since used_days 2 < carried 5)
  assert.equal(captured.carried_forward_days, 0);
});

test('expireCarriedForwardLeave leaves the total untouched if carry-forward was already fully used', async () => {
  mock('dbAll', async () => ([
    { user_id: 1, leave_type_id: 1, year: 2027, total_days: 17, used_days: 6, carried_forward_days: 5, carry_forward_expires_on: '2027-04-01' },
  ]));
  let captured;
  mock('upsertLeaveBalance', async (userId, typeId, year, data) => { captured = data; });

  await leave.expireCarriedForwardLeave('2027-05-01');
  assert.equal(captured.carried_forward_days, 0);
  assert.equal('total_days' in captured, false); // total untouched — no unused carry-forward to claw back
});
}

// ---------------------------------------------------------------------------
// Consolidated from lifecycle_block1_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/lifecycle_block1_unit.test.js
//
// Offline unit tests for Block 1 (Advanced Employee Lifecycle).
//
// Run with:  node --test tests/unit.test.js

const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const lifecycle = require('../src/services').lifecycle;

let patched = [];
function mock(name, fn) { patched.push([name, db[name]]); db[name] = fn; }
afterEach(() => {
  for (const [name, original] of patched) db[name] = original;
  patched = [];
});

// ---------------------------------------------------------------------------
// Onboarding
// ---------------------------------------------------------------------------

test('initializeLifecycle sets status to onboarding and generates the onboarding checklist', async () => {
  mock('findUserById', async () => ({ id: 1, joined_date: '2026-06-01' }));
  let statusSet;
  mock('updateLifecycleStatus', async (userId, status) => { statusSet = status; });
  mock('createLifecycleEvent', async () => {});
  mock('listChecklistTemplateItems', async () => ([{ id: 1, label: 'Collect ID' }, { id: 2, label: 'Set up payroll' }]));
  let tasksCreated = 0;
  mock('createChecklistTask', async () => { tasksCreated++; });

  const result = await lifecycle.initializeLifecycle(1, 9);
  assert.equal(statusSet, 'onboarding');
  assert.equal(tasksCreated, 2);
  assert.equal(result.tasksCreated, 2);
});

test('completeOnboarding moves the employee to active status', async () => {
  let statusSet;
  mock('updateLifecycleStatus', async (userId, status) => { statusSet = status; });
  mock('createLifecycleEvent', async () => {});
  const result = await lifecycle.completeOnboarding(1, 9);
  assert.equal(statusSet, 'active');
  assert.equal(result.status, 'active');
});

// ---------------------------------------------------------------------------
// Transfers (department / designation / manager / location)
// ---------------------------------------------------------------------------

test('transferDepartment updates the live field and logs previous/new values', async () => {
  mock('findUserById', async () => ({ dept: 'Engineering' }));
  let patched_;
  mock('updateUserAdmin', async (userId, patch) => { patched_ = patch; });
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });

  const result = await lifecycle.transferDepartment({ userId: 1, newDept: 'Sales', actorId: 9 });
  assert.equal(patched_.dept, 'Sales');
  assert.equal(event.eventType, 'department_transfer');
  assert.equal(event.previousValue, 'Engineering');
  assert.equal(event.newValue, 'Sales');
  assert.equal(result.previousValue, 'Engineering');
});

test('changeManager stores manager IDs as strings for the history record', async () => {
  mock('findUserById', async () => ({ manager_id: 5 }));
  mock('updateUserAdmin', async () => {});
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });

  await lifecycle.changeManager({ userId: 1, newManagerId: 8, actorId: 9 });
  assert.equal(event.eventType, 'manager_change');
  assert.equal(event.previousValue, '5');
  assert.equal(event.newValue, '8');
});

test('changeLocation handles a null previous location gracefully', async () => {
  mock('findUserById', async () => ({ location: null }));
  mock('updateUserAdmin', async () => {});
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });

  await lifecycle.changeLocation({ userId: 1, newLocation: 'Hyderabad', actorId: 9 });
  assert.equal(event.previousValue, null);
  assert.equal(event.newValue, 'Hyderabad');
});

// ---------------------------------------------------------------------------
// Promotion
// ---------------------------------------------------------------------------

test('promoteEmployee requires at least a newTitle or newDept', async () => {
  mock('findUserById', async () => ({ title: 'Engineer', dept: 'Eng' }));
  await assert.rejects(() => lifecycle.promoteEmployee({ userId: 1, actorId: 9 }), /Provide at least/);
});

test('promoteEmployee updates only the provided fields and logs both old and new as JSON', async () => {
  mock('findUserById', async () => ({ title: 'Engineer', dept: 'Eng' }));
  let patched_;
  mock('updateUserAdmin', async (userId, patch) => { patched_ = patch; });
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });

  await lifecycle.promoteEmployee({ userId: 1, newTitle: 'Senior Engineer', actorId: 9 });
  assert.deepEqual(patched_, { title: 'Senior Engineer' });
  const prev = JSON.parse(event.previousValue);
  const next = JSON.parse(event.newValue);
  assert.equal(prev.title, 'Engineer');
  assert.equal(next.title, 'Senior Engineer');
  assert.equal(next.dept, 'Eng'); // unchanged field carried through
});

// ---------------------------------------------------------------------------
// Probation
// ---------------------------------------------------------------------------

test('startProbation refuses a second active probation for the same employee', async () => {
  mock('getActiveProbationForUser', async () => ({ id: 1, status: 'on_probation' }));
  await assert.rejects(() => lifecycle.startProbation({ userId: 1, actorId: 9 }), /already has an active probation/);
});

test('startProbation computes the expected end date from the duration', async () => {
  mock('getActiveProbationForUser', async () => null);
  let captured;
  mock('createProbationRecord', async (data) => { captured = data; return 501; });
  mock('updateLifecycleStatus', async () => {});
  mock('createLifecycleEvent', async () => {});

  const result = await lifecycle.startProbation({ userId: 1, startDate: '2026-01-01', durationDays: 90, actorId: 9 });
  assert.equal(result.expectedEndDate, '2026-04-01');
  assert.equal(captured.expectedEndDate, '2026-04-01');
});

test('confirmProbation refuses to re-confirm an already-confirmed record', async () => {
  mock('getProbationRecord', async () => ({ status: 'confirmed' }));
  await assert.rejects(() => lifecycle.confirmProbation(1, 9), /already been confirmed/);
});

test('confirmProbation moves lifecycle status to active', async () => {
  mock('getProbationRecord', async () => ({ id: 1, user_id: 1, status: 'on_probation' }));
  mock('confirmProbationRecord', async () => {});
  let statusSet;
  mock('updateLifecycleStatus', async (userId, status) => { statusSet = status; });
  mock('createLifecycleEvent', async () => {});
  await lifecycle.confirmProbation(1, 9);
  assert.equal(statusSet, 'active');
});

test('extendProbation refuses to extend an already-confirmed probation', async () => {
  mock('getProbationRecord', async () => ({ status: 'confirmed', expected_end_date: '2026-04-01' }));
  await assert.rejects(() => lifecycle.extendProbation(1, '2026-06-01', 9), /already been confirmed/);
});

test('extendProbation requires the new date to be after the current expected end date', async () => {
  mock('getProbationRecord', async () => ({ status: 'on_probation', expected_end_date: '2026-04-01' }));
  await assert.rejects(() => lifecycle.extendProbation(1, '2026-03-01', 9), /must be after/);
});

test('extendProbation succeeds with a valid later date and logs the change', async () => {
  mock('getProbationRecord', async () => ({ user_id: 1, status: 'on_probation', expected_end_date: '2026-04-01' }));
  mock('extendProbationRecord', async () => {});
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });
  await lifecycle.extendProbation(1, '2026-06-01', 9, 'needs more ramp-up time');
  assert.equal(event.eventType, 'probation_extended');
  assert.equal(event.previousValue, '2026-04-01');
  assert.equal(event.newValue, '2026-06-01');
});

// ---------------------------------------------------------------------------
// Exit interview
// ---------------------------------------------------------------------------

test('recordExitInterview refuses to record a second interview for the same separation', async () => {
  mock('getExitInterview', async () => ({ id: 1 }));
  await assert.rejects(() => lifecycle.recordExitInterview({ employeeSeparationId: 1, conductedBy: 9 }), /already been recorded/);
});

// ---------------------------------------------------------------------------
// F&F integration hooks
// ---------------------------------------------------------------------------

test('onSeparationApproved moves the employee to notice_period and generates the offboarding checklist', async () => {
  let statusSet;
  mock('updateLifecycleStatus', async (userId, status) => { statusSet = status; });
  mock('createLifecycleEvent', async () => {});
  mock('listChecklistTemplateItems', async () => ([{ id: 1, label: 'Return laptop' }]));
  let taskArgs;
  mock('createChecklistTask', async (data) => { taskArgs = data; });

  const result = await lifecycle.onSeparationApproved(1, 55, 9);
  assert.equal(statusSet, 'notice_period');
  assert.equal(result.tasksCreated, 1);
  assert.equal(taskArgs.employeeSeparationId, 55);
  assert.equal(taskArgs.type, 'offboarding');
});

test('onSettlementPaid sets lifecycle status to exited and logs the terminal event', async () => {
  let statusSet;
  mock('updateLifecycleStatus', async (userId, status) => { statusSet = status; });
  let event;
  mock('createLifecycleEvent', async (data) => { event = data; });

  await lifecycle.onSettlementPaid(1, 9);
  assert.equal(statusSet, 'exited');
  assert.equal(event.eventType, 'exited');
});
}

// ---------------------------------------------------------------------------
// Consolidated from payroll_block4_unit.test.js
// ---------------------------------------------------------------------------
{
// tests/payroll_block4_unit.test.js
//
// Offline unit tests for the Block 4 (Advanced Payroll Engine) additions:
// formula/conditional salary components, employee loans, salary advances,
// leave encashment, retroactive-revision arrears, gratuity estimation, and
// the month-to-month comparison/variance reports.
//
// Unlike tests/regression.test.js, this file needs NO real PostgreSQL
// database and NO network access — it drives payroll.js directly and
// monkey-patches the handful of db.js functions each test touches (db.js
// exports a shared object, so reassigning a property on it here is visible
// to payroll.js, which required the same module instance).
//
// Run with:  node --test tests/unit.test.js
// (from backend/, after `npm install`; a `@prisma/client`/`dotenv` stub is
// NOT needed once real dependencies are installed — this file works either
// way since it never lets a real query run.)

const { test, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const db = require('../src/db');
const services = require('../src/services');
const payroll = services.payroll;
const utils = services.utils;

// Keeps track of which db.* functions each test overrides so we can restore
// the originals afterwards and tests can't leak mocks into one another.
let patched = [];
function mock(name, fn) {
  patched.push([name, db[name]]);
  db[name] = fn;
}
afterEach(() => {
  for (const [name, original] of patched) db[name] = original;
  patched = [];
});

// ---------------------------------------------------------------------------
// Formula / conditional salary component evaluation
// ---------------------------------------------------------------------------

test('evaluateArithmeticFormula supports +-*/ and parentheses with variables', () => {
  assert.equal(utils.evaluateArithmeticFormula('monthlyBasic*0.4 + 500', { monthlyBasic: 40000 }), 16500);
  assert.equal(utils.evaluateArithmeticFormula('(monthlyBasic + 1000) / 2', { monthlyBasic: 40000 }), 20500);
});

test('evaluateArithmeticFormula rejects unknown variables and malformed input', () => {
  assert.throws(() => utils.evaluateArithmeticFormula('unknownVar * 2', { monthlyBasic: 1 }), /Unknown variable/);
  assert.throws(() => utils.evaluateArithmeticFormula('1 + ', {}), /formula/i);
});

test('evaluateConditionalRule picks thenValue/elseValue per operator', () => {
  const rule = { variable: 'monthlyBasic', operator: '>', threshold: 50000, thenValue: 2000, elseValue: 1000 };
  assert.equal(utils.evaluateConditionalRule(rule, { monthlyBasic: 60000 }), 2000);
  assert.equal(utils.evaluateConditionalRule(rule, { monthlyBasic: 40000 }), 1000);
});

// ---------------------------------------------------------------------------
// EMI calculation
// ---------------------------------------------------------------------------

test('computeEmi matches reducing-balance EMI formula, and is a plain split at 0% interest', () => {
  assert.equal(utils.computeEmi(120000, 12, 12), 10661.85);
  assert.equal(utils.computeEmi(120000, 0, 12), 10000);
  assert.equal(utils.computeEmi(0, 12, 12), 0);
});

// ---------------------------------------------------------------------------
// Gratuity (Payment of Gratuity Act, 1972 convention)
// ---------------------------------------------------------------------------

test('calculateGratuity: not eligible before 5 completed years of service', async () => {
  mock('findUserById', async () => ({ id: 1, joined_date: '2023-01-01' }));
  mock('getActiveFinancialYear', async () => ({ id: 1 }));
  mock('getSalaryStructureAsOf', async () => ({ id: 10 }));
  mock('getStructureComponents', async () => [{ code: 'BASIC', amount: 50000 }]);

  const result = await payroll.calculateGratuity(1, null, '2026-06-01');
  assert.equal(result.eligible, false);
  assert.equal(result.gratuityAmount, 0);
});

test('calculateGratuity: eligible employee gets (basic*15*years)/26, capped at the statutory ceiling', async () => {
  mock('findUserById', async () => ({ id: 2, joined_date: '2015-01-01' }));
  mock('getActiveFinancialYear', async () => ({ id: 1 }));
  mock('getSalaryStructureAsOf', async () => ({ id: 11 }));
  mock('getStructureComponents', async () => [{ code: 'BASIC', amount: 60000 }]);

  const result = await payroll.calculateGratuity(2, null, '2026-06-01');
  assert.equal(result.eligible, true);
  assert.equal(result.yearsOfService, 11);
  const expectedRaw = Math.round(((60000 * 15 * 11) / 26) * 100) / 100;
  assert.equal(result.rawAmount, expectedRaw);
  assert.equal(result.gratuityAmount, Math.min(expectedRaw, 2000000));
});

test('calculateGratuity: very long tenure at a high basic is capped at the statutory ceiling', async () => {
  mock('findUserById', async () => ({ id: 3, joined_date: '1995-01-01' }));
  mock('getActiveFinancialYear', async () => ({ id: 1 }));
  mock('getSalaryStructureAsOf', async () => ({ id: 12 }));
  mock('getStructureComponents', async () => [{ code: 'BASIC', amount: 300000 }]);

  const result = await payroll.calculateGratuity(3, null, '2026-06-01');
  assert.equal(result.statutoryCapApplied, true);
  assert.equal(result.gratuityAmount, 2000000);
});

// ---------------------------------------------------------------------------
// Loan / advance request validation
// ---------------------------------------------------------------------------

test('requestLoan rejects non-positive principal or tenure', async () => {
  await assert.rejects(() => payroll.requestLoan({ userId: 1, principalAmount: 0, tenureMonths: 6 }), /Principal amount/);
  await assert.rejects(() => payroll.requestLoan({ userId: 1, principalAmount: 1000, tenureMonths: 0 }), /Tenure/);
});

test('requestLoan creates a pending loan row via db.createLoan', async () => {
  let captured;
  mock('createLoan', async (data) => { captured = data; return 42; });
  const id = await payroll.requestLoan({ userId: 5, principalAmount: 50000, interestRateAnnual: 10, tenureMonths: 10, purpose: 'Medical' });
  assert.equal(id, 42);
  assert.equal(captured.userId, 5);
  assert.equal(captured.principalAmount, 50000);
});

test('decideLoanRequest refuses to re-decide an already-decided loan', async () => {
  mock('getLoan', async () => ({ id: 1, status: 'approved' }));
  await assert.rejects(() => payroll.decideLoanRequest(1, 'approved', 99), /already been decided/);
});

test('disburseLoanFull computes and stores the EMI, only from approved status', async () => {
  mock('getLoan', async (id) => ({ id, status: 'approved', principal_amount: 120000, interest_rate_annual: 12, tenure_months: 12 }));
  let disbursedEmi;
  mock('disburseLoan', async (id, emi) => { disbursedEmi = emi; });
  mock('logPayrollAudit', async () => {});
  await payroll.disburseLoanFull(1, 99);
  assert.equal(disbursedEmi, 10661.85);
});

test('requestSalaryAdvance rejects non-positive amount', async () => {
  await assert.rejects(() => payroll.requestSalaryAdvance({ userId: 1, amount: 0 }), /greater than zero/);
});

// ---------------------------------------------------------------------------
// Leave encashment
// ---------------------------------------------------------------------------

test('requestLeaveEncashment blocks encashing more days than available balance', async () => {
  mock('getFinancialYear', async () => ({ id: 1, start_date: '2025-04-01' }));
  mock('dbGet', async () => ({ total_days: 12, used_days: 10 })); // 2 days available
  await assert.rejects(
    () => payroll.requestLeaveEncashment({ userId: 1, leaveTypeId: 1, financialYearId: 1, days: 5 }),
    /Only 2 day\(s\) available/
  );
});

test('requestLeaveEncashment computes amount as (monthlyBasic/26)*days', async () => {
  mock('getFinancialYear', async () => ({ id: 1, start_date: '2025-04-01' }));
  mock('dbGet', async () => ({ total_days: 12, used_days: 2 }));
  mock('getActiveSalaryStructure', async () => ({ id: 7 }));
  mock('getStructureComponents', async () => [{ code: 'BASIC', amount: 52000 }]);
  mock('createLeaveEncashmentRequest', async () => ({ id: 501 }));

  const result = await payroll.requestLeaveEncashment({ userId: 1, leaveTypeId: 1, financialYearId: 1, days: 4 });
  assert.equal(result.perDayAmount, 2000); // 52000/26
  assert.equal(result.amount, 8000);
});

// ---------------------------------------------------------------------------
// Arrears from retroactive salary revisions
// ---------------------------------------------------------------------------

test('generateArrearsForRetroactiveRevision creates one row per already-settled month, prorated by paid/working days', async () => {
  mock('listSettledPayrollMonthsForUser', async () => ([
    { payroll_month: '2026-04', paid_days: 22, working_days: 22 },
    { payroll_month: '2026-05', paid_days: 20, working_days: 22 }, // some LOP that month
  ]));
  const created = [];
  mock('createArrearsPayment', async (data) => { created.push(data); return { id: created.length }; });

  const result = await payroll.generateArrearsForRetroactiveRevision({
    userId: 1, financialYearId: 1, effectiveDate: '2026-04-01',
    previousMonthlyCtc: 80000, newMonthlyCtc: 90000, revisionId: 77, tx: {},
  });

  assert.equal(result.length, 2);
  assert.equal(result[0].amount, 10000); // full ratio
  assert.equal(result[1].amount, Math.round(10000 * (20 / 22) * 100) / 100);
  assert.equal(created[0].salaryRevisionId, 77);
});

test('generateArrearsForRetroactiveRevision is a no-op when CTC did not actually change', async () => {
  mock('listSettledPayrollMonthsForUser', async () => { throw new Error('should not be called when delta is 0'); });
  const result = await payroll.generateArrearsForRetroactiveRevision({
    userId: 1, financialYearId: 1, effectiveDate: '2026-04-01',
    previousMonthlyCtc: 80000, newMonthlyCtc: 80000, revisionId: 1, tx: {},
  });
  assert.deepEqual(result, []);
});

// ---------------------------------------------------------------------------
// Month-to-month comparison & variance report
// ---------------------------------------------------------------------------

test('comparePayrollMonths totals both months and flags employees present in only one', async () => {
  mock('getPayrollDetailsByMonth', async (fyId, month) => {
    if (month === '2026-04') return [
      { user_id: 1, user_name: 'Asha', gross_earning: 80000, net_salary: 70000, tds_deduction: 5000 },
      { user_id: 2, user_name: 'Ravi', gross_earning: 60000, net_salary: 52000, tds_deduction: 3000 },
    ];
    return [
      { user_id: 1, user_name: 'Asha', gross_earning: 88000, net_salary: 76000, tds_deduction: 5500 },
      { user_id: 3, user_name: 'Priya', gross_earning: 50000, net_salary: 45000, tds_deduction: 1000 },
    ];
  });

  const cmp = await payroll.comparePayrollMonths(1, '2026-04', '2026-05');
  assert.equal(cmp.totals.grossA, 140000);
  assert.equal(cmp.totals.grossB, 138000);
  const asha = cmp.employees.find(e => e.userId === 1);
  assert.equal(asha.grossDelta, 8000);
  const ravi = cmp.employees.find(e => e.userId === 2);
  assert.equal(ravi.presentInB, false);
  const priya = cmp.employees.find(e => e.userId === 3);
  assert.equal(priya.presentInA, false);
});

test('payrollVarianceReport flags only employees present in both months whose net changed beyond the threshold', async () => {
  mock('getPayrollDetailsByMonth', async (fyId, month) => {
    if (month === '2026-04') return [
      { user_id: 1, user_name: 'Asha', gross_earning: 80000, net_salary: 70000, tds_deduction: 5000 },
      { user_id: 2, user_name: 'Ravi', gross_earning: 60000, net_salary: 52000, tds_deduction: 3000 },
    ];
    return [
      { user_id: 1, user_name: 'Asha', gross_earning: 88000, net_salary: 84000, tds_deduction: 5500 }, // +20% net
      { user_id: 2, user_name: 'Ravi', gross_earning: 60500, net_salary: 52200, tds_deduction: 3000 }, // ~0.4% net
    ];
  });

  const report = await payroll.payrollVarianceReport(1, '2026-04', '2026-05', 10);
  assert.equal(report.flagged.length, 1);
  assert.equal(report.flagged[0].userId, 1);
});

console.log('Consolidated unit.test.js loaded');

// ---------------------------------------------------------------------------
// Shared security, integration, and storage boundary coverage
// ---------------------------------------------------------------------------
{
  const { test } = require('node:test');
  const assert = require('node:assert/strict');
  const crypto = require('node:crypto');
  const services = require('../src/services');

  test('password hashing verifies the original password and rejects a different password', () => {
    const auth = services.auth;
    const credentials = auth.hashPassword('Correct horse battery staple');
    assert.equal(auth.verifyPassword('Correct horse battery staple', credentials.hash, credentials.salt), true);
    assert.equal(auth.verifyPassword('wrong password', credentials.hash, credentials.salt), false);
  });

  test('temporary passwords are generated with the expected length and are not repeated', () => {
    const auth = services.auth;
    const first = auth.generateTempPassword();
    const second = auth.generateTempPassword();
    assert.equal(first.length >= 16, true);
    assert.equal(second.length >= 16, true);
    assert.notEqual(first, second);
  });

  test('integration adapters fail closed when providers are not configured', async () => {
    const integrations = services.integrationAdapters;
    const adapter = integrations.getAdapter('Google-Drive');
    assert.equal(adapter.provider, 'google-drive');
    assert.deepEqual(await adapter.test({}), {
      ok: false,
      provider: 'google-drive',
      message: 'Adapter not configured',
    });
    assert.equal(integrations.getAdapter('unknown-provider').provider, 'unknown-provider');
    assert.ok(integrations.listAdapters().some((item) => item.provider === 'google-drive'));
  });

  test('storage scan accepts valid PDF content and rejects mismatched signatures', async () => {
    const storage = services.storage;
    assert.deepEqual(await storage.scanBuffer(Buffer.from('%PDF-1.7\n'), 'policy.pdf'), { status: 'clean' });
    const result = await storage.scanBuffer(Buffer.from('not a pdf'), 'policy.pdf');
    assert.equal(result.status, 'rejected');
    assert.match(result.reason, /signature mismatch/);
  });

  test('storage scan rejects executable content even with an allowed extension', async () => {
    const storage = services.storage;
    const executable = Buffer.concat([Buffer.from('MZ'), Buffer.alloc(20)]);
    const result = await storage.scanBuffer(executable, 'document.pdf');
    assert.deepEqual(result, { status: 'rejected', reason: 'Executable content is not allowed' });
  });

  test('storage scan rejects unsupported file extensions', async () => {
    const result = await services.storage.scanBuffer(Buffer.from('content'), 'payload.exe');
    assert.deepEqual(result, { status: 'rejected', reason: 'File type not allowed' });
  });

  test('storage SHA-256 hashes are deterministic and match Node crypto', () => {
    const input = Buffer.from('vasjo-test-data');
    assert.equal(services.storage.sha256(input), crypto.createHash('sha256').update(input).digest('hex'));
  });
}
}
