'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const p0p1 = fs.readFileSync(path.join(root, 'src/services/p0p1.service.js'), 'utf8');
const p2Routes = fs.readFileSync(path.join(root, 'src/routes/p2.js'), 'utf8');
const enterprise = fs.readFileSync(path.join(root, 'src/services/enterprise.service.js'), 'utf8');
const platform = fs.readFileSync(path.join(root, 'src/services/platform.service.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

 test('worker profile masks statutory and banking fields for non-sensitive viewers', () => {
  assert.match(p0p1, /SENSITIVE_PROFILE_FIELDS\s*=\s*\['uan','pf_number','pan','esi_number','bank_account_no','bank_name'\]/);
  assert.match(p0p1, /sanitizeProfileUser\(u,allowSensitive\)/);
  assert.match(p0p1, /sanitizeHistory\(history,allowSensitive\)/);
  assert.match(p0p1, /employee\.sensitive\.read/);
 });

test('change request approval uses fixed SQL statements and validates manager ownership', () => {
  assert.doesNotMatch(p0p1, /UPDATE users SET \$\{r\.field_name\}/);
  assert.match(p0p1, /case 'bank_account_no'/);
  assert.match(p0p1, /case 'manager_id'/);
  assert.match(p0p1, /Manager not found in tenant/);
});

test('privileged P2 routes have explicit permission middleware', () => {
  const required = [
    "'/api/p2/workflow/delegations'",
    "'/api/p2/onboarding/processes'",
    "'/api/p2/reports/overview'",
    "'/api/p2/documents/:id/share'",
    "'/api/p2/recruitment/offers/:id/accept'",
  ];
  for (const route of required) {
    const line = p2Routes.split('\n').find(x => x.includes(`app.`) && x.includes(route));
    assert.ok(line, `route missing: ${route}`);
    assert.match(line, /authz\.require(Permission|AnyPermission)/, `route lacks RBAC: ${route}`);
  }
});

test('authorization no longer falls back to users.role for workflow role approvals', () => {
  assert.match(enterprise, /if\(step\.approverType==='role'\) return hasPermission\(user,step\.approverValue\);/);
  assert.doesNotMatch(enterprise, /user\.role==='admin'.*step\.approverValue/);
});

test('platform admin detection is permission based', () => {
  assert.match(platform, /async function isAdmin\(ctx\)\{ return enterprise\.hasPermission\(\{permissions:ctx\.permissions\|\|\[\]\},'admin\.configure'\); \}/);
  assert.doesNotMatch(platform, /u\?\.role.*admin/);
});

test('backend dependencies are locked to the tested versions', () => {
  assert.equal(pkg.dependencies['@prisma/client'], '5.22.0');
  assert.equal(pkg.devDependencies.prisma, '5.22.0');
});


test('legacy user lookup APIs are tenant-scoped and profile access is manager-of/admin only', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  const db = fs.readFileSync(path.join(root, 'src/db.js'), 'utf8');
  assert.match(db, /async function findUserById\(id, tenantId = null\)/);
  assert.match(db, /u\.tenant_id = \?/);
  assert.match(server, /db\.findUserById\(id, req\.session\.user\.tenant_id\)/);
  assert.match(server, /targetManager\.manager_id\).*req\.session\.user\.id/);
});

test('employees cannot directly mutate statutory or banking profile fields', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /SENSITIVE_FIELD_CHANGE_REQUEST_REQUIRED/);
  assert.match(server, /\['uan','pfNumber','pan','bankAccountNo','bankName','esiNumber'\]/);
});

test('employee performance permissions are separated from management and calibration', () => {
  assert.match(enterprise, /'Employee':\[[^\]]*'performance\.self'/s);
  assert.doesNotMatch(enterprise, /'Employee':\[[^\]]*'performance\.write'/s);
  assert.match(enterprise, /'Manager':\[[^\]]*'performance\.manage'/s);
  assert.match(enterprise, /'HR Admin':\[[^\]]*'performance\.calibrate'/s);
  assert.match(p2Routes, /\/api\/p2\/calibration.*requirePermission\('performance\.calibrate'\)/);
});

test('payroll access is permission based and tenant scoped', () => {
  const db = fs.readFileSync(path.join(root, 'src/db.js'), 'utf8');
  assert.match(db, /async function canAccessEmployeePayroll[\s\S]*findUserById\(targetUserId, user\.tenant_id\)/);
  assert.match(db, /payroll\.read/);
  assert.doesNotMatch(db, /if \(user\.role === 'admin'\) return true;/);
  assert.doesNotMatch(db, /if \(user\.role !== 'manager'\) return false;/);
});

test('candidate conversion requires recruitment.write and never returns a password', () => {
  assert.match(p2Routes, /recruitment\/candidates\/:id\/convert.*requirePermission\('recruitment\.write'\)/);
  assert.match(platform, /initialPassword/);
  assert.match(platform, /mustResetPassword/);
  assert.doesNotMatch(platform, /temporaryPassword:password/);
});

test('competency and calibration actions cannot be performed by Employee performance.self alone', () => {
  assert.match(p0p1, /performance\.manage/);
  assert.match(p2Routes, /rating-scales.*performance\.calibrate/);
  assert.match(p2Routes, /calibration.*performance\.calibrate/);
});


test('generic /api/me response redacts sensitive fields and self-sensitive endpoint is explicit', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /const safeUser = \{ \.\.\.req\.session\.user \};/);
  assert.match(server, /app\.get\('\/api\/me\/sensitive'/);
  assert.match(server, /bank_account_no/);
});


test('onboarding process creation is management-only, while employee onboarding remains self-service through the existing checklist flow', () => {
  assert.match(p2Routes, /\/api\/p2\/onboarding\/processes.*requireAnyPermission\(\['onboarding\.manage','admin\.configure'\]\)/);
  assert.doesNotMatch(p2Routes, /\/api\/p2\/onboarding\/processes.*employee\.self/);
});

test('payroll legacy endpoints accept canonical payroll permissions and tenant-scope employee lookups', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /\/api\/payroll\/financial-years.*payroll\.read/);
  assert.match(server, /\/api\/admin\/employees\/:userId\/compensation.*payroll\.read/);
  assert.match(server, /assertPayrollAccess\(req, userId\);[\s\S]*db\.findUserById\(userId, req\.session\.user\.tenant_id\)/);
});

test('F&F settlement statement lookup is tenant-scoped', () => {
  const fnf = fs.readFileSync(path.join(root, 'src/services/fnf.service.js'), 'utf8');
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(fnf, /getSettlementStatement\(settlementId, tenantId = null\)/);
  assert.match(fnf, /db\.findUserById\(settlement\.user_id, tenantId\)/);
  assert.match(server, /fnf\.getSettlementStatement\(parseInt\(req\.params\.id, 10\), req\.session\.user\.tenant_id\)/);
});

test('reset-db does not manufacture empty seed passwords', () => {
  const resetDb = fs.readFileSync(path.join(root, 'reset-db.js'), 'utf8');
  assert.doesNotMatch(resetDb, /SEED_(ADMIN|MANAGER|EMPLOYEE)_PASSWORD\s*=\s*process\.env\.SEED_.*\|\|\s*['"]['"]/);
});
