'use strict';
// Phase 1 integration/API/database tests. Real routes + services + SQL against
// SQLite generated from schema.prisma (see helpers/sqlite-prisma.js).
process.removeAllListeners('warning');
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const h = require('./helpers/harness');
const { db, services, call, makeApp, requireAuth } = h;

const app = makeApp();
for (const r of ['approvals', 'documents', 'compliance-rules', 'payroll-controls', 'analytics', 'leave-calendar']) require(`../src/routes/${r}`)(app, { requireAuth });
require('../src/routes/p0p1')(app, { auth: { requireAuth }, authz: services.authorization, asyncHandler: (fn)=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next), tenantCtx: (req)=>services.authorization.contextFrom(req) });

let ids; let U = {};
before(async () => {
  ids = await h.seed();
  for (const k of ['admin', 'mgr', 'mgr2', 'emp', 'emp2', 'orphan', 'other']) U[k] = await h.loadUser(ids[k]);
});
const pdf = (extra = '') => Buffer.from(`%PDF-1.4 ${extra} ${crypto.randomUUID()}`);
const dbrow = (sql, p = []) => db.dbGet(sql, p);

// ===================== RBAC / permission resolver =====================
test('UI-created users get built-in roles: manager can approve, employee cannot', async () => {
  assert.ok(U.mgr.permissions.includes('manager.approve'));
  assert.ok(U.mgr.permissions.includes('expense.approve') && U.mgr.permissions.includes('helpdesk.approve'));
  assert.ok(!U.emp.permissions.includes('expense.approve'));
  assert.ok(!U.emp.permissions.includes('analytics.read'), 'employees must not hold tenant-wide analytics');
  assert.ok(U.admin.permissions.includes('admin.configure'));
  const rows = await db.dbAll('SELECT * FROM user_roles WHERE tenant_id=1 AND user_id=?', [ids.mgr]);
  assert.equal(rows.length, 1, 'user_roles written at creation');
});
test('login-path and request-path resolve identical permissions', async () => {
  const a = (await services.enterprise.permissionsForUser(ids.mgr, 1)).sort();
  assert.deepEqual(a, [...U.mgr.permissions].sort());
});
test('role change syncs RBAC (promoted employee can approve)', async () => {
  const id = await db.createUser({ name: 'Pat Promote', email: 'pat@t.test', role: 'employee', tenantId: 1, joinedDate: '2024-02-01' });
  assert.ok(!(await h.loadUser(id)).permissions.includes('manager.approve'));
  await db.updateUserAdmin(id, { role: 'manager' });
  const after = await h.loadUser(id);
  assert.ok(after.permissions.includes('manager.approve') && after.permissions.includes('expense.approve'));
  await db.updateUserAdmin(id, { role: 'employee' });
  assert.ok(!(await h.loadUser(id)).permissions.includes('manager.approve'), 'demotion revokes');
});
test('users are created in the caller tenant', async () => {
  const u = await dbrow('SELECT tenant_id FROM users WHERE id=?', [ids.other]);
  assert.equal(u.tenant_id, 2);
});

// ===================== Expense approval flow =====================
let claimId;
test('EXPENSE: employee creates draft with lines, total computed', async () => {
  const r = await call(app, 'POST', '/api/expenses', { user: U.emp, body: { claimDate: '2026-09-01', lines: [{ category: 'travel', amount: 120.5 }, { category: 'meals', amount: 30 }] } });
  assert.equal(r.status, 201);
  assert.equal(r.body.status, 'draft'); assert.equal(Number(r.body.total_amount), 150.5); assert.equal(r.body.manager_id, ids.mgr);
  claimId = r.body.id;
});
test('EXPENSE: validation errors are 400', async () => {
  const r = await call(app, 'POST', '/api/expenses', { user: U.emp, body: { lines: [{ amount: -5 }] } });
  assert.equal(r.status, 400); assert.equal(r.body.code, 'VALIDATION_ERROR');
});
test('EXPENSE: manager does not see a draft', async () => {
  const r = await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr });
  assert.equal(r.status, 200); assert.equal(r.body.claims.length, 0);
});
test('EXPENSE: another employee cannot submit it (403); owner submits -> submitted', async () => {
  assert.equal((await call(app, 'POST', `/api/expenses/${claimId}/submit`, { user: U.emp2 })).status, 403);
  const r = await call(app, 'POST', `/api/expenses/${claimId}/submit`, { user: U.emp });
  assert.equal(r.status, 200); assert.equal(r.body.status, 'submitted');
  assert.ok((await dbrow('SELECT submitted_at FROM expense_claims WHERE id=?', [claimId])).submitted_at);
});
test('EXPENSE: submitted claim cannot be edited or re-submitted (state machine)', async () => {
  assert.equal((await call(app, 'POST', `/api/expenses/${claimId}/lines`, { user: U.emp, body: { amount: 5 } })).status, 409);
  const r = await call(app, 'POST', `/api/expenses/${claimId}/submit`, { user: U.emp });
  assert.equal(r.status, 409); assert.equal(r.body.code, 'INVALID_TRANSITION');
});
test('EXPENSE: correct manager sees it; other manager and employee do not', async () => {
  const r = await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr });
  assert.equal(r.body.claims.length, 1); assert.equal(r.body.claims[0].employee_name, 'Eve Employee');
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr2 })).body.claims.length, 0);
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.emp })).status, 403);
});
test('EXPENSE: employee / unrelated manager cannot decide (direct API)', async () => {
  const body = { decision: 'approve' };
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.emp, body })).status, 403);
  assert.equal((await call(app, 'POST', `/api/expenses/${claimId}/decide`, { user: U.emp, body })).status, 403);
  const r = await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.mgr2, body });
  assert.equal(r.status, 403); assert.equal(r.body.code, 'NOT_APPROVER');
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: null, body })).status, 401);
  assert.equal((await dbrow('SELECT status FROM expense_claims WHERE id=?', [claimId])).status, 'submitted');
});
test('EXPENSE: reject requires a comment; bad decision rejected', async () => {
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.mgr, body: { decision: 'reject' } })).status, 400);
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.mgr, body: { decision: 'maybe' } })).status, 400);
});
test('EXPENSE: manager approves -> DB changes -> employee sees Approved', async () => {
  const r = await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.mgr, body: { decision: 'approve', comment: 'ok' } });
  assert.equal(r.status, 200); assert.equal(r.body.status, 'approved');
  const row = await dbrow('SELECT * FROM expense_claims WHERE id=?', [claimId]);
  assert.equal(row.status, 'approved'); assert.equal(row.decided_by, ids.mgr); assert.equal(row.decision_comment, 'ok'); assert.ok(row.decided_at);
  const mine = await call(app, 'GET', '/api/expenses', { user: U.emp });
  assert.equal(mine.body.claims.find((c) => c.id === claimId).status, 'approved');
  const log = await db.dbAll("SELECT action FROM approvals_log WHERE entity_type='expense' AND entity_id=? ORDER BY id", [String(claimId)]);
  assert.deepEqual(log.map((l) => l.action), ['submitted', 'approved']);
  const n = await dbrow("SELECT * FROM notifications WHERE user_id=? AND type='expense.approved'", [ids.emp]);
  assert.ok(n); assert.equal(n.read, 0);
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr })).body.claims.length, 0, 'queue is empty after decision (read-your-writes)');
});
test('EXPENSE: decided claim cannot be decided again (409)', async () => {
  const r = await call(app, 'POST', `/api/approvals/expenses/${claimId}/decide`, { user: U.admin, body: { decision: 'reject', comment: 'no' } });
  assert.equal(r.status, 409); assert.equal(r.body.code, 'ALREADY_DECIDED');
});
test('EXPENSE: admin approves any claim; reject path; self-approval blocked', async () => {
  const c = await call(app, 'POST', '/api/expenses', { user: U.emp2, body: { lines: [{ amount: 50 }] } });
  await call(app, 'POST', `/api/expenses/${c.body.id}/submit`, { user: U.emp2 });
  const rej = await call(app, 'POST', `/api/approvals/expenses/${c.body.id}/decide`, { user: U.admin, body: { decision: 'reject', comment: 'missing receipt' } });
  assert.equal(rej.body.status, 'rejected');
  const own = await call(app, 'POST', '/api/expenses', { user: U.mgr, body: { lines: [{ amount: 10 }] } });
  await call(app, 'POST', `/api/expenses/${own.body.id}/submit`, { user: U.mgr });
  const self = await call(app, 'POST', `/api/approvals/expenses/${own.body.id}/decide`, { user: U.mgr, body: { decision: 'approve' } });
  assert.equal(self.status, 403); assert.equal(self.body.code, 'SELF_APPROVAL');
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${own.body.id}/decide`, { user: U.admin, body: { decision: 'approve' } })).status, 200, 'admin approves manager claim');
});
test('EXPENSE: a claim with no manager is only approvable by admin', async () => {
  const c = await call(app, 'POST', '/api/expenses', { user: await h.loadUser(ids.orphan), body: { lines: [{ amount: 20 }] } });
  await call(app, 'POST', `/api/expenses/${c.body.id}/submit`, { user: await h.loadUser(ids.orphan) });
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr })).body.claims.length, 0);
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.admin })).body.claims.length, 1);
});
test('EXPENSE: delegate of the approver can approve', async () => {
  await db.dbRun('UPDATE users SET delegate_id=? WHERE id=?', [ids.mgr2, ids.mgr]);
  const c = await call(app, 'POST', '/api/expenses', { user: U.emp, body: { lines: [{ amount: 15 }] } });
  await call(app, 'POST', `/api/expenses/${c.body.id}/submit`, { user: U.emp });
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.mgr2 })).body.claims.length, 1);
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${c.body.id}/decide`, { user: U.mgr2, body: { decision: 'approve' } })).status, 200);
  await db.dbRun('UPDATE users SET delegate_id=NULL WHERE id=?', [ids.mgr]);
});
test('EXPENSE: cross-tenant admin cannot see or decide', async () => {
  const c = await call(app, 'POST', '/api/expenses', { user: U.emp, body: { lines: [{ amount: 9 }] } });
  await call(app, 'POST', `/api/expenses/${c.body.id}/submit`, { user: U.emp });
  assert.equal((await call(app, 'POST', `/api/approvals/expenses/${c.body.id}/decide`, { user: U.other, body: { decision: 'approve' } })).status, 404);
  assert.equal((await call(app, 'GET', '/api/approvals/expenses', { user: U.other })).body.claims.length, 0);
});

// ===================== HR request flow =====================
let tid;
test('HR REQUEST: employee submits -> open (pending approval); validation', async () => {
  assert.equal((await call(app, 'POST', '/api/helpdesk/tickets', { user: U.emp, body: {} })).status, 400);
  assert.equal((await call(app, 'POST', '/api/helpdesk/tickets', { user: U.emp, body: { subject: 'x', priority: 'urgent!' } })).status, 400);
  const r = await call(app, 'POST', '/api/helpdesk/tickets', { user: U.emp, body: { subject: 'Employment letter', category: 'Letters', priority: 'high' } });
  assert.equal(r.status, 201); assert.equal(r.body.status, 'open'); tid = r.body.id;
});
test('HR REQUEST: manager sees it, others do not, employee cannot approve', async () => {
  assert.equal((await call(app, 'GET', '/api/approvals/hr-requests', { user: U.mgr })).body.requests.length, 1);
  assert.equal((await call(app, 'GET', '/api/approvals/hr-requests', { user: U.mgr2 })).body.requests.length, 0);
  assert.equal((await call(app, 'GET', '/api/approvals/hr-requests', { user: U.emp })).status, 403);
  assert.equal((await call(app, 'POST', `/api/approvals/hr-requests/${tid}/decide`, { user: U.emp, body: { decision: 'approve' } })).status, 403);
});
test('HR REQUEST: approval cannot be faked through the ticket update endpoint', async () => {
  const r = await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.admin, body: { status: 'approved' } });
  assert.equal(r.status, 403); assert.equal(r.body.code, 'USE_APPROVAL_WORKFLOW');
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.admin, body: { status: 'resolved' } })).status, 409, 'open -> resolved skips approval');
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.emp, body: { status: 'closed' } })).status, 403);
});
test('HR REQUEST: manager approves -> DB changes -> employee sees Approved', async () => {
  const r = await call(app, 'POST', `/api/approvals/hr-requests/${tid}/decide`, { user: U.mgr, body: { decision: 'approve', comment: 'fine' } });
  assert.equal(r.status, 200); assert.equal(r.body.status, 'approved');
  const row = await dbrow('SELECT * FROM service_tickets WHERE id=?', [tid]);
  assert.equal(row.status, 'approved'); assert.equal(row.decided_by, ids.mgr); assert.equal(row.decision_comment, 'fine');
  const mine = await call(app, 'GET', '/api/helpdesk/tickets', { user: U.emp });
  assert.equal(mine.body.tickets.find((t) => t.id === tid).status, 'approved');
  assert.equal((await call(app, 'POST', `/api/approvals/hr-requests/${tid}/decide`, { user: U.mgr, body: { decision: 'reject', comment: 'x' } })).status, 409);
});
test('HR REQUEST: fulfilment transitions + internal notes hidden from requester', async () => {
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.admin, body: { status: 'in_progress' } })).body.status, 'in_progress');
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.admin, body: { status: 'open' } })).status, 409);
  await call(app, 'POST', `/api/helpdesk/tickets/${tid}/notes`, { user: U.admin, body: { note: 'internal only' } });
  await call(app, 'POST', `/api/helpdesk/tickets/${tid}/notes`, { user: U.admin, body: { note: 'public note', internal: false } });
  assert.equal((await call(app, 'GET', `/api/helpdesk/tickets/${tid}/notes`, { user: U.emp })).body.notes.length, 1);
  assert.equal((await call(app, 'GET', `/api/helpdesk/tickets/${tid}/notes`, { user: U.admin })).body.notes.length, 2);
  assert.equal((await call(app, 'GET', `/api/helpdesk/tickets/${tid}/notes`, { user: U.emp2 })).status, 403);
  await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.admin, body: { status: 'resolved', resolution: 'sent' } });
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${tid}`, { user: U.emp, body: { status: 'closed' } })).body.status, 'closed');
});
test('HR REQUEST: rejection needs comment and is terminal', async () => {
  const t = await call(app, 'POST', '/api/helpdesk/tickets', { user: U.emp, body: { subject: 'Laptop upgrade' } });
  assert.equal((await call(app, 'POST', `/api/approvals/hr-requests/${t.body.id}/decide`, { user: U.mgr, body: { decision: 'reject' } })).status, 400);
  assert.equal((await call(app, 'POST', `/api/approvals/hr-requests/${t.body.id}/decide`, { user: U.mgr, body: { decision: 'reject', comment: 'budget' } })).body.status, 'rejected');
  assert.equal((await call(app, 'PATCH', `/api/helpdesk/tickets/${t.body.id}`, { user: U.admin, body: { status: 'in_progress' } })).status, 409);
});

// ===================== Transaction lifecycle =====================
test('TX: a failing request rolls back its writes', async () => {
  const before = (await dbrow('SELECT COUNT(*) n FROM approvals_log')).n;
  const r = await call(app, 'POST', '/api/helpdesk/tickets/999999/notes', { user: U.admin, body: { note: 'x' } });
  assert.equal(r.status, 404);
  assert.equal((await dbrow('SELECT COUNT(*) n FROM approvals_log')).n, before);
});
test('TX: writes are committed before the response is delivered', async () => {
  let seenInsideResponse;
  const original = db.withRequestContext;
  const r = await call(app, 'POST', '/api/expenses', { user: U.emp, body: { lines: [{ amount: 1 }] } });
  seenInsideResponse = await dbrow('SELECT id FROM expense_claims WHERE id=?', [r.body.id]);
  assert.ok(seenInsideResponse);
  assert.equal(db.withRequestContext, original);
});
test('ERR: unknown API route -> 404 envelope; 500 hides internals', async () => {
  const r = await call(app, 'GET', '/api/nope', { user: U.emp });
  assert.equal(r.status, 404); assert.equal(r.body.code, 'NOT_FOUND');
  const { normalizeError } = require('../src/http/error-handler');
  process.env.NODE_ENV = 'production';
  const n = normalizeError(new Error('secret sql detail'));
  process.env.NODE_ENV = 'test';
  assert.equal(n.status, 500); assert.ok(!JSON.stringify(n.body).includes('secret'));
  assert.equal(normalizeError(Object.assign(new Error('dup'), { code: 'P2002' })).status, 409);
  assert.equal(normalizeError(Object.assign(new Error('OVERLAP'), { code: 'OVERLAP' })).status, 400);
});

// ===================== Compliance rules =====================
const rule = { ruleType: 'PF', jurisdiction: 'IN', effectiveFrom: '2026-04-01', value: 12, sourceReference: 'EPF Act' };
let ruleId;
test('COMPLIANCE: list/create/get/update/enable/disable/delete', async () => {
  assert.deepEqual((await call(app, 'GET', '/api/compliance/rules', { user: U.admin })).body.rules, []);
  const c = await call(app, 'POST', '/api/compliance/rules', { user: U.admin, body: rule });
  assert.equal(c.status, 201); ruleId = c.body.id; assert.equal(c.body.active, 1); assert.equal(Number(c.body.value), 12);
  assert.equal((await call(app, 'GET', `/api/compliance/rules/${ruleId}`, { user: U.admin })).body.rule_type, 'PF');
  const u = await call(app, 'PUT', `/api/compliance/rules/${ruleId}`, { user: U.admin, body: { value: 12.5, effectiveTo: '2027-03-31' } });
  assert.equal(Number(u.body.value), 12.5); assert.equal(u.body.effective_to, '2027-03-31'); assert.equal(u.body.updated_by, ids.admin);
  assert.equal((await call(app, 'POST', `/api/compliance/rules/${ruleId}/disable`, { user: U.admin })).body.active, 0);
  assert.equal((await call(app, 'POST', `/api/compliance/rules/${ruleId}/enable`, { user: U.admin })).body.active, 1);
  const list = await call(app, 'GET', '/api/compliance/rules?ruleType=pf&active=1&asOf=2026-06-01', { user: U.admin });
  assert.equal(list.body.rules.length, 1);
  assert.equal((await call(app, 'GET', '/api/compliance/rules?asOf=2028-01-01', { user: U.admin })).body.rules.length, 0);
  const del = await call(app, 'DELETE', `/api/compliance/rules/${ruleId}`, { user: U.admin });
  assert.equal(del.body.active, 0);
  assert.ok(await dbrow('SELECT id FROM compliance_rules WHERE id=?', [ruleId]), 'delete deactivates, history is kept');
  assert.equal(await dbrow("SELECT id FROM audit_events WHERE action='compliance_rule.updated' AND resource_id=?", [String(ruleId)]) !== undefined, true);
});
test('COMPLIANCE: validation, overlap, 404, authorization', async () => {
  const bad = (b) => call(app, 'POST', '/api/compliance/rules', { user: U.admin, body: b });
  assert.equal((await bad({ ...rule, ruleType: 'p f' })).status, 400);
  assert.equal((await bad({ ...rule, effectiveFrom: '01/04/2026' })).status, 400);
  assert.equal((await bad({ ...rule, effectiveFrom: '2026-13-45' })).status, 400);
  assert.equal((await bad({ ...rule, effectiveTo: '2026-01-01' })).status, 400);
  assert.equal((await bad({ ...rule, value: 'abc' })).status, 400);
  assert.equal((await bad({ ruleType: 'ESI', effectiveFrom: '2026-04-01' })).status, 400, 'value or formula required');
  await call(app, 'POST', `/api/compliance/rules/${ruleId}/enable`, { user: U.admin });
  const ov = await bad({ ...rule, effectiveFrom: '2026-10-01' });
  assert.equal(ov.status, 409); assert.equal(ov.body.code, 'RULE_OVERLAP');
  assert.equal((await bad({ ...rule, effectiveFrom: '2027-04-01' })).status, 201, 'non-overlapping successor allowed');
  assert.equal((await call(app, 'GET', '/api/compliance/rules/99999', { user: U.admin })).status, 404);
  assert.equal((await call(app, 'GET', '/api/compliance/rules', { user: U.emp })).status, 403);
  assert.equal((await call(app, 'POST', '/api/compliance/rules', { user: U.mgr, body: rule })).status, 403);
  assert.equal((await call(app, 'GET', '/api/compliance/rules', { user: U.other })).body.rules.length, 0, 'tenant isolation');
});

// ===================== Documents =====================
let docId;
test('DOCUMENTS: static routes are not shadowed by /:id (expiring/types)', async () => {
  const e = await call(app, 'GET', '/api/documents/expiring?daysAhead=30', { user: U.emp });
  assert.equal(e.status, 200); assert.ok(Array.isArray(e.body.documents));
  assert.equal((await call(app, 'GET', '/api/documents/types', { user: U.emp })).status, 200);
  assert.equal((await call(app, 'GET', '/api/documents/expiring?daysAhead=-1', { user: U.emp })).status, 400);
});
test('DOCUMENTS: upload -> metadata -> list -> download (storage + DB)', async () => {
  const body = pdf('passport');
  const up = await call(app, 'POST', '/api/documents/upload?filename=passport.pdf&expiresOn=2020-01-01', { user: U.emp, body, headers: { 'x-file-mime': 'application/pdf' } });
  assert.equal(up.status, 201); docId = up.body.documentId;
  const meta = await call(app, 'GET', `/api/documents/${docId}`, { user: U.emp });
  assert.equal(meta.status, 200); assert.equal(meta.body.original_filename, 'passport.pdf'); assert.equal(meta.body.version_no, 1); assert.equal(meta.body.object_key, undefined);
  assert.equal(meta.body.versions.length, 1);
  const list = await call(app, 'GET', '/api/documents', { user: U.emp });
  assert.equal(list.body.documents.length, 1);
  const dl = await call(app, 'GET', `/api/documents/${docId}/download`, { user: U.emp });
  assert.equal(dl.status, 200); assert.ok(Buffer.isBuffer(dl.body) && dl.body.equals(body), 'streamed bytes equal upload'); assert.match(dl.headers['content-disposition'], /passport\.pdf/);
  assert.equal((await call(app, 'GET', '/api/documents?search=PASS', { user: U.emp })).body.documents.length, 1);
  assert.equal((await call(app, 'GET', '/api/documents/expiring?daysAhead=30', { user: U.emp })).body.documents.length, 1, 'expired doc listed');
  assert.ok(await dbrow("SELECT id FROM audit_events WHERE action='document.download'"));
});
test('DOCUMENTS: unauthorized access is refused everywhere', async () => {
  assert.equal((await call(app, 'GET', `/api/documents/${docId}`, { user: U.emp2 })).status, 403);
  assert.equal((await call(app, 'GET', `/api/documents/${docId}/download`, { user: U.emp2 })).status, 403);
  assert.equal((await call(app, 'DELETE', `/api/documents/${docId}`, { user: U.emp2 })).status, 403);
  assert.equal((await call(app, 'POST', `/api/documents/${docId}/verify`, { user: U.emp, body: { status: 'verified' } })).status, 403);
  assert.equal((await call(app, 'GET', `/api/documents/${docId}`, { user: U.other })).status, 404, 'other tenant');
  assert.equal((await call(app, 'GET', `/api/documents?ownerUserId=${ids.emp}`, { user: U.emp2 })).status, 403);
  assert.equal((await call(app, 'GET', '/api/documents', { user: U.emp2 })).body.documents.length, 0);
  assert.equal((await call(app, 'POST', `/api/documents/upload?filename=a.pdf&ownerUserId=${ids.emp}`, { user: U.emp2, body: pdf() })).status, 403);
  assert.equal((await call(app, 'GET', '/api/documents/not-a-uuid', { user: U.emp })).status, 400);
});
test('DOCUMENTS: HR can read, verify, and versions/restore work', async () => {
  assert.equal((await call(app, 'GET', `/api/documents/${docId}`, { user: U.admin })).status, 200);
  const v = await call(app, 'POST', `/api/documents/${docId}/verify`, { user: U.admin, body: { status: 'verified' } });
  assert.equal(v.body.status, 'verified');
  assert.equal((await call(app, 'POST', `/api/documents/${docId}/verify`, { user: U.admin, body: { status: 'rejected' } })).status, 400);
  const v2 = await call(app, 'POST', `/api/documents/${docId}/versions?filename=passport-v2.pdf`, { user: U.emp, body: pdf('v2') });
  assert.equal(v2.status, 201); assert.equal(v2.body.versionNo, 2);
  const detail = (await call(app, 'GET', `/api/documents/${docId}`, { user: U.emp })).body;
  assert.equal(detail.version_no, 2);
  const first = detail.versions.find((x) => x.version_no === 1);
  const rs = await call(app, 'POST', `/api/documents/${docId}/restore/${first.id}`, { user: U.admin, body: { reason: 'wrong file' } });
  assert.equal(rs.body.version_no, 1);
  assert.equal((await call(app, 'POST', `/api/documents/${docId}/restore/${crypto.randomUUID()}`, { user: U.admin })).status, 404);
});
test('DOCUMENTS: file validation (type, empty, malware signature, duplicate-per-owner)', async () => {
  const up = (name, body, user = U.emp) => call(app, 'POST', `/api/documents/upload?filename=${name}`, { user, body });
  assert.equal((await up('run.exe', Buffer.from('MZ....'))).status, 422);
  assert.equal((await up('empty.pdf', Buffer.alloc(0))).status, 400);
  assert.equal((await up('fake.pdf', Buffer.from('not a pdf'))).status, 422);
  assert.equal((await call(app, 'POST', '/api/documents/upload?filename=a.pdf', { user: U.emp, body: 'text' })).status, 400);
  const same = pdf('dup');
  assert.equal((await up('a.pdf', same)).status, 201);
  const dup = await up('b.pdf', same); assert.equal(dup.status, 409); assert.equal(dup.body.code, 'DUPLICATE_DOCUMENT'); assert.equal(dup.body.documentId, undefined, 'no id leak');
  assert.equal((await up('c.pdf', same, U.emp2)).status, 201, 'same content for a different owner is fine');
});
test('DOCUMENTS: archive hides from list; owner-only', async () => {
  assert.equal((await call(app, 'DELETE', `/api/documents/${docId}`, { user: U.emp })).status, 200);
  assert.ok(!(await call(app, 'GET', '/api/documents', { user: U.emp })).body.documents.some((d) => d.id === docId));
  assert.equal((await dbrow('SELECT status FROM documents WHERE id=?', [docId])).status, 'archived');
});
test('DOCUMENTS: expiry sweep writes notifications with boolean default (no integer literal)', async () => {
  const d = await call(app, 'POST', `/api/documents/upload?filename=visa.pdf&expiresOn=${new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10)}`, { user: U.emp, body: pdf('visa') });
  const res = await services.document.documentExpirySweep({ tenantId: 1, actorId: null, user: U.admin });
  assert.ok(res.some((x) => x.documentId === d.body.documentId));
  assert.ok(await dbrow("SELECT id FROM notifications WHERE type='document.expiry' AND user_id=?", [ids.emp]));
});

// ===================== Leave calendar =====================
function leave(userId, from, to, status, days = 1) {
  return db.dbRun('INSERT INTO leave_applications(tenant_id,id,user_id,leave_type_id,from_date,to_date,days,unit,status,applied_at) VALUES(1,?,?,1,?,?,?,?,?,?)', [crypto.randomUUID(), userId, from, to, days, 'days', status, '2026-08-01']);
}
test('LEAVE CALENDAR: filters, scopes, statuses, validation', async () => {
  await leave(ids.emp, '2026-09-10', '2026-09-12', 'approved', 3);
  await leave(ids.emp, '2026-09-28', '2026-10-02', 'pending', 5); // spans months
  await leave(ids.emp, '2026-09-15', '2026-09-15', 'rejected');
  await leave(ids.emp2, '2026-09-11', '2026-09-11', 'approved');
  const get = (q, user) => call(app, 'GET', `/api/leave/calendar?${q}`, { user });
  let r = await get('from=2026-09-01&to=2026-09-30', U.emp);
  assert.equal(r.status, 200); assert.deepEqual(r.body.map((x) => x.status).sort(), ['approved', 'pending'], 'own leave, rejected hidden by default');
  assert.equal(r.body[0].from_date, '2026-09-10', 'plain YYYY-MM-DD, no timezone shift');
  assert.equal((await get('from=2026-10-01&to=2026-10-31', U.emp)).body.length, 1, 'month-spanning leave shows in next month');
  assert.equal((await get('from=2026-08-01&to=2026-08-31', U.emp)).body.length, 0, 'empty state = []');
  assert.equal((await get('from=2026-09-01&to=2026-09-30&status=all', U.emp)).body.length, 3);
  assert.equal((await get('from=2026-09-01&to=2026-09-30&status=rejected', U.emp)).body.length, 1);
  assert.equal((await get('from=2026-09-01&to=2026-09-30&scope=team', U.mgr)).body.length, 2, 'manager sees own reports only');
  assert.equal((await get('from=2026-09-01&to=2026-09-30&scope=team', U.admin)).body.length, 3, 'admin sees all');
  assert.equal((await get(`from=2026-09-01&to=2026-09-30&scope=team&userId=${ids.emp2}`, U.admin)).body.length, 1, 'employee filter');
  assert.equal((await get(`from=2026-09-01&to=2026-09-30&scope=team&managerId=${ids.mgr2}`, U.admin)).body.length, 1, 'team filter');
  assert.equal((await get('from=2026-09-01&to=2026-09-30&scope=team', U.emp)).status, 403);
  assert.equal((await get('from=2026-09-01&to=2026-09-30', U.emp2)).body.length, 1, 'employee never sees others');
  assert.equal((await get('from=2026-09-01&to=2026-09-30', U.other)).body.length, 0, 'tenant isolation');
  for (const q of ['from=2026-09-01', 'from=2026-13-01&to=2026-09-30', 'from=2026-09-30&to=2026-09-01', 'from=2026-09-01&to=2026-09-30&status=bogus', 'from=2026-09-01&to=2029-09-30']) assert.equal((await get(q, U.emp)).status, 400, q);
});

// ===================== Payroll controls =====================
test('PAYROLL CONTROLS: prechecks detect problems, approval is blocked until cleared/waived, reconciliation validated', async () => {
  await db.dbRun("INSERT INTO financial_years(id,tenant_id,name,start_date,end_date,is_active) VALUES(1,1,'FY26','2026-04-01','2027-03-31',1)");
  await db.dbRun("INSERT INTO payroll_runs(tenant_id,id,financial_year_id,payroll_month,status) VALUES(1,1,1,'2026-09','draft')");
  const run = (m, p, body, user = U.admin) => call(app, m, `/api/payroll/runs/1/${p}`, { user, body });
  assert.equal((await run('GET', 'controls', undefined, U.emp)).status, 403);
  const pre = await run('POST', 'prechecks');
  assert.equal(pre.status, 200);
  const errs = pre.body.checks.filter((c) => c.severity === 'error');
  assert.ok(errs.length >= 5 && errs.every((c) => c.code === 'NO_SALARY_STRUCTURE'), 'active employees without salary structure block payroll');
  const ctl = await run('GET', 'controls');
  assert.equal(ctl.body.blocking, errs.length);
  await assert.rejects(services.payrollControls.assertControlsClear({ tenantId: 1, actorId: ids.admin, user: U.admin }, 1), (e) => e.code === 'PAYROLL_CONTROLS_OPEN' && e.httpStatus === 422);
  assert.equal((await run('POST', `prechecks/${errs[0].id}/waive`, {})).status, 400, 'waive needs reason');
  for (const e of errs) { const w = await run('POST', `prechecks/${e.id}/waive`, { reason: 'contractor, paid off-cycle' }); assert.equal(w.body.status, 'waived', JSON.stringify(w.body)); }
  await services.payrollControls.assertControlsClear({ tenantId: 1, actorId: ids.admin, user: U.admin }, 1); // now passes
  assert.equal((await run('POST', 'reconciliation', { grossTotal: 100, netTotal: 200 })).status, 400);
  assert.equal((await run('POST', 'reconciliation', { grossTotal: 100, netTotal: 80, status: 'weird' })).status, 400);
  const rec = await run('POST', 'reconciliation', { grossTotal: 1000, netTotal: 800, bankTotal: 800, journalTotal: 1000, status: 'reconciled' });
  assert.equal(rec.status, 201); assert.ok(rec.body.reconciled_at);
  assert.equal((await run('GET', 'controls')).body.reconciliation.status, 'reconciled');
  assert.equal((await call(app, 'GET', '/api/payroll/runs/999/controls', { user: U.admin })).status, 404);
  assert.equal((await run('POST', 'reconciliation', { grossTotal: 1, netTotal: 1 }, U.mgr)).status, 403);
});

// ===================== Analytics =====================
test('ANALYTICS: numbers match the database; scoping and filters', async () => {
  const get = (q, user) => call(app, 'GET', `/api/analytics/enterprise${q}`, { user });
  const a = await get('?from=2024-01-01&to=2024-12-31', U.admin);
  const dbActive = (await dbrow("SELECT COUNT(*) n FROM users WHERE tenant_id=1 AND active='active'")).n;
  assert.equal(a.status, 200); assert.equal(a.body.scope, 'tenant');
  assert.equal(a.body.headcount, dbActive);
  assert.equal(a.body.hires30, (await dbrow("SELECT COUNT(*) n FROM users WHERE tenant_id=1 AND joined_date BETWEEN '2024-01-01' AND '2024-12-31'")).n);
  assert.equal(a.body.departmentMix.reduce((s, d) => s + d.count, 0), dbActive);
  assert.equal(a.body.exits30, 0);
  const t = await get('?department=Engineering', U.admin);
  assert.equal(t.body.headcount, (await dbrow("SELECT COUNT(*) n FROM users WHERE tenant_id=1 AND dept='Engineering' AND active='active'")).n);
  const m = await get('', U.mgr);
  assert.equal(m.body.scope, 'team'); assert.equal(m.body.headcount, 1, 'manager sees only direct reports');
  assert.equal((await get('', U.emp)).status, 403);
  assert.equal((await get('?from=bad', U.admin)).status, 400);
  assert.equal((await get('?from=2026-09-30&to=2026-09-01', U.admin)).status, 400);
  assert.equal((await get('', U.other)).body.headcount, 1, 'tenant isolation');
  const empty = await get('?department=Nowhere', U.admin);
  assert.equal(empty.body.headcount, 0); assert.deepEqual(empty.body.departmentMix, []);
  assert.ok((await get('', U.admin)).body.submittedExpenses >= 0);
  const pending = (await dbrow("SELECT COUNT(*) n FROM expense_claims WHERE tenant_id=1 AND status='submitted'")).n;
  assert.equal((await get('', U.admin)).body.submittedExpenses, pending);
});


test('P0/P1: employee profile and onboarding are self-scoped', async () => {
  const p = await call(app,'GET','/api/p0p1/profile',{user:U.emp});
  assert.equal(p.status,200); assert.equal(p.body.summary.id,ids.emp); assert.equal(p.body.manager.id,ids.mgr);
  await db.dbRun("INSERT INTO employee_checklist_tasks(user_id,type,label,status,created_at) VALUES(?,?,?,?,?)",[ids.emp,'onboarding','Upload PAN','pending','2026-09-01']);
  const o = await call(app,'GET','/api/p0p1/onboarding/me',{user:U.emp}); assert.equal(o.status,200); assert.equal(o.body.tasks.length,1);
  assert.equal((await call(app,'GET',`/api/p0p1/onboarding/${ids.emp2}`,{user:U.emp})).status,403);
});

test('P0: goal submission enforces 100 percent weight and preserves check-in history', async () => {
  const c = await db.dbGet("INSERT INTO performance_cycles(tenant_id,name,start_date,end_date,status,rating_scale,created_at) VALUES(?,?,?,?,?,?,?) RETURNING *",[1,'2026 Annual','2026-01-01','2026-12-31','open','1-5','2026-09-01']);
  const g1 = await db.dbGet("INSERT INTO performance_goals(tenant_id,cycle_id,user_id,level,title,weight,progress,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *",[1,c.id,ids.emp,'employee','Deliver platform',60,10,'draft','2026-09-01','2026-09-01']);
  const g2 = await db.dbGet("INSERT INTO performance_goals(tenant_id,cycle_id,user_id,level,title,weight,progress,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *",[1,c.id,ids.emp,'employee','Improve quality',40,20,'draft','2026-09-01','2026-09-01']);
  assert.equal((await call(app,'POST',`/api/p0p1/goals/${g1.id}/submit`,{user:U.emp})).status,200);
  const ci1=await call(app,'POST',`/api/p0p1/goals/${g1.id}/check-ins`,{user:U.emp,body:{progress:30,employeeComment:'API complete'}}); const ci2=await call(app,'POST',`/api/p0p1/goals/${g1.id}/check-ins`,{user:U.emp,body:{progress:55,employeeComment:'Integration complete'}});
  assert.equal(ci1.status,201); assert.equal(ci2.status,201); const hist=await call(app,'GET',`/api/p0p1/goals/${g1.id}/check-ins`,{user:U.emp}); assert.equal(hist.body.checkIns.length,2); assert.equal((await db.dbGet('SELECT progress FROM performance_goals WHERE id=?',[g1.id])).progress,55);
});

test('P0: review workflow submit, finalize, release and acknowledge is stateful', async () => {
  const c = await db.dbGet("SELECT * FROM performance_cycles WHERE tenant_id=1 ORDER BY id DESC LIMIT 1");
  const r = await db.dbGet("INSERT INTO performance_reviews(tenant_id,cycle_id,reviewee_id,reviewer_id,review_type,status,comments,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *",[1,c.id,ids.emp,ids.mgr,'self','draft','draft','2026-09-01']);
  assert.equal((await call(app,'POST',`/api/p0p1/reviews/${r.id}/submit-self`,{user:U.emp})).status,200);
  const m=await call(app,'POST',`/api/p0p1/reviews/${r.id}/submit-manager`,{user:U.mgr,body:{comments:'Manager review'}}); assert.equal(m.status,200);
  assert.equal((await call(app,'POST',`/api/p0p1/reviews/${r.id}/finalize`,{user:U.mgr})).status,200);
  assert.equal((await call(app,'POST',`/api/p0p1/reviews/${r.id}/release`,{user:U.mgr})).status,200);
  const a=await call(app,'POST',`/api/p0p1/reviews/${r.id}/acknowledge`,{user:U.emp}); assert.equal(a.status,200); assert.equal(a.body.status,'ACKNOWLEDGED');
});

test('P0: manager team review queue and unified inbox are permission/tenant scoped', async () => {
  const q=await call(app,'GET','/api/p0p1/team/performance/reviews',{user:U.mgr}); assert.equal(q.status,200); assert.ok(q.body.reviews.some(x=>Number(x.reviewee_id)===ids.emp));
  const inbox=await call(app,'GET','/api/p0p1/inbox',{user:U.mgr}); assert.equal(inbox.status,200); assert.ok(Array.isArray(inbox.body.items));
  assert.equal((await call(app,'GET','/api/p0p1/team/performance/reviews',{user:U.emp2})).status,403);
});
