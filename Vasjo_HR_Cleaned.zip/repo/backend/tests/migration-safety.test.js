'use strict';

const assert = require('node:assert/strict');
const http = require('node:http');
const test = require('node:test');
const express = require('express');
const { createCorsMiddleware, parseCorsOrigins } = require('../src/cors');
const { resolveSeedPassword } = require('../prisma/seed');

test('CORS allow-list permits configured origins and credentials', async (t) => {
  const app = express();
  app.use(createCorsMiddleware({ origin: 'http://localhost:5173,https://erp.example.test', nodeEnv: 'production' }));
  app.get('/health', (_req, res) => res.json({ ok: true }));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  t.after(() => server.close());

  const address = server.address();
  const response = await fetch(`http://127.0.0.1:${address.port}/health`, {
    headers: { Origin: 'https://erp.example.test', 'Access-Control-Request-Headers': 'Authorization' },
  });
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('access-control-allow-origin'), 'https://erp.example.test');
  assert.equal(response.headers.get('access-control-allow-credentials'), 'true');
});

test('CORS rejects unconfigured browser origins and supports preflight', async (t) => {
  const app = express();
  app.use(createCorsMiddleware({ origin: 'https://erp.example.test', nodeEnv: 'production' }));
  app.post('/health', (_req, res) => res.json({ ok: true }));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  t.after(() => server.close());
  const address = server.address();

  const blocked = await fetch(`http://127.0.0.1:${address.port}/health`, {
    headers: { Origin: 'https://unexpected.example.test' },
  });
  assert.equal(blocked.headers.get('access-control-allow-origin'), null);

  const preflight = await fetch(`http://127.0.0.1:${address.port}/health`, {
    method: 'OPTIONS',
    headers: {
      Origin: 'https://erp.example.test',
      'Access-Control-Request-Method': 'POST',
      'Access-Control-Request-Headers': 'Authorization',
    },
  });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-methods').includes('POST'), true);
});

test('seed credentials reject weak values and generate non-empty temporary values', () => {
  const previous = process.env.SEED_ADMIN_PASSWORD;
  process.env.SEED_ADMIN_PASSWORD = 'admin';
  assert.throws(() => resolveSeedPassword('SEED_ADMIN_PASSWORD'), /at least 12 characters/i);
  delete process.env.SEED_ADMIN_PASSWORD;
  const generated = resolveSeedPassword('SEED_ADMIN_PASSWORD');
  assert.equal(generated.generated, true);
  assert.equal(generated.password.length >= 16, true);
  assert.notEqual(generated.password, resolveSeedPassword('SEED_ADMIN_PASSWORD').password);
  if (previous === undefined) delete process.env.SEED_ADMIN_PASSWORD;
  else process.env.SEED_ADMIN_PASSWORD = previous;
});

test('CORS origin parsing canonicalizes and de-duplicates origins', () => {
  assert.deepEqual(parseCorsOrigins('http://localhost:5173/, http://localhost:5173'), ['http://localhost:5173']);
});
