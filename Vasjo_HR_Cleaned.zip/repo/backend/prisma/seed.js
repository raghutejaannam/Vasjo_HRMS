// prisma/seed.js — one-time (idempotent) seed data for a fresh database.
// Run with `npx prisma db seed` (configured in package.json's `prisma.seed`
// field) after migrations have been applied.
//
// Ported from the original seedIfEmpty()/seedDefaultSalaryComponents()/
// seedDefaultTaxRules() functions that used to run automatically on every
// server boot in the SQLite version. Moved here — an explicit, standard
// Prisma seeding step — rather than an automatic startup side effect, which
// is more appropriate for a real Postgres-backed deployment (see the note
// at the top of src/db.js).

const db = require('../src/db');
const services = require('../src/services');
const auth = services.auth;
const payroll = services.payroll;
const enterprise = services.enterprise;
const { nowStr } = services.utils;

const DEFAULT_TENANT_SLUG = 'vasjo';

function isEnabled(value) {
  return String(value || '').toLowerCase() === 'true';
}

function resolveSeedPassword(variableName) {
  const supplied = process.env[variableName];
  if (supplied) {
    auth.assertStrongPassword(supplied);
    return { password: supplied, generated: false };
  }
  return { password: auth.generateTempPassword(), generated: true };
}

async function ensureTenant() {
  const slug = String(process.env.SEED_TENANT_SLUG || DEFAULT_TENANT_SLUG).trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]{1,62}$/.test(slug)) throw new Error('SEED_TENANT_SLUG must contain lowercase letters, numbers, and hyphens only');
  return db.dbGet(`INSERT INTO tenants (slug,name,legal_name,created_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name
    RETURNING *`, [slug, process.env.SEED_TENANT_NAME || 'Vasjo Technologies', process.env.SEED_TENANT_LEGAL_NAME || 'Vasjo Technologies', nowStr()]);
}

async function ensureAuthorizationFoundation(tenantId) {
  // Single implementation shared with runtime user provisioning.
  await enterprise.ensureBuiltInRoles(tenantId);
}

async function createSeedUser({ name, email, role, title, dept, managerId, joinedDate, employeeCode, password }) {
  const existing = await db.findUserByEmail(email);
  if (existing) return existing;
  const credential = auth.hashPassword(password);
  const info = await db.dbInsert(`
    INSERT INTO users (name,email,password_hash,password_salt,role,title,dept,manager_id,joined_date,must_reset_password,employee_code)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?::date, true, ?)
  `, [name, email, credential.hash, credential.salt, role, title, dept, managerId || null, joinedDate, employeeCode || null]);
  return db.findUserById(info.id);
}

async function assignBuiltInRoles(tenantId, user) {
  await db.dbRun(`INSERT INTO tenant_memberships (tenant_id,user_id,role,status,created_at)
    VALUES (?, ?, ?, 'active', ?)
    ON CONFLICT (tenant_id,user_id) DO UPDATE SET role=EXCLUDED.role,status='active'`, [tenantId, user.id, user.role, nowStr()]);
  const roleNames = user.role === 'admin' ? ['HR Admin', 'Payroll Admin'] : [user.role === 'manager' ? 'Manager' : 'Employee'];
  for (const roleName of roleNames) {
    await db.dbRun(`INSERT INTO user_roles(tenant_id,user_id,role_id)
      SELECT ?, ?, id FROM roles WHERE tenant_id=? AND name=? ON CONFLICT DO NOTHING`, [tenantId, user.id, tenantId, roleName]);
  }
}

async function main() {
  if (process.env.NODE_ENV === 'production' && isEnabled(process.env.SEED_DEMO_DATA)) {
    throw new Error('SEED_DEMO_DATA must be false in production');
  }
  const tenant = await ensureTenant();
  await ensureAuthorizationFoundation(tenant.id);
  const adminCredential = resolveSeedPassword('SEED_ADMIN_PASSWORD');
  const managerCredential = isEnabled(process.env.SEED_DEMO_DATA) ? resolveSeedPassword('SEED_MANAGER_PASSWORD') : null;
  const employeeCredential = isEnabled(process.env.SEED_DEMO_DATA) ? resolveSeedPassword('SEED_EMPLOYEE_PASSWORD') : null;

  return db.withRequestContext(tenant.id, async () => {
    console.log(`Seeding tenant ${tenant.slug}...`);

  // ---- Departments -------------------------------------------------------
  const deptNames = ['Engineering', 'Sales', 'Human Resources', 'Finance'];
  for (const name of deptNames) {
    await db.dbRun('INSERT INTO departments (name) VALUES (?) ON CONFLICT (name) DO NOTHING', [name]);
  }

  // ---- Leave types --------------------------------------------------------
  const leaveTypeDefs = [
    ['Annual Leave', 18, 5],
    ['Sick Leave', 10, 0],
    ['Casual Leave', 6, 0],
    ['Maternity/Paternity Leave', 90, 0],
  ];
  for (const [name, annual, carry] of leaveTypeDefs) {
    const existing = await db.dbGet('SELECT id FROM leave_types WHERE name = ?', [name]);
    if (!existing) await db.createLeaveType(name, annual, carry);
  }

  // ---- Company holidays ----------------------------------------------------
  const year = new Date().getFullYear();
  const holidayDefs = [
    [`${year}-01-26`, 'Republic Day'],
    [`${year}-08-15`, 'Independence Day'],
    [`${year}-10-02`, 'Gandhi Jayanti'],
  ];
  for (const [date, name] of holidayDefs) {
    const existing = await db.dbGet('SELECT id FROM company_holidays WHERE holiday_date = ?', [date]);
    if (!existing) await db.addHoliday(date, name, false);
  }

  // ---- Projects & tasks ----------------------------------------------------
  let project = await db.dbGet("SELECT * FROM projects WHERE name = 'Internal Tools'");
  if (!project) {
    const id = await db.createProject('Internal Tools', 'INT-001');
    project = await db.dbGet('SELECT * FROM projects WHERE id = ?', [id]);
    for (const taskName of ['Development', 'Code Review', 'Testing', 'Deployment']) {
      await db.createTask(project.id, taskName);
    }
  }

  // ---- Initial administrator and optional development demonstrations -------
  const admin = await createSeedUser({
    name: 'Asha Administrator', email: process.env.SEED_ADMIN_EMAIL || 'admin@vasjo.local', role: 'admin',
    title: 'HR Administrator', dept: 'Human Resources', joinedDate: `${year}-01-01`, password: adminCredential.password,
  });
  const manager = managerCredential ? await createSeedUser({
    name: 'Manoj Manager', email: process.env.SEED_MANAGER_EMAIL || 'manager@vasjo.local', role: 'manager',
    title: 'Engineering Manager', dept: 'Engineering', managerId: admin.id, joinedDate: `${year}-01-01`, password: managerCredential.password,
  }) : null;
  const employee = employeeCredential ? await createSeedUser({
    name: 'Priya Employee', email: process.env.SEED_EMPLOYEE_EMAIL || 'employee@vasjo.local', role: 'employee',
    title: 'Software Engineer', dept: 'Engineering', managerId: manager.id, joinedDate: `${year}-01-15`, employeeCode: 'EMP-001', password: employeeCredential.password,
  }) : null;

  for (const user of [admin, manager, employee].filter(Boolean)) {
    await assignBuiltInRoles(tenant.id, user);
    await db.dbRun('INSERT INTO employee_projects (user_id, project_id) VALUES (?, ?) ON CONFLICT DO NOTHING', [user.id, project.id]);
    const types = await db.listLeaveTypes(true);
    for (const t of types) {
      await db.ensureLeaveBalance(user.id, t, year, user.joined_date);
    }
  }

  // ---- Financial year + statutory tax rules ---------------------------------
  // Seed runs inside one Prisma transaction. Do not call setActiveFinancialYear()
  // here because that helper opens a nested transaction; the newly inserted FY
  // would not be visible to that nested transaction under PostgreSQL.
  const fyName = `FY ${year}-${String(year + 1).slice(2)}`;
  let fy = await db.getActiveFinancialYear();
  if (!fy) {
    await db.dbRun('UPDATE financial_years SET is_active = false');
    await db.dbRun(
      `INSERT INTO financial_years (name, start_date, end_date, is_active)
       VALUES (?, ?, ?, true)
       ON CONFLICT (name) DO UPDATE SET
         start_date = EXCLUDED.start_date,
         end_date = EXCLUDED.end_date,
         is_active = true`,
      [fyName, `${year}-04-01`, `${year + 1}-03-31`]
    );
    fy = await db.dbGet('SELECT * FROM financial_years WHERE name = ?', [fyName]);
  }
  if (!fy || !fy.id) {
    throw new Error('Unable to establish an active financial year before seeding tax regimes.');
  }
  // Explicit FK preflight: fail here with a useful message instead of a
  // cryptic tax_regimes_financial_year_id_fkey error.
  const fyCheck = await db.getFinancialYear(fy.id);
  if (!fyCheck) {
    throw new Error(`Financial year ${fy.id} was not found before tax regime seeding.`);
  }
  await payroll.ensureStatutoryTaxRules(fy.id);

  // ---- Salary components (master list) --------------------------------------
  const componentDefs = [
    ['BASIC', 'Basic Salary', 'earning', 'fixed', null, null, 1],
    ['HRA', 'House Rent Allowance', 'earning', 'percentage_of_basic', 40, 2],
    ['SPECIAL_ALLOWANCE', 'Special Allowance', 'earning', null, null, 3],
    ['TRANSPORT_ALLOWANCE', 'Transport Allowance', 'earning', 'fixed_amount', 1600, 4],
    ['MEDICAL_ALLOWANCE', 'Medical Allowance', 'earning', 'fixed_amount', 1250, 5],
    ['PF_EMPLOYER', 'Employer PF Contribution', 'earning', 'percentage_of_basic', 12, 6],
    ['BONUS', 'Performance Bonus', 'earning', null, null, 7],
    ['OVERTIME', 'Overtime Pay', 'earning', null, null, 8],
    ['ARREARS', 'Arrears', 'earning', null, null, 9],
    ['REIMBURSEMENT', 'Reimbursement', 'reimbursement', null, null, 10],
    ['PF_EMPLOYEE', 'Employee PF Contribution', 'deduction', 'percentage_of_basic', 12, 11],
    ['PT', 'Professional Tax', 'deduction', null, null, 12],
    ['INSURANCE', 'Group Health Insurance', 'deduction', null, null, 13],
    ['LOAN_RECOVERY', 'Loan Recovery', 'deduction', null, null, 14],
    ['TDS', 'Income Tax (TDS)', 'tax', null, null, 15],
    ['GRATUITY', 'Gratuity Accrual', 'earning', 'percentage_of_basic', 4.81, 16],
  ];
  for (const [code, name, type, calcType, calcValue, order] of componentDefs) {
    const existing = await db.getSalaryComponentByCode(code);
    if (!existing) {
      await db.createSalaryComponent({
        code, name, type, isTaxable: type !== 'reimbursement', isFixed: calcType !== null,
        calculationType: calcType, calculationValue: calcValue, displayOrder: order,
      });
    }
  }

  // ---- Tax declaration sections (Chapter VI-A, old regime) -------------------
  const sectionDefs = [
    ['80C', 'Section 80C', 'PF, ELSS, life insurance, principal repayment on home loan, etc.', 150000, 1, 'old'],
    ['80CCD1B', 'Section 80CCD(1B)', 'Additional NPS contribution', 50000, 2, 'old'],
    ['80D', 'Section 80D', 'Medical insurance premium', 25000, 3, 'old'],
    ['80E', 'Section 80E', 'Interest on education loan', null, 4, 'old'],
    ['80G', 'Section 80G', 'Donations to approved charities', null, 5, 'old'],
    ['24B', 'Section 24(b)', 'Interest on home loan', 200000, 6, 'old'],
    ['HRA_EXEMPTION', 'HRA Exemption', 'House rent paid, for HRA exemption calculation', null, 7, 'old'],
    ['LTA', 'LTA', 'Leave Travel Allowance claims', null, 8, 'old'],
    ['80TTA', 'Section 80TTA', 'Interest on savings account', 10000, 9, 'old'],
    ['NPS_EMPLOYER', 'Section 80CCD(2)', 'Employer NPS contribution', null, 10, 'both'],
  ];
  for (const [code, name, desc, maxLimit, order, regime] of sectionDefs) {
    const existing = await db.dbGet('SELECT id FROM tax_declaration_sections WHERE financial_year_id = ? AND section_code = ?', [fy.id, code]);
    if (!existing) {
      await db.insertTaxDeclarationSection({ financialYearId: fy.id, sectionCode: code, sectionName: name, description: desc, maxLimit, displayOrder: order, applicableRegime: regime });
    }
  }

    console.log('Seed complete. No credentials were written to application logs.');
  });
}

if (require.main === module) {
  main()
    .catch((e) => { console.error(e.message); process.exitCode = 1; })
    .finally(async () => { await db.prisma.$disconnect(); });
}

module.exports = { DEFAULT_TENANT_SLUG, isEnabled, resolveSeedPassword, ensureTenant, ensureAuthorizationFoundation, main };
