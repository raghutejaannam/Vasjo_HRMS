-- 0001_core_modules: consolidated migration history.
-- Apply migrations in numeric order on a new database.

-- ---------------------------------------------------------------------------
-- Consolidated from 0001_init/migration.sql
-- ---------------------------------------------------------------------------
-- 0001_init: PostgreSQL schema for the Vasjo Technologies Timesheet/Leave/Payroll backend.
-- Direct translation of the original SQLite schema (src/db.js). Only the DDL
-- dialect changed (AUTOINCREMENT -> SERIAL/IDENTITY, REAL -> DOUBLE PRECISION,
-- datetime('now') defaults -> to_char(now(),...) producing the exact same
-- 'YYYY-MM-DD HH24:MI:SS' text format the application already relies on).
-- No table, column, or CHECK constraint was dropped.

-- ---------------------------------------------------------------------------
-- CORE / AUTH
-- ---------------------------------------------------------------------------

CREATE TABLE users (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('employee','manager','admin')),
  title TEXT,
  dept TEXT,
  manager_id INTEGER REFERENCES users(id),
  delegate_id INTEGER REFERENCES users(id),
  phone TEXT,
  joined_date TEXT,
  must_reset_password INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  avatar_color TEXT NOT NULL DEFAULT '#C08A2E',
  emergency_contact_name TEXT,
  emergency_contact_phone TEXT,
  employee_code TEXT,
  location TEXT,
  gender TEXT,
  uan TEXT,
  pf_number TEXT,
  pan TEXT,
  bank_account_no TEXT,
  bank_name TEXT,
  employee_group TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  csrf_token TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  expires_at TEXT NOT NULL
);

CREATE TABLE leave_types (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  default_annual_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  max_carry_forward_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE leave_balances (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  leave_type_id INTEGER NOT NULL REFERENCES leave_types(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  total_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  used_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  UNIQUE(user_id, leave_type_id, year)
);

CREATE TABLE timesheets (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  week_start TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('draft','pending','approved','rejected')) DEFAULT 'draft',
  total_hours DOUBLE PRECISION NOT NULL DEFAULT 0,
  overtime_hours DOUBLE PRECISION NOT NULL DEFAULT 0,
  submitted_at TEXT,
  decided_at TEXT,
  decided_by INTEGER REFERENCES users(id),
  last_comment TEXT,
  correction_status TEXT,
  correction_reason TEXT,
  correction_requested_at TEXT,
  escalated INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(user_id, week_start)
);

CREATE TABLE projects (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE tasks (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE employee_projects (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  UNIQUE(user_id, project_id)
);

CREATE TABLE departments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE timesheet_entries (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  timesheet_id TEXT NOT NULL REFERENCES timesheets(id) ON DELETE CASCADE,
  entry_date TEXT NOT NULL,
  hours DOUBLE PRECISION NOT NULL DEFAULT 0,
  note TEXT,
  project_id INTEGER REFERENCES projects(id),
  task_id INTEGER REFERENCES tasks(id),
  work_mode TEXT,
  in_time TEXT,
  out_time TEXT
);

CREATE TABLE leave_applications (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  leave_type_id INTEGER NOT NULL REFERENCES leave_types(id),
  from_date TEXT NOT NULL,
  to_date TEXT NOT NULL,
  days DOUBLE PRECISION NOT NULL,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','cancelled')) DEFAULT 'pending',
  applied_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  decided_at TEXT,
  decided_by INTEGER REFERENCES users(id),
  last_comment TEXT,
  escalated INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE approvals_log (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK(entity_type IN ('timesheet','leave')),
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL CHECK(action IN ('submitted','approved','rejected','cancelled','correction_requested','correction_approved','correction_rejected')),
  actor_id INTEGER NOT NULL REFERENCES users(id),
  acted_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  notes TEXT
);

CREATE TABLE company_holidays (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  holiday_date TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  blackout INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE notifications (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  message TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

-- ---------------------------------------------------------------------------
-- PAYROLL MODULE
-- ---------------------------------------------------------------------------

CREATE TABLE financial_years (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE salary_components (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('earning','deduction','reimbursement','tax')),
  category TEXT,
  is_taxable INTEGER NOT NULL DEFAULT 1,
  is_fixed INTEGER NOT NULL DEFAULT 1,
  calculation_type TEXT,
  calculation_value DOUBLE PRECISION,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE employee_salary_structures (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  annual_ctc DOUBLE PRECISION NOT NULL,
  monthly_ctc DOUBLE PRECISION NOT NULL,
  basic_salary DOUBLE PRECISION NOT NULL,
  offer_letter_path TEXT,
  offer_letter_uploaded_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('draft','active','superseded')) DEFAULT 'draft',
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(user_id, financial_year_id, effective_from)
);

CREATE TABLE salary_structure_components (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  salary_structure_id INTEGER NOT NULL REFERENCES employee_salary_structures(id) ON DELETE CASCADE,
  component_id INTEGER NOT NULL REFERENCES salary_components(id),
  amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  is_override INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(salary_structure_id, component_id)
);

CREATE TABLE tax_regimes (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(financial_year_id, code)
);

CREATE TABLE tax_slabs (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tax_regime_id INTEGER NOT NULL REFERENCES tax_regimes(id) ON DELETE CASCADE,
  min_income DOUBLE PRECISION NOT NULL,
  max_income DOUBLE PRECISION,
  rate DOUBLE PRECISION NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE tax_rules (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tax_regime_id INTEGER NOT NULL REFERENCES tax_regimes(id) ON DELETE CASCADE,
  rule_key TEXT NOT NULL,
  rule_value DOUBLE PRECISION NOT NULL,
  rule_type TEXT NOT NULL CHECK(rule_type IN ('amount','percentage','boolean')),
  description TEXT,
  UNIQUE(tax_regime_id, rule_key)
);

CREATE TABLE deduction_limits (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  section_code TEXT NOT NULL,
  section_name TEXT NOT NULL,
  limit_amount DOUBLE PRECISION NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(financial_year_id, section_code)
);

CREATE TABLE employee_tax_regime (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  tax_regime_id INTEGER NOT NULL REFERENCES tax_regimes(id),
  selected_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  selected_by INTEGER NOT NULL REFERENCES users(id),
  UNIQUE(user_id, financial_year_id)
);

CREATE TABLE tax_declaration_sections (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  section_code TEXT NOT NULL,
  section_name TEXT NOT NULL,
  description TEXT,
  max_limit DOUBLE PRECISION,
  is_active INTEGER NOT NULL DEFAULT 1,
  display_order INTEGER NOT NULL DEFAULT 0,
  applicable_regime TEXT NOT NULL DEFAULT 'old',
  UNIQUE(financial_year_id, section_code)
);

CREATE TABLE tax_declarations (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  section_id INTEGER NOT NULL REFERENCES tax_declaration_sections(id),
  declared_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  eligible_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK(status IN ('draft','submitted','verified','rejected')) DEFAULT 'draft',
  submitted_at TEXT,
  verified_by INTEGER REFERENCES users(id),
  verified_at TEXT,
  rejection_reason TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE tax_declaration_entries (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tax_declaration_id INTEGER NOT NULL REFERENCES tax_declarations(id) ON DELETE CASCADE,
  investment_type TEXT,
  provider_name TEXT,
  amount DOUBLE PRECISION NOT NULL,
  investment_date TEXT,
  financial_year TEXT,
  supporting_doc_path TEXT,
  status TEXT NOT NULL CHECK(status IN ('declared','proof_uploaded','approved','rejected','correction_requested')) DEFAULT 'declared',
  approved_amount DOUBLE PRECISION,
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  rejection_reason TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE fixed_deductions (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  component_id INTEGER NOT NULL REFERENCES salary_components(id),
  amount DOUBLE PRECISION NOT NULL,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE variable_deductions (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payroll_month TEXT NOT NULL,
  component_id INTEGER NOT NULL REFERENCES salary_components(id),
  amount DOUBLE PRECISION NOT NULL,
  reason TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(user_id, payroll_month, component_id)
);

CREATE TABLE previous_employer_income (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  previous_employer_name TEXT,
  gross_income DOUBLE PRECISION NOT NULL DEFAULT 0,
  tds_deducted DOUBLE PRECISION NOT NULL DEFAULT 0,
  professional_tax_paid DOUBLE PRECISION NOT NULL DEFAULT 0,
  joining_date_current_org TEXT,
  document_path TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(user_id, financial_year_id)
);

CREATE TABLE payroll_runs (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  payroll_month TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('draft','calculated','reviewed','approved','locked','disbursed')) DEFAULT 'draft',
  total_employees INTEGER NOT NULL DEFAULT 0,
  total_gross DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_deductions DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_tds DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_net DOUBLE PRECISION NOT NULL DEFAULT 0,
  calculated_by INTEGER REFERENCES users(id),
  calculated_at TEXT,
  reviewed_by INTEGER REFERENCES users(id),
  reviewed_at TEXT,
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  locked_by INTEGER REFERENCES users(id),
  locked_at TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(financial_year_id, payroll_month)
);

CREATE TABLE payroll_details (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  payroll_run_id INTEGER NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  salary_structure_id INTEGER REFERENCES employee_salary_structures(id),

  basic_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  hra_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  allowances_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  variable_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  overtime_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  bonus_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  reimbursement_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  other_earning DOUBLE PRECISION NOT NULL DEFAULT 0,
  gross_earning DOUBLE PRECISION NOT NULL DEFAULT 0,

  pf_employee_deduction DOUBLE PRECISION NOT NULL DEFAULT 0,
  professional_tax_deduction DOUBLE PRECISION NOT NULL DEFAULT 0,
  insurance_deduction DOUBLE PRECISION NOT NULL DEFAULT 0,
  other_fixed_deduction DOUBLE PRECISION NOT NULL DEFAULT 0,
  variable_deductions_total DOUBLE PRECISION NOT NULL DEFAULT 0,
  tds_deduction DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_deductions DOUBLE PRECISION NOT NULL DEFAULT 0,

  taxable_income DOUBLE PRECISION NOT NULL DEFAULT 0,
  annual_taxable_income DOUBLE PRECISION NOT NULL DEFAULT 0,
  annual_tax DOUBLE PRECISION NOT NULL DEFAULT 0,
  monthly_tds DOUBLE PRECISION NOT NULL DEFAULT 0,
  tds_already_deducted DOUBLE PRECISION NOT NULL DEFAULT 0,
  remaining_tax_liability DOUBLE PRECISION NOT NULL DEFAULT 0,

  net_salary DOUBLE PRECISION NOT NULL DEFAULT 0,

  working_days INTEGER NOT NULL DEFAULT 0,
  paid_days INTEGER NOT NULL DEFAULT 0,
  lop_days INTEGER NOT NULL DEFAULT 0,

  status TEXT NOT NULL CHECK(status IN ('calculated','reviewed','approved','adjusted')) DEFAULT 'calculated',
  exception_flags TEXT,
  reviewed_by INTEGER REFERENCES users(id),
  reviewed_at TEXT,
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,

  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(payroll_run_id, user_id)
);

CREATE TABLE payslips (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  payroll_detail_id INTEGER NOT NULL REFERENCES payroll_details(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payroll_month TEXT NOT NULL,
  pdf_path TEXT,
  generated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  generated_by INTEGER NOT NULL REFERENCES users(id),
  downloaded_at TEXT,
  downloaded_by INTEGER REFERENCES users(id),
  UNIQUE(payroll_detail_id)
);

CREATE TABLE payroll_exceptions (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  payroll_run_id INTEGER NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exception_code TEXT NOT NULL,
  exception_message TEXT NOT NULL,
  severity TEXT NOT NULL CHECK(severity IN ('warning','error','info')),
  is_resolved INTEGER NOT NULL DEFAULT 0,
  resolved_by INTEGER REFERENCES users(id),
  resolved_at TEXT,
  resolution_notes TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE payroll_audit_log (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  actor_id INTEGER NOT NULL REFERENCES users(id),
  old_values TEXT,
  new_values TEXT,
  acted_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE payroll_adjustments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  payroll_detail_id INTEGER NOT NULL REFERENCES payroll_details(id) ON DELETE CASCADE,
  adjustment_type TEXT NOT NULL CHECK(adjustment_type IN ('earning','deduction','tds','net')),
  component_id INTEGER REFERENCES salary_components(id),
  amount DOUBLE PRECISION NOT NULL,
  reason TEXT NOT NULL,
  requested_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected')) DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE salary_revisions (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  salary_structure_id INTEGER REFERENCES employee_salary_structures(id) ON DELETE SET NULL,
  previous_annual_ctc DOUBLE PRECISION,
  new_annual_ctc DOUBLE PRECISION NOT NULL,
  previous_monthly_ctc DOUBLE PRECISION,
  new_monthly_ctc DOUBLE PRECISION NOT NULL,
  previous_basic_salary DOUBLE PRECISION,
  new_basic_salary DOUBLE PRECISION,
  hike_percentage DOUBLE PRECISION,
  hike_amount DOUBLE PRECISION,
  effective_date TEXT NOT NULL,
  revision_type TEXT NOT NULL CHECK(revision_type IN ('new_joining','annual_appraisal','mid_year_correction','promotion','market_adjustment','other')),
  reason TEXT,
  notes TEXT,
  approved_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_salary_revisions_user ON salary_revisions(user_id);
CREATE INDEX idx_salary_revisions_effective ON salary_revisions(effective_date);

-- ---------------------------------------------------------------------------
-- Consolidated from 0002_payroll_block4_extensions/migration.sql
-- ---------------------------------------------------------------------------
-- 0002_payroll_block4_extensions
--
-- Additive migration only (no drops, no renames, no data loss) supporting:
--   * formula / conditional salary component calculation types
--   * employee loans + payroll-integrated repayment
--   * salary advances + payroll-integrated recovery
--   * leave encashment payout via payroll
--   * arrears payment generation from retroactive salary revisions
--
-- Safe to run against a database that already has 0001_init applied.

ALTER TABLE salary_components ADD COLUMN formula TEXT;
ALTER TABLE salary_components ADD COLUMN conditional_rule TEXT;

ALTER TABLE salary_revisions ADD COLUMN is_retroactive INTEGER NOT NULL DEFAULT 0;

ALTER TABLE payroll_details ADD COLUMN loan_deduction DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE payroll_details ADD COLUMN advance_recovery_deduction DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE payroll_details ADD COLUMN arrears_earning DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE payroll_details ADD COLUMN leave_encashment_earning DOUBLE PRECISION NOT NULL DEFAULT 0;

CREATE TABLE loans (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  principal_amount DOUBLE PRECISION NOT NULL,
  interest_rate_annual DOUBLE PRECISION NOT NULL DEFAULT 0,
  tenure_months INTEGER NOT NULL,
  emi_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  outstanding_balance DOUBLE PRECISION NOT NULL DEFAULT 0,
  purpose TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','active','closed','cancelled')) DEFAULT 'pending',
  requested_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  disbursed_at TEXT,
  closed_at TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_loans_user ON loans(user_id);

CREATE TABLE loan_repayments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  loan_id INTEGER NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
  payroll_detail_id INTEGER REFERENCES payroll_details(id) ON DELETE SET NULL,
  payroll_month TEXT NOT NULL,
  amount DOUBLE PRECISION NOT NULL,
  principal_component DOUBLE PRECISION NOT NULL DEFAULT 0,
  interest_component DOUBLE PRECISION NOT NULL DEFAULT 0,
  balance_after DOUBLE PRECISION NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_loan_repayments_loan ON loan_repayments(loan_id);

CREATE TABLE salary_advances (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount DOUBLE PRECISION NOT NULL,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','recovering','closed')) DEFAULT 'pending',
  requested_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  recovery_months INTEGER NOT NULL DEFAULT 1,
  monthly_recovery_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  outstanding_balance DOUBLE PRECISION NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_salary_advances_user ON salary_advances(user_id);

CREATE TABLE advance_recoveries (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  advance_id INTEGER NOT NULL REFERENCES salary_advances(id) ON DELETE CASCADE,
  payroll_detail_id INTEGER REFERENCES payroll_details(id) ON DELETE SET NULL,
  payroll_month TEXT NOT NULL,
  amount DOUBLE PRECISION NOT NULL,
  balance_after DOUBLE PRECISION NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_advance_recoveries_advance ON advance_recoveries(advance_id);

CREATE TABLE leave_encashments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  leave_type_id INTEGER NOT NULL REFERENCES leave_types(id),
  financial_year_id INTEGER NOT NULL REFERENCES financial_years(id),
  days DOUBLE PRECISION NOT NULL,
  per_day_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','paid')) DEFAULT 'pending',
  requested_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  payroll_detail_id INTEGER REFERENCES payroll_details(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_leave_encashments_user ON leave_encashments(user_id);

CREATE TABLE arrears_payments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  salary_revision_id INTEGER REFERENCES salary_revisions(id) ON DELETE SET NULL,
  for_payroll_month TEXT NOT NULL,
  amount DOUBLE PRECISION NOT NULL,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','paid')) DEFAULT 'pending',
  payroll_detail_id INTEGER REFERENCES payroll_details(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_arrears_payments_user ON arrears_payments(user_id);

-- ---------------------------------------------------------------------------
-- Consolidated from 0003_attendance_block2/migration.sql
-- ---------------------------------------------------------------------------
-- 0003_attendance_block2
--
-- Additive migration only. Adds the Attendance Management module: shifts,
-- shift assignments, one attendance_records row per employee per day, and
-- correction/regularization requests. Nothing here touches existing tables
-- except adding two new company_holidays-adjacent settings keys, which are
-- written at the application layer (src/db.js updateSettings), not schema.

CREATE TABLE shifts (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  grace_period_minutes INTEGER NOT NULL DEFAULT 10,
  break_minutes INTEGER NOT NULL DEFAULT 60,
  full_day_min_minutes INTEGER NOT NULL DEFAULT 480,
  half_day_min_minutes INTEGER NOT NULL DEFAULT 240,
  is_night_shift INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

CREATE TABLE shift_assignments (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  shift_id INTEGER NOT NULL REFERENCES shifts(id),
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_shift_assignments_user ON shift_assignments(user_id);

CREATE TABLE attendance_records (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  shift_id INTEGER REFERENCES shifts(id),
  check_in_at TEXT,
  check_out_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('present','absent','half_day','wfh','on_duty','holiday','weekly_off','leave','pending')) DEFAULT 'pending',
  worked_minutes DOUBLE PRECISION NOT NULL DEFAULT 0,
  late_minutes INTEGER NOT NULL DEFAULT 0,
  early_leave_minutes INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL CHECK(source IN ('check_in_out','manual','regularization')) DEFAULT 'check_in_out',
  notes TEXT,
  marked_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  UNIQUE(user_id, date)
);
CREATE INDEX idx_attendance_records_user ON attendance_records(user_id);
CREATE INDEX idx_attendance_records_date ON attendance_records(date);

CREATE TABLE attendance_correction_requests (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  attendance_record_id INTEGER REFERENCES attendance_records(id) ON DELETE SET NULL,
  requested_check_in_at TEXT,
  requested_check_out_at TEXT,
  requested_status TEXT,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected')) DEFAULT 'pending',
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_attendance_correction_user ON attendance_correction_requests(user_id);

-- ---------------------------------------------------------------------------
-- Consolidated from 0004_compliance_block5/migration.sql
-- ---------------------------------------------------------------------------
-- 0004_compliance_block5
--
-- Additive migration only. Block 5 (Tax & Compliance) turned out to need
-- almost no new schema — tax_declarations, tax_declaration_entries (with
-- proof upload + verify/reject), previous_employer_income, tax_regimes,
-- tax_slabs, tax_rules and deduction_limits already existed and already
-- covered the declaration/proof/verification workflow and the old-vs-new
-- regime comparison. This migration only adds the one column genuinely
-- missing: an ESI number on the employee record, needed for the new ESI
-- compliance report (src/compliance.js).

ALTER TABLE users ADD COLUMN esi_number TEXT;

-- ---------------------------------------------------------------------------
-- Consolidated from 0005_fnf_block6/migration.sql
-- ---------------------------------------------------------------------------
-- 0005_fnf_block6
--
-- Additive migration only. Block 6 (Full & Final Settlement) needed a
-- minimal resignation/exit record (employee_separations) since the full
-- Employee Lifecycle module (Block 1: onboarding, transfers, promotions,
-- exit workflow) hasn't been built yet — this is deliberately scoped to
-- just what F&F needs (resignation date, last working date, notice period),
-- not a general-purpose lifecycle/status-history table. If Block 1 gets
-- built later, employee_separations is a natural table for it to extend
-- rather than replace.

CREATE TABLE employee_separations (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resignation_date TEXT NOT NULL,
  last_working_date TEXT NOT NULL,
  notice_period_required_days INTEGER NOT NULL,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','withdrawn','exited')) DEFAULT 'pending',
  initiated_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_employee_separations_user ON employee_separations(user_id);

CREATE TABLE fnf_settlements (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  employee_separation_id INTEGER NOT NULL UNIQUE REFERENCES employee_separations(id) ON DELETE CASCADE,
  unpaid_salary_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  unpaid_salary_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  notice_recovery_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  notice_recovery_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  leave_encashment_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  leave_encashment_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  bonus_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  gratuity_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  reimbursements_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  loan_recovery_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  advance_recovery_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  asset_recovery_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  other_deductions_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  other_deductions_notes TEXT,
  total_earnings DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_deductions DOUBLE PRECISION NOT NULL DEFAULT 0,
  final_payable DOUBLE PRECISION NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK(status IN ('draft','pending_approval','approved','paid')) DEFAULT 'draft',
  prepared_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  paid_at TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_fnf_settlements_user ON fnf_settlements(user_id);

-- ---------------------------------------------------------------------------
-- Consolidated from 0006_leave_block3/migration.sql
-- ---------------------------------------------------------------------------
-- 0006_leave_block3
--
-- Additive migration only. Extends the existing leave_applications /
-- leave_balances tables with a few new columns (unit, sandwich flag,
-- comp-off link, multi-level approval tracking; carried-forward days +
-- expiry) and adds three new tables: leave_policies (employee/department-
-- specific overrides of a leave type's defaults), comp_offs, and
-- leave_approvals (the per-level audit trail for multi-level approval).

ALTER TABLE leave_applications ADD COLUMN unit TEXT NOT NULL DEFAULT 'day';
ALTER TABLE leave_applications ADD COLUMN is_sandwich INTEGER NOT NULL DEFAULT 0;
ALTER TABLE leave_applications ADD COLUMN comp_off_id INTEGER;
ALTER TABLE leave_applications ADD COLUMN current_approval_level INTEGER NOT NULL DEFAULT 1;
ALTER TABLE leave_applications ADD COLUMN required_approval_levels INTEGER NOT NULL DEFAULT 1;

ALTER TABLE leave_balances ADD COLUMN carried_forward_days DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE leave_balances ADD COLUMN carry_forward_expires_on TEXT;

CREATE TABLE leave_policies (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  leave_type_id INTEGER NOT NULL REFERENCES leave_types(id) ON DELETE CASCADE,
  department_name TEXT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  annual_days DOUBLE PRECISION NOT NULL,
  accrual_method TEXT NOT NULL CHECK(accrual_method IN ('annual','monthly')) DEFAULT 'annual',
  monthly_accrual_days DOUBLE PRECISION,
  carry_forward_enabled INTEGER NOT NULL DEFAULT 0,
  max_carry_forward_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  carry_forward_expiry_months INTEGER NOT NULL DEFAULT 3,
  min_service_days_before_eligible INTEGER NOT NULL DEFAULT 0,
  allow_negative_balance INTEGER NOT NULL DEFAULT 0,
  max_negative_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  is_sandwich_leave INTEGER NOT NULL DEFAULT 0,
  unit TEXT NOT NULL CHECK(unit IN ('day','hour')) DEFAULT 'day',
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_leave_policies_type ON leave_policies(leave_type_id);

CREATE TABLE comp_offs (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  worked_date TEXT NOT NULL,
  earned_days DOUBLE PRECISION NOT NULL DEFAULT 1,
  reason TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','used','expired')) DEFAULT 'pending',
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  expires_on TEXT,
  used_in_application_id TEXT REFERENCES leave_applications(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_comp_offs_user ON comp_offs(user_id);

CREATE TABLE leave_approvals (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  leave_application_id TEXT NOT NULL REFERENCES leave_applications(id) ON DELETE CASCADE,
  level INTEGER NOT NULL,
  approver_id INTEGER NOT NULL REFERENCES users(id),
  decision TEXT NOT NULL CHECK(decision IN ('approved','rejected')),
  comment TEXT,
  decided_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_leave_approvals_application ON leave_approvals(leave_application_id);

-- ---------------------------------------------------------------------------
-- Consolidated from 0007_lifecycle_block1/migration.sql
-- ---------------------------------------------------------------------------
-- 0007_lifecycle_block1
--
-- Additive migration only. Adds one column to users (lifecycle_status) and
-- six new tables. employee_lifecycle_events is deliberately a single
-- append-only timeline covering employment history, department/designation/
-- manager/location changes, promotions, probation milestones, and status
-- changes — one table instead of five near-identical ones. Resignation/exit
-- itself is already tracked by employee_separations (Block 6); this
-- migration adds exit_interviews and offboarding checklist tasks as the
-- pieces of Block 1 that specifically attach to that.

ALTER TABLE users ADD COLUMN lifecycle_status TEXT NOT NULL DEFAULT 'active';

CREATE TABLE employee_lifecycle_events (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK(event_type IN (
    'joined','department_transfer','designation_change','manager_change','location_change',
    'promotion','probation_started','probation_confirmed','probation_extended','status_change','resigned','exited'
  )),
  previous_value TEXT,
  new_value TEXT,
  effective_date TEXT NOT NULL,
  notes TEXT,
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_lifecycle_events_user ON employee_lifecycle_events(user_id);

CREATE TABLE probation_records (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  expected_end_date TEXT NOT NULL,
  actual_confirmation_date TEXT,
  status TEXT NOT NULL CHECK(status IN ('on_probation','confirmed','extended')) DEFAULT 'on_probation',
  extended_to_date TEXT,
  notes TEXT,
  confirmed_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  updated_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_probation_records_user ON probation_records(user_id);

CREATE TABLE employee_documents (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL,
  file_path TEXT,
  issue_date TEXT,
  expiry_date TEXT,
  uploaded_by INTEGER NOT NULL REFERENCES users(id),
  uploaded_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_employee_documents_user ON employee_documents(user_id);
CREATE INDEX idx_employee_documents_expiry ON employee_documents(expiry_date);

CREATE TABLE checklist_template_items (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  type TEXT NOT NULL CHECK(type IN ('onboarding','offboarding')),
  label TEXT NOT NULL,
  description TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE employee_checklist_tasks (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  employee_separation_id INTEGER REFERENCES employee_separations(id) ON DELETE CASCADE,
  template_item_id INTEGER REFERENCES checklist_template_items(id),
  type TEXT NOT NULL CHECK(type IN ('onboarding','offboarding')),
  label TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pending','completed','skipped')) DEFAULT 'pending',
  completed_by INTEGER REFERENCES users(id),
  completed_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);
CREATE INDEX idx_checklist_tasks_user ON employee_checklist_tasks(user_id);

CREATE TABLE exit_interviews (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  employee_separation_id INTEGER NOT NULL UNIQUE REFERENCES employee_separations(id) ON DELETE CASCADE,
  conducted_by INTEGER NOT NULL REFERENCES users(id),
  conducted_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS'),
  reason_for_leaving TEXT,
  feedback TEXT,
  would_rehire INTEGER,
  rating INTEGER,
  created_at TEXT NOT NULL DEFAULT to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS')
);

-- A small, sensible default checklist so the feature isn't empty out of the box.
INSERT INTO checklist_template_items (type, label, description, display_order) VALUES
  ('onboarding', 'Collect signed offer letter', 'Countersigned copy on file', 1),
  ('onboarding', 'Collect ID & address proof', 'PAN, Aadhar or equivalent', 2),
  ('onboarding', 'Set up payroll bank details', 'Bank account and IFSC captured', 3),
  ('onboarding', 'Provision system access', 'Email, tools, building access', 4),
  ('onboarding', 'Assign onboarding buddy / manager intro', NULL, 5),
  ('offboarding', 'Knowledge transfer completed', NULL, 1),
  ('offboarding', 'Return company assets', 'Laptop, ID card, access cards', 2),
  ('offboarding', 'Revoke system access', NULL, 3),
  ('offboarding', 'Exit interview conducted', NULL, 4),
  ('offboarding', 'Full & final settlement processed', NULL, 5);
