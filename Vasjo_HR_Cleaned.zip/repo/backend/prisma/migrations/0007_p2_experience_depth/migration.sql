CREATE TABLE IF NOT EXISTS background_verification_cases (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, worker_id INTEGER NOT NULL, provider TEXT NOT NULL,
  case_type TEXT NOT NULL, status TEXT NOT NULL, reference TEXT, notes TEXT, created_by INTEGER,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_background_cases_worker ON background_verification_cases(tenant_id, worker_id);
CREATE TABLE IF NOT EXISTS document_share_links (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, document_id TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL, max_uses INTEGER NOT NULL DEFAULT 1, used_count INTEGER NOT NULL DEFAULT 0,
  watermark INTEGER NOT NULL DEFAULT 1, created_by INTEGER NOT NULL, created_at TEXT NOT NULL, revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_document_share_links_document ON document_share_links(tenant_id, document_id);
CREATE TABLE IF NOT EXISTS rating_scales (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, name TEXT NOT NULL, description TEXT, active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(tenant_id, name)
);
CREATE TABLE IF NOT EXISTS rating_scale_values (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, scale_id TEXT NOT NULL, value NUMERIC NOT NULL, label TEXT NOT NULL,
  description TEXT, sort_order INTEGER NOT NULL DEFAULT 0, UNIQUE(tenant_id, scale_id, value)
);
CREATE TABLE IF NOT EXISTS shift_swap_requests (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, requester_id INTEGER NOT NULL, target_user_id INTEGER NOT NULL,
  shift_id INTEGER NOT NULL, swap_date TEXT NOT NULL, reason TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shift_swap_users ON shift_swap_requests(tenant_id, requester_id, target_user_id);
CREATE TABLE IF NOT EXISTS asset_requests (
  id TEXT PRIMARY KEY, tenant_id INTEGER NOT NULL, user_id INTEGER NOT NULL, category TEXT NOT NULL, name TEXT NOT NULL,
  reason TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_asset_requests_user ON asset_requests(tenant_id, user_id);
ALTER TABLE service_tickets ADD COLUMN IF NOT EXISTS satisfaction_rating INTEGER;
ALTER TABLE service_tickets ADD COLUMN IF NOT EXISTS satisfaction_comment TEXT;
