-- 0005: approval engine columns, RBAC repair, query-path indexes.
-- Additive except the one Employee analytics.read revocation noted below.

-- Approval decision trail (approval.service.js)
ALTER TABLE expense_claims  ADD COLUMN IF NOT EXISTS submitted_at TEXT;
ALTER TABLE expense_claims  ADD COLUMN IF NOT EXISTS decided_by INTEGER;
ALTER TABLE expense_claims  ADD COLUMN IF NOT EXISTS decided_at TEXT;
ALTER TABLE expense_claims  ADD COLUMN IF NOT EXISTS decision_comment TEXT;
ALTER TABLE service_tickets ADD COLUMN IF NOT EXISTS decided_by INTEGER;
ALTER TABLE service_tickets ADD COLUMN IF NOT EXISTS decided_at TEXT;
ALTER TABLE service_tickets ADD COLUMN IF NOT EXISTS decision_comment TEXT;

-- Compliance rule maintenance trail
ALTER TABLE compliance_rules ADD COLUMN IF NOT EXISTS updated_at TEXT;
ALTER TABLE compliance_rules ADD COLUMN IF NOT EXISTS updated_by INTEGER;

-- New approval permissions
INSERT INTO permissions (code, description, resource, action, created_at) VALUES
  ('expense.approve',  'Approve or reject expense claims', 'expense',  'approve', ''),
  ('helpdesk.approve', 'Approve or reject HR requests',    'helpdesk', 'approve', '')
ON CONFLICT (code) DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('expense.approve', 'helpdesk.approve')
WHERE r.name IN ('Manager', 'HR Admin') AND r.is_system = 1
ON CONFLICT DO NOTHING;

-- Managers/HR must be able to use the approval queues end to end.
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('manager.approve', 'expense.read', 'expense.write', 'helpdesk.read', 'helpdesk.write', 'reports.read')
WHERE r.name IN ('Manager', 'HR Admin') AND r.is_system = 1
ON CONFLICT DO NOTHING;

-- Tenant-wide analytics are not an Employee permission (REVOKE: the only non-additive statement).
DELETE FROM role_permissions
WHERE role_id IN (SELECT id FROM roles WHERE name = 'Employee' AND is_system = 1)
  AND permission_id IN (SELECT id FROM permissions WHERE code = 'analytics.read');

-- Backfill: every user gets a tenant membership and a built-in role matching users.role.
-- (user_roles used to be written only by the seed, so UI-created users had no roles.)
INSERT INTO tenant_memberships (tenant_id, user_id, role, status, created_at)
SELECT u.tenant_id, u.id, u.role, 'active', '' FROM users u
ON CONFLICT (tenant_id, user_id) DO NOTHING;

INSERT INTO user_roles (tenant_id, user_id, role_id)
SELECT u.tenant_id, u.id, r.id FROM users u
JOIN roles r ON r.tenant_id = u.tenant_id
 AND r.name = CASE u.role WHEN 'manager' THEN 'Manager' WHEN 'admin' THEN 'HR Admin' ELSE 'Employee' END
WHERE NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.tenant_id = u.tenant_id AND ur.user_id = u.id)
ON CONFLICT DO NOTHING;

INSERT INTO user_roles (tenant_id, user_id, role_id)
SELECT u.tenant_id, u.id, r.id FROM users u
JOIN roles r ON r.tenant_id = u.tenant_id AND r.name = 'Payroll Admin'
WHERE u.role = 'admin'
ON CONFLICT DO NOTHING;

-- Query-path indexes for the approval queues and audit trail
CREATE INDEX IF NOT EXISTS idx_expense_claims_status_mgr ON expense_claims (tenant_id, status, manager_id);
CREATE INDEX IF NOT EXISTS idx_service_tickets_status ON service_tickets (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_approvals_log_entity ON approvals_log (tenant_id, entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_compliance_rules_type ON compliance_rules (tenant_id, rule_type, active);
