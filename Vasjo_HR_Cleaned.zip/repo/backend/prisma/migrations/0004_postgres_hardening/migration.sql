-- PostgreSQL hardening after the engine migration. This migration is additive
-- and data-preserving: invalid historical temporal values are retained as NULL
-- rather than causing a destructive cast.

ALTER TABLE tenants ADD COLUMN IF NOT EXISTS slug TEXT;
UPDATE tenants
SET slug = CASE
  WHEN id = 1 THEN 'vasjo'
  ELSE 'tenant-' || id::text
END
WHERE slug IS NULL OR btrim(slug) = '';
ALTER TABLE tenants ALTER COLUMN slug SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS tenants_slug_key ON tenants(slug);

CREATE OR REPLACE FUNCTION vasjo_safe_date(value TEXT) RETURNS DATE LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF value IS NULL OR btrim(value) = '' THEN RETURN NULL; END IF;
  RETURN value::date;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION vasjo_safe_timestamptz(value TEXT) RETURNS TIMESTAMPTZ LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF value IS NULL OR btrim(value) = '' THEN RETURN NULL; END IF;
  RETURN value::timestamptz;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

-- Event times use a real instant. Date-only values stay DATE so that payroll
-- and leave calculations do not acquire a time zone accidentally.
ALTER TABLE users
  ALTER COLUMN joined_date TYPE DATE USING vasjo_safe_date(joined_date),
  ALTER COLUMN created_at DROP NOT NULL,
  ALTER COLUMN created_at DROP DEFAULT,
  ALTER COLUMN created_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(created_at),
  ALTER COLUMN must_reset_password DROP DEFAULT,
  ALTER COLUMN must_reset_password TYPE BOOLEAN USING CASE WHEN must_reset_password::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN must_reset_password SET DEFAULT false;
ALTER TABLE sessions
  ALTER COLUMN created_at DROP NOT NULL,
  ALTER COLUMN created_at DROP DEFAULT,
  ALTER COLUMN created_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(created_at),
  ALTER COLUMN expires_at DROP NOT NULL,
  ALTER COLUMN expires_at DROP DEFAULT,
  ALTER COLUMN expires_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(expires_at);
ALTER TABLE leave_applications
  ALTER COLUMN from_date TYPE DATE USING vasjo_safe_date(from_date),
  ALTER COLUMN to_date TYPE DATE USING vasjo_safe_date(to_date),
  ALTER COLUMN applied_at DROP NOT NULL,
  ALTER COLUMN applied_at DROP DEFAULT,
  ALTER COLUMN applied_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(applied_at),
  ALTER COLUMN decided_at DROP DEFAULT,
  ALTER COLUMN decided_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(decided_at);
ALTER TABLE timesheets
  ALTER COLUMN week_start TYPE DATE USING vasjo_safe_date(week_start),
  ALTER COLUMN submitted_at DROP DEFAULT,
  ALTER COLUMN submitted_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(submitted_at),
  ALTER COLUMN decided_at DROP DEFAULT,
  ALTER COLUMN decided_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(decided_at),
  ALTER COLUMN created_at DROP NOT NULL,
  ALTER COLUMN created_at DROP DEFAULT,
  ALTER COLUMN created_at TYPE TIMESTAMPTZ USING vasjo_safe_timestamptz(created_at);

-- The selected flags are boolean concepts, not counters. Existing 0/1 values
-- are converted explicitly; non-standard historical values fail closed.
ALTER TABLE leave_types
  ALTER COLUMN active DROP DEFAULT,
  ALTER COLUMN active TYPE BOOLEAN USING CASE WHEN active::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN active SET DEFAULT true;
ALTER TABLE timesheets
  ALTER COLUMN escalated DROP DEFAULT,
  ALTER COLUMN escalated TYPE BOOLEAN USING CASE WHEN escalated::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN escalated SET DEFAULT false;
ALTER TABLE company_holidays
  ALTER COLUMN blackout DROP DEFAULT,
  ALTER COLUMN blackout TYPE BOOLEAN USING CASE WHEN blackout::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN blackout SET DEFAULT false;
ALTER TABLE notifications
  ALTER COLUMN read DROP DEFAULT,
  ALTER COLUMN read TYPE BOOLEAN USING CASE WHEN read::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN read SET DEFAULT false;
ALTER TABLE financial_years
  ALTER COLUMN is_active DROP DEFAULT,
  ALTER COLUMN is_active TYPE BOOLEAN USING CASE WHEN is_active::text IN ('1','true','t','yes') THEN true ELSE false END,
  ALTER COLUMN is_active SET DEFAULT false;

-- Enforce finite state machines for new writes without rejecting historical
-- data while it is reviewed. PostgreSQL enforces NOT VALID constraints for all
-- subsequent INSERT/UPDATE operations.
ALTER TABLE leave_applications DROP CONSTRAINT IF EXISTS leave_applications_status_check;
ALTER TABLE leave_applications ADD CONSTRAINT leave_applications_status_check
  CHECK (status IN ('pending','approved','rejected','cancelled')) NOT VALID;
ALTER TABLE timesheets DROP CONSTRAINT IF EXISTS timesheets_status_check;
ALTER TABLE timesheets ADD CONSTRAINT timesheets_status_check
  CHECK (status IN ('draft','pending','approved','rejected')) NOT VALID;
ALTER TABLE ai_document_extractions ADD CONSTRAINT ai_document_extractions_status_check
  CHECK (status IN ('queued','processing','completed','partial','failed','confirmed')) NOT VALID;

-- Permissions used by the canonical authorization middleware.
INSERT INTO permissions (code,description,resource,action,created_at)
VALUES
  ('employee.self','Access own employee data','employee','self',to_char(now() AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS')),
  ('manager.approve','Approve manager work queues','manager','approve',to_char(now() AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS'))
ON CONFLICT (code) DO NOTHING;
INSERT INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.code = 'manager.approve'
WHERE r.name IN ('Manager','HR Admin') ON CONFLICT DO NOTHING;
INSERT INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.code = 'employee.self'
WHERE r.name IN ('Employee','Manager','HR Admin') ON CONFLICT DO NOTHING;

DROP FUNCTION vasjo_safe_date(TEXT);
DROP FUNCTION vasjo_safe_timestamptz(TEXT);
