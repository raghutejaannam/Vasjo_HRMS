-- 0002_enterprise_foundation: consolidated migration history.
-- Apply migrations in numeric order on a new database.

-- ---------------------------------------------------------------------------
-- Consolidated from 0009_enterprise_foundation/migration.sql
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- VASJO HCM P0/P1 enterprise foundation.
-- Regression-fixed migration: corrected nested dollar-quoting in the dynamic tenant trigger function.
CREATE TABLE IF NOT EXISTS tenants (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  legal_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  locale TEXT NOT NULL DEFAULT 'en-IN',
  currency TEXT NOT NULL DEFAULT 'INR',
  country TEXT NOT NULL DEFAULT 'IN',
  subscription_plan TEXT NOT NULL DEFAULT 'standard',
  created_at TEXT NOT NULL DEFAULT ''
);
INSERT INTO tenants (id, name, legal_name, created_at)
VALUES (1, 'Default Tenant', 'Vasjo Technologies', to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
ON CONFLICT (id) DO NOTHING;
SELECT setval(pg_get_serial_sequence('tenants','id'), GREATEST((SELECT COALESCE(MAX(id),1) FROM tenants),1), true);

CREATE TABLE IF NOT EXISTS tenant_memberships (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL DEFAULT 'employee',
  status TEXT NOT NULL DEFAULT 'active',
  employee_id INTEGER,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, user_id)
);

CREATE TABLE IF NOT EXISTS permissions (
  id SERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  description TEXT,
  resource TEXT,
  action TEXT,
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS roles (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, name)
);
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);
CREATE TABLE IF NOT EXISTS user_roles (
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (tenant_id, user_id, role_id)
);

CREATE TABLE IF NOT EXISTS audit_events (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  actor_id INTEGER,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  before_json JSONB,
  after_json JSONB,
  timestamp TEXT NOT NULL DEFAULT '',
  request_id TEXT,
  ip TEXT,
  user_agent TEXT,
  outcome TEXT NOT NULL DEFAULT 'success'
);

CREATE TABLE IF NOT EXISTS feature_flags (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0,
  config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, key)
);

CREATE TABLE IF NOT EXISTS document_types (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code TEXT,
  required INTEGER NOT NULL DEFAULT 0,
  expiry_enabled INTEGER NOT NULL DEFAULT 0,
  expiry_reminders TEXT NOT NULL DEFAULT '90,60,30,15,7,1,0',
  verification_policy TEXT NOT NULL DEFAULT 'hr',
  sensitive INTEGER NOT NULL DEFAULT 0,
  allowed_extensions TEXT NOT NULL DEFAULT 'pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv',
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, name)
);
CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_type_id INTEGER REFERENCES document_types(id),
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_verification',
  verification_status TEXT NOT NULL DEFAULT 'pending',
  current_version_id UUID,
  owner_user_id INTEGER,
  linked_module TEXT,
  linked_resource_id TEXT,
  expires_on TEXT,
  retention_until TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS document_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version_no INTEGER NOT NULL,
  object_key TEXT NOT NULL,
  checksum_sha256 TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  mime_type TEXT NOT NULL,
  source TEXT NOT NULL,
  source_reference TEXT,
  original_filename TEXT NOT NULL,
  uploaded_by INTEGER,
  upload_reason TEXT,
  malware_status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (document_id, version_no),
  UNIQUE (tenant_id, checksum_sha256)
);
ALTER TABLE documents ADD CONSTRAINT documents_current_version_fk FOREIGN KEY (current_version_id) REFERENCES document_versions(id) DEFERRABLE INITIALLY DEFERRED;
CREATE TABLE IF NOT EXISTS document_links (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, document_id, resource_type, resource_id)
);
CREATE TABLE IF NOT EXISTS document_access_policies (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_type_id INTEGER REFERENCES document_types(id) ON DELETE CASCADE,
  permission_code TEXT NOT NULL,
  resource_scope TEXT NOT NULL DEFAULT 'tenant'
);
CREATE TABLE IF NOT EXISTS document_audit_logs (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  actor_id INTEGER,
  action TEXT NOT NULL,
  version_id UUID,
  reason TEXT,
  created_at TEXT NOT NULL DEFAULT '',
  metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS document_import_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  source_reference TEXT NOT NULL,
  filename TEXT,
  status TEXT NOT NULL DEFAULT 'queued',
  error TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  source_url TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS document_retention_policies (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_type_id INTEGER REFERENCES document_types(id) ON DELETE CASCADE,
  retention_days INTEGER NOT NULL DEFAULT 2555,
  archive_after_days INTEGER,
  allow_secure_delete INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, document_type_id)
);

CREATE TABLE IF NOT EXISTS workflow_definitions (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  module TEXT NOT NULL,
  name TEXT NOT NULL,
  trigger_event TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, module, name)
);
CREATE TABLE IF NOT EXISTS workflow_steps (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  workflow_id INTEGER NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
  step_no INTEGER NOT NULL,
  approval_mode TEXT NOT NULL DEFAULT 'sequential',
  approver_type TEXT NOT NULL,
  approver_value TEXT,
  condition_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  sla_hours INTEGER,
  escalation_type TEXT,
  escalation_value TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE (workflow_id, step_no)
);
CREATE TABLE IF NOT EXISTS workflow_instances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  workflow_id INTEGER NOT NULL REFERENCES workflow_definitions(id),
  module TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  current_step INTEGER NOT NULL DEFAULT 1,
  initiated_by INTEGER,
  due_at TEXT,
  created_at TEXT NOT NULL DEFAULT '',
  completed_at TEXT,
  UNIQUE (tenant_id, workflow_id, resource_id, status)
);
CREATE TABLE IF NOT EXISTS workflow_actions (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  instance_id UUID NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  step_no INTEGER NOT NULL,
  actor_id INTEGER,
  action TEXT NOT NULL,
  comment TEXT,
  acted_at TEXT NOT NULL DEFAULT '',
  metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS workflow_delegations (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  delegator_id INTEGER NOT NULL,
  delegate_id INTEGER NOT NULL,
  starts_on TEXT NOT NULL,
  ends_on TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  reason TEXT
);

CREATE TABLE IF NOT EXISTS notification_templates (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  channel TEXT NOT NULL DEFAULT 'in_app',
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE (tenant_id, code, channel)
);
CREATE TABLE IF NOT EXISTS notification_deliveries (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  template_id INTEGER REFERENCES notification_templates(id),
  recipient_user_id INTEGER NOT NULL,
  channel TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  attempts INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  sent_at TEXT,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, idempotency_key, channel)
);

CREATE TABLE IF NOT EXISTS organizations (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  parent_id INTEGER REFERENCES organizations(id),
  kind TEXT NOT NULL,
  code TEXT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  effective_from TEXT,
  effective_to TEXT,
  created_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, kind, code)
);
CREATE TABLE IF NOT EXISTS cost_centers (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE (tenant_id, code)
);
CREATE TABLE IF NOT EXISTS job_families (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  UNIQUE (tenant_id, name)
);
CREATE TABLE IF NOT EXISTS job_grades (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  family_id INTEGER REFERENCES job_families(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  band TEXT,
  UNIQUE (tenant_id, code)
);
CREATE TABLE IF NOT EXISTS positions (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  position_code TEXT NOT NULL,
  title TEXT NOT NULL,
  grade_id INTEGER REFERENCES job_grades(id),
  department_id INTEGER REFERENCES departments(id),
  cost_center_id INTEGER REFERENCES cost_centers(id),
  location TEXT,
  manager_id INTEGER,
  status TEXT NOT NULL DEFAULT 'open',
  budget_amount NUMERIC,
  effective_from TEXT,
  effective_to TEXT,
  UNIQUE (tenant_id, position_code)
);
CREATE TABLE IF NOT EXISTS employee_history (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  field_name TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  reason TEXT,
  changed_by INTEGER,
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS employee_org_assignments (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  organization_id INTEGER REFERENCES organizations(id),
  position_id INTEGER REFERENCES positions(id),
  primary_manager_id INTEGER,
  dotted_line_manager_id INTEGER,
  work_arrangement TEXT,
  worker_type TEXT,
  employment_type TEXT,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  created_at TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS payroll_prechecks (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payroll_run_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  code TEXT NOT NULL,
  message TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'error',
  status TEXT NOT NULL DEFAULT 'open',
  resolved_by INTEGER,
  resolved_at TEXT,
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS payroll_reconciliations (
  id BIGSERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payroll_run_id INTEGER NOT NULL,
  gross_total NUMERIC NOT NULL DEFAULT 0,
  net_total NUMERIC NOT NULL DEFAULT 0,
  employer_cost_total NUMERIC NOT NULL DEFAULT 0,
  bank_total NUMERIC NOT NULL DEFAULT 0,
  journal_total NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  reconciled_by INTEGER,
  reconciled_at TEXT,
  created_at TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS compliance_rules (
  id SERIAL PRIMARY KEY,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  rule_type TEXT NOT NULL,
  jurisdiction TEXT,
  employee_category TEXT,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  value NUMERIC,
  formula TEXT,
  source_reference TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT ''
);


ALTER TABLE notifications ADD COLUMN IF NOT EXISTS title TEXT;
-- All existing business tables receive tenant ownership. User/session records remain
-- application-authorized because login must resolve the tenant before a request context exists.
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.tables
           WHERE table_schema='public' AND table_name NOT IN ('tenants','tenant_memberships','permissions','roles','role_permissions','user_roles','audit_events','feature_flags','document_types','documents','document_versions','document_links','document_access_policies','document_audit_logs','document_import_jobs','document_retention_policies','workflow_definitions','workflow_steps','workflow_instances','workflow_actions','workflow_delegations','notification_templates','notification_deliveries','organizations','cost_centers','job_families','job_grades','positions','employee_history','employee_org_assignments','payroll_prechecks','payroll_reconciliations','compliance_rules')
  LOOP
    BEGIN
      EXECUTE format('ALTER TABLE %I ADD COLUMN IF NOT EXISTS tenant_id INTEGER NOT NULL DEFAULT 1 REFERENCES tenants(id)', r.table_name);
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;

-- Membership for all existing users. Role string is kept for backward compatibility.
INSERT INTO tenant_memberships (tenant_id, user_id, role, status, created_at)
SELECT 1, id, role, CASE WHEN active=1 THEN 'active' ELSE 'inactive' END, COALESCE(created_at,'') FROM users
ON CONFLICT (tenant_id,user_id) DO UPDATE SET role=EXCLUDED.role, status=EXCLUDED.status;

-- Seed built-in permissions and roles for the default tenant.
INSERT INTO permissions (code, description, resource, action, created_at) VALUES
('employee.read','Read employee records','employee','read',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('employee.write','Update employee records','employee','write',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('employee.*','All employee permissions','employee','*',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('lifecycle.*','All lifecycle permissions','lifecycle','*',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('document.self','Employee document access','document','self',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('document.read','Read documents','document','read',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('document.upload','Upload documents','document','upload',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('document.verify','Verify documents','document','verify',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('workflow.manage','Manage workflows','workflow','manage',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('workflow.act','Act on workflows','workflow','act',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('payroll.read','Read payroll','payroll','read',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('payroll.calculate','Calculate payroll','payroll','calculate',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('payroll.review','Review payroll','payroll','review',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('payroll.approve','Approve payroll','payroll','approve',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('payroll.lock','Lock payroll','payroll','lock',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('leave.approve','Approve leave','leave','approve',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('timesheet.approve','Approve timesheets','timesheet','approve',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('audit.read','Read audit events','audit','read',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('reports.read','Read reports','reports','read',to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
('admin.configure','Manage tenant configuration','admin','configure',to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
ON CONFLICT (code) DO NOTHING;
INSERT INTO roles (tenant_id,name,description,is_system,created_at) VALUES
(1,'HR Admin','Full HR administration',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
(1,'Payroll Admin','Payroll maker/admin',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
(1,'Payroll Reviewer','Payroll checker/reviewer',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
(1,'Manager','People manager',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
(1,'Employee','Employee self-service',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS')),
(1,'Auditor','Read-only audit access',1,to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
ON CONFLICT (tenant_id,name) DO NOTHING;

-- Built-in role mapping. Legacy admin users get HR Admin + Payroll Admin.
INSERT INTO user_roles (tenant_id,user_id,role_id)
SELECT tm.tenant_id, tm.user_id, r.id FROM tenant_memberships tm JOIN roles r ON r.tenant_id=tm.tenant_id
WHERE (tm.role='admin' AND r.name IN ('HR Admin','Payroll Admin'))
   OR (tm.role='manager' AND r.name='Manager')
   OR (tm.role='employee' AND r.name='Employee')
ON CONFLICT DO NOTHING;

-- Tenant context injection for inserts into legacy/new tenant-owned tables.
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.columns
           WHERE table_schema='public' AND column_name='tenant_id'
  LOOP
    IF r.table_name IN ('tenants','tenant_memberships','permissions','roles','role_permissions','user_roles') THEN CONTINUE; END IF;
    EXECUTE format($f$
      CREATE OR REPLACE FUNCTION set_%I_tenant()
      RETURNS trigger
      LANGUAGE plpgsql
      AS $func$
      DECLARE
        t INTEGER;
      BEGIN
        t := NULLIF(current_setting('app.tenant_id', true), '')::INTEGER;
        IF t IS NOT NULL THEN
          NEW.tenant_id := t;
        END IF;
        RETURN NEW;
      END;
      $func$;
      $f$, r.table_name);
    EXECUTE format('DROP TRIGGER IF EXISTS %I_tenant_trigger ON %I', r.table_name, r.table_name);
    EXECUTE format('CREATE TRIGGER %I_tenant_trigger BEFORE INSERT ON %I FOR EACH ROW EXECUTE FUNCTION set_%I_tenant()', r.table_name, r.table_name, r.table_name);
  END LOOP;
END $$;

-- RLS protects all business/enterprise data in authenticated request transactions.
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.columns
           WHERE table_schema='public' AND column_name='tenant_id'
  LOOP
    IF r.table_name IN ('tenants','users','sessions') THEN CONTINUE; END IF;
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', r.table_name);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation_policy ON %I', r.table_name);
    EXECUTE format($p$
      CREATE POLICY tenant_isolation_policy ON %I
      USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER)
      WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER)
    $p$, r.table_name);
  END LOOP;
END $$;

CREATE INDEX IF NOT EXISTS idx_audit_events_tenant_time ON audit_events(tenant_id,timestamp);
CREATE INDEX IF NOT EXISTS idx_documents_tenant_owner ON documents(tenant_id,owner_user_id);
CREATE INDEX IF NOT EXISTS idx_document_versions_tenant_checksum ON document_versions(tenant_id,checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_workflow_instances_tenant_resource ON workflow_instances(tenant_id,module,resource_id,status);
CREATE INDEX IF NOT EXISTS idx_employee_history_tenant_user_effective ON employee_history(tenant_id,user_id,effective_from,effective_to);
CREATE INDEX IF NOT EXISTS idx_employee_org_assignments_tenant_user_effective ON employee_org_assignments(tenant_id,user_id,effective_from,effective_to);
CREATE INDEX IF NOT EXISTS idx_compliance_rules_tenant_type_effective ON compliance_rules(tenant_id,rule_type,effective_from,effective_to);

CREATE TABLE IF NOT EXISTS integration_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  account_label TEXT,
  access_token_enc TEXT,
  refresh_token_enc TEXT,
  expires_at TEXT,
  scopes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT '',
  UNIQUE (tenant_id, provider, account_label)
);
CREATE TABLE IF NOT EXISTS oauth_states (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  state_hash TEXT NOT NULL UNIQUE,
  code_verifier TEXT,
  created_at TEXT NOT NULL DEFAULT '',
  expires_at TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
ALTER TABLE integration_connections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS integration_connections_tenant ON integration_connections;
CREATE POLICY integration_connections_tenant ON integration_connections
USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER)
WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER);
-- oauth_states is intentionally not RLS-protected because the OAuth callback is unauthenticated; the state hash is the authorization boundary.

-- Users are tenant-scoped. Authentication gets a narrowly scoped transaction-level lookup
-- exemption so login can discover the user's tenant before a tenant context exists.
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS users_tenant_policy ON users;
CREATE POLICY users_tenant_policy ON users
USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER OR current_setting('app.auth_lookup', true)='true')
WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::INTEGER OR current_setting('app.auth_lookup', true)='true');
