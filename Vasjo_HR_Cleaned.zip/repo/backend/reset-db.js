'use strict';
// Development helper: wipes every application table (derived from
// prisma/schema.prisma, so it can never drift) and restarts identities.
//   node reset-db.js            (refuses in production unless CONFIRM_RESET=yes)
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
process.env.SEED_DEMO_DATA = 'false';

if (process.env.NODE_ENV === 'production' && process.env.CONFIRM_RESET !== 'yes') {
  console.error('Refusing to reset a production database (set CONFIRM_RESET=yes to override).');
  process.exit(1);
}
const db = require('./src/db');
const schema = fs.readFileSync(path.join(__dirname, 'prisma/schema.prisma'), 'utf8');
const tables = [...schema.matchAll(/@@map\("(\w+)"\)/g)].map((m) => m[1]);

(async () => {
  await db.dbRun(`TRUNCATE TABLE ${tables.join(', ')} RESTART IDENTITY CASCADE`);
  console.log(`Truncated ${tables.length} tables.`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
