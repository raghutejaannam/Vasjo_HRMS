# Vasjo HR Platform — P2 Implementation

This release extends the existing P0/P1 implementation. It does not replace payroll, tax calculation, attendance, leave, compliance, RBAC, or the enterprise document backbone.

## P2 implemented

### Core HR / lifecycle
- My reporting line / org tree
- Employee offboarding self-service and exit interview
- Background verification case tracking
- 30/60/90 onboarding journey tasks

### Documents
- Secure share links with expiry and max-use controls
- Document template CRUD and token rendering
- E-sign envelope persistence/adapter entry point
- AI document extraction surfaced for human validation

### Performance / talent
- Structured rating scales and values
- Calibration session and rating adjustment audit
- PIP creation/listing
- Skill-gap/development-plan UI using LearningSkills

### Workforce
- Team leave calendar data surface
- Shift swap request/decision API
- Employee asset request workflow
- Helpdesk satisfaction capture

### Payroll / tax
- Annual tax statement/Form-16 data surface from payroll records
- Tax-regime comparison UI using the existing tax-regime catalogue

### Recruitment
- Interview scheduling
- Candidate-to-employee conversion
- Offer acceptance command

### Learning / benefits
- Mandatory course enrollment
- Benefits plan guided enrollment

### Workflow / analytics
- Approval delegation self-service
- Phase-2 HR experience overview metrics

## Important production limitations
- E-sign provider calls are represented by the existing adapter/envelope model; provider-specific network integration is not hard-coded.
- Document watermarking is stored as a share-link policy but is not rendered into files by this release.
- Tax comparison is an estimation surface and must not replace the existing statutory tax calculation engine.
- Candidate conversion returns a temporary credential in the authenticated admin/recruitment response; production delivery should move this to a secure invitation/reset channel.
- P2 pages use the existing API/data model and are intentionally incremental rather than a frontend rewrite.
