# VASJO HCM — Architecture Baseline (snapshot taken before Phase 1 changes)

Method: static inspection of `backend-fixed.zip` / `frontend-fixed.zip`. No live PostgreSQL was available, so
runtime behaviour below is inferred from code, not observed. Items marked **(verified offline)** were confirmed by
the SQLite-backed test harness added in Phase 1; PostgreSQL-specific claims are marked **(unverified on PG)**.

## Frontend
React 18 + Vite, plain JSX, no router library (page registry + nav config in `pages.jsx`), one API client
(`api.js`, ~310 calls, cookie session + CSRF header). Pages are split across `pages.jsx` (core/leave/attendance/
payroll/approvals), `advancedPages.jsx` (expenses, helpdesk, analytics, …), `enterprisePages.jsx` (documents,
workflows, org, payroll controls, compliance rules, security). Shared UI in `components.jsx`.
Known weaknesses: most pages load with `Promise.all` and no error state (one failed call = endless spinner);
permission-gated buttons were shown to everyone.

## Backend
Node 20+/Express 4, Prisma 5 client, PostgreSQL. Layout (before): `server.js` (≈1950 lines, every route),
`db.js` (access layer + user/leave queries), `services.js` (≈4,200-line factory bundle of 13 modules),
`cors.js`. Tests: `unit.test.js` (no DB), `regression.test.js` (needs PostgreSQL), `migration-safety.test.js`.

## Database
PostgreSQL, ~125 tables, defined by `prisma/schema.prisma` + hand-written SQL migrations `0001`–`0004`
(append-only). Multi-tenancy = `tenant_id` column on business tables + Row-Level Security keyed on
`app.tenant_id`, set per request by `db.withRequestContext` (AsyncLocalStorage carries the transaction).
Data access is overwhelmingly **raw SQL** through `db.dbGet/dbAll/dbRun` (`?` placeholders converted to Prisma
tagged SQL); Prisma models exist mainly as schema source of truth.

## API
~357 REST routes under `/api/*`, JSON, session cookie `session`, CSRF token on mutating calls.

## Authentication
scrypt password hashes, DB-backed sessions (12h), CSRF token per session, login rate limiting (in memory).

## Authorization — five competing mechanisms (before Phase 1)
1. `req.session.user.role === 'admin'` (16 places in `server.js`) — reads the mutable legacy column.
2. `auth.requireRoleMw(['manager','admin'])` — maps role labels to permissions (~135 uses).
3. `enterprise.requirePermission('x.y')` (~129 uses).
4. Per-service helpers (`isAdmin`, `canSeeUser` in platform; `canAccessEmployeePayroll`).
5. Frontend-only hiding of buttons.
Two different permission resolvers existed: `permissionsForUser` (login, full built-in matrix) and
`enrichEnterpriseIdentity` (every later request, reduced fallback list when the user has no `user_roles` rows).
`user_roles` was written only by the migration/seed, never at runtime.

## Approval workflow
Leave, timesheets, corrections, loans, advances, comp-off, encashment: each has its own approve endpoint and
status handling. Expense claims and HR requests (service tickets): ad-hoc decide functions in `platform`,
guarded by `expense.write` / `helpdesk.write` + role label; HR request "approve" set `in_progress`; no state
machine, no self-approval guard, comment overwrote `notes`/`resolution`.

## Service structure
`services.js` = object of 13 factories `{ utils, integrationAdapters, auth, attendance, compliance(statutory),
fnf, leave, lifecycle, payroll, reports, enterprise, platform, storage }` with an internal `require` shim.

## Known legacy / duplicate code
- Comments only (no runtime code) referencing the former SQLite implementation; `sqlite`-named helpers in `utils`.
- `reset-db.js` listed 10 tables that do not exist and omitted 92 that do.
- `enterprise` and `platform` each held unrelated domains (documents, payroll controls, compliance rules,
  expenses, tickets, analytics).
- Duplicate role/permission seeding logic (seed vs. runtime).
- `zod` and `pg` are declared but unused in source (left in place: changing them requires regenerating the lockfile).

## Known broken modules → see `PHASE1_REPORT.md`
