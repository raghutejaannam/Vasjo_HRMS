# Vasjo HR Platform - P0/P1 implementation drop

This drop extends the existing Phase 1 codebase. It does not rebuild the Node/Express + raw-SQL/Prisma/PostgreSQL architecture.

## Implemented P0

- Permission-aware navigation additions and Recruitment permission gating.
- Employee-scoped onboarding endpoint and `/me/onboarding` UI.
- Manager new-hire onboarding progress endpoint and UI.
- Canonical enterprise document experience at `/me/documents` and a separate HR verification queue.
- Existing EmployeeDocument remains legacy/read-compatible; new self-service document writes use the enterprise document API.
- Goal submission with 100% active-weight validation.
- Goal progress history through `goal_check_ins`.
- Self-review / manager-review state transitions: submit, return, finalize, release, acknowledge.
- Mid-year/annual review data is retained from existing cycle configuration and shown in review UX.
- Team performance review queue.
- Unified Inbox endpoint aggregating leave, performance, document and onboarding work items.
- Worker Profile V1 using existing user/org/history/document/performance data.
- Reusable EmployeePicker component.
- URL/deep-link routing foundation for the new P0 destinations.
- P0 integration tests for profile isolation, onboarding, goal workflow, review workflow and manager queue/inbox.

## P1 foundation implemented

- Document taxonomy surfaced through the enterprise document types.
- Document request records with employee fulfilment.
- 360/peer feedback request and response records/UI API surface.
- Competency catalogue and review competency ratings.
- Change-request workflow for sensitive worker fields instead of direct employee writes.
- Additive onboarding process/task tables for expansion of preboarding and 30/60/90-day journeys.
- Additive document template/e-sign envelope persistence primitives.
- Worker profile photo storage field (`users.photo_url`) prepared for the existing storage adapter.

## Existing functionality reused

- Enterprise Documents / DocumentVersions / DocumentTypes.
- Existing checklist APIs.
- Existing performance cycles/goals/reviews/feedback/PIP/calibration APIs.
- Existing RBAC and permission resolver.
- Existing audit events.
- Existing learning, benefits, recruitment, workflow and payroll modules remain intact.

## Migration

Apply migration `0006_p0_p1_hr_experience` after migration 0005 and before starting the new backend. It is additive and introduces no replacement of payroll, tax, leave, attendance, compliance or RBAC foundations.

## Verification

- Backend JavaScript syntax check: passed for all `src/*.js` files.
- Existing Phase 1 integration suite plus new P0/P1 workflow tests: **43/43 passed offline** using the repository's SQLite compatibility harness.
- PostgreSQL-specific verification and browser E2E were not available in this environment. Run `prisma validate`, `prisma migrate deploy`, frontend `vite build`, and the full PostgreSQL regression suite in CI/staging before production deployment.
