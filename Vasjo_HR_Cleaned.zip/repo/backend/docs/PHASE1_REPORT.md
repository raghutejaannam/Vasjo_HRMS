# Phase 1 Report

## Read this first — what was and was not verified
* No PostgreSQL, Prisma engine, Vite or browser was available in the working environment.
* Verified: **147/147 offline tests pass** (108 pre-existing unit tests + 39 new `tests/phase1.test.js`),
  the frontend bundles with esbuild, `server.js` loads with 357 routes and no duplicate registrations,
  `tsc` finds no undefined identifiers in the backend, and frontend→backend route diff shows no missing routes.
* The new tests run the real routes/services/SQL on SQLite generated from `schema.prisma`. They prove logic,
  authorization, workflow, column names and parameter arity. They **cannot** prove PostgreSQL typing (uuid/boolean),
  RLS, or browser behaviour. Fixes for those are marked *(unverified on PG)*.
* **Not run:** `regression.test.js`, `migration-safety.test.js` (need PostgreSQL / installed deps), `prisma validate`,
  `vite build`, browser E2E, manual browser-console/network review. Step 17 (full regression) is therefore **open**.

## 1. Root causes
| Area | Root cause | Evidence |
|---|---|---|
| Expense / HR request approval | (a) `user_roles` never written at runtime; (b) login and per-request permission resolvers diverged, the latter falling back to a list without `manager.approve`/`expense.write`/`helpdesk.write`; (c) HR approve set `in_progress`; (d) response sent before COMMIT → stale reload; (e) no state machine / self-approval guard | (a)(b)(c)(e) verified offline; (d) by code reading of `withRequestContext` (`res.once('finish')`) |
| Users created in UI | `createUser` ignored tenant (defaulted to 1) and wrote integer `1` to boolean `must_reset_password` | code; boolean *(unverified on PG)* |
| Documents page | `/api/documents/expiring` registered after `/:id` → `::uuid` cast error → `Promise.all` failed the page; UUID params without casts; frontend Open expected JSON from a binary stream; no upload type validation; tenant-wide duplicate check leaked ids | route order + validation verified offline; uuid casts *(unverified on PG)* |
| Compliance rules | Only list+create existed (no get/update/enable/disable/delete in routes, service or UI); list SQL used `? IS NULL OR …` | CRUD verified offline; 42P18 *(unverified on PG)* |
| Notifications / expiry sweep | `INSERT … read` with literal `0` into boolean column | code *(unverified on PG)* |
| Analytics | Tenant-wide numbers reachable by every employee (`analytics.read` on Employee); no filters/error/empty states; PG interval math | verified offline |
| Payroll controls | Prechecks never enforced by approval; reconciliation UI was a stub; re-run replaced check ids | verified offline |
| Leave calendar | **No hard defect found by static analysis.** Gaps fixed: rejected leave unreachable, no filters, no validation, endless spinner on API failure, date-typed columns serialised as UTC timestamps. Actual reported failure not reproduced. | filters/validation verified offline |

## 2. Files changed / added
Backend — **added:** `src/errors.js`, `src/http/error-handler.js`, `src/routes/{approvals,documents,compliance-rules,payroll-controls,analytics,leave-calendar}.js`,
`src/services/{index,utils,integration-adapters,auth.service,attendance.service,statutory-compliance.service,fnf.service,leave.service,lifecycle.service,payroll.service,reports.service,enterprise.service,platform.service,storage.service}.js`
(mechanical split of `services.js`), new: `authorization.service.js`, `approval.service.js`, `expense.service.js`, `hr-request.service.js`,
`document.service.js`, `compliance-rules.service.js`, `analytics.service.js`, `payroll-controls.service.js`;
`prisma/migrations/0005_approval_and_rbac_hardening/`, `tests/phase1.test.js`, `tests/helpers/{sqlite-prisma,harness}.js`, `docs/*`.
**Modified:** `src/server.js` (33 routes moved out, role checks → `authz`, atomic-request + error middleware, payroll approve gate),
`src/db.js` (createUser tenant/boolean/role sync, role-change sync, permission-based `resolveManagerScope`),
`prisma/schema.prisma`, `prisma/seed.js`, `reset-db.js`, `package.json`.
**Deleted:** `src/services.js` (replaced by `src/services/`).
Frontend — modified: `api.js`, `components.jsx`, `pages.jsx` (Leave Calendar, Approval Center loader), `enterprisePages.jsx`
(Documents, Compliance Rules, Payroll Controls), `advancedPages.jsx` (Analytics).

## 3. APIs changed
* New: `GET/PUT/PATCH/DELETE /api/compliance/rules/:id`, `POST …/:id/enable|disable`, `POST /api/payroll/runs/:id/prechecks/:checkId/waive`,
  `DELETE /api/documents/:id` (archive), `GET /api/approvals/{expenses,hr-requests}/:id/history`.
* Changed semantics: approval endpoints now require `expense.approve` / `helpdesk.approve` (not `expense.write`);
  decision `reject` requires a comment; HR request approve → status `approved`; `POST /api/payroll/runs/:id/approve` returns 422
  `PAYROLL_CONTROLS_OPEN` while blocking checks are open; `/api/analytics/enterprise` needs `analytics.read`+`reports.read` and
  manager/admin, accepts `from,to,department`; `/api/leave/calendar` accepts `status,userId,managerId`, returns text dates;
  ticket PATCH can no longer approve/reject and validates transitions; internal ticket notes hidden from requesters.
* Error envelope everywhere: `{ error, code, details?, requestId }`; 400/401/403/404/409/422/500.

## 4. Database changes (migration 0005)
Columns: `expense_claims.{submitted_at,decided_by,decided_at,decision_comment}`, `service_tickets.{decided_by,decided_at,decision_comment}`,
`compliance_rules.{updated_at,updated_by}`; permissions `expense.approve`, `helpdesk.approve` granted to Manager/HR Admin;
manager/HR baseline permissions ensured; **REVOKE** `analytics.read` from Employee; backfill `tenant_memberships` + `user_roles`
from `users.role`; four indexes. Prisma schema updated to match (incl. pre-existing drift `notifications.title`).

## 5–6. Tests added / executed
`tests/phase1.test.js` (39 tests): RBAC resolver & role sync; full Expense and HR-request lifecycles (employee→manager→DB→employee view),
direct-API denial for employee / wrong manager / anonymous / cross-tenant, self-approval, double-decision, delegate approval, no-manager
claims, transaction rollback, error envelope, compliance CRUD/validation/overlap, documents (route order, upload→download, ownership,
versions, restore, validation, duplicates, archive, expiry sweep), leave calendar (scopes/filters/validation), payroll controls gate,
analytics numbers vs. DB. Mutation checks: reintroducing the route-order bug and removing the self-approval guard both make the suite fail.
Executed: `node --test tests/unit.test.js tests/phase1.test.js` → 147 pass, 0 fail.

## 7. Remaining issues
* Full regression / E2E / `vite build` / `prisma validate` / PG-specific verification **not done**.
* Approval engine registers Expense and HR request only. Leave, timesheet, correction, loan, advance, comp-off, encashment keep their existing
  approve paths (config-driven registry is ready). Approval Center tabs for loan/advance/comp-off/encashment still show 0.
* Leave Calendar original failure unconfirmed.
* 16 `requireRoleMw` label checks remain as a compatibility layer (they resolve to the same permissions); mass migration to
  `requirePermission` not done. ~250 raw-SQL queries were not converted to Prisma (by design, Step 12).
* Unused `zod`/`pg` dependencies left (lockfile). `sqlite`-named helper comments remain in `utils.js`.
* Ticket approval applies to *every* new HR request (previous behaviour surfaced all open tickets to managers anyway).

## 8. Architecture changes
`services.js` → `src/services/*` (lazy registry, same `services.<name>` API); central authz, approval engine with state machine,
commit-before-respond request transactions with rollback on 4xx/5xx, central error middleware, route modules, shared role provisioning.

## 9. Deleted / merged
`services.js` split; duplicate role seeding in `seed.js` replaced by `enterprise.ensureBuiltInRoles`; enterprise/platform document, payroll-control,
compliance-rule, expense, ticket and analytics functions moved to dedicated services; `reset-db.js` regenerated from schema.

## 10. Regression results
Offline only (see top). Deployment order: apply migration 0005 **before** starting the new code, then run the full suite against a disposable PostgreSQL.
