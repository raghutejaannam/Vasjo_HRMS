'use strict';
const authz = require('../services/authorization.service');
const controls = require('../services/payroll-controls.service');
const { asyncHandler } = require('../http/error-handler');

module.exports = function registerPayrollControlRoutes(app, { requireAuth }) {
  const ctx = authz.contextFrom; const P = authz.requirePermission;
  app.get('/api/payroll/runs/:id/controls', requireAuth, P('payroll.read'), asyncHandler(async (req, res) => res.json(await controls.listPayrollControls(ctx(req), req.params.id))));
  app.post('/api/payroll/runs/:id/prechecks', requireAuth, P('payroll.calculate'), asyncHandler(async (req, res) => res.json({ checks: await controls.runPrechecks(ctx(req), req.params.id) })));
  app.post('/api/payroll/runs/:id/prechecks/:checkId/waive', requireAuth, P('payroll.approve'), asyncHandler(async (req, res) => res.json(await controls.waiveCheck(ctx(req), req.params.id, req.params.checkId, req.body?.reason))));
  app.post('/api/payroll/runs/:id/reconciliation', requireAuth, P('payroll.approve'), asyncHandler(async (req, res) => res.status(201).json(await controls.saveReconciliation(ctx(req), req.params.id, req.body || {}))));
};
// The approve endpoint itself stays in server.js (payroll.approve) and calls
// controls.assertControlsClear before payroll.approvePayrollRun.
