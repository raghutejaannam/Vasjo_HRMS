'use strict';
// Expense claims, HR requests and their approval queues. Every decision goes
// through services/approval.service (single workflow + authorization path).
const authz = require('../services/authorization.service');
const expense = require('../services/expense.service');
const hr = require('../services/hr-request.service');
const approval = require('../services/approval.service');
const { asyncHandler } = require('../http/error-handler');

module.exports = function registerApprovalRoutes(app, { requireAuth }) {
  const ctx = authz.contextFrom;
  const P = authz.requirePermission;

  // --- Expenses -------------------------------------------------------------
  app.get('/api/expenses', requireAuth, P('expense.read'), asyncHandler(async (req, res) => res.json({ claims: await expense.listExpenses(ctx(req), { status: req.query.status, userId: req.query.userId }) })));
  app.post('/api/expenses', requireAuth, P('expense.write'), asyncHandler(async (req, res) => res.status(201).json(await expense.createExpense(ctx(req), req.body || {}))));
  app.post('/api/expenses/:id/lines', requireAuth, P('expense.write'), asyncHandler(async (req, res) => res.status(201).json(await expense.addExpenseLine(ctx(req), req.params.id, req.body || {}))));
  app.get('/api/expenses/:id/lines', requireAuth, P('expense.read'), asyncHandler(async (req, res) => res.json({ lines: await expense.listExpenseLines(ctx(req), req.params.id) })));
  app.post('/api/expenses/:id/submit', requireAuth, P('expense.write'), asyncHandler(async (req, res) => res.json(await expense.submitExpense(ctx(req), req.params.id))));
  app.post('/api/expenses/:id/decide', requireAuth, P('expense.approve'), asyncHandler(async (req, res) => res.json(await expense.decideExpense(ctx(req), req.params.id, req.body?.decision, req.body?.comment))));
  app.get('/api/approvals/expenses', requireAuth, P('expense.approve'), asyncHandler(async (req, res) => res.json({ claims: await expense.listExpenseApprovals(ctx(req)) })));
  app.post('/api/approvals/expenses/:id/decide', requireAuth, P('expense.approve'), asyncHandler(async (req, res) => res.json(await expense.decideExpense(ctx(req), req.params.id, req.body?.decision, req.body?.comment))));
  app.get('/api/approvals/expenses/:id/history', requireAuth, P('expense.read'), asyncHandler(async (req, res) => res.json({ history: await approval.listHistory(ctx(req), 'expense', req.params.id) })));

  // --- HR requests (service desk tickets) -------------------------------------
  app.get('/api/helpdesk/tickets', requireAuth, P('helpdesk.read'), asyncHandler(async (req, res) => res.json({ tickets: await hr.listTickets(ctx(req), { status: req.query.status, priority: req.query.priority }) })));
  app.post('/api/helpdesk/tickets', requireAuth, P('helpdesk.write'), asyncHandler(async (req, res) => res.status(201).json(await hr.createTicket(ctx(req), req.body || {}))));
  app.patch('/api/helpdesk/tickets/:id', requireAuth, P('helpdesk.write'), asyncHandler(async (req, res) => res.json(await hr.updateTicket(ctx(req), req.params.id, req.body || {}))));
  app.get('/api/helpdesk/tickets/:id/notes', requireAuth, P('helpdesk.read'), asyncHandler(async (req, res) => res.json({ notes: await hr.ticketNotes(ctx(req), req.params.id) })));
  app.post('/api/helpdesk/tickets/:id/notes', requireAuth, P('helpdesk.write'), asyncHandler(async (req, res) => res.status(201).json(await hr.addTicketNote(ctx(req), req.params.id, req.body?.note, req.body?.internal !== false))));
  app.get('/api/approvals/hr-requests', requireAuth, P('helpdesk.approve'), asyncHandler(async (req, res) => res.json({ requests: await hr.listServiceRequestApprovals(ctx(req)) })));
  app.post('/api/approvals/hr-requests/:id/decide', requireAuth, P('helpdesk.approve'), asyncHandler(async (req, res) => res.json(await hr.decideServiceRequest(ctx(req), req.params.id, req.body?.decision, req.body?.comment))));
  app.get('/api/approvals/hr-requests/:id/history', requireAuth, P('helpdesk.read'), asyncHandler(async (req, res) => res.json({ history: await approval.listHistory(ctx(req), 'hr_request', req.params.id) })));
};
