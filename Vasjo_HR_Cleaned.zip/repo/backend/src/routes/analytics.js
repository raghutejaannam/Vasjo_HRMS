'use strict';
const authz = require('../services/authorization.service');
const analytics = require('../services/analytics.service');
const { asyncHandler } = require('../http/error-handler');

module.exports = function registerAnalyticsRoutes(app, { requireAuth }) {
  app.get('/api/analytics/enterprise', requireAuth, authz.requireAllPermissions(['analytics.read', 'reports.read']),
    asyncHandler(async (req, res) => res.json(await analytics.analyticsOverview(authz.contextFrom(req), { from: req.query.from, to: req.query.to, department: req.query.department }))));
};
