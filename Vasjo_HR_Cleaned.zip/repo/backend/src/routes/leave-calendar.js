'use strict';
const authz = require('../services/authorization.service');
const leave = require('../services/leave.service');
const { asyncHandler } = require('../http/error-handler');

module.exports = function registerLeaveCalendarRoutes(app, { requireAuth }) {
  app.get('/api/leave/calendar', requireAuth, asyncHandler(async (req, res) => {
    const { from, to, scope, status, userId, managerId } = req.query;
    res.json(await leave.getLeaveCalendar(authz.contextFrom(req), { from, to, scope, status, userId, managerId }));
  }));
};
