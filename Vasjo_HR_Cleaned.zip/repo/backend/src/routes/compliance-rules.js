'use strict';
const authz = require('../services/authorization.service');
const rules = require('../services/compliance-rules.service');
const { asyncHandler } = require('../http/error-handler');

module.exports = function registerComplianceRuleRoutes(app, { requireAuth }) {
  const ctx = authz.contextFrom; const R = authz.requirePermission('payroll.read'); const W = authz.requirePermission('payroll.calculate');
  app.get('/api/compliance/rules', requireAuth, R, asyncHandler(async (req, res) => res.json({ rules: await rules.listComplianceRules(ctx(req), { ruleType: req.query.ruleType, active: req.query.active, asOf: req.query.asOf }) })));
  app.get('/api/compliance/rules/:id', requireAuth, R, asyncHandler(async (req, res) => res.json(await rules.getComplianceRule(ctx(req), req.params.id))));
  app.post('/api/compliance/rules', requireAuth, W, asyncHandler(async (req, res) => res.status(201).json(await rules.createComplianceRule(ctx(req), req.body || {}))));
  app.put('/api/compliance/rules/:id', requireAuth, W, asyncHandler(async (req, res) => res.json(await rules.updateComplianceRule(ctx(req), req.params.id, req.body || {}))));
  app.patch('/api/compliance/rules/:id', requireAuth, W, asyncHandler(async (req, res) => res.json(await rules.updateComplianceRule(ctx(req), req.params.id, req.body || {}))));
  app.post('/api/compliance/rules/:id/enable', requireAuth, W, asyncHandler(async (req, res) => res.json(await rules.setComplianceRuleActive(ctx(req), req.params.id, true))));
  app.post('/api/compliance/rules/:id/disable', requireAuth, W, asyncHandler(async (req, res) => res.json(await rules.setComplianceRuleActive(ctx(req), req.params.id, false))));
  app.delete('/api/compliance/rules/:id', requireAuth, W, asyncHandler(async (req, res) => res.json(await rules.deactivateComplianceRule(ctx(req), req.params.id))));
};
