'use strict';
// Service registry. Each domain lives in its own module under src/services/.
// Modules are loaded lazily so that db.js <-> services circular requires keep
// working (db.js only needs `utils` at load time).
const registry = {
  utils: () => require('./utils'),
  integrationAdapters: () => require('./integration-adapters'),
  auth: () => require('./auth.service'),
  attendance: () => require('./attendance.service'),
  compliance: () => require('./statutory-compliance.service'),
  fnf: () => require('./fnf.service'),
  leave: () => require('./leave.service'),
  lifecycle: () => require('./lifecycle.service'),
  payroll: () => require('./payroll.service'),
  reports: () => require('./reports.service'),
  enterprise: () => require('./enterprise.service'),
  platform: () => require('./platform.service'),
  storage: () => require('./storage.service'),
  authorization: () => require('./authorization.service'),
  approval: () => require('./approval.service'),
  expense: () => require('./expense.service'),
  hrRequest: () => require('./hr-request.service'),
  complianceRules: () => require('./compliance-rules.service'),
  document: () => require('./document.service'),
  analytics: () => require('./analytics.service'),
  payrollControls: () => require('./payroll-controls.service'),
};
const services = {};
for (const [name, load] of Object.entries(registry)) {
  Object.defineProperty(services, name, { enumerable: true, configurable: true, get: load });
}
module.exports = services;
