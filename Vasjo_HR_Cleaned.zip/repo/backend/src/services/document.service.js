'use strict';
// Document Center: types, records, versions, access control, verification,
// expiry. All UUID columns are bound with explicit ::uuid casts (Prisma binds
// JS strings as text, and PostgreSQL will not compare/assign text to uuid).
const crypto = require('node:crypto');
const db = require('../db');
const authz = require('./authorization.service');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { NotFoundError, ForbiddenError, ValidationError, ConflictError, BusinessRuleError } = require('../errors');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DEFAULT_EXTENSIONS = 'pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv';
const audit = (...a) => enterprise.audit(...a);
function uuid(v, name = 'id') { if (!UUID_RE.test(String(v || ''))) throw new ValidationError(`${name} must be a valid document id`); return String(v).toLowerCase(); }
const CURRENT_VERSION_JOIN = 'LEFT JOIN document_versions dv ON CAST(dv.id AS TEXT)=CAST(d.current_version_id AS TEXT)';
const ymd = (d) => d.toISOString().slice(0, 10);
const addDays = (n) => ymd(new Date(Date.now() + n * 86400000));

// ---- types -------------------------------------------------------------------
const listDocumentTypes = (ctx) => db.dbAll('SELECT * FROM document_types WHERE tenant_id=? ORDER BY name', [ctx.tenantId]);
const ensureDocumentType = enterprise.ensureDocumentType;

// ---- access ------------------------------------------------------------------
function canAccess(ctx, doc) {
  if (authz.hasPermission(ctx.user, 'document.verify')) return true;               // HR / admin
  if (doc.owner_user_id != null) return Number(doc.owner_user_id) === Number(ctx.actorId);
  return Number(doc.created_by) === Number(ctx.actorId);                            // ownerless: creator only
}
function assertCanAccess(ctx, doc) { if (!canAccess(ctx, doc)) throw new ForbiddenError('You do not have access to this document'); }

// ---- upload validation ---------------------------------------------------------
function sanitizeFilename(name) { return String(name || 'upload.bin').replace(/[\\/\0\r\n]/g, '_').replace(/^\.+/, '').slice(0, 255) || 'upload.bin'; }
async function validateUpload(ctx, { filename, size, documentTypeId }) {
  if (!size) throw new ValidationError('The file is empty');
  const max = Number(process.env.MAX_DOCUMENT_SIZE_BYTES || 50 * 1024 * 1024);
  if (size > max) throw Object.assign(new BusinessRuleError('File too large', 'FILE_TOO_LARGE'), { httpStatus: 413 });
  let allowed = DEFAULT_EXTENSIONS;
  if (documentTypeId) {
    const t = await db.dbGet('SELECT allowed_extensions FROM document_types WHERE tenant_id=? AND id=?', [ctx.tenantId, documentTypeId]);
    if (!t) throw new ValidationError('Unknown document type');
    allowed = t.allowed_extensions || DEFAULT_EXTENSIONS;
  }
  const ext = (String(filename).split('.').pop() || '').toLowerCase();
  if (!allowed.split(',').map((x) => x.trim().toLowerCase()).includes(ext)) throw new BusinessRuleError(`File type ".${ext}" is not allowed (allowed: ${allowed})`, 'FILE_TYPE_NOT_ALLOWED');
}

// ---- records & versions ----------------------------------------------------------
async function createDocumentRecord(ctx, meta) {
  const id = crypto.randomUUID();
  return db.dbGet(`INSERT INTO documents(id,tenant_id,document_type_id,name,status,verification_status,owner_user_id,linked_module,linked_resource_id,expires_on,retention_until,created_by,created_at,updated_at) VALUES (?::uuid,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [id, ctx.tenantId, meta.documentTypeId || null, meta.name, 'pending_verification', 'pending', meta.ownerUserId || null, meta.linkedModule || null, meta.linkedResourceId == null ? null : String(meta.linkedResourceId), meta.expiresOn || null, meta.retentionUntil || null, ctx.actorId, nowStr(), nowStr()]);
}
async function addDocumentVersion(ctx, { documentId, objectKey, checksum, sizeBytes, mimeType, source, sourceReference, originalFilename, uploadReason, malwareStatus = 'clean' }) {
  documentId = uuid(documentId, 'documentId');
  const current = await db.dbGet('SELECT COALESCE(MAX(version_no),0) AS n FROM document_versions WHERE tenant_id=? AND document_id=?::uuid', [ctx.tenantId, documentId]);
  const versionNo = Number(current.n || 0) + 1; const id = crypto.randomUUID();
  const ver = await db.dbGet(`INSERT INTO document_versions(id,tenant_id,document_id,version_no,object_key,checksum_sha256,size_bytes,mime_type,source,source_reference,original_filename,uploaded_by,upload_reason,malware_status,created_at) VALUES(?::uuid,?,?::uuid,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [id, ctx.tenantId, documentId, versionNo, objectKey, checksum, Number(sizeBytes), mimeType, source, sourceReference || null, originalFilename, ctx.actorId, uploadReason || null, malwareStatus, nowStr()]);
  await db.dbRun('UPDATE documents SET current_version_id=?::uuid,updated_at=?,status=?,verification_status=? WHERE tenant_id=? AND id=?::uuid', [id, nowStr(), 'pending_verification', 'pending', ctx.tenantId, documentId]);
  await db.dbRun('INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,version_id,created_at,metadata_json) VALUES(?,?::uuid,?,?,?::uuid,?,?::jsonb)', [ctx.tenantId, documentId, ctx.actorId, 'upload', id, nowStr(), JSON.stringify({ source, versionNo })]);
  await audit(ctx, 'document.upload', 'document', documentId, null, { versionId: id, versionNo, source, checksum });
  return ver;
}

// ---- queries ---------------------------------------------------------------------
// Visibility is enforced HERE (not only in the route): non-HR callers only ever get their own documents.
async function listDocuments(ctx, { ownerUserId, module, resourceId, status, search } = {}) {
  const w = ['d.tenant_id=?']; const p = [ctx.tenantId];
  const isHr = authz.hasPermission(ctx.user, 'document.verify');
  if (!isHr) { w.push('(d.owner_user_id=? OR (d.owner_user_id IS NULL AND d.created_by=?))'); p.push(ctx.actorId, ctx.actorId); }
  if (ownerUserId) {
    if (!isHr && Number(ownerUserId) !== Number(ctx.actorId)) throw new ForbiddenError();
    w.push('d.owner_user_id=?'); p.push(Number(ownerUserId));
  }
  if (module) { w.push('d.linked_module=?'); p.push(module); }
  if (resourceId) { w.push('d.linked_resource_id=?'); p.push(String(resourceId)); }
  if (status) { w.push('d.status=?'); p.push(status); } else { w.push("d.status<>'archived'"); }
  if (search) { w.push('d.name ILIKE ?'); p.push(`%${String(search).replace(/[%_]/g, '\\$&')}%`); }
  return db.dbAll(`SELECT d.*,dv.version_no,dv.size_bytes,dv.mime_type,dv.source,dv.original_filename,dv.checksum_sha256,dt.name AS document_type_name FROM documents d ${CURRENT_VERSION_JOIN} LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE ${w.join(' AND ')} ORDER BY d.updated_at DESC`, p);
}
async function getDocument(ctx, id) {
  return db.dbGet(`SELECT d.*,dv.object_key,dv.version_no,dv.size_bytes,dv.mime_type,dv.source,dv.original_filename,dv.checksum_sha256,dv.uploaded_by,dv.created_at AS version_created_at,dt.name AS document_type_name FROM documents d ${CURRENT_VERSION_JOIN} LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE d.tenant_id=? AND d.id=?::uuid`, [ctx.tenantId, uuid(id)]);
}
// Load + authorize in one step (404 before 403 is avoided for other tenants because of the tenant filter).
async function getAccessibleDocument(ctx, id) {
  const d = await getDocument(ctx, id);
  if (!d) throw new NotFoundError('Document not found');
  assertCanAccess(ctx, d);
  return d;
}
const listDocumentVersions = (ctx, id) => db.dbAll('SELECT * FROM document_versions WHERE tenant_id=? AND document_id=?::uuid ORDER BY version_no DESC', [ctx.tenantId, uuid(id)]);

// Duplicate = same content already stored for the SAME owner (never leaks other employees' documents).
async function findDuplicate(ctx, checksum, ownerUserId) {
  return db.dbGet(`SELECT d.id FROM documents d JOIN document_versions v ON CAST(v.id AS TEXT)=CAST(d.current_version_id AS TEXT) WHERE d.tenant_id=? AND d.owner_user_id=? AND d.status<>'archived' AND v.checksum_sha256=?`, [ctx.tenantId, ownerUserId, checksum]);
}
async function linkDocument(ctx, { documentId, resourceType, resourceId }) {
  await getAccessibleDocument(ctx, documentId);
  if (!resourceType || resourceId == null) throw new ValidationError('resourceType and resourceId are required');
  await db.dbRun('INSERT INTO document_links(tenant_id,document_id,resource_type,resource_id,created_at) VALUES(?,?::uuid,?,?,?) ON CONFLICT DO NOTHING', [ctx.tenantId, uuid(documentId), resourceType, String(resourceId), nowStr()]);
  await audit(ctx, 'document.link', 'document', documentId, null, { resourceType, resourceId });
}
async function verifyDocument(ctx, id, status, reason) {
  if (!['verified', 'rejected'].includes(status)) throw new ValidationError('status must be verified or rejected');
  if (status === 'rejected' && !reason) throw new ValidationError('Rejection reason is required');
  const before = await getDocument(ctx, id); if (!before) throw new NotFoundError('Document not found');
  await db.dbRun('UPDATE documents SET verification_status=?,status=?,updated_at=? WHERE tenant_id=? AND id=?::uuid', [status, status, nowStr(), ctx.tenantId, uuid(id)]);
  await db.dbRun('INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,reason,created_at) VALUES(?,?::uuid,?,?,?,?)', [ctx.tenantId, uuid(id), ctx.actorId, status, reason || null, nowStr()]);
  await audit(ctx, `document.${status}`, 'document', id, before, { verificationStatus: status, reason });
  return getDocument(ctx, id);
}
async function restoreVersion(ctx, id, versionId, reason) {
  const d = await getDocument(ctx, id); if (!d) throw new NotFoundError('Document not found');
  const v = await db.dbGet('SELECT id FROM document_versions WHERE tenant_id=? AND document_id=?::uuid AND id=?::uuid', [ctx.tenantId, uuid(id), uuid(versionId, 'versionId')]);
  if (!v) throw new NotFoundError('Version not found');
  await db.dbRun('UPDATE documents SET current_version_id=?::uuid,updated_at=? WHERE tenant_id=? AND id=?::uuid', [uuid(versionId), nowStr(), ctx.tenantId, uuid(id)]);
  await db.dbRun('INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,version_id,reason,created_at) VALUES(?,?::uuid,?,?,?::uuid,?,?)', [ctx.tenantId, uuid(id), ctx.actorId, 'restore', uuid(versionId), reason || null, nowStr()]);
  await audit(ctx, 'document.version.restore', 'document', id, d, { versionId, reason });
  return getDocument(ctx, id);
}
// "Delete" archives (retention rules: files and history are kept).
async function archiveDocument(ctx, id) {
  const d = await getAccessibleDocument(ctx, id);
  if (Number(d.owner_user_id) !== Number(ctx.actorId) && !authz.hasPermission(ctx.user, 'document.verify')) throw new ForbiddenError();
  await db.dbRun("UPDATE documents SET status='archived',updated_at=? WHERE tenant_id=? AND id=?::uuid", [nowStr(), ctx.tenantId, uuid(id)]);
  await db.dbRun('INSERT INTO document_audit_logs(tenant_id,document_id,actor_id,action,created_at) VALUES(?,?::uuid,?,?,?)', [ctx.tenantId, uuid(id), ctx.actorId, 'archive', nowStr()]);
  await audit(ctx, 'document.archive', 'document', id, { status: d.status }, { status: 'archived' });
  return { ok: true };
}
async function expiringDocuments(ctx, daysAhead = 30) {
  const n = Number(daysAhead); if (!Number.isInteger(n) || n < 0 || n > 3650) throw new ValidationError('daysAhead must be an integer between 0 and 3650');
  const w = ["d.tenant_id=?", 'd.expires_on IS NOT NULL', 'd.expires_on<=?', "d.status<>'archived'"]; const p = [ctx.tenantId, addDays(n)];
  if (!authz.hasPermission(ctx.user, 'document.verify')) { w.push('d.owner_user_id=?'); p.push(ctx.actorId); }
  return db.dbAll(`SELECT d.*,dv.original_filename,dt.name AS document_type_name FROM documents d ${CURRENT_VERSION_JOIN} LEFT JOIN document_types dt ON dt.id=d.document_type_id WHERE ${w.join(' AND ')} ORDER BY d.expires_on`, p);
}
async function documentExpirySweep(ctx) {
  const docs = await db.dbAll("SELECT d.id,d.owner_user_id,d.name,d.expires_on FROM documents d WHERE d.tenant_id=? AND d.expires_on IS NOT NULL AND d.expires_on<=? AND d.status<>'archived'", [ctx.tenantId, addDays(90)]);
  const reminders = [90, 60, 30, 15, 7, 1, 0]; const results = [];
  for (const d of docs) {
    const days = Math.ceil((new Date(`${d.expires_on}T00:00:00Z`) - new Date(`${ymd(new Date())}T00:00:00Z`)) / 86400000);
    const hit = reminders.includes(days) ? days : (days < 0 ? -1 : null); if (hit === null) continue;
    if (d.owner_user_id) await enterprise.createNotification(ctx, d.owner_user_id, 'document.expiry', 'Document expiry reminder', `${d.name} ${hit < 0 ? 'has expired' : `expires in ${hit} day(s)`}.`);
    results.push({ documentId: d.id, daysRemaining: days });
  }
  return results;
}

module.exports = {
  canAccess, assertCanAccess, sanitizeFilename, validateUpload, listDocumentTypes, ensureDocumentType, createDocumentRecord, addDocumentVersion,
  listDocuments, getDocument, getAccessibleDocument, listDocumentVersions, findDuplicate, linkDocument, verifyDocument, restoreVersion,
  archiveDocument, expiringDocuments, documentExpirySweep,
};
