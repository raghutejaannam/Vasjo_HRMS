'use strict';
// Payroll controls = pre-run checks + reconciliation. Controls are ENFORCED:
// approvePayrollRun is blocked while any error-severity check is open
// (assertControlsClear, wired in routes/payroll-controls.js).
const db = require('../db');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { NotFoundError, ValidationError, BusinessRuleError, ConflictError } = require('../errors');

const toId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const RECON_STATUSES = ['pending', 'reconciled', 'variance'];

async function getRun(ctx, runId) {
  const run = await db.dbGet('SELECT * FROM payroll_runs WHERE tenant_id=? AND id=?', [ctx.tenantId, toId(runId)]);
  if (!run) throw new NotFoundError('Payroll run not found');
  return run;
}

// Detect problems and (re)build the check list. Waived checks stay waived.
async function runPrechecks(ctx, runId) {
  const run = await getRun(ctx, runId);
  const issues = [];
  const active = await db.dbGet("SELECT COUNT(*) AS n FROM users WHERE tenant_id=? AND active='active'", [ctx.tenantId]);
  if (Number(active.n) === 0) issues.push({ category: 'employee', code: 'NO_ACTIVE_EMPLOYEES', message: 'No active employees found', severity: 'error' });
  const noStructure = await db.dbAll("SELECT u.id,u.name FROM users u WHERE u.tenant_id=? AND u.active='active' AND NOT EXISTS (SELECT 1 FROM employee_salary_structures s WHERE s.user_id=u.id)", [ctx.tenantId]);
  for (const u of noStructure) issues.push({ category: 'salary', code: 'NO_SALARY_STRUCTURE', message: `${u.name} has no salary structure`, severity: 'error', ref: String(u.id) });
  const noBank = await db.dbAll("SELECT u.id,u.name FROM users u WHERE u.tenant_id=? AND u.active='active' AND (u.bank_account_no IS NULL OR u.bank_account_no='')", [ctx.tenantId]);
  for (const u of noBank) issues.push({ category: 'bank', code: 'NO_BANK_ACCOUNT', message: `${u.name} has no bank account on file`, severity: 'warning', ref: String(u.id) });
  const rules = await db.dbGet('SELECT COUNT(*) AS n FROM compliance_rules WHERE tenant_id=? AND active=1', [ctx.tenantId]);
  if (Number(rules.n) === 0) issues.push({ category: 'compliance', code: 'NO_COMPLIANCE_RULES', message: 'No active compliance rules configured', severity: 'warning' });

  // Reconcile with the stored checks by (code,message): existing rows keep their
  // id and status (so waivers and UI references survive a re-run), rows whose
  // problem disappeared are removed, new problems are inserted.
  const existing = await db.dbAll('SELECT id,code,message,status FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=?', [ctx.tenantId, run.id]);
  const key = (x) => `${x.code}|${x.message}`;
  const current = new Set(issues.map(key));
  for (const e of existing) if (!current.has(key(e))) await db.dbRun('DELETE FROM payroll_prechecks WHERE tenant_id=? AND id=?', [ctx.tenantId, e.id]);
  const have = new Set(existing.map(key));
  for (const x of issues) {
    if (have.has(key(x))) continue;
    await db.dbRun('INSERT INTO payroll_prechecks(tenant_id,payroll_run_id,category,code,message,severity,status,created_at) VALUES(?,?,?,?,?,?,?,?)', [ctx.tenantId, run.id, x.category, x.code, x.message, x.severity, 'open', nowStr()]);
  }
  await enterprise.audit(ctx, 'payroll.prechecks', 'payroll_run', run.id, null, { issues: issues.length });
  return db.dbAll('SELECT * FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=? ORDER BY id', [ctx.tenantId, run.id]);
}

async function waiveCheck(ctx, runId, checkId, reason) {
  if (!String(reason || '').trim()) throw new ValidationError('A reason is required to waive a check');
  const c = await db.dbGet('SELECT * FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=? AND id=?', [ctx.tenantId, toId(runId), toId(checkId)]);
  if (!c) throw new NotFoundError('Check not found');
  await db.dbRun("UPDATE payroll_prechecks SET status='waived' WHERE tenant_id=? AND id=?", [ctx.tenantId, c.id]);
  await enterprise.audit(ctx, 'payroll.precheck.waived', 'payroll_run', runId, c, { reason });
  return db.dbGet('SELECT * FROM payroll_prechecks WHERE tenant_id=? AND id=?', [ctx.tenantId, c.id]);
}

async function saveReconciliation(ctx, runId, d = {}) {
  const run = await getRun(ctx, runId);
  const status = d.status || 'pending';
  if (!RECON_STATUSES.includes(status)) throw new ValidationError(`status must be one of ${RECON_STATUSES.join(', ')}`);
  const nums = {};
  for (const k of ['grossTotal', 'netTotal', 'employerCostTotal', 'bankTotal', 'journalTotal']) {
    const v = d[k] == null || d[k] === '' ? 0 : Number(d[k]);
    if (!Number.isFinite(v) || v < 0) throw new ValidationError(`${k} must be a non-negative number`);
    nums[k] = v;
  }
  if (nums.netTotal > nums.grossTotal) throw new ValidationError('netTotal cannot exceed grossTotal');
  const r = await db.dbGet('INSERT INTO payroll_reconciliations(tenant_id,payroll_run_id,gross_total,net_total,employer_cost_total,bank_total,journal_total,status,notes,reconciled_by,reconciled_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *',
    [ctx.tenantId, run.id, nums.grossTotal, nums.netTotal, nums.employerCostTotal, nums.bankTotal, nums.journalTotal, status, d.notes || null, ctx.actorId, status === 'reconciled' ? nowStr() : null, nowStr()]);
  await enterprise.audit(ctx, 'payroll.reconciliation', 'payroll_run', run.id, null, r);
  return r;
}

async function listPayrollControls(ctx, runId) {
  const run = await getRun(ctx, runId);
  const [checks, recon] = await Promise.all([
    db.dbAll("SELECT * FROM payroll_prechecks WHERE tenant_id=? AND payroll_run_id=? ORDER BY CASE severity WHEN 'error' THEN 0 ELSE 1 END, id", [ctx.tenantId, run.id]),
    db.dbAll('SELECT * FROM payroll_reconciliations WHERE tenant_id=? AND payroll_run_id=? ORDER BY id DESC', [ctx.tenantId, run.id]),
  ]);
  return { checks, reconciliation: recon[0] || null, blocking: checks.filter((c) => c.severity === 'error' && c.status === 'open').length };
}

// Gate used before a run can be approved: (re)run the checks and refuse while any error is open.
async function assertControlsClear(ctx, runId) {
  const checks = await runPrechecks(ctx, runId);
  const open = checks.filter((c) => c.severity === 'error' && c.status === 'open');
  if (open.length) throw Object.assign(new BusinessRuleError(`Payroll cannot be approved: ${open.length} blocking control(s) open`, 'PAYROLL_CONTROLS_OPEN'), { details: open.map((c) => ({ id: c.id, code: c.code, message: c.message })) });
}

module.exports = { runPrechecks, waiveCheck, saveReconciliation, listPayrollControls, assertControlsClear, payrollPrechecks: runPrechecks };
