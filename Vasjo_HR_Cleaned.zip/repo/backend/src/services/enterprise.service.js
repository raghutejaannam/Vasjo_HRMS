'use strict';
const crypto = require('node:crypto');
const db = require('../db');
const { nowStr } = require('./utils');

const BUILTIN_ROLE_PERMISSIONS = {
  'HR Admin':['employee.*','employee.self','employee.sensitive.read','manager.approve','lifecycle.*','document.read','document.upload','document.verify','workflow.manage','workflow.act','onboarding.manage','audit.read','reports.read','admin.configure','recruitment.read','recruitment.write','performance.read','performance.manage','performance.calibrate','learning.read','learning.write','benefits.read','benefits.write','expense.read','expense.write','expense.approve','asset.read','asset.write','helpdesk.read','helpdesk.write','helpdesk.approve','integration.manage','analytics.read','ai.assistant','ai.document','ai.payroll'],
  'Payroll Admin':['payroll.read','payroll.calculate','payroll.review','payroll.approve','payroll.lock','document.read','document.upload','workflow.act','audit.read','reports.read','analytics.read','ai.payroll'],
  'Payroll Reviewer':['payroll.read','payroll.review','payroll.approve','document.read','workflow.act','audit.read','reports.read','analytics.read'],
  'Manager':['employee.read','employee.self','manager.approve','document.read','document.upload','workflow.act','leave.approve','timesheet.approve','reports.read','performance.read','performance.manage','learning.read','benefits.read','expense.read','expense.write','expense.approve','asset.read','helpdesk.read','helpdesk.write','helpdesk.approve','analytics.read','onboarding.manage'],
  'Employee':['employee.self','document.self','document.read','document.upload','performance.read','performance.self','learning.read','learning.write','benefits.read','benefits.write','expense.read','expense.write','asset.read','helpdesk.read','helpdesk.write','ai.assistant'],
  'Auditor':['audit.read','reports.read','document.read','analytics.read'],
  'Finance':['expense.read','expense.write','payroll.read','payroll.approve','reports.read','analytics.read','workflow.act','employee.read'],
};

function safeJson(v) { try { return v == null ? null : JSON.stringify(v); } catch { return null; } }
async function audit(ctx, action, resourceType, resourceId, before, after, outcome='success') {
  const req = ctx?.req;
  await db.dbRun(`INSERT INTO audit_events (tenant_id,actor_id,action,resource_type,resource_id,before_json,after_json,timestamp,request_id,ip,user_agent,outcome)
                  VALUES (?,?,?,?,?,?::jsonb,?::jsonb,?,?,?,?,?)`, [ctx.tenantId, ctx.actorId || null, action, resourceType, resourceId == null ? null : String(resourceId), safeJson(before), safeJson(after), nowStr(), req?.requestId || null, req?.ip || null, req?.get?.('user-agent') || null, outcome]);
}

async function getTenantByUser(userId) { return db.dbGet('SELECT tm.tenant_id, t.* FROM tenant_memberships tm JOIN tenants t ON t.id=tm.tenant_id WHERE tm.user_id=? AND tm.status=\'active\' ORDER BY tm.tenant_id LIMIT 1',[userId]); }
async function getMembership(userId, tenantId) { return db.dbGet('SELECT * FROM tenant_memberships WHERE user_id=? AND tenant_id=? AND status=\'active\'',[userId,tenantId]); }
async function ensureMembership(userId, tenantId, role) {
  await db.dbRun(`INSERT INTO tenant_memberships(tenant_id,user_id,role,status,created_at) VALUES (?,?,?,?,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET role=EXCLUDED.role,status='active'`,[tenantId,userId,role||'employee', 'active', nowStr()]);
}
const LEGACY_ROLE_TO_BUILTIN = { admin: ['HR Admin', 'Payroll Admin'], manager: ['Manager'], employee: ['Employee'] };
function builtinPermissionsFor(legacyRole) {
  const names = LEGACY_ROLE_TO_BUILTIN[legacyRole] || LEGACY_ROLE_TO_BUILTIN.employee;
  return [...new Set(names.flatMap((r) => BUILTIN_ROLE_PERMISSIONS[r] || []))];
}
// THE permission resolver. Used at login AND on every authenticated request
// (auth.enrichEnterpriseIdentity) so the two can never diverge.
// DB role assignments win; users with no assignment fall back to the full
// built-in matrix of their tenant membership role (never a reduced list).
async function permissionsForUser(userId, tenantId, _legacyRole) {
  const rows = await db.dbAll(`SELECT DISTINCT p.code FROM user_roles ur JOIN roles r ON r.id=ur.role_id JOIN role_permissions rp ON rp.role_id=r.id JOIN permissions p ON p.id=rp.permission_id WHERE ur.tenant_id=? AND ur.user_id=?`,[tenantId,userId]);
  if (rows.length) return rows.map(r=>r.code);
  const membership = await getMembership(userId,tenantId);
  // Authorization is derived from explicit tenant role assignment only.
  // A missing assignment fails closed to the least-privileged Employee baseline.
  return builtinPermissionsFor(membership?.role || 'employee');
}
// Create/refresh the built-in system roles (and their permissions) for a tenant.
async function ensureBuiltInRoles(tenantId) {
  const codes = [...new Set(Object.values(BUILTIN_ROLE_PERMISSIONS).flat())];
  for (const code of codes) {
    const [resource, action] = code.split('.');
    await db.dbRun('INSERT INTO permissions (code,description,resource,action,created_at) VALUES (?,?,?,?,?) ON CONFLICT (code) DO NOTHING',[code,`Built-in ${code} permission`,resource,action||null,nowStr()]);
  }
  for (const [roleName, perms] of Object.entries(BUILTIN_ROLE_PERMISSIONS)) {
    const role = await db.dbGet('INSERT INTO roles (tenant_id,name,description,is_system,created_at) VALUES (?,?,?,1,?) ON CONFLICT (tenant_id,name) DO UPDATE SET description=EXCLUDED.description,is_system=true RETURNING id',[tenantId,roleName,`Built-in ${roleName} role`,nowStr()]);
    await db.dbRun('DELETE FROM role_permissions WHERE role_id=?',[role.id]);
    for (const code of perms) await db.dbRun('INSERT INTO role_permissions(role_id,permission_id) SELECT ?, id FROM permissions WHERE code=? ON CONFLICT DO NOTHING',[role.id,code]);
  }
}
// Keep tenant membership + built-in role assignments consistent with a user's
// legacy role. Called on user create and role change. Custom (non-system)
// role assignments are left untouched.
async function syncUserRoles(tenantId, userId, legacyRole) {
  await ensureMembership(userId, tenantId, legacyRole);
  const wanted = LEGACY_ROLE_TO_BUILTIN[legacyRole] || LEGACY_ROLE_TO_BUILTIN.employee;
  const builtinNames = Object.keys(BUILTIN_ROLE_PERMISSIONS);
  const existingRoles = await db.dbAll('SELECT id,name FROM roles WHERE tenant_id=?',[tenantId]);
  await ensureBuiltInRoles(tenantId);
  const roles = await db.dbAll('SELECT id,name FROM roles WHERE tenant_id=?',[tenantId]);
  for (const r of roles) {
    if (!builtinNames.includes(r.name)) continue;
    if (wanted.includes(r.name)) await db.dbRun('INSERT INTO user_roles(tenant_id,user_id,role_id) VALUES (?,?,?) ON CONFLICT DO NOTHING',[tenantId,userId,r.id]);
    else if (Object.values(LEGACY_ROLE_TO_BUILTIN).flat().includes(r.name)) await db.dbRun('DELETE FROM user_roles WHERE tenant_id=? AND user_id=? AND role_id=?',[tenantId,userId,r.id]);
  }
}
const authz = require('./authorization.service');
const { hasPermission, requirePermission, requireAnyPermission } = authz;

async function listAudit(ctx,{entityType,entityId,limit=200}={}) {
  const where=[]; const p=[ctx.tenantId]; where.push('ae.tenant_id=?');
  if(entityType){where.push('ae.resource_type=?');p.push(entityType)}
  if(entityId){where.push('ae.resource_id=?');p.push(String(entityId))}
  p.push(Math.min(Math.max(Number(limit)||200,1),500));
  return db.dbAll(`SELECT ae.*,u.name actor_name FROM audit_events ae LEFT JOIN users u ON u.id=ae.actor_id WHERE ${where.join(' AND ')} ORDER BY ae.id DESC LIMIT ?`,p);
}

async function listFeatureFlags(ctx){ return db.dbAll('SELECT * FROM feature_flags WHERE tenant_id=? ORDER BY key',[ctx.tenantId]); }
async function setFeatureFlag(ctx,key,enabled,config={}) {
  await db.dbRun(`INSERT INTO feature_flags(tenant_id,key,enabled,config_json,updated_at) VALUES (?,?,?,?::jsonb,?) ON CONFLICT(tenant_id,key) DO UPDATE SET enabled=EXCLUDED.enabled,config_json=EXCLUDED.config_json,updated_at=EXCLUDED.updated_at`,[ctx.tenantId,key,enabled?1:0,JSON.stringify(config),nowStr()]);
  await audit(ctx,'feature_flag.updated','feature_flag',key,null,{enabled:!!enabled,config});
  return db.dbGet('SELECT * FROM feature_flags WHERE tenant_id=? AND key=?',[ctx.tenantId,key]);
}
async function listRoles(ctx){ return db.dbAll(`SELECT r.*, COALESCE(json_agg(p.code) FILTER (WHERE p.code IS NOT NULL),'[]') permissions FROM roles r LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE r.tenant_id=? GROUP BY r.id ORDER BY r.name`,[ctx.tenantId]); }
async function upsertRole(ctx,{name,description,permissionCodes=[]}) {
  const role=await db.dbGet(`INSERT INTO roles(tenant_id,name,description,is_system,created_at) VALUES (?,?,?,0,?) ON CONFLICT(tenant_id,name) DO UPDATE SET description=EXCLUDED.description RETURNING id,*`,[ctx.tenantId,name,description||null,nowStr()]);
  await db.dbRun('DELETE FROM role_permissions WHERE role_id=?',[role.id]);
  for(const code of permissionCodes){const p=await db.dbGet('SELECT id FROM permissions WHERE code=?',[code]); if(p) await db.dbRun('INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?) ON CONFLICT DO NOTHING',[role.id,p.id]);}
  await audit(ctx,'role.updated','role',role.id,null,{name,permissionCodes}); return role;
}

async function ensureDocumentType(ctx,{name,code,required=false,expiryEnabled=false,expiryReminders,sensitive=false,verificationPolicy='hr',allowedExtensions}){
  const row=await db.dbGet(`INSERT INTO document_types(tenant_id,name,code,required,expiry_enabled,expiry_reminders,verification_policy,sensitive,allowed_extensions,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,name) DO UPDATE SET code=EXCLUDED.code RETURNING *`,[ctx.tenantId,name,code||null,required?1:0,expiryEnabled?1:0,expiryReminders||'90,60,30,15,7,1,0',verificationPolicy,sensitive?1:0,allowedExtensions||'pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv',nowStr()]);
  return row;
}

async function listWorkflows(ctx){return db.dbAll(`SELECT w.*,COUNT(s.id)::int step_count FROM workflow_definitions w LEFT JOIN workflow_steps s ON s.workflow_id=w.id WHERE w.tenant_id=? GROUP BY w.id ORDER BY w.module,w.name`,[ctx.tenantId]);}
async function createWorkflow(ctx,{module,name,triggerEvent,active=true,steps=[]}){const w=await db.dbGet(`INSERT INTO workflow_definitions(tenant_id,module,name,trigger_event,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,module,name,triggerEvent,active?1:0,nowStr(),nowStr()]); for(const st of steps){await db.dbRun(`INSERT INTO workflow_steps(tenant_id,workflow_id,step_no,approval_mode,approver_type,approver_value,condition_json,sla_hours,escalation_type,escalation_value) VALUES(?,?,?,?,?,?,?::jsonb,?,?,?)`,[ctx.tenantId,w.id,st.stepNo,st.approvalMode||'sequential',st.approverType,st.approverValue||null,JSON.stringify(st.condition||{}),st.slaHours||null,st.escalationType||null,st.escalationValue||null]);} await audit(ctx,'workflow.created','workflow',w.id,null,{module,name,steps:steps.length}); return w;}
async function getWorkflow(ctx,id){const w=await db.dbGet('SELECT * FROM workflow_definitions WHERE tenant_id=? AND id=?',[ctx.tenantId,id]); if(!w)return null; w.steps=await db.dbAll('SELECT * FROM workflow_steps WHERE tenant_id=? AND workflow_id=? ORDER BY step_no',[ctx.tenantId,id]); return w;}
async function startWorkflow(ctx,{workflowId,module,resourceId,dueAt,initiatedBy}){const w=await getWorkflow(ctx,workflowId);if(!w||!w.active)throw new Error('Workflow not active'); const i=await db.dbGet(`INSERT INTO workflow_instances(tenant_id,workflow_id,module,resource_id,status,current_step,initiated_by,due_at,created_at) VALUES(?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,workflowId,module,String(resourceId),'pending',1,initiatedBy||ctx.actorId,dueAt||null,nowStr()]); await audit(ctx,'workflow.started','workflow_instance',i.id,null,{resourceId,module});return i;}
async function listWorkflowInstances(ctx,{status,module,assigneeId}={}){const w=['wi.tenant_id=?'];const p=[ctx.tenantId];if(status){w.push('wi.status=?');p.push(status)}if(module){w.push('wi.module=?');p.push(module)}const rows=await db.dbAll(`SELECT wi.*,wf.name workflow_name,wf.module FROM workflow_instances wi JOIN workflow_definitions wf ON wf.id=wi.workflow_id WHERE ${w.join(' AND ')} ORDER BY wi.created_at DESC`,p);if(assigneeId){/* assignee resolution is computed per current step below */}return rows;}
function resolveApprover(step,user,ctx){ if(step.approverType==='user') return Number(step.approverValue)===Number(user.id); if(step.approverType==='manager') return true; if(step.approverType==='role') return hasPermission(user,step.approverValue); return false; }
async function actWorkflow(ctx, instanceId, action, comment) {
  const i = await db.dbGet('SELECT wi.*,wf.name workflow_name,wf.module FROM workflow_instances wi JOIN workflow_definitions wf ON wf.id=wi.workflow_id WHERE wi.tenant_id=? AND wi.id=?',[ctx.tenantId,instanceId]);
  if (!i) throw new Error('Workflow instance not found');
  if (!['approve','reject','return','cancel'].includes(action)) throw new Error('Invalid workflow action');
  if (i.status !== 'pending') throw new Error('Workflow is no longer pending');
  const step = await db.dbGet('SELECT * FROM workflow_steps WHERE tenant_id=? AND workflow_id=? AND step_no=?',[ctx.tenantId,i.workflow_id,i.current_step]);
  if (!step) throw new Error('Workflow step not found');
  if (step.approverType === 'user' && Number(step.approverValue) !== Number(ctx.actorId)) throw new Error('You are not an approver for this step');
  if (step.approverType === 'role' && !hasPermission(ctx.req.session.user,step.approverValue)) throw new Error('You are not an approver for this step');
  await db.withTx(async()=>{
    await db.dbRun('INSERT INTO workflow_actions(tenant_id,instance_id,step_no,actor_id,action,comment,acted_at) VALUES(?,?,?,?,?,?,?)',[ctx.tenantId,instanceId,i.current_step,ctx.actorId,action,comment||null,nowStr()]);
    if (action === 'approve') {
      const next = await db.dbGet('SELECT step_no FROM workflow_steps WHERE tenant_id=? AND workflow_id=? AND step_no>? ORDER BY step_no LIMIT 1',[ctx.tenantId,i.workflow_id,i.current_step]);
      if (next) await db.dbRun('UPDATE workflow_instances SET current_step=? WHERE tenant_id=? AND id=?',[next.step_no,ctx.tenantId,instanceId]);
      else await db.dbRun("UPDATE workflow_instances SET status='approved',completed_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,instanceId]);
    } else {
      const status = action === 'cancel' ? 'cancelled' : action === 'return' ? 'returned' : 'rejected';
      await db.dbRun('UPDATE workflow_instances SET status=?,completed_at=? WHERE tenant_id=? AND id=?',[status,nowStr(),ctx.tenantId,instanceId]);
    }
  });
  await audit(ctx,`workflow.${action}`,'workflow_instance',instanceId,null,{action,comment});
  return db.dbGet('SELECT * FROM workflow_instances WHERE tenant_id=? AND id=?',[ctx.tenantId,instanceId]);
}

async function listNotifications(ctx){return db.dbAll('SELECT * FROM notifications WHERE tenant_id=? AND user_id=? ORDER BY id DESC LIMIT 100',[ctx.tenantId,ctx.actorId]);}
async function createNotification(ctx,userId,type,title,message,metadata={}){await db.dbRun(`INSERT INTO notifications(tenant_id,user_id,type,title,message,created_at) VALUES(?,?,?,?,?,?)`,[ctx.tenantId,userId,type,title||type,message,nowStr()]);}

async function orgTree(ctx){return db.dbAll(`SELECT o.*,p.name parent_name FROM organizations o LEFT JOIN organizations p ON p.id=o.parent_id WHERE o.tenant_id=? ORDER BY o.kind,o.name`,[ctx.tenantId]);}
async function upsertOrg(ctx,data){const row=await db.dbGet(`INSERT INTO organizations(tenant_id,parent_id,kind,code,name,active,effective_from,effective_to,created_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,kind,code) DO UPDATE SET parent_id=EXCLUDED.parent_id,name=EXCLUDED.name,active=EXCLUDED.active,effective_from=EXCLUDED.effective_from,effective_to=EXCLUDED.effective_to RETURNING *`,[ctx.tenantId,data.parentId||null,data.kind,data.code||`${data.kind}-${Date.now()}`,data.name,data.active===false?0:1,data.effectiveFrom||null,data.effectiveTo||null,nowStr()]);await audit(ctx,'organization.upsert','organization',row.id,null,row);return row;}
async function positions(ctx){return db.dbAll(`SELECT p.*,jg.code grade_code,jg.name grade_name,cc.code cost_center_code FROM positions p LEFT JOIN job_grades jg ON jg.id=p.grade_id LEFT JOIN cost_centers cc ON cc.id=p.cost_center_id WHERE p.tenant_id=? ORDER BY p.title`,[ctx.tenantId]);}
async function upsertPosition(ctx,data){const row=await db.dbGet(`INSERT INTO positions(tenant_id,position_code,title,grade_id,department_id,cost_center_id,location,manager_id,status,budget_amount,effective_from,effective_to) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,position_code) DO UPDATE SET title=EXCLUDED.title,grade_id=EXCLUDED.grade_id,department_id=EXCLUDED.department_id,cost_center_id=EXCLUDED.cost_center_id,location=EXCLUDED.location,manager_id=EXCLUDED.manager_id,status=EXCLUDED.status,budget_amount=EXCLUDED.budget_amount,effective_from=EXCLUDED.effective_from,effective_to=EXCLUDED.effective_to RETURNING *`,[ctx.tenantId,data.positionCode,data.title,data.gradeId||null,data.departmentId||null,data.costCenterId||null,data.location||null,data.managerId||null,data.status||'open',data.budgetAmount==null?null:Number(data.budgetAmount),data.effectiveFrom||null,data.effectiveTo||null]);return row;}
async function recordEmployeeHistory(ctx,userId,fieldName,oldValue,newValue,effectiveFrom,reason){const current=await db.dbGet('SELECT * FROM employee_history WHERE tenant_id=? AND user_id=? AND field_name=? AND effective_to IS NULL ORDER BY effective_from DESC LIMIT 1',[ctx.tenantId,userId,fieldName]); if(current) await db.dbRun('UPDATE employee_history SET effective_to=? WHERE tenant_id=? AND id=?',[effectiveFrom,ctx.tenantId,current.id]); await db.dbRun('INSERT INTO employee_history(tenant_id,user_id,field_name,old_value,new_value,effective_from,reason,changed_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)',[ctx.tenantId,userId,fieldName,oldValue==null?null:String(oldValue),newValue==null?null:String(newValue),effectiveFrom,reason||null,ctx.actorId,nowStr()]);await audit(ctx,'employee.history.record','employee',userId,current,{fieldName,oldValue,newValue,effectiveFrom,reason});}
async function getEmployeeHistory(ctx,userId){return db.dbAll('SELECT * FROM employee_history WHERE tenant_id=? AND user_id=? ORDER BY effective_from DESC,id DESC',[ctx.tenantId,userId]);}
async function orgChart(ctx){const users=await db.dbAll(`SELECT u.id,u.name,u.title,u.dept,u.manager_id,u.location,u.lifecycle_status,eo.position_id,eo.organization_id FROM users u LEFT JOIN employee_org_assignments eo ON eo.user_id=u.id AND eo.tenant_id=u.tenant_id AND eo.effective_to IS NULL WHERE u.tenant_id=? AND u.active='active' ORDER BY u.name`,[ctx.tenantId]);return users;}
async function assignEmployeeOrg(ctx,data){await db.dbRun(`UPDATE employee_org_assignments SET effective_to=? WHERE tenant_id=? AND user_id=? AND effective_to IS NULL`,[data.effectiveFrom,ctx.tenantId,data.userId]); const row=await db.dbGet(`INSERT INTO employee_org_assignments(tenant_id,user_id,organization_id,position_id,primary_manager_id,dotted_line_manager_id,work_arrangement,worker_type,employment_type,effective_from) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,data.userId,data.organizationId||null,data.positionId||null,data.primaryManagerId||null,data.dottedLineManagerId||null,data.workArrangement||null,data.workerType||null,data.employmentType||null,data.effectiveFrom]);await audit(ctx,'employee.org_assignment','employee',data.userId,null,row);return row;}

async function listNotificationTemplates(ctx){ return db.dbAll('SELECT * FROM notification_templates WHERE tenant_id=? ORDER BY code,channel',[ctx.tenantId]); }
async function ensureNotificationTemplate(ctx,data){
  return db.dbGet(`INSERT INTO notification_templates(tenant_id,code,subject,body,channel) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,code,channel) DO UPDATE SET subject=EXCLUDED.subject,body=EXCLUDED.body RETURNING *`,[ctx.tenantId,data.code,data.subject,data.body,data.channel||'in_app']);
}

async function seedBuiltins(ctx){await ensureNotificationTemplate(ctx,{code:'document.expiry',subject:'Document expiry reminder',body:'{{name}} is due to expire on {{expires_on}}.',channel:'in_app'}); const defs=[['Leave','Leave approval','leave.application.created',[{stepNo:1,approverType:'manager',slaHours:48},{stepNo:2,approverType:'role',approverValue:'document.verify',slaHours:72}]],['Timesheet','Timesheet approval','timesheet.submitted',[{stepNo:1,approverType:'manager',slaHours:48}]],['Payroll','Payroll maker-checker','payroll.pending_approval',[{stepNo:1,approverType:'role',approverValue:'payroll.review',slaHours:24},{stepNo:2,approverType:'role',approverValue:'payroll.approve',slaHours:24}]],['Document','Document verification','document.uploaded',[{stepNo:1,approverType:'role',approverValue:'document.verify',slaHours:72}]]];for(const [m,n,t,steps] of defs){const ex=await db.dbGet('SELECT id FROM workflow_definitions WHERE tenant_id=? AND module=? AND name=?',[ctx.tenantId,m,n]);if(!ex)await createWorkflow(ctx,{module:m,name:n,triggerEvent:t,steps});}}

module.exports={BUILTIN_ROLE_PERMISSIONS,builtinPermissionsFor,ensureBuiltInRoles,syncUserRoles,getTenantByUser,getMembership,ensureMembership,permissionsForUser,hasPermission,requirePermission,requireAnyPermission,audit,listAudit,listFeatureFlags,setFeatureFlag,listRoles,upsertRole,ensureDocumentType,listWorkflows,createWorkflow,getWorkflow,startWorkflow,listWorkflowInstances,actWorkflow,createNotification,orgTree,upsertOrg,positions,upsertPosition,recordEmployeeHistory,getEmployeeHistory,orgChart,assignEmployeeOrg,listNotificationTemplates,seedBuiltins,ensureNotificationTemplate};

