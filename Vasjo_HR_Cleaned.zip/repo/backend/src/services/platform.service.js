'use strict';
const crypto = require('node:crypto');
const db = require('../db');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { getAdapter, listAdapters } = require('./integration-adapters');

function asId(v){ const n=Number(v); return Number.isInteger(n)?n:null; }
function isoNow(){ return new Date().toISOString(); }
function json(v){ return JSON.stringify(v ?? {}); }
async function userName(id){ const u=await db.dbGet('SELECT id,name,email,manager_id,role FROM users WHERE id=?',[id]); return u; }
async function isAdmin(ctx){ return enterprise.hasPermission({permissions:ctx.permissions||[]},'admin.configure'); }
async function canSeeUser(ctx,userId){
  if(Number(userId)===Number(ctx.actorId)) return true;
  const admin=await isAdmin(ctx); if(admin) return true;
  const u=await userName(userId); return Number(u?.manager_id)===Number(ctx.actorId);
}
async function audit(ctx, action, type, id, before, after){ return enterprise.audit(ctx,action,type,id,before,after); }

// ---------------------------------------------------------------------------
// Recruitment / ATS
// ---------------------------------------------------------------------------
async function listRequisitions(ctx){
  return db.dbAll(`SELECT r.*,d.name department_name,u.name hiring_manager_name,p.title position_title,
    (SELECT COUNT(*) FROM candidates c WHERE c.requisition_id=r.id AND c.tenant_id=r.tenant_id) candidate_count
    FROM job_requisitions r LEFT JOIN departments d ON d.id=r.department_id AND d.tenant_id=r.tenant_id
    LEFT JOIN users u ON u.id=r.hiring_manager_id AND u.tenant_id=r.tenant_id
    LEFT JOIN positions p ON p.id=r.position_id AND p.tenant_id=r.tenant_id
    WHERE r.tenant_id=? ORDER BY r.created_at DESC`,[ctx.tenantId]);
}
async function saveRequisition(ctx,d){
  if(!d.title || !d.code) throw Object.assign(new Error('code and title are required'),{code:'VALIDATION_ERROR',httpStatus:422});
  const row=await db.dbGet(`INSERT INTO job_requisitions(tenant_id,code,title,department_id,position_id,hiring_manager_id,openings,budget_amount,status,description,target_join_date,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET title=EXCLUDED.title,department_id=EXCLUDED.department_id,position_id=EXCLUDED.position_id,hiring_manager_id=EXCLUDED.hiring_manager_id,openings=EXCLUDED.openings,budget_amount=EXCLUDED.budget_amount,status=EXCLUDED.status,description=EXCLUDED.description,target_join_date=EXCLUDED.target_join_date,updated_at=EXCLUDED.updated_at RETURNING *`,
    [ctx.tenantId,d.code,d.title,asId(d.departmentId),asId(d.positionId),asId(d.hiringManagerId),Math.max(1,Number(d.openings)||1),d.budgetAmount==null?null:Number(d.budgetAmount),d.status||'draft',d.description||null,d.targetJoinDate||null,ctx.actorId,nowStr(),nowStr()]);
  await audit(ctx,'recruitment.requisition.save','job_requisition',row.id,null,row); return row;
}
async function listCandidates(ctx,filters={}){
  const w=['c.tenant_id=?']; const p=[ctx.tenantId];
  if(filters.stage){w.push('c.stage=?');p.push(filters.stage)} if(filters.search){w.push('(c.first_name ILIKE ? OR c.last_name ILIKE ? OR c.email ILIKE ?)');const q=`%${filters.search}%`;p.push(q,q,q)}
  return db.dbAll(`SELECT c.*,r.code requisition_code,r.title requisition_title FROM candidates c LEFT JOIN job_requisitions r ON r.id=c.requisition_id AND r.tenant_id=c.tenant_id WHERE ${w.join(' AND ')} ORDER BY c.updated_at DESC`,p);
}
async function createCandidate(ctx,d){
  if(!d.firstName) throw Object.assign(new Error('firstName is required'),{code:'VALIDATION_ERROR',httpStatus:422});
  const row=await db.dbGet(`INSERT INTO candidates(tenant_id,requisition_id,first_name,last_name,email,phone,source,current_company,current_title,stage,status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [ctx.tenantId,asId(d.requisitionId),d.firstName,d.lastName||null,d.email||null,d.phone||null,d.source||'direct',d.currentCompany||null,d.currentTitle||null,d.stage||'applied','active',d.notes||null,nowStr(),nowStr()]);
  await db.dbRun(`INSERT INTO candidate_stage_history(tenant_id,candidate_id,from_stage,to_stage,changed_by,reason,created_at) VALUES(?,?,?,?,?,?,?)`,[ctx.tenantId,row.id,null,row.stage,ctx.actorId,'candidate created',nowStr()]);
  await audit(ctx,'recruitment.candidate.create','candidate',row.id,null,row); return row;
}
async function moveCandidate(ctx,id,stage,reason){
  const c=await db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!c) throw Object.assign(new Error('Candidate not found'),{code:'NOT_FOUND',httpStatus:404});
  const allowed=['applied','screening','shortlisted','interview','offer','accepted','joined','rejected']; if(!allowed.includes(stage)) throw Object.assign(new Error('Invalid candidate stage'),{code:'VALIDATION_ERROR',httpStatus:422});
  await db.dbRun('UPDATE candidates SET stage=?,status=?,updated_at=? WHERE tenant_id=? AND id=?',[stage,['rejected'].includes(stage)?'rejected':'active',nowStr(),ctx.tenantId,c.id]);
  await db.dbRun('INSERT INTO candidate_stage_history(tenant_id,candidate_id,from_stage,to_stage,changed_by,reason,created_at) VALUES(?,?,?,?,?,?,?)',[ctx.tenantId,c.id,c.stage,stage,ctx.actorId,reason||null,nowStr()]);
  await audit(ctx,'recruitment.candidate.stage','candidate',c.id,{stage:c.stage},{stage}); return db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,c.id]);
}
async function scheduleInterview(ctx,d){
  const row=await db.dbGet(`INSERT INTO interviews(tenant_id,candidate_id,scheduled_at,duration_minutes,interviewer_id,mode,location,status,created_at) VALUES(?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.candidateId),d.scheduledAt,Math.max(15,Number(d.durationMinutes)||45),asId(d.interviewerId),d.mode||'online',d.location||null,'scheduled',nowStr()]);
  await audit(ctx,'recruitment.interview.schedule','interview',row.id,null,row); return row;
}
async function listInterviews(ctx){return db.dbAll(`SELECT i.*,c.first_name||' '||COALESCE(c.last_name,'') candidate_name,u.name interviewer_name FROM interviews i JOIN candidates c ON c.id=i.candidate_id AND c.tenant_id=i.tenant_id LEFT JOIN users u ON u.id=i.interviewer_id AND u.tenant_id=i.tenant_id WHERE i.tenant_id=? ORDER BY i.scheduled_at`,[ctx.tenantId]);}
async function createOffer(ctx,d){
  const row=await db.dbGet(`INSERT INTO offers(tenant_id,candidate_id,offer_date,joining_date,annual_ctc,status,document_id,created_by,created_at) VALUES(?,?,?,?,?,?,?::uuid,?,?) RETURNING *`,[ctx.tenantId,asId(d.candidateId),d.offerDate||nowStr().slice(0,10),d.joiningDate||null,d.annualCtc==null?null:Number(d.annualCtc),d.status||'draft',d.documentId||null,ctx.actorId,nowStr()]);
  await audit(ctx,'recruitment.offer.create','offer',row.id,null,row); return row;
}
async function recruitmentAnalytics(ctx){
  const funnel=await db.dbAll(`SELECT stage,COUNT(*)::int count FROM candidates WHERE tenant_id=? GROUP BY stage ORDER BY stage`,[ctx.tenantId]);
  const time=await db.dbGet(`SELECT COALESCE(AVG((o.joining_date::date-c.created_at::timestamp::date)),0) avg_days FROM offers o JOIN candidates c ON c.id=o.candidate_id AND c.tenant_id=o.tenant_id WHERE o.tenant_id=? AND o.joining_date IS NOT NULL`,[ctx.tenantId]);
  return {funnel,avgDaysToJoin:Number(time?.avg_days||0)};
}

// ---------------------------------------------------------------------------
// Performance / goals
// ---------------------------------------------------------------------------
async function listCycles(ctx){return db.dbAll('SELECT * FROM performance_cycles WHERE tenant_id=? ORDER BY start_date DESC',[ctx.tenantId]);}
async function saveCycle(ctx,d){ if(!enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.manage')) throw Object.assign(new Error('Performance management permission required'),{httpStatus:403,code:'FORBIDDEN'});
  const row=await db.dbGet(`INSERT INTO performance_cycles(tenant_id,name,start_date,end_date,self_review_due,manager_review_due,status,rating_scale,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,d.name,d.startDate,d.endDate,d.selfReviewDue||null,d.managerReviewDue||null,d.status||'draft',d.ratingScale||'1-5',ctx.actorId,nowStr()]);
  await audit(ctx,'performance.cycle.create','performance_cycle',row.id,null,row); return row;
}
async function listGoals(ctx,userId){
  const target=asId(userId)||ctx.actorId; if(!(await canSeeUser(ctx,target))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  return db.dbAll(`SELECT g.*,pc.name cycle_name,u.name user_name FROM performance_goals g JOIN performance_cycles pc ON pc.id=g.cycle_id AND pc.tenant_id=g.tenant_id JOIN users u ON u.id=g.user_id AND u.tenant_id=g.tenant_id WHERE g.tenant_id=? AND g.user_id=? ORDER BY g.due_date NULLS LAST,g.id DESC`,[ctx.tenantId,target]);
}
async function saveGoal(ctx,d){
  const target=asId(d.userId)||ctx.actorId; const canManage=enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.manage'); const canSelf=enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.self'); if(!canManage && (!canSelf || target!==Number(ctx.actorId))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'}); if(!(await canSeeUser(ctx,target))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  const row=await db.dbGet(`INSERT INTO performance_goals(tenant_id,cycle_id,user_id,parent_goal_id,level,title,description,metric,target_value,weight,progress,status,due_date,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.cycleId),target,asId(d.parentGoalId),d.level||'employee',d.title,d.description||null,d.metric||null,d.targetValue==null?null:String(d.targetValue),Number(d.weight)||0,Number(d.progress)||0,d.status||'open',d.dueDate||null,ctx.actorId,nowStr(),nowStr()]);
  await audit(ctx,'performance.goal.create','performance_goal',row.id,null,row); return row;
}
async function saveReview(ctx,d){
  const target=asId(d.revieweeId)||ctx.actorId; const canManage=enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.manage'); const canSelf=enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.self'); if(!canManage && (!canSelf || target!==Number(ctx.actorId))) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'}); if(!(await canSeeUser(ctx,target)) && Number(d.reviewerId||ctx.actorId)!==ctx.actorId) throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});
  const reviewer=asId(d.reviewerId)||ctx.actorId;
  const row=await db.dbGet(`INSERT INTO performance_reviews(tenant_id,cycle_id,reviewee_id,reviewer_id,review_type,status,rating,comments,submitted_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,cycle_id,reviewee_id,reviewer_id,review_type) DO UPDATE SET status=EXCLUDED.status,rating=EXCLUDED.rating,comments=EXCLUDED.comments,submitted_at=EXCLUDED.submitted_at RETURNING *`,[ctx.tenantId,asId(d.cycleId),target,reviewer,d.reviewType||'self',d.status||'submitted',d.rating==null?null:Number(d.rating),d.comments||null,(d.status||'submitted')==='submitted'?nowStr():null,nowStr()]);
  await audit(ctx,'performance.review.save','performance_review',row.id,null,row); return row;
}
async function listReviews(ctx,userId){const target=asId(userId); const w=['r.tenant_id=?'];const p=[ctx.tenantId]; if(target){if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});w.push('r.reviewee_id=?');p.push(target)} else if(!(await isAdmin(ctx))){w.push('(r.reviewee_id=? OR r.reviewer_id=?)');p.push(ctx.actorId,ctx.actorId)} return db.dbAll(`SELECT r.*,pc.name cycle_name,ru.name reviewer_name,ee.name reviewee_name FROM performance_reviews r JOIN performance_cycles pc ON pc.id=r.cycle_id LEFT JOIN users ru ON ru.id=r.reviewer_id LEFT JOIN users ee ON ee.id=r.reviewee_id WHERE ${w.join(' AND ')} ORDER BY r.created_at DESC`,p);}
async function listFeedback(ctx,userId){const target=asId(userId);const w=['f.tenant_id=?'];const p=[ctx.tenantId];if(target)w.push('f.reviewee_id=?'),p.push(target);else if(!(await isAdmin(ctx)))w.push('(f.reviewee_id=? OR f.reviewer_id=?)'),p.push(ctx.actorId,ctx.actorId);return db.dbAll(`SELECT f.*,ru.name reviewer_name,ee.name reviewee_name,pc.name cycle_name FROM feedback_entries f JOIN performance_cycles pc ON pc.id=f.cycle_id LEFT JOIN users ru ON ru.id=f.reviewer_id LEFT JOIN users ee ON ee.id=f.reviewee_id WHERE ${w.join(' AND ')} ORDER BY f.created_at DESC`,p);}
async function savePip(ctx,d){if(!enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.manage'))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO performance_pips(tenant_id,user_id,start_date,end_date,objective,actions,success_criteria,status,outcome,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,d.startDate,d.endDate||null,d.objective,d.actions||null,d.successCriteria||null,d.status||'open',d.outcome||null,ctx.actorId,nowStr()]);await audit(ctx,'performance.pip.create','performance_pip',row.id,null,row);return row;}

// ---------------------------------------------------------------------------
// Learning
// ---------------------------------------------------------------------------
async function listCourses(ctx){return db.dbAll('SELECT * FROM learning_courses WHERE tenant_id=? ORDER BY title',[ctx.tenantId]);}
async function saveCourse(ctx,d){const row=await db.dbGet(`INSERT INTO learning_courses(tenant_id,code,title,description,mandatory,duration_hours,provider,active,created_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,mandatory=EXCLUDED.mandatory,duration_hours=EXCLUDED.duration_hours,provider=EXCLUDED.provider,active=EXCLUDED.active RETURNING *`,[ctx.tenantId,d.code,d.title,d.description||null,d.mandatory?1:0,d.durationHours==null?null:Number(d.durationHours),d.provider||null,d.active===false?0:1,nowStr()]);await audit(ctx,'learning.course.save','learning_course',row.id,null,row);return row;}
async function enroll(ctx,courseId,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_enrollments(tenant_id,course_id,user_id,status,enrolled_at) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,course_id,user_id) DO UPDATE SET status=EXCLUDED.status RETURNING *`,[ctx.tenantId,asId(courseId),target,'enrolled',nowStr()]);await audit(ctx,'learning.enroll','learning_enrollment',row.id,null,row);return row;}
async function completeEnrollment(ctx,id,score){const row=await db.dbGet('SELECT * FROM learning_enrollments WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!row)throw Object.assign(new Error('Enrollment not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await canSeeUser(ctx,row.user_id)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});await db.dbRun(`UPDATE learning_enrollments SET status='completed',completed_at=?,score=? WHERE tenant_id=? AND id=?`,[nowStr(),score==null?null:Number(score),ctx.tenantId,row.id]);await audit(ctx,'learning.complete','learning_enrollment',row.id,{status:row.status},{status:'completed',score:score==null?null:Number(score)});return db.dbGet('SELECT * FROM learning_enrollments WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);}
async function listEnrollments(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll(`SELECT e.*,c.code,c.title,c.mandatory,c.provider FROM learning_enrollments e JOIN learning_courses c ON c.id=e.course_id AND c.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.user_id=? ORDER BY e.enrolled_at DESC`,[ctx.tenantId,target]);}
async function saveCertification(ctx,d){const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_certifications(tenant_id,user_id,course_id,name,certificate_number,issued_on,expires_on,status,document_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,asId(d.courseId),d.name,d.certificateNumber||null,d.issuedOn||null,d.expiresOn||null,'active',d.documentId||null,nowStr()]);await audit(ctx,'learning.certification.save','learning_certification',row.id,null,row);return row;}
async function saveSkill(ctx,d){const target=asId(d.userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO learning_skills(tenant_id,user_id,skill,proficiency,target_proficiency,development_plan,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id,skill) DO UPDATE SET proficiency=EXCLUDED.proficiency,target_proficiency=EXCLUDED.target_proficiency,development_plan=EXCLUDED.development_plan,updated_at=EXCLUDED.updated_at RETURNING *`,[ctx.tenantId,target,d.skill,Math.min(5,Math.max(1,Number(d.proficiency)||1)),Math.min(5,Math.max(1,Number(d.targetProficiency)||3)),d.developmentPlan||null,nowStr()]);await audit(ctx,'learning.skill.save','learning_skill',row.id,null,row);return row;}

// ---------------------------------------------------------------------------
// Benefits
// ---------------------------------------------------------------------------
async function listBenefitPlans(ctx){return db.dbAll('SELECT * FROM benefit_plans WHERE tenant_id=? ORDER BY name',[ctx.tenantId]);}
async function saveBenefitPlan(ctx,d){const row=await db.dbGet(`INSERT INTO benefit_plans(tenant_id,code,name,benefit_type,employee_contribution,employer_contribution,coverage_amount,enrollment_start,enrollment_end,active,created_at) VALUES(?,?,?,?,?::numeric,?::numeric,?::numeric,?,?,?,?) ON CONFLICT(tenant_id,code) DO UPDATE SET name=EXCLUDED.name,benefit_type=EXCLUDED.benefit_type,employee_contribution=EXCLUDED.employee_contribution,employer_contribution=EXCLUDED.employer_contribution,coverage_amount=EXCLUDED.coverage_amount,enrollment_start=EXCLUDED.enrollment_start,enrollment_end=EXCLUDED.enrollment_end,active=EXCLUDED.active RETURNING *`,[ctx.tenantId,d.code,d.name,d.benefitType,d.employeeContribution||0,d.employerContribution||0,d.coverageAmount==null?null:Number(d.coverageAmount),d.enrollmentStart||null,d.enrollmentEnd||null,d.active===false?0:1,nowStr()]);await audit(ctx,'benefit.plan.save','benefit_plan',row.id,null,row);return row;}
async function enrollBenefit(ctx,planId,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const plan=await db.dbGet('SELECT * FROM benefit_plans WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(planId)]);if(!plan)throw Object.assign(new Error('Benefit plan not found'),{httpStatus:404,code:'NOT_FOUND'});const today=nowStr().slice(0,10);if(plan.enrollment_start&&today<plan.enrollment_start)throw Object.assign(new Error('Benefit enrollment has not opened yet'),{httpStatus:409,code:'ENROLLMENT_CLOSED'});if(plan.enrollment_end&&today>plan.enrollment_end)throw Object.assign(new Error('Benefit enrollment window is closed'),{httpStatus:409,code:'ENROLLMENT_CLOSED'});const row=await db.dbGet(`INSERT INTO benefit_enrollments(tenant_id,plan_id,user_id,status,enrolled_on,payroll_deduction,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,plan_id,user_id) DO UPDATE SET status=EXCLUDED.status,payroll_deduction=EXCLUDED.payroll_deduction RETURNING *`,[ctx.tenantId,plan.id,target,'enrolled',today,Number(plan.employee_contribution)||0,nowStr()]);await audit(ctx,'benefit.enroll','benefit_enrollment',row.id,null,row);return row;}
async function listBenefitsForUser(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});const [plans,enrollments,deps]=await Promise.all([listBenefitPlans(ctx),db.dbAll(`SELECT e.*,p.code,p.name,p.benefit_type,p.coverage_amount,p.employer_contribution FROM benefit_enrollments e JOIN benefit_plans p ON p.id=e.plan_id AND p.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.user_id=?`,[ctx.tenantId,target]),db.dbAll('SELECT * FROM benefit_dependents WHERE tenant_id=? AND user_id=? ORDER BY name',[ctx.tenantId,target])]);return {plans,enrollments,dependents:deps};}
async function saveDependent(ctx,d){const target=asId(d.userId)||ctx.actorId;if(Number(target)!==Number(ctx.actorId) && !(await isAdmin(ctx)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbGet(`INSERT INTO benefit_dependents(tenant_id,user_id,name,relationship,date_of_birth,beneficiary_percent,created_at) VALUES(?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,target,d.name,d.relationship,d.dateOfBirth||null,Number(d.beneficiaryPercent)||0,nowStr()]);}

// ---------------------------------------------------------------------------
// Expenses
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Assets
// ---------------------------------------------------------------------------
async function listAssets(ctx){return db.dbAll(`SELECT a.*,u.name current_user FROM assets a LEFT JOIN asset_assignments aa ON aa.asset_id=a.id AND aa.tenant_id=a.tenant_id AND aa.returned_on IS NULL LEFT JOIN users u ON u.id=aa.user_id WHERE a.tenant_id=? ORDER BY a.asset_tag`,[ctx.tenantId]);}
async function saveAsset(ctx,d){const row=await db.dbGet(`INSERT INTO assets(tenant_id,asset_tag,category,name,serial_number,purchase_cost,warranty_until,condition,status,document_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?::uuid,?) ON CONFLICT(tenant_id,asset_tag) DO UPDATE SET category=EXCLUDED.category,name=EXCLUDED.name,serial_number=EXCLUDED.serial_number,purchase_cost=EXCLUDED.purchase_cost,warranty_until=EXCLUDED.warranty_until,condition=EXCLUDED.condition,status=EXCLUDED.status,document_id=EXCLUDED.document_id RETURNING *`,[ctx.tenantId,d.assetTag,d.category,d.name,d.serialNumber||null,d.purchaseCost==null?null:Number(d.purchaseCost),d.warrantyUntil||null,d.condition||'good',d.status||'available',d.documentId||null,nowStr()]);await audit(ctx,'asset.save','asset',row.id,null,row);return row;}
async function assignAsset(ctx,id,d){const asset=await db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!asset)throw Object.assign(new Error('Asset not found'),{httpStatus:404,code:'NOT_FOUND'});const userId=asId(d.userId);if(!userId)throw Object.assign(new Error('userId is required'),{httpStatus:422,code:'VALIDATION_ERROR'});await db.dbRun('UPDATE asset_assignments SET returned_on=? WHERE tenant_id=? AND asset_id=? AND returned_on IS NULL',[nowStr().slice(0,10),ctx.tenantId,asset.id]);const row=await db.dbGet(`INSERT INTO asset_assignments(tenant_id,asset_id,user_id,action,assigned_on,notes,created_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asset.id,userId,d.action||'issue',d.assignedOn||nowStr().slice(0,10),d.notes||null,ctx.actorId,nowStr()]);await db.dbRun("UPDATE assets SET status='assigned' WHERE tenant_id=? AND id=?",[ctx.tenantId,asset.id]);await audit(ctx,'asset.assign','asset',asset.id,{status:asset.status},{status:'assigned',userId});return row;}
async function returnAsset(ctx,id,d){const asset=await db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!asset)throw Object.assign(new Error('Asset not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE asset_assignments SET returned_on=? WHERE tenant_id=? AND asset_id=? AND returned_on IS NULL',[d.returnedOn||nowStr().slice(0,10),ctx.tenantId,asset.id]);await db.dbRun("UPDATE assets SET status='available',condition=? WHERE tenant_id=? AND id=?",[d.condition||asset.condition,ctx.tenantId,asset.id]);return db.dbGet('SELECT * FROM assets WHERE tenant_id=? AND id=?',[ctx.tenantId,asset.id]);}

// ---------------------------------------------------------------------------
// HR Service Desk
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Integration hub / webhooks
// ---------------------------------------------------------------------------
function cryptoKey(){return crypto.createHash('sha256').update(process.env.APP_ENCRYPTION_KEY||'vasjo-dev-key').digest();}
function encryptSecret(v){const key=cryptoKey();const iv=crypto.randomBytes(12);const c=crypto.createCipheriv('aes-256-gcm',key,iv);const x=Buffer.concat([c.update(String(v),'utf8'),c.final()]);return `${iv.toString('base64url')}.${c.getAuthTag().toString('base64url')}.${x.toString('base64url')}`;}
function decryptSecret(v){if(!v)return null;const [ivB64,tagB64,dataB64]=String(v).split('.');const d=crypto.createDecipheriv('aes-256-gcm',cryptoKey(),Buffer.from(ivB64,'base64url'));d.setAuthTag(Buffer.from(tagB64,'base64url'));return Buffer.concat([d.update(Buffer.from(dataB64,'base64url')),d.final()]).toString('utf8');}
async function listIntegrations(ctx){const conns=await db.dbAll('SELECT id,provider,account_label,expires_at,scopes,status,updated_at FROM integration_connections WHERE tenant_id=? ORDER BY provider',[ctx.tenantId]);const jobs=await db.dbAll('SELECT * FROM integration_sync_jobs WHERE tenant_id=? ORDER BY created_at DESC LIMIT 50',[ctx.tenantId]);const subs=await db.dbAll('SELECT id,url,events_json,active,created_at FROM webhook_subscriptions WHERE tenant_id=? ORDER BY created_at DESC',[ctx.tenantId]);return {connections:conns,syncJobs:jobs,webhooks:subs,adapters:listAdapters()};}
async function saveWebhook(ctx,d){if(!/^https:\/\//i.test(String(d.url||'')))throw Object.assign(new Error('Webhook URL must use HTTPS'),{httpStatus:422,code:'VALIDATION_ERROR'});const secret=d.secret||crypto.randomBytes(24).toString('hex');const row=await db.dbGet(`INSERT INTO webhook_subscriptions(tenant_id,url,secret_enc,events_json,active,created_at) VALUES(?,?,?,?,?::jsonb,?) ON CONFLICT(tenant_id,url) DO UPDATE SET secret_enc=EXCLUDED.secret_enc,events_json=EXCLUDED.events_json,active=EXCLUDED.active RETURNING id,url,events_json,active,created_at`,[ctx.tenantId,d.url,encryptSecret(secret),json(d.events||[]),d.active===false?0:1,nowStr()]);await audit(ctx,'integration.webhook.save','webhook_subscription',row.id,null,{url:d.url,events:d.events||[]});return {...row,secret};}
async function disableWebhook(ctx,id){const before=await db.dbGet('SELECT * FROM webhook_subscriptions WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!before)throw Object.assign(new Error('Webhook not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE webhook_subscriptions SET active=0 WHERE tenant_id=? AND id=?',[ctx.tenantId,before.id]);await audit(ctx,'integration.webhook.disable','webhook_subscription',before.id,{active:before.active},{active:0});return {ok:true};}
async function createSyncJob(ctx,d){const key=d.idempotencyKey||crypto.randomUUID();const existing=await db.dbGet('SELECT * FROM integration_sync_jobs WHERE tenant_id=? AND idempotency_key=?',[ctx.tenantId,key]);if(existing)return existing;return db.dbGet(`INSERT INTO integration_sync_jobs(tenant_id,provider,direction,entity_type,status,idempotency_key,created_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,d.provider,d.direction||'outbound',d.entityType||'employee', 'queued',key,ctx.actorId,nowStr()]);}
async function testIntegration(ctx,provider){const adapter=getAdapter(provider);const row=await db.dbGet('SELECT id,provider,status,expires_at FROM integration_connections WHERE tenant_id=? AND provider=? AND status=\'active\' ORDER BY updated_at DESC LIMIT 1',[ctx.tenantId,provider]);if(!row)return {ok:false,provider,message:'No active connection',adapter:adapter.provider};return {ok:true,provider,message:'Connection record is active',expiresAt:row.expires_at,adapter:adapter.provider};}
async function removeIntegration(ctx,provider){await db.dbRun("UPDATE integration_connections SET status='revoked',updated_at=? WHERE tenant_id=? AND provider=?",[nowStr(),ctx.tenantId,provider]);await audit(ctx,'integration.disconnect','integration_connection',provider,null,{status:'revoked'});return {ok:true};}

// ---------------------------------------------------------------------------
// Analytics / reporting
// ---------------------------------------------------------------------------
async function saveReport(ctx,d){return db.dbGet(`INSERT INTO saved_reports(tenant_id,owner_id,name,area,filters_json,schedule,active,created_at,updated_at) VALUES(?,?,?,?,?::jsonb,?,?,?,?) RETURNING *`,[ctx.tenantId,ctx.actorId,d.name,d.area,json(d.filters),d.schedule||null,d.active===false?0:1,nowStr(),nowStr()]);}
async function listReports(ctx){return db.dbAll('SELECT * FROM saved_reports WHERE tenant_id=? AND (owner_id=? OR ?=1) ORDER BY updated_at DESC',[ctx.tenantId,ctx.actorId,(await isAdmin(ctx))?1:0]);}

// ---------------------------------------------------------------------------
// Mobile-optimized API contract
// ---------------------------------------------------------------------------
async function mobileHome(ctx){
  const [notifs,bals,timesheets,leave,expenses,tickets]=await Promise.all([
    db.dbAll('SELECT * FROM notifications WHERE tenant_id=? AND user_id=? ORDER BY created_at DESC LIMIT 10',[ctx.tenantId,ctx.actorId]),
    db.dbAll(`SELECT lb.*,lt.name type_name FROM leave_balances lb JOIN leave_types lt ON lt.id=lb.leave_type_id AND lt.tenant_id=lb.tenant_id WHERE lb.tenant_id=? AND lb.user_id=? AND lb.year=?`,[ctx.tenantId,ctx.actorId,new Date().getFullYear()]),
    db.dbAll('SELECT * FROM timesheets WHERE tenant_id=? AND user_id=? ORDER BY week_start DESC LIMIT 5',[ctx.tenantId,ctx.actorId]),
    db.dbAll('SELECT * FROM leave_applications WHERE tenant_id=? AND user_id=? ORDER BY applied_at DESC LIMIT 5',[ctx.tenantId,ctx.actorId]),
    db.dbAll("SELECT * FROM expense_claims WHERE tenant_id=? AND user_id=? ORDER BY created_at DESC LIMIT 5",[ctx.tenantId,ctx.actorId]),
    db.dbAll("SELECT * FROM service_tickets WHERE tenant_id=? AND requester_id=? ORDER BY created_at DESC LIMIT 5",[ctx.tenantId,ctx.actorId])
  ]);return {notifications:notifs,leaveBalances:bals,timesheets,leaveApplications:leave,expenses,tickets};
}

// ---------------------------------------------------------------------------
// AI: permission-aware deterministic assistant + document intelligence + payroll anomalies
// ---------------------------------------------------------------------------
function has(ctx,p){return enterprise.hasPermission({permissions:ctx.permissions||[]},p);}
async function aiAssistant(ctx,question){
  const q=String(question||'').trim(); if(!q)throw Object.assign(new Error('question is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const lower=q.toLowerCase(); let intent='help'; let result={answer:'I can answer workforce, leave, timesheet, document and payroll questions that your permissions allow.'};
  if(/on leave today|leave today/.test(lower)){
    intent='leave.today'; if(!has(ctx,'leave.approve')&&!has(ctx,'employee.*')&&!has(ctx,'reports.read')){
      const rows=await db.dbAll(`SELECT u.name,la.from_date,la.to_date,lt.name leave_type FROM leave_applications la JOIN users u ON u.id=la.user_id AND u.tenant_id=la.tenant_id JOIN leave_types lt ON lt.id=la.leave_type_id AND lt.tenant_id=la.tenant_id WHERE la.tenant_id=? AND la.status='approved' AND CURRENT_DATE BETWEEN la.from_date AND la.to_date AND la.user_id=?`,[ctx.tenantId,ctx.actorId]);result={answer:rows.length?`You are on ${rows[0].leave_type} today.`:'You are not on approved leave today.',rows};
    } else {const rows=await db.dbAll(`SELECT u.name,la.from_date,la.to_date,lt.name leave_type FROM leave_applications la JOIN users u ON u.id=la.user_id AND u.tenant_id=la.tenant_id JOIN leave_types lt ON lt.id=la.leave_type_id AND lt.tenant_id=la.tenant_id WHERE la.tenant_id=? AND la.status='approved' AND to_char(current_date,'YYYY-MM-DD') BETWEEN la.from_date AND la.to_date ORDER BY u.name`,[ctx.tenantId]);result={answer:`${rows.length} employee(s) are on approved leave today.`,rows};}
  } else if(/documents? expire|expir.*document/.test(lower)){
    intent='documents.expiring'; if(!has(ctx,'document.read'))throw Object.assign(new Error('AI document access is not permitted'),{httpStatus:403,code:'FORBIDDEN'}); const rows=await db.dbAll("SELECT d.id,d.name,d.expires_on,u.name owner_name FROM documents d LEFT JOIN users u ON u.id=d.owner_user_id AND u.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.expires_on BETWEEN to_char(current_date,'YYYY-MM-DD') AND to_char(current_date + interval '30 day','YYYY-MM-DD') ORDER BY d.expires_on",[ctx.tenantId]);result={answer:`${rows.length} document(s) expire in the next 30 days.`,rows};
  } else if(/missing timesheet/.test(lower)){
    intent='timesheets.missing'; const target=await isAdmin(ctx)||has(ctx,'reports.read')?null:ctx.actorId; const rows=target?await db.dbAll(`SELECT u.name,u.id FROM users u WHERE u.tenant_id=? AND u.id=? AND NOT EXISTS (SELECT 1 FROM timesheets t WHERE t.tenant_id=u.tenant_id AND t.user_id=u.id AND t.week_start>=to_char(current_date - interval '21 day','YYYY-MM-DD'))`,[ctx.tenantId,target]):await db.dbAll(`SELECT u.name,u.id FROM users u WHERE u.tenant_id=? AND u.active='active' AND NOT EXISTS (SELECT 1 FROM timesheets t WHERE t.tenant_id=u.tenant_id AND t.user_id=u.id AND t.week_start>=to_char(current_date - interval '21 day','YYYY-MM-DD')) ORDER BY u.name`,[ctx.tenantId]);result={answer:`${rows.length} employee(s) have no timesheet in the last three weeks.`,rows};
  } else if(/headcount|workforce/.test(lower)){
    intent='workforce.headcount'; if(!has(ctx,'analytics.read')&&!has(ctx,'employee.*'))throw Object.assign(new Error('Workforce analytics permission is required'),{httpStatus:403,code:'FORBIDDEN'}); const r=await db.dbGet("SELECT COUNT(*)::int n FROM users WHERE tenant_id=? AND active='active'",[ctx.tenantId]); result={answer:`Current active headcount is ${Number(r.n||0)}.`,headcount:Number(r.n||0)};
  } else if(/payroll.*increase|why did payroll/.test(lower)){
    intent='payroll.explain'; if(!has(ctx,'ai.payroll')&&!has(ctx,'payroll.read'))throw Object.assign(new Error('Payroll intelligence permission is required'),{httpStatus:403,code:'FORBIDDEN'}); const r=await db.dbAll(`SELECT pr.id,pr.payroll_month,COALESCE(SUM(pd.gross_earning),0) gross_total,COALESCE(SUM(pd.net_salary),0) net_total FROM payroll_runs pr JOIN payroll_details pd ON pd.payroll_run_id=pr.id AND pd.tenant_id=pr.tenant_id WHERE pr.tenant_id=? GROUP BY pr.id,pr.payroll_month ORDER BY pr.payroll_month DESC LIMIT 2`,[ctx.tenantId]); const delta=r.length>1?Number(r[0].net_total)-Number(r[1].net_total):0; result={answer:r.length>1?`Latest net payroll changed by ₹${Math.round(delta).toLocaleString('en-IN')} versus the previous run.`:'Not enough payroll runs to compare.',runs:r};
  } else if(/missing|not.*complete/.test(lower)&&/attendance/.test(lower)){
    intent='attendance.missing'; const rows=await db.dbAll(`SELECT u.id,u.name FROM users u WHERE u.tenant_id=? AND u.active='active' AND NOT EXISTS (SELECT 1 FROM attendance_records ar WHERE ar.tenant_id=u.tenant_id AND ar.user_id=u.id AND ar.date=to_char(current_date,'YYYY-MM-DD')) ORDER BY u.name`,[ctx.tenantId]); result={answer:`${rows.length} active employee(s) have no attendance record today.`,rows};
  }
  await db.dbRun('INSERT INTO ai_queries(tenant_id,actor_id,question,intent,result_json,created_at) VALUES(?,?,?,?,?::jsonb,?)',[ctx.tenantId,ctx.actorId,q,intent,json(result),nowStr()]);
  await audit(ctx,'ai.query','ai_query',null,null,{intent,question:q}); return {intent,...result,explainability:{permissionChecked:true,tenantId:ctx.tenantId}};
}
async function getAiHistory(ctx){return db.dbAll('SELECT id,question,intent,created_at,result_json FROM ai_queries WHERE tenant_id=? AND actor_id=? ORDER BY created_at DESC LIMIT 50',[ctx.tenantId,ctx.actorId]);}
async function extractDocument(ctx,documentId){
  if(!has(ctx,'ai.document')&&!(await isAdmin(ctx)))throw Object.assign(new Error('Document AI permission is required'),{httpStatus:403,code:'FORBIDDEN'});
  const doc=await enterprise.getDocument(ctx,documentId); if(!doc)throw Object.assign(new Error('Document not found'),{httpStatus:404,code:'NOT_FOUND'});
  const classification=(doc.document_type_name||'unknown').toLowerCase();
  const fields={filename:doc.original_filename||doc.name,mimeType:doc.mime_type,sizeBytes:Number(doc.size_bytes||0)};
  const confidence=classification==='unknown'?0.55:0.85;
  const row=await db.dbGet(`INSERT INTO ai_document_extractions(tenant_id,document_id,status,extractor,classification,fields_json,confidence,created_at,updated_at) VALUES(?,?,?,?,?,?::jsonb,?,?,?) RETURNING *`,[ctx.tenantId,doc.id,'completed','metadata','document',json(fields),confidence,nowStr(),nowStr()]);
  await audit(ctx,'ai.document.extract','document',doc.id,null,{extractionId:row.id,classification,confidence}); return row;
}
async function confirmDocumentExtraction(ctx,id,d){const ex=await db.dbGet('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!ex)throw Object.assign(new Error('Extraction not found'),{httpStatus:404,code:'NOT_FOUND'});if(!(await isAdmin(ctx)))throw Object.assign(new Error('Only authorized reviewers can confirm extracted fields'),{httpStatus:403,code:'FORBIDDEN'});await db.dbRun('UPDATE ai_document_extractions SET fields_json=?::jsonb,confirmed_by=?,confirmed_at=?,updated_at=?,status=\'confirmed\' WHERE tenant_id=? AND id=?',[json(d.fields),ctx.actorId,nowStr(),nowStr(),ctx.tenantId,ex.id]);await audit(ctx,'ai.document.confirm','ai_document_extraction',ex.id,{status:ex.status},{status:'confirmed',fields:d.fields});return db.dbGet('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND id=?',[ctx.tenantId,ex.id]);}
async function listAiExtractions(ctx,documentId){return db.dbAll('SELECT * FROM ai_document_extractions WHERE tenant_id=? AND (?::uuid IS NULL OR document_id=?::uuid) ORDER BY created_at DESC',[ctx.tenantId,documentId||null,documentId||null]);}
async function scanPayrollAnomalies(ctx,runId){
  if(!has(ctx,'ai.payroll')&&!has(ctx,'payroll.read'))throw Object.assign(new Error('Payroll intelligence permission is required'),{httpStatus:403,code:'FORBIDDEN'});
  const run=asId(runId); if(!run)throw Object.assign(new Error('runId is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  await db.dbRun('DELETE FROM ai_payroll_anomalies WHERE tenant_id=? AND payroll_run_id=?',[ctx.tenantId,run]);
  const rows=await db.dbAll(`SELECT pd.user_id,pd.gross_earning,pd.net_salary,pd.basic_earning,pr.payroll_month,u.name,u.bank_account_no FROM payroll_details pd JOIN payroll_runs pr ON pr.id=pd.payroll_run_id AND pr.tenant_id=pd.tenant_id JOIN users u ON u.id=pd.user_id AND u.tenant_id=pd.tenant_id WHERE pd.tenant_id=? AND pd.payroll_run_id=?`,[ctx.tenantId,run]);
  const prev=await db.dbGet(`SELECT pr.id FROM payroll_runs pr WHERE pr.tenant_id=? AND pr.id<? ORDER BY pr.id DESC LIMIT 1`,[ctx.tenantId,run]);
  const prevMap={}; if(prev)for(const r of await db.dbAll('SELECT user_id,net_salary,gross_earning FROM payroll_details WHERE tenant_id=? AND payroll_run_id=?',[ctx.tenantId,prev.id]))prevMap[r.user_id]=r;
  for(const r of rows){const p=prevMap[r.user_id]; if(p&&Number(p.net_salary)>0){const delta=(Number(r.net_salary)-Number(p.net_salary))/Number(p.net_salary);if(Math.abs(delta)>=0.25){await db.dbRun(`INSERT INTO ai_payroll_anomalies(tenant_id,payroll_run_id,user_id,anomaly_type,severity,score,explanation,source_json,created_at) VALUES(?,?,?,?,?,?,?,?::jsonb,?)`,[ctx.tenantId,run,r.user_id,'net_pay_change',Math.abs(delta)>=0.5?'high':'medium',Math.min(1,Math.abs(delta)),`Net pay changed ${(delta*100).toFixed(1)}% versus the previous payroll run.`,json({previous:p.net_salary,current:r.net_salary}),nowStr()]);}}
    if(!r.bank_account_no)await db.dbRun(`INSERT INTO ai_payroll_anomalies(tenant_id,payroll_run_id,user_id,anomaly_type,severity,score,explanation,source_json,created_at) VALUES(?,?,?,?,?,?,?,?::jsonb,?)`,[ctx.tenantId,run,r.user_id,'missing_bank_account','high',1,'Employee has no bank account recorded.',json({}),nowStr()]);
  }
  return db.dbAll(`SELECT a.*,u.name user_name FROM ai_payroll_anomalies a LEFT JOIN users u ON u.id=a.user_id AND u.tenant_id=a.tenant_id WHERE a.tenant_id=? AND a.payroll_run_id=? ORDER BY a.score DESC`,[ctx.tenantId,run]);
}
async function reviewAnomaly(ctx,id,status,notes){const row=await db.dbGet('SELECT * FROM ai_payroll_anomalies WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!row)throw Object.assign(new Error('Anomaly not found'),{httpStatus:404,code:'NOT_FOUND'});await db.dbRun('UPDATE ai_payroll_anomalies SET status=?,reviewed_by=?,reviewed_at=?,explanation=? WHERE tenant_id=? AND id=?',[status||'reviewed',ctx.actorId,nowStr(),notes?`${row.explanation} Review: ${notes}`:row.explanation,ctx.tenantId,row.id]);await audit(ctx,'ai.payroll.review','ai_payroll_anomaly',row.id,{status:row.status},{status:status||'reviewed',notes});return db.dbGet('SELECT * FROM ai_payroll_anomalies WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);}


async function updateInterview(ctx,id,d){
  const row=await db.dbGet('SELECT * FROM interviews WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!row) throw Object.assign(new Error('Interview not found'),{httpStatus:404,code:'NOT_FOUND'});
  await db.dbRun(`UPDATE interviews SET status=?,feedback=?,rating=?,scheduled_at=?,duration_minutes=?,mode=?,location=? WHERE tenant_id=? AND id=?`,[d.status||row.status,d.feedback??row.feedback,d.rating==null?row.rating:Number(d.rating),d.scheduledAt||row.scheduled_at,Number(d.durationMinutes)||row.duration_minutes,d.mode||row.mode,d.location??row.location,ctx.tenantId,row.id]);
  return db.dbGet('SELECT * FROM interviews WHERE tenant_id=? AND id=?',[ctx.tenantId,row.id]);
}
async function acceptOffer(ctx,id){
  const o=await db.dbGet('SELECT * FROM offers WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!o) throw Object.assign(new Error('Offer not found'),{httpStatus:404,code:'NOT_FOUND'});
  await db.dbRun("UPDATE offers SET status='accepted',accepted_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,o.id]);
  await moveCandidate(ctx,o.candidate_id,'accepted','Offer accepted');
  return db.dbGet('SELECT * FROM offers WHERE tenant_id=? AND id=?',[ctx.tenantId,o.id]);
}
async function convertCandidateToEmployee(ctx,id,d={}){
  if(!enterprise.hasPermission({permissions:ctx.permissions||[]},'recruitment.write')&&!isAdmin(ctx)) throw Object.assign(new Error('Recruitment write permission required'),{httpStatus:403,code:'FORBIDDEN'});
  const c=await db.dbGet('SELECT * FROM candidates WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]); if(!c) throw Object.assign(new Error('Candidate not found'),{httpStatus:404,code:'NOT_FOUND'});
  const existing=c.email?await db.dbGet('SELECT id FROM users WHERE tenant_id=? AND lower(email)=lower(?)',[ctx.tenantId,c.email]):null; if(existing) return {userId:existing.id,existing:true};
  const email=c.email||d.email; if(!email) throw Object.assign(new Error('Candidate email is required'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const password=String(d.initialPassword||''); if(password.length<12||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/[0-9]/.test(password)||!/[^A-Za-z0-9]/.test(password)) throw Object.assign(new Error('initialPassword must be at least 12 characters and include upper, lower, number and special character'),{httpStatus:422,code:'VALIDATION_ERROR'});
  const role=d.role||'employee'; const {hashPassword}=require('./auth.service');const pw=hashPassword(password);
  const row=await db.dbGet(`INSERT INTO users(tenant_id,name,email,password_hash,password_salt,role,title,phone,joined_date,must_reset_password,active,avatar_color,created_at) VALUES(?,?,?,?,?,?,?,?,?::date,true,'active','#2F6F5E',?) RETURNING id,name,email`,[ctx.tenantId,`${c.first_name} ${c.last_name||''}`.trim(),email,pw.hash,pw.salt,role,c.current_title||null,c.phone||null,d.joinedDate||nowStr().slice(0,10),nowStr()]);
  await enterprise.ensureMembership(row.id,ctx.tenantId,role); await db.dbRun("UPDATE candidates SET stage='joined',status='hired',updated_at=? WHERE tenant_id=? AND id=?",[nowStr(),ctx.tenantId,c.id]); await audit(ctx,'recruitment.candidate.convert','candidate',c.id,{stage:c.stage},{stage:'joined',userId:row.id}); return {userId:row.id,existing:false,mustResetPassword:true};
}
async function calibrateRating(ctx,d){if(!enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.calibrate')&&!await isAdmin(ctx))throw Object.assign(new Error('Calibration requires HR/admin permission'),{httpStatus:403,code:'FORBIDDEN'});const row=await db.dbGet(`INSERT INTO performance_calibrations(tenant_id,cycle_id,user_id,original_rating,calibrated_rating,notes,calibrated_by,created_at) VALUES(?,?,?,?,?,?,?,?) RETURNING *`,[ctx.tenantId,asId(d.cycleId),asId(d.userId),Number(d.originalRating),Number(d.calibratedRating),d.notes||null,ctx.actorId,nowStr()]);await audit(ctx,'performance.calibration','performance_calibration',row.id,null,row);return row;}
async function listCalibrations(ctx,cycleId){if(!enterprise.hasPermission({permissions:ctx.permissions||[]},'performance.calibrate')&&!await isAdmin(ctx))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll('SELECT c.*,u.name user_name FROM performance_calibrations c LEFT JOIN users u ON u.id=c.user_id AND u.tenant_id=c.tenant_id WHERE c.tenant_id=? AND (? IS NULL OR c.cycle_id=?) ORDER BY c.created_at DESC',[ctx.tenantId,cycleId||null,cycleId||null]);}
async function listCertifications(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll('SELECT c.*,lc.title course_title FROM learning_certifications c LEFT JOIN learning_courses lc ON lc.id=c.course_id AND lc.tenant_id=c.tenant_id WHERE c.tenant_id=? AND c.user_id=? ORDER BY c.expires_on NULLS LAST',[ctx.tenantId,target]);}
async function listAssetsForUser(ctx,userId){const target=asId(userId)||ctx.actorId;if(!(await canSeeUser(ctx,target)))throw Object.assign(new Error('Forbidden'),{httpStatus:403,code:'FORBIDDEN'});return db.dbAll(`SELECT a.*,aa.assigned_on,aa.returned_on,aa.notes FROM assets a JOIN asset_assignments aa ON aa.asset_id=a.id AND aa.tenant_id=a.tenant_id WHERE a.tenant_id=? AND aa.user_id=? ORDER BY aa.assigned_on DESC`,[ctx.tenantId,target]);}
async function executeSavedReport(ctx,id){const report=await db.dbGet('SELECT * FROM saved_reports WHERE tenant_id=? AND id=?',[ctx.tenantId,asId(id)]);if(!report)throw Object.assign(new Error('Report not found'),{httpStatus:404,code:'NOT_FOUND'});const area=report.area;let rows=[];if(area==='workforce')rows=await db.dbAll("SELECT dept,COUNT(*)::int headcount FROM users WHERE tenant_id=? AND active='active' GROUP BY dept ORDER BY headcount DESC",[ctx.tenantId]);else if(area==='attendance')rows=await db.dbAll("SELECT date attendance_date,COUNT(*)::int records FROM attendance_records WHERE tenant_id=? GROUP BY date ORDER BY date DESC LIMIT 90",[ctx.tenantId]);else if(area==='leave')rows=await db.dbAll('SELECT status,COUNT(*)::int count,SUM(days) days FROM leave_applications WHERE tenant_id=? GROUP BY status',[ctx.tenantId]);else if(area==='recruitment')rows=await db.dbAll('SELECT stage,COUNT(*)::int count FROM candidates WHERE tenant_id=? GROUP BY stage',[ctx.tenantId]);else if(area==='documents')rows=await db.dbAll('SELECT verification_status,COUNT(*)::int count FROM documents WHERE tenant_id=? GROUP BY verification_status',[ctx.tenantId]);else if(area==='support')rows=await db.dbAll('SELECT status,COUNT(*)::int count FROM service_tickets WHERE tenant_id=? GROUP BY status',[ctx.tenantId]);else rows=await db.dbAll('SELECT payroll_month,total_employees,total_gross,total_net,status FROM payroll_runs WHERE tenant_id=? ORDER BY payroll_month DESC LIMIT 24',[ctx.tenantId]);return {report,rows};}
async function publishEvent(ctx,eventType,payload){const eventId=crypto.randomUUID();const subs=await db.dbAll('SELECT * FROM webhook_subscriptions WHERE tenant_id=? AND active=1',[ctx.tenantId]);for(const s of subs){let events=[];try{events=JSON.parse(s.events_json||'[]')}catch{} if(events.length&&!events.includes(eventType))continue;await db.dbRun(`INSERT INTO webhook_deliveries(tenant_id,subscription_id,event_type,event_id,payload_json,status,created_at) VALUES(?,?,?,?,?::jsonb,'queued',?) ON CONFLICT(subscription_id,event_id) DO NOTHING`,[ctx.tenantId,s.id,eventType,eventId,json(payload),nowStr()]);}return {eventId,queued:subs.length};}
async function processWebhookDeliveries(ctx){const rows=await db.dbAll("SELECT d.*,s.url FROM webhook_deliveries d JOIN webhook_subscriptions s ON s.id=d.subscription_id AND s.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.status='queued' ORDER BY d.id LIMIT 25",[ctx.tenantId]);for(const d of rows){const attempt=Number(d.attempts||0)+1;try{const body=JSON.stringify(d.payload_json);const secret=decryptSecret((await db.dbGet('SELECT secret_enc FROM webhook_subscriptions WHERE tenant_id=? AND id=?',[ctx.tenantId,d.subscription_id]))?.secret_enc||'');const signature=crypto.createHmac('sha256',secret||'').update(body).digest('hex');const resp=await fetch(d.url,{method:'POST',headers:{'content-type':'application/json','x-vasjo-event':d.event_type,'x-vasjo-signature':signature},body});if(!resp.ok)throw new Error(`HTTP ${resp.status}`);await db.dbRun("UPDATE webhook_deliveries SET status='delivered',attempts=?,delivered_at=? WHERE tenant_id=? AND id=?",[attempt,nowStr(),ctx.tenantId,d.id]);}catch(e){await db.dbRun("UPDATE webhook_deliveries SET attempts=?,error=?,status=? WHERE tenant_id=? AND id=?",[attempt,String(e.message||e),attempt>=5?'failed':'queued',ctx.tenantId,d.id]);}}return {processed:rows.length};}

module.exports={
  listRequisitions,saveRequisition,listCandidates,createCandidate,moveCandidate,scheduleInterview,updateInterview,listInterviews,createOffer,acceptOffer,convertCandidateToEmployee,recruitmentAnalytics,
  listCycles,saveCycle,listGoals,saveGoal,saveReview,listReviews,listFeedback,savePip,calibrateRating,listCalibrations,
  listCourses,saveCourse,enroll,completeEnrollment,listEnrollments,saveCertification,listCertifications,saveSkill,
  listBenefitPlans,saveBenefitPlan,enrollBenefit,listBenefitsForUser,saveDependent,
  
  listAssets,saveAsset,assignAsset,returnAsset,listAssetsForUser,
  
  listIntegrations,saveWebhook,disableWebhook,createSyncJob,testIntegration,removeIntegration,
  saveReport,listReports,executeSavedReport,mobileHome,publishEvent,processWebhookDeliveries,
  aiAssistant,getAiHistory,extractDocument,confirmDocumentExtraction,listAiExtractions,scanPayrollAnomalies,reviewAnomaly,
};

