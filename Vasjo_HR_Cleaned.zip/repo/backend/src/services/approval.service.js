'use strict';
// Reusable approval engine. One implementation of:
//   submitForApproval / getPendingApprovals / canApprove / approve / reject /
//   getApprover / recordApproval
// plus the workflow state machine for each approvable entity.
//
// Adding an approvable entity = adding one entry to ENTITY_TYPES (table,
// owner/approver columns, statuses, transitions, permission). Leave and
// timesheets keep their existing, separately tested approval paths; the
// engine is intentionally config-driven so they can be registered later
// without touching this file's logic.
const db = require('../db');
const authz = require('./authorization.service');
const { NotFoundError, ForbiddenError, ConflictError, BusinessRuleError, ValidationError } = require('../errors');
const { nowStr } = require('./utils');

const ENTITY_TYPES = {
  expense: {
    label: 'Expense claim', table: 'expense_claims', ownerCol: 'user_id', approverCol: 'manager_id',
    permission: 'expense.approve', pendingStatus: 'submitted', approvedStatus: 'approved', rejectedStatus: 'rejected',
    // draft -> submitted (pending approval) -> approved | rejected
    transitions: { draft: ['submitted'], submitted: ['approved', 'rejected'], approved: [], rejected: [] },
    hasSubmittedAt: true,
    select: `SELECT c.*, u.name AS employee_name FROM expense_claims c LEFT JOIN users u ON u.id = c.user_id AND u.tenant_id = c.tenant_id`,
    alias: 'c',
  },
  hr_request: {
    label: 'HR request', table: 'service_tickets', ownerCol: 'requester_id', approverCol: null, // approver = requester's manager
    permission: 'helpdesk.approve', pendingStatus: 'open', approvedStatus: 'approved', rejectedStatus: 'rejected',
    // open (pending approval) -> approved | rejected; fulfilment then runs approved -> in_progress -> resolved -> closed
    transitions: { open: ['approved', 'rejected'], approved: ['in_progress', 'resolved', 'closed'], in_progress: ['resolved', 'closed'], resolved: ['closed', 'in_progress'], rejected: [], closed: [] },
    select: `SELECT t.*, r.name AS requester_name, a.name AS assignee_name FROM service_tickets t LEFT JOIN users r ON r.id = t.requester_id AND r.tenant_id = t.tenant_id LEFT JOIN users a ON a.id = t.assignee_id AND a.tenant_id = t.tenant_id`,
    alias: 't',
  },
};
const DECISIONS = { approve: 'approve', approved: 'approve', reject: 'reject', rejected: 'reject' };

function entity(type) {
  const cfg = ENTITY_TYPES[type];
  if (!cfg) throw new ValidationError(`Unknown approval entity type: ${type}`);
  return cfg;
}
const id = (v) => { const n = Number(v); if (!Number.isInteger(n) || n <= 0) throw new ValidationError('Invalid id'); return n; };

// ---- state machine ---------------------------------------------------------
function canTransition(type, from, to) { return (entity(type).transitions[from] || []).includes(to); }
function assertTransition(type, from, to) {
  if (!canTransition(type, from, to)) {
    throw new ConflictError(`Invalid status change for ${entity(type).label.toLowerCase()}: ${from} -> ${to}`, 'INVALID_TRANSITION');
  }
}

async function loadRow(ctx, type, entityId) {
  const cfg = entity(type);
  const row = await db.dbGet(`${cfg.select} WHERE ${cfg.alias}.tenant_id=? AND ${cfg.alias}.id=?`, [ctx.tenantId, id(entityId)]);
  if (!row) throw new NotFoundError(`${cfg.label} not found`);
  return row;
}
async function ownerOf(ctx, cfg, row) {
  return db.dbGet('SELECT id, name, manager_id FROM users WHERE tenant_id=? AND id=?', [ctx.tenantId, row[cfg.ownerCol]]);
}

// The approver of record: the claim's stored manager, else the owner's current manager.
async function getApprover(ctx, type, row) {
  const cfg = entity(type);
  if (cfg.approverCol && row[cfg.approverCol] != null) return Number(row[cfg.approverCol]);
  const owner = await ownerOf(ctx, cfg, row);
  return owner && owner.manager_id != null ? Number(owner.manager_id) : null;
}

// ---- authorization for one decision ---------------------------------------
// allowed = has entity approve permission AND is not the requester AND
//           (is admin OR is the approver of record / a delegate of that approver)
async function canApprove(ctx, type, row) {
  const cfg = entity(type);
  if (!authz.can(ctx.user, cfg.permission)) return { allowed: false, reason: 'MISSING_PERMISSION' };
  if (Number(row[cfg.ownerCol]) === Number(ctx.actorId)) return { allowed: false, reason: 'SELF_APPROVAL' };
  if (authz.isAdmin(ctx.user)) return { allowed: true };
  const approver = await getApprover(ctx, type, row);
  if (approver == null) return { allowed: false, reason: 'NO_APPROVER' };
  const scope = await authz.managerScope(ctx);
  return scope.includes(approver) ? { allowed: true } : { allowed: false, reason: 'NOT_APPROVER' };
}

// ---- audit trail + notifications ------------------------------------------
async function recordApproval(ctx, type, entityId, action, comment, extra = {}) {
  await db.dbRun('INSERT INTO approvals_log (tenant_id, entity_type, entity_id, action, actor_id, acted_at, notes) VALUES (?,?,?,?,?,?,?)',
    [ctx.tenantId, type, String(entityId), action, ctx.actorId, nowStr(), comment || null]);
  const enterprise = require('./enterprise.service');
  await enterprise.audit(ctx, `${type}.${action}`, type, entityId, extra.before || null, { ...(extra.after || {}), comment: comment || null });
}
async function notify(ctx, userId, type, title, message, entityType, entityId) {
  if (userId == null) return;
  await db.dbRun('INSERT INTO notifications (tenant_id, user_id, type, title, message, entity_type, entity_id, created_at) VALUES (?,?,?,?,?,?,?,?)',
    [ctx.tenantId, userId, type, title, message, entityType, String(entityId), nowStr()]);
}

// ---- submit ----------------------------------------------------------------
// Moves draft -> submitted (pending approval). Only the owner may submit.
async function submitForApproval(ctx, type, entityId) {
  const cfg = entity(type);
  if (type === 'hr_request') throw new BusinessRuleError('HR requests enter approval when they are created', 'NOT_SUBMITTABLE');
  const row = await loadRow(ctx, type, entityId);
  if (Number(row[cfg.ownerCol]) !== Number(ctx.actorId)) throw new ForbiddenError('Only the owner can submit this record');
  assertTransition(type, row.status, cfg.pendingStatus);
  if (type === 'expense' && !(Number(row.total_amount) > 0)) throw new BusinessRuleError('Expense claim must have a positive total', 'EMPTY_CLAIM');
  const approver = await getApprover(ctx, type, row);
  const res = await db.dbRun(`UPDATE ${cfg.table} SET status=?, ${cfg.hasSubmittedAt ? 'submitted_at=?, ' : ''}${cfg.approverCol ? `${cfg.approverCol}=?, ` : ''}updated_at=? WHERE tenant_id=? AND id=? AND status=?`,
    [cfg.pendingStatus, ...(cfg.hasSubmittedAt ? [nowStr()] : []), ...(cfg.approverCol ? [approver] : []), nowStr(), ctx.tenantId, row.id, row.status]);
  if (res.changes !== 1) throw new ConflictError('The record changed while submitting; reload and retry', 'STALE_STATE');
  await recordApproval(ctx, type, row.id, 'submitted', null, { before: { status: row.status }, after: { status: cfg.pendingStatus, approver } });
  await notify(ctx, approver, `${type}.pending`, `${cfg.label} awaiting approval`, `A ${cfg.label.toLowerCase()} is awaiting your approval.`, type, row.id);
  return loadRow(ctx, type, row.id);
}

// ---- queue -----------------------------------------------------------------
// Everything of this type that is pending AND that ctx may decide.
async function getPendingApprovals(ctx, type) {
  const cfg = entity(type);
  if (!authz.can(ctx.user, cfg.permission)) return [];
  const a = cfg.alias;
  const params = [ctx.tenantId, cfg.pendingStatus, ctx.actorId];
  let where = `${a}.tenant_id=? AND ${a}.status=? AND ${a}.${cfg.ownerCol} <> ?`;
  if (!authz.isAdmin(ctx.user)) {
    const scope = await authz.managerScope(ctx);
    const ph = scope.map(() => '?').join(',');
    // approver of record = stored approver column, else the owner's manager
    const approverExpr = cfg.approverCol
      ? `COALESCE(${a}.${cfg.approverCol}, (SELECT ow.manager_id FROM users ow WHERE ow.id=${a}.${cfg.ownerCol} AND ow.tenant_id=${a}.tenant_id))`
      : `(SELECT ow.manager_id FROM users ow WHERE ow.id=${a}.${cfg.ownerCol} AND ow.tenant_id=${a}.tenant_id)`;
    where += ` AND ${approverExpr} IN (${ph})`;
    params.push(...scope);
  }
  return db.dbAll(`${cfg.select} WHERE ${where} ORDER BY ${a}.id DESC`, params);
}

// ---- decide ----------------------------------------------------------------
async function decide(ctx, type, entityId, decision, comment) {
  const cfg = entity(type);
  const normalized = DECISIONS[String(decision || '').toLowerCase()];
  if (!normalized) throw new ValidationError('decision must be "approve" or "reject"');
  if (normalized === 'reject' && !String(comment || '').trim()) throw new ValidationError('A comment is required when rejecting');
  const row = await loadRow(ctx, type, entityId);
  const check = await canApprove(ctx, type, row);
  if (!check.allowed) {
    throw new ForbiddenError(check.reason === 'SELF_APPROVAL' ? 'You cannot approve your own request' : 'You are not an approver for this request', check.reason);
  }
  const target = normalized === 'approve' ? cfg.approvedStatus : cfg.rejectedStatus;
  if (row.status !== cfg.pendingStatus) {
    throw new ConflictError(`This ${cfg.label.toLowerCase()} has already been decided (status: ${row.status})`, 'ALREADY_DECIDED');
  }
  assertTransition(type, row.status, target);
  // Compare-and-set on status: two concurrent decisions cannot both win.
  const res = await db.dbRun(`UPDATE ${cfg.table} SET status=?, decided_by=?, decided_at=?, decision_comment=?, updated_at=? WHERE tenant_id=? AND id=? AND status=?`,
    [target, ctx.actorId, nowStr(), comment || null, nowStr(), ctx.tenantId, row.id, row.status]);
  if (res.changes !== 1) throw new ConflictError(`This ${cfg.label.toLowerCase()} has already been decided`, 'ALREADY_DECIDED');
  await recordApproval(ctx, type, row.id, target, comment, { before: { status: row.status }, after: { status: target } });
  await notify(ctx, Number(row[cfg.ownerCol]), `${type}.${target}`, `${cfg.label} ${target}`, `Your ${cfg.label.toLowerCase()} was ${target}${comment ? `: ${comment}` : '.'}`, type, row.id);
  return loadRow(ctx, type, row.id);
}
const approve = (ctx, type, entityId, comment) => decide(ctx, type, entityId, 'approve', comment);
const reject = (ctx, type, entityId, comment) => decide(ctx, type, entityId, 'reject', comment);

async function listHistory(ctx, type, entityId) {
  const row = await loadRow(ctx, type, entityId);
  const cfg = entity(type);
  const mine = Number(row[cfg.ownerCol]) === Number(ctx.actorId);
  if (!mine && !authz.isAdmin(ctx.user) && !(await canApprove(ctx, type, row)).allowed) throw new ForbiddenError();
  return db.dbAll('SELECT l.*, u.name AS actor_name FROM approvals_log l LEFT JOIN users u ON u.id=l.actor_id WHERE l.tenant_id=? AND l.entity_type=? AND l.entity_id=? ORDER BY l.id', [ctx.tenantId, type, String(row.id)]);
}

module.exports = {
  ENTITY_TYPES, canTransition, assertTransition, getApprover, canApprove, submitForApproval,
  getPendingApprovals, approve, reject, decide, recordApproval, listHistory,
};
