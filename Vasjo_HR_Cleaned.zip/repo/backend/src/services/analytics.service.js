'use strict';
// Workforce analytics. Every number is computed from PostgreSQL at request
// time (nothing hardcoded). Scope: admins see the tenant, managers see their
// own team (direct reports + delegated); everyone else is refused.
// Date bounds are computed in JS and bound as parameters (no interval math in SQL).
const db = require('../db');
const authz = require('./authorization.service');
const { ForbiddenError, ValidationError } = require('../errors');

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const ymd = (d) => d.toISOString().slice(0, 10);
const shift = (base, days) => ymd(new Date(new Date(`${base}T00:00:00Z`).getTime() + days * 86400000));

function parseRange({ from, to } = {}) {
  const today = ymd(new Date());
  const end = to || today;
  const start = from || shift(end, -30);
  for (const [k, v] of [['from', start], ['to', end]]) if (!DATE_RE.test(v) || Number.isNaN(Date.parse(v))) throw new ValidationError(`${k} must be a valid YYYY-MM-DD date`);
  if (start > end) throw new ValidationError('from must not be after to');
  if ((Date.parse(end) - Date.parse(start)) / 86400000 > 366) throw new ValidationError('Date range cannot exceed 366 days');
  return { from: start, to: end, today };
}

async function analyticsOverview(ctx, filters = {}) {
  const admin = authz.isAdmin(ctx.user);
  if (!admin && !authz.isApprover(ctx.user)) throw new ForbiddenError('Analytics are available to managers and administrators');
  const { from, to, today } = parseRange(filters);
  const department = filters.department ? String(filters.department) : null;

  // Scoped user set (all statuses); reused as a sub-select by every metric.
  const uw = ['u.tenant_id=?']; const up = [ctx.tenantId];
  if (!admin) {
    const scope = await authz.managerScope(ctx);
    uw.push(`u.manager_id IN (${scope.map(() => '?').join(',')})`); up.push(...scope);
  }
  if (department) { uw.push('u.dept=?'); up.push(department); }
  const users = `SELECT u.id FROM users u WHERE ${uw.join(' AND ')}`;
  const n = async (sql, params) => Number((await db.dbGet(sql, params))?.n || 0);
  const t = ctx.tenantId;

  const [headcount, hires, exits, expiring, expired, tickets, submitted, hrPending, approvedAmt] = await Promise.all([
    n(`SELECT COUNT(*) AS n FROM users u WHERE ${uw.join(' AND ')} AND u.active='active'`, up),
    n(`SELECT COUNT(*) AS n FROM users u WHERE ${uw.join(' AND ')} AND u.joined_date BETWEEN ?::date AND ?::date`, [...up, from, to]),
    n(`SELECT COUNT(DISTINCT e.user_id) AS n FROM employee_lifecycle_events e WHERE e.tenant_id=? AND e.event_type='exited' AND e.effective_date BETWEEN ? AND ? AND e.user_id IN (${users})`, [t, from, to, ...up]),
    n(`SELECT COUNT(*) AS n FROM documents d WHERE d.tenant_id=? AND d.status<>'archived' AND d.expires_on BETWEEN ? AND ? AND d.owner_user_id IN (${users})`, [t, today, shift(today, 30), ...up]),
    n(`SELECT COUNT(*) AS n FROM documents d WHERE d.tenant_id=? AND d.status<>'archived' AND d.expires_on < ? AND d.owner_user_id IN (${users})`, [t, today, ...up]),
    n(`SELECT COUNT(*) AS n FROM service_tickets s WHERE s.tenant_id=? AND s.status NOT IN ('resolved','closed','rejected') AND s.requester_id IN (${users})`, [t, ...up]),
    n(`SELECT COUNT(*) AS n FROM expense_claims c WHERE c.tenant_id=? AND c.status='submitted' AND c.user_id IN (${users})`, [t, ...up]),
    n(`SELECT COUNT(*) AS n FROM service_tickets s WHERE s.tenant_id=? AND s.status='open' AND s.requester_id IN (${users})`, [t, ...up]),
    db.dbGet(`SELECT COALESCE(SUM(c.total_amount),0) AS n FROM expense_claims c WHERE c.tenant_id=? AND c.status='approved' AND c.claim_date BETWEEN ? AND ? AND c.user_id IN (${users})`, [t, from, to, ...up]).then((r) => Number(r?.n || 0)),
  ]);
  const departmentMix = await db.dbAll(`SELECT u.dept AS dept, COUNT(*) AS count FROM users u WHERE ${uw.join(' AND ')} AND u.active='active' GROUP BY u.dept ORDER BY count DESC, dept`, up);
  const leaveStatus = await db.dbAll(`SELECT la.status AS status, COUNT(*) AS count FROM leave_applications la WHERE la.tenant_id=? AND la.from_date<=?::date AND la.to_date>=?::date AND la.user_id IN (${users}) GROUP BY la.status ORDER BY la.status`, [t, to, from, ...up]);
  const num = (r) => ({ ...r, count: Number(r.count) });
  return {
    range: { from, to }, scope: admin ? 'tenant' : 'team', department,
    headcount, hires30: hires, exits30: exits, hires, exits, // hires30/exits30 kept for the existing UI contract
    docsExpiring30: expiring, docsExpired: expired, openTickets: tickets, submittedExpenses: submitted,
    pendingHrRequests: hrPending, approvedExpenseAmount: approvedAmt,
    departmentMix: departmentMix.map(num), leaveStatus: leaveStatus.map(num),
  };
}

module.exports = { analyticsOverview, parseRange };
