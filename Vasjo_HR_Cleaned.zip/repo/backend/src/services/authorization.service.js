'use strict';
// Canonical authorization. EVERY access decision goes through this module:
//   1. authentication   -> requireAuth (auth.service) / ctx.user present
//   2. permission (RBAC) -> can() / requirePermission()
//   3. tenant           -> all queries are tenant-scoped; ctx.tenantId only
//   4. ownership        -> isOwner()
//   5. manager relation -> isManagerOf() (direct manager or delegate)
// The users.role column is NEVER consulted for access decisions; it is only a
// seed for role assignment (see enterprise.syncUserRoles).
const db = require('../db');
const { AuthenticationError, ForbiddenError } = require('../errors');

function hasPermission(user, permission) {
  const ps = (user && user.permissions) || [];
  if (ps.includes('*') || ps.includes(permission)) return true;
  const [resource] = String(permission).split('.');
  return ps.includes(`${resource}.*`);
}
const can = hasPermission;
const isAdmin = (user) => hasPermission(user, 'admin.configure');
const isApprover = (user) => hasPermission(user, 'manager.approve') || isAdmin(user);

// Express middleware factories -------------------------------------------
function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.session || !req.session.user) return next(new AuthenticationError());
    if (!hasPermission(req.session.user, permission)) {
      return res.status(403).json({ error: 'Missing permission', code: 'FORBIDDEN', permission });
    }
    return next();
  };
}
function requireAnyPermission(permissions) {
  return (req, res, next) => {
    if (!req.session || !req.session.user) return next(new AuthenticationError());
    if (!permissions.some((p) => hasPermission(req.session.user, p))) {
      return res.status(403).json({ error: 'Missing required permission', code: 'FORBIDDEN', permissions });
    }
    return next();
  };
}
function requireAllPermissions(permissions) {
  return (req, res, next) => {
    if (!req.session || !req.session.user) return next(new AuthenticationError());
    const missing = permissions.filter((p) => !hasPermission(req.session.user, p));
    if (missing.length) return res.status(403).json({ error: 'Missing permission', code: 'FORBIDDEN', permission: missing[0] });
    return next();
  };
}

// Relationship checks (data-dependent) -----------------------------------
const isOwner = (ctx, ownerId) => Number(ownerId) === Number(ctx.actorId);

// Users a person may act for as manager: themself + anyone who delegated to them.
async function managerScope(ctx) {
  const delegators = await db.dbAll('SELECT id FROM users WHERE tenant_id=? AND delegate_id=?', [ctx.tenantId, ctx.actorId]);
  return [Number(ctx.actorId), ...delegators.map((r) => Number(r.id))];
}
async function isManagerOf(ctx, targetUserId) {
  const target = await db.dbGet('SELECT manager_id FROM users WHERE tenant_id=? AND id=?', [ctx.tenantId, Number(targetUserId)]);
  if (!target || target.manager_id == null) return false;
  return (await managerScope(ctx)).includes(Number(target.manager_id));
}
async function canViewEmployee(ctx, targetUserId) {
  if (isOwner(ctx, targetUserId) || isAdmin(ctx.user)) return true;
  return isManagerOf(ctx, targetUserId);
}
async function assertCanViewEmployee(ctx, targetUserId) {
  if (!(await canViewEmployee(ctx, targetUserId))) throw new ForbiddenError();
}
// ctx builder shared by every route module.
function contextFrom(req) {
  const user = req.session.user;
  return { tenantId: user.tenant_id, actorId: user.id, user, permissions: user.permissions || [], req };
}

module.exports = {
  hasPermission, can, isAdmin, isApprover,
  requirePermission, requireAnyPermission, requireAllPermissions,
  isOwner, managerScope, isManagerOf, canViewEmployee, assertCanViewEmployee, contextFrom,
};
