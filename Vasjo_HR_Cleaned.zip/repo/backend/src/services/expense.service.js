'use strict';
const db = require('../db');
const authz = require('./authorization.service');
const approval = require('./approval.service');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { NotFoundError, ForbiddenError, ValidationError, ConflictError } = require('../errors');

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const toId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const today = () => nowStr().slice(0, 10);

function normalizeLine(l, fallbackDate) {
  const amount = Number(l && l.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new ValidationError('Each expense line needs an amount greater than zero');
  const expenseDate = (l.expenseDate || fallbackDate || today());
  if (!DATE_RE.test(expenseDate)) throw new ValidationError('expenseDate must be YYYY-MM-DD');
  return {
    expenseDate, amount: Math.round(amount * 100) / 100, category: String(l.category || 'other').trim() || 'other',
    merchant: l.merchant || null, description: l.description || null, documentId: l.documentId || null,
  };
}
const LINE_SQL = 'INSERT INTO expense_lines(tenant_id,claim_id,expense_date,category,merchant,amount,description,document_id) VALUES(?,?,?,?,?,?,?,?::uuid)';
const lineParams = (ctx, claimId, l) => [ctx.tenantId, claimId, l.expenseDate, l.category, l.merchant, l.amount, l.description, l.documentId];

async function getClaim(ctx, claimId) {
  const claim = await db.dbGet('SELECT * FROM expense_claims WHERE tenant_id=? AND id=?', [ctx.tenantId, toId(claimId)]);
  if (!claim) throw new NotFoundError('Claim not found');
  return claim;
}
async function recalc(ctx, claimId) {
  const t = await db.dbGet('SELECT COALESCE(SUM(amount),0) AS total FROM expense_lines WHERE tenant_id=? AND claim_id=?', [ctx.tenantId, claimId]);
  await db.dbRun('UPDATE expense_claims SET total_amount=?, updated_at=? WHERE tenant_id=? AND id=?', [Number(t.total || 0), nowStr(), ctx.tenantId, claimId]);
}

async function listExpenses(ctx, filters = {}) {
  const where = ['c.tenant_id=?']; const p = [ctx.tenantId];
  if (filters.userId) {
    const uid = toId(filters.userId); if (!uid) throw new ValidationError('userId must be an integer');
    await authz.assertCanViewEmployee(ctx, uid);
    where.push('c.user_id=?'); p.push(uid);
  } else if (!authz.isAdmin(ctx.user)) { where.push('c.user_id=?'); p.push(ctx.actorId); }
  if (filters.status) { where.push('c.status=?'); p.push(String(filters.status)); }
  return db.dbAll(`SELECT c.*, u.name AS employee_name FROM expense_claims c LEFT JOIN users u ON u.id=c.user_id AND u.tenant_id=c.tenant_id WHERE ${where.join(' AND ')} ORDER BY c.id DESC`, p);
}

async function createExpense(ctx, d = {}) {
  const userId = toId(d.userId) || ctx.actorId;
  if (!authz.isOwner(ctx, userId) && !authz.isAdmin(ctx.user)) throw new ForbiddenError();
  const claimDate = d.claimDate || today();
  if (!DATE_RE.test(claimDate)) throw new ValidationError('claimDate must be YYYY-MM-DD');
  const lines = (d.lines || []).map((l) => normalizeLine(l, claimDate));
  const owner = await db.dbGet('SELECT manager_id FROM users WHERE tenant_id=? AND id=?', [ctx.tenantId, userId]);
  if (!owner) throw new NotFoundError('Employee not found');
  const claimNo = d.claimNo || `EXP-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const row = await db.dbGet(`INSERT INTO expense_claims(tenant_id,claim_no,user_id,claim_date,currency,total_amount,status,manager_id,reimbursement_status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [ctx.tenantId, claimNo, userId, claimDate, d.currency || 'INR', 0, 'draft', owner.manager_id || null, 'pending', d.notes || null, nowStr(), nowStr()]);
  for (const l of lines) await db.dbRun(LINE_SQL, lineParams(ctx, row.id, l));
  await recalc(ctx, row.id);
  await enterprise.audit(ctx, 'expense.created', 'expense_claim', row.id, null, { status: 'draft' });
  return getClaim(ctx, row.id);
}

// Lines may only be edited by the owner while the claim is still a draft.
async function addExpenseLine(ctx, claimId, l) {
  const claim = await getClaim(ctx, claimId);
  if (!authz.isOwner(ctx, claim.user_id)) throw new ForbiddenError();
  if (claim.status !== 'draft') throw new ConflictError('Only draft claims can be edited', 'NOT_EDITABLE');
  const line = normalizeLine(l || {}, claim.claim_date);
  const row = await db.dbGet(`${LINE_SQL} RETURNING *`, lineParams(ctx, claim.id, line));
  await recalc(ctx, claim.id);
  return row;
}
async function listExpenseLines(ctx, claimId) {
  const claim = await getClaim(ctx, claimId);
  if (!(await authz.canViewEmployee(ctx, claim.user_id)) && !(await approval.canApprove(ctx, 'expense', claim)).allowed) throw new ForbiddenError();
  return db.dbAll('SELECT * FROM expense_lines WHERE tenant_id=? AND claim_id=? ORDER BY expense_date, id', [ctx.tenantId, claim.id]);
}

const submitExpense = (ctx, claimId) => approval.submitForApproval(ctx, 'expense', claimId);
const decideExpense = (ctx, claimId, decision, comment) => approval.decide(ctx, 'expense', claimId, decision, comment);
const listExpenseApprovals = (ctx) => approval.getPendingApprovals(ctx, 'expense');

module.exports = { listExpenses, createExpense, addExpenseLine, listExpenseLines, submitExpense, decideExpense, listExpenseApprovals };
