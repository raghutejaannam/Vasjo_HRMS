'use strict';
// HR Service Desk requests. A request starts as `open` = pending approval and
// is approved/rejected through approval.service; after approval the assignee
// works it approved -> in_progress -> resolved -> closed (transitions are
// validated by approval.assertTransition, never set freely).
const db = require('../db');
const authz = require('./authorization.service');
const approval = require('./approval.service');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { NotFoundError, ForbiddenError, ValidationError } = require('../errors');

const PRIORITIES = ['low', 'medium', 'high', 'critical'];
const SLA_HOURS = { low: 72, medium: 48, high: 24, critical: 4 };
const toId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };

async function getTicket(ctx, ticketId) {
  const t = await db.dbGet('SELECT * FROM service_tickets WHERE tenant_id=? AND id=?', [ctx.tenantId, toId(ticketId)]);
  if (!t) throw new NotFoundError('Request not found');
  return t;
}
async function canWorkTicket(ctx, t) {
  return authz.isAdmin(ctx.user) || Number(t.assignee_id || 0) === Number(ctx.actorId);
}
async function canSeeTicket(ctx, t) {
  if (authz.isOwner(ctx, t.requester_id) || (await canWorkTicket(ctx, t))) return true;
  return (await approval.canApprove(ctx, 'hr_request', t)).allowed;
}

async function listTickets(ctx, filters = {}) {
  const w = ['t.tenant_id=?']; const p = [ctx.tenantId];
  if (filters.status) { w.push('t.status=?'); p.push(String(filters.status)); }
  if (filters.priority) { w.push('t.priority=?'); p.push(String(filters.priority)); }
  if (!authz.isAdmin(ctx.user)) { w.push('(t.requester_id=? OR t.assignee_id=?)'); p.push(ctx.actorId, ctx.actorId); }
  return db.dbAll(`SELECT t.*, r.name AS requester_name, a.name AS assignee_name FROM service_tickets t LEFT JOIN users r ON r.id=t.requester_id AND r.tenant_id=t.tenant_id LEFT JOIN users a ON a.id=t.assignee_id AND a.tenant_id=t.tenant_id WHERE ${w.join(' AND ')} ORDER BY t.id DESC`, p);
}

async function createTicket(ctx, d = {}) {
  const subject = String(d.subject || '').trim();
  if (!subject) throw new ValidationError('subject is required');
  const priority = d.priority || 'medium';
  if (!PRIORITIES.includes(priority)) throw new ValidationError(`priority must be one of ${PRIORITIES.join(', ')}`);
  const no = d.ticketNo || `HR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}${Math.floor(Math.random() * 10)}`;
  const due = new Date(Date.now() + SLA_HOURS[priority] * 3600000).toISOString();
  const assignee = d.assigneeId != null && authz.isAdmin(ctx.user) ? toId(d.assigneeId) : null; // only HR admins pre-assign
  const row = await db.dbGet(`INSERT INTO service_tickets(tenant_id,ticket_no,requester_id,category,subject,description,priority,status,assignee_id,sla_due_at,knowledge_url,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [ctx.tenantId, no, ctx.actorId, d.category || 'HR', subject, d.description || null, priority, 'open', assignee, due, d.knowledgeUrl || null, nowStr(), nowStr()]);
  await approval.recordApproval(ctx, 'hr_request', row.id, 'submitted', null, { after: { status: 'open' } });
  const owner = await db.dbGet('SELECT manager_id FROM users WHERE tenant_id=? AND id=?', [ctx.tenantId, ctx.actorId]);
  if (owner && owner.manager_id != null) {
    await db.dbRun('INSERT INTO notifications (tenant_id,user_id,type,title,message,entity_type,entity_id,created_at) VALUES (?,?,?,?,?,?,?,?)',
      [ctx.tenantId, owner.manager_id, 'hr_request.pending', 'HR request awaiting approval', `${subject}`, 'hr_request', String(row.id), nowStr()]);
  }
  return row;
}

// Fulfilment updates. Status changes are validated against the state machine
// and can never be used to approve/reject (that requires approval.decide).
async function updateTicket(ctx, ticketId, d = {}) {
  const t = await getTicket(ctx, ticketId);
  const worker = await canWorkTicket(ctx, t);
  const requesterClosing = authz.isOwner(ctx, t.requester_id) && d.status === 'closed' && t.status === 'resolved';
  if (!worker && !requesterClosing) throw new ForbiddenError();
  let status = t.status;
  if (d.status && d.status !== t.status) {
    if (['approved', 'rejected'].includes(d.status)) throw new ForbiddenError('Use the approval workflow to approve or reject a request', 'USE_APPROVAL_WORKFLOW');
    approval.assertTransition('hr_request', t.status, d.status);
    status = d.status;
  }
  if (d.priority && !PRIORITIES.includes(d.priority)) throw new ValidationError(`priority must be one of ${PRIORITIES.join(', ')}`);
  const resolved = status === 'resolved' || status === 'closed';
  await db.dbRun('UPDATE service_tickets SET status=?, assignee_id=?, priority=?, resolution=?, resolved_at=?, updated_at=? WHERE tenant_id=? AND id=?',
    [status, (worker && d.assigneeId != null ? toId(d.assigneeId) : null) ?? t.assignee_id, worker && d.priority ? d.priority : t.priority,
      d.resolution || t.resolution, resolved ? (t.resolved_at || nowStr()) : null, nowStr(), ctx.tenantId, t.id]);
  await enterprise.audit(ctx, 'helpdesk.ticket.update', 'service_ticket', t.id, { status: t.status }, { status });
  return getTicket(ctx, t.id);
}

async function addTicketNote(ctx, ticketId, note, internal = true) {
  const t = await getTicket(ctx, ticketId);
  if (!(await canSeeTicket(ctx, t))) throw new ForbiddenError();
  if (!String(note || '').trim()) throw new ValidationError('note is required');
  const isInternal = internal && (await canWorkTicket(ctx, t)) ? 1 : 0; // requesters cannot write internal notes
  return db.dbGet('INSERT INTO service_ticket_notes(tenant_id,ticket_id,author_id,note,internal,created_at) VALUES(?,?,?,?,?,?) RETURNING *', [ctx.tenantId, t.id, ctx.actorId, note, isInternal, nowStr()]);
}
async function ticketNotes(ctx, ticketId) {
  const t = await getTicket(ctx, ticketId);
  if (!(await canSeeTicket(ctx, t))) throw new ForbiddenError();
  const staff = await canWorkTicket(ctx, t);
  return db.dbAll(`SELECT n.*, u.name AS author_name FROM service_ticket_notes n LEFT JOIN users u ON u.id=n.author_id AND u.tenant_id=n.tenant_id WHERE n.tenant_id=? AND n.ticket_id=? ${staff ? '' : 'AND n.internal=0'} ORDER BY n.id`, [ctx.tenantId, t.id]);
}

const listServiceRequestApprovals = (ctx) => approval.getPendingApprovals(ctx, 'hr_request');
const decideServiceRequest = (ctx, ticketId, decision, comment) => approval.decide(ctx, 'hr_request', ticketId, decision, comment);

module.exports = { listTickets, createTicket, updateTicket, addTicketNote, ticketNotes, listServiceRequestApprovals, decideServiceRequest };
