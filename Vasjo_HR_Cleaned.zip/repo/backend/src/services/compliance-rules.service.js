'use strict';
// Effective-dated statutory/compliance rule configuration (PF, ESI, PT, ...).
// History is never destroyed: "delete" deactivates, so payroll runs that used a
// rule remain reproducible.
const db = require('../db');
const enterprise = require('./enterprise.service');
const { nowStr } = require('./utils');
const { NotFoundError, ValidationError, ConflictError } = require('../errors');

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TYPE_RE = /^[A-Z][A-Z0-9_]{1,39}$/;
const toId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const flag = (v) => (v === false || v === 0 || v === '0' || v === 'false' ? 0 : 1);

function validate(d, { partial = false } = {}) {
  const out = {};
  const has = (k) => d[k] !== undefined;
  if (!partial || has('ruleType')) {
    const t = String(d.ruleType || '').trim().toUpperCase();
    if (!TYPE_RE.test(t)) throw new ValidationError('ruleType must be 2-40 characters: A-Z, 0-9 and _');
    out.rule_type = t;
  }
  if (!partial || has('effectiveFrom')) {
    if (!DATE_RE.test(String(d.effectiveFrom || '')) || Number.isNaN(Date.parse(d.effectiveFrom))) throw new ValidationError('effectiveFrom must be a valid YYYY-MM-DD date');
    out.effective_from = d.effectiveFrom;
  }
  if (has('effectiveTo') && d.effectiveTo !== null && d.effectiveTo !== '') {
    if (!DATE_RE.test(String(d.effectiveTo)) || Number.isNaN(Date.parse(d.effectiveTo))) throw new ValidationError('effectiveTo must be a valid YYYY-MM-DD date');
    out.effective_to = d.effectiveTo;
  } else if (has('effectiveTo')) out.effective_to = null;
  if (has('value')) {
    if (d.value === null || d.value === '') out.value = null;
    else { const n = Number(d.value); if (!Number.isFinite(n)) throw new ValidationError('value must be a number'); out.value = n; }
  }
  for (const [k, col] of [['jurisdiction', 'jurisdiction'], ['employeeCategory', 'employee_category'], ['formula', 'formula'], ['sourceReference', 'source_reference']]) {
    if (has(k)) out[col] = d[k] === '' || d[k] == null ? null : String(d[k]).trim();
  }
  if (has('active')) out.active = flag(d.active);
  return out;
}

async function get(ctx, id) {
  const row = await db.dbGet('SELECT * FROM compliance_rules WHERE tenant_id=? AND id=?', [ctx.tenantId, toId(id)]);
  if (!row) throw new NotFoundError('Compliance rule not found');
  return row;
}
const same = (a, b) => (a || '') === (b || '');

// Two ACTIVE rules for the same type/jurisdiction/category may not overlap in time.
async function assertNoOverlap(ctx, rule, excludeId) {
  if (!rule.active) return;
  const others = await db.dbAll('SELECT * FROM compliance_rules WHERE tenant_id=? AND rule_type=? AND active=1', [ctx.tenantId, rule.rule_type]);
  const end = rule.effective_to || '9999-12-31';
  for (const o of others) {
    if (excludeId && Number(o.id) === Number(excludeId)) continue;
    if (!same(o.jurisdiction, rule.jurisdiction) || !same(o.employee_category, rule.employee_category)) continue;
    if (rule.effective_from <= (o.effective_to || '9999-12-31') && o.effective_from <= end) {
      throw new ConflictError(`Overlaps active rule #${o.id} (${o.effective_from} to ${o.effective_to || 'open-ended'}). End-date that rule first.`, 'RULE_OVERLAP');
    }
  }
}

async function listComplianceRules(ctx, { ruleType, active, asOf } = {}) {
  const where = ['tenant_id=?']; const p = [ctx.tenantId];
  if (ruleType) { where.push('rule_type=?'); p.push(String(ruleType).toUpperCase()); }
  if (active !== undefined && active !== '') { where.push('active=?'); p.push(flag(active)); }
  if (asOf) {
    if (!DATE_RE.test(asOf)) throw new ValidationError('asOf must be YYYY-MM-DD');
    where.push('effective_from<=? AND (effective_to IS NULL OR effective_to>=?)'); p.push(asOf, asOf);
  }
  return db.dbAll(`SELECT * FROM compliance_rules WHERE ${where.join(' AND ')} ORDER BY rule_type, effective_from DESC, id DESC`, p);
}
const getComplianceRule = get;

async function createComplianceRule(ctx, d = {}) {
  const v = validate(d);
  if (v.effective_to && v.effective_to < v.effective_from) throw new ValidationError('effectiveTo cannot be before effectiveFrom');
  if ((v.value === undefined || v.value === null) && !v.formula) throw new ValidationError('Provide a value or a formula');
  const rule = { active: 1, jurisdiction: null, employee_category: null, effective_to: null, value: null, formula: null, source_reference: null, ...v };
  await assertNoOverlap(ctx, rule);
  const row = await db.dbGet(`INSERT INTO compliance_rules(tenant_id,rule_type,jurisdiction,employee_category,effective_from,effective_to,value,formula,source_reference,active,created_at,updated_at,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`,
    [ctx.tenantId, rule.rule_type, rule.jurisdiction, rule.employee_category, rule.effective_from, rule.effective_to, rule.value, rule.formula, rule.source_reference, rule.active, nowStr(), nowStr(), ctx.actorId]);
  await enterprise.audit(ctx, 'compliance_rule.created', 'compliance_rule', row.id, null, row);
  return row;
}

async function updateComplianceRule(ctx, id, d = {}) {
  const before = await get(ctx, id);
  const v = validate(d, { partial: true });
  if (!Object.keys(v).length) throw new ValidationError('No updatable fields supplied');
  const merged = { ...before, ...v };
  if (merged.effective_to && merged.effective_to < merged.effective_from) throw new ValidationError('effectiveTo cannot be before effectiveFrom');
  if ((merged.value === null || merged.value === undefined) && !merged.formula) throw new ValidationError('Provide a value or a formula');
  await assertNoOverlap(ctx, merged, before.id);
  const cols = Object.keys(v);
  await db.dbRun(`UPDATE compliance_rules SET ${cols.map((c) => `${c}=?`).join(', ')}, updated_at=?, updated_by=? WHERE tenant_id=? AND id=?`,
    [...cols.map((c) => v[c]), nowStr(), ctx.actorId, ctx.tenantId, before.id]);
  const after = await get(ctx, before.id);
  await enterprise.audit(ctx, 'compliance_rule.updated', 'compliance_rule', before.id, before, after);
  return after;
}
async function setComplianceRuleActive(ctx, id, active) {
  return updateComplianceRule(ctx, id, { active: !!active });
}
// "Delete" preserves history: it deactivates.
async function deactivateComplianceRule(ctx, id) {
  const before = await get(ctx, id);
  if (!before.active) return before;
  return setComplianceRuleActive(ctx, id, false);
}

module.exports = {
  listComplianceRules, getComplianceRule, createComplianceRule, updateComplianceRule,
  setComplianceRuleActive, deactivateComplianceRule, upsertComplianceRule: createComplianceRule,
};
