'use strict';

const cors = require('cors');

const DEVELOPMENT_ORIGIN = 'http://localhost:5173';
const ALLOWED_METHODS = ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'];
const ALLOWED_HEADERS = ['Content-Type', 'Authorization', 'X-CSRF-Token', 'X-Request-Id'];

function parseCorsOrigins(value, { nodeEnv = process.env.NODE_ENV } = {}) {
  const configured = String(value || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean)
    .map((origin) => new URL(origin).origin);

  if (configured.length) return [...new Set(configured)];
  return nodeEnv === 'production' ? [] : [DEVELOPMENT_ORIGIN];
}

function createCorsMiddleware({ origin = process.env.CORS_ORIGIN, nodeEnv = process.env.NODE_ENV } = {}) {
  const allowedOrigins = new Set(parseCorsOrigins(origin, { nodeEnv }));
  return cors({
    origin(requestOrigin, callback) {
      // Non-browser and same-origin requests do not send Origin. They are not
      // granted a browser CORS response, but remain valid server requests.
      if (!requestOrigin) return callback(null, true);
      return callback(null, allowedOrigins.has(requestOrigin));
    },
    credentials: true,
    methods: ALLOWED_METHODS,
    allowedHeaders: ALLOWED_HEADERS,
    exposedHeaders: ['X-Request-Id'],
    optionsSuccessStatus: 204,
    maxAge: 600,
  });
}

module.exports = { DEVELOPMENT_ORIGIN, ALLOWED_METHODS, ALLOWED_HEADERS, parseCorsOrigins, createCorsMiddleware };
