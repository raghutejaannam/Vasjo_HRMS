'use strict';
// Central HTTP error handling + request transaction lifecycle.
const { AppError } = require('../errors');

const IS_PROD = () => process.env.NODE_ENV === 'production';

// Express 4 does not catch rejected promises from async handlers.
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

// Map any thrown value onto { status, body }. Never leaks stack traces and
// never leaks 5xx messages in production.
function normalizeError(err) {
  if (err instanceof AppError) {
    const body = { error: err.message, code: err.code };
    if (err.details !== undefined) body.details = err.details;
    return { status: err.httpStatus, body };
  }
  // body-parser / express.json errors
  if (err && err.type === 'entity.parse.failed') return { status: 400, body: { error: 'Malformed JSON body', code: 'VALIDATION_ERROR' } };
  if (err && err.type === 'entity.too.large') return { status: 413, body: { error: 'Request body too large', code: 'PAYLOAD_TOO_LARGE' } };
  // Zod
  if (err && err.name === 'ZodError') return { status: 400, body: { error: 'Validation failed', code: 'VALIDATION_ERROR', details: err.issues } };
  // PostgreSQL / Prisma constraint violations
  const pg = err && (err.code || err.meta?.code);
  if (err && (err.code === 'P2002' || pg === '23505')) return { status: 409, body: { error: 'A record with the same unique value already exists', code: 'CONFLICT' } };
  if (err && (err.code === 'P2003' || pg === '23503')) return { status: 409, body: { error: 'The record references, or is referenced by, another record', code: 'CONFLICT' } };
  if (pg === '22P02' || pg === '22007' || pg === '22008') return { status: 400, body: { error: 'Malformed value in request', code: 'VALIDATION_ERROR' } };
  // Legacy business-rule errors: Error with .code (and optionally .httpStatus).
  if (err && typeof err.code === 'string' && !/^P\d{4}$/.test(err.code) && /^[A-Z][A-Z0-9_]+$/.test(err.code) && err.httpStatus !== 500) {
    return { status: err.httpStatus || 400, body: { error: err.message, code: err.code } };
  }
  return { status: 500, body: { error: IS_PROD() ? 'Internal server error' : (err && err.message) || 'Internal server error', code: 'INTERNAL_ERROR' } };
}

// Express error middleware (must be registered last, 4 args).
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const { status, body } = normalizeError(err);
  if (status >= 500) {
    // Full detail goes to the server log only, correlated by request id.
    console.error(JSON.stringify({ level: 'error', requestId: req.requestId, method: req.method, path: req.originalUrl || req.url, message: err && err.message, stack: err && err.stack }));
  }
  if (req.requestId) body.requestId = req.requestId;
  if (res.headersSent) return next ? next(err) : undefined;
  res.status(status).json(body);
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: 'Not found', code: 'NOT_FOUND', requestId: req.requestId });
}

// Runs every authenticated request inside ONE database transaction (carrying
// the tenant id for PostgreSQL RLS) and COMMITS BEFORE THE RESPONSE IS SENT.
//  - Commit-before-respond gives read-your-writes: a client that reloads
//    immediately after a 2xx can never observe pre-commit state.
//  - A 4xx/5xx response (or thrown error) rolls the whole request back, so a
//    failed request cannot leave partial writes behind.
// `db` is injected so tests can substitute a fake.
class RollbackSignal extends Error { constructor() { super('rollback'); this.rollback = true; } }

function atomicRequest(db) {
  return (req, res, next) => {
    const tenantId = req.session && req.session.user && req.session.user.tenant_id;
    if (!tenantId) return next();
    const origEnd = res.end.bind(res);
    let captured = null;
    let settle;
    const handlerDone = new Promise((resolve) => { settle = resolve; });
    res.end = function (...args) { // eslint-disable-line func-names
      if (captured) return res;
      captured = args;
      settle();
      return res;
    };
    const flush = () => { res.end = origEnd; origEnd(...(captured || [])); };
    db.withRequestContext(tenantId, async () => {
      next();
      await handlerDone;
      if (res.statusCode >= 400) throw new RollbackSignal();
    }).then(flush, (err) => {
      if (err instanceof RollbackSignal) return flush();
      res.end = origEnd;
      // commit failed: the client must not be told the operation succeeded
      res.removeHeader && res.removeHeader('Content-Length');
      errorHandler(err, req, res);
    });
    // Handler threw synchronously / delegated to next(err): ensure we unwind.
    res.once('close', () => { if (!captured) settle(); });
  };
}

module.exports = { asyncHandler, errorHandler, notFoundHandler, normalizeError, atomicRequest, RollbackSignal };
