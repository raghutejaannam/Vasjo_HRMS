'use strict';
// Canonical application errors. Anything thrown from a service/route that
// should reach the client with a specific HTTP status is an AppError.
// Legacy code throws `Object.assign(new Error(msg), { code, httpStatus })`;
// http/error-handler.js normalises both shapes into one response envelope:
//   { error: <message>, code: <MACHINE_CODE>, details?: <object> }

class AppError extends Error {
  constructor(message, { status = 500, code = 'INTERNAL_ERROR', details } = {}) {
    super(message);
    this.name = this.constructor.name;
    this.httpStatus = status;
    this.code = code;
    if (details !== undefined) this.details = details;
  }
}
class ValidationError extends AppError { constructor(m = 'Invalid request', d) { super(m, { status: 400, code: 'VALIDATION_ERROR', details: d }); } }
class AuthenticationError extends AppError { constructor(m = 'Not signed in') { super(m, { status: 401, code: 'UNAUTHENTICATED' }); } }
class ForbiddenError extends AppError { constructor(m = 'Forbidden', code = 'FORBIDDEN') { super(m, { status: 403, code: code }); } }
class NotFoundError extends AppError { constructor(m = 'Not found') { super(m, { status: 404, code: 'NOT_FOUND' }); } }
class ConflictError extends AppError { constructor(m = 'Conflict', code = 'CONFLICT') { super(m, { status: 409, code }); } }
class BusinessRuleError extends AppError { constructor(m = 'Business rule violated', code = 'BUSINESS_RULE') { super(m, { status: 422, code }); } }

module.exports = { AppError, ValidationError, AuthenticationError, ForbiddenError, NotFoundError, ConflictError, BusinessRuleError };
