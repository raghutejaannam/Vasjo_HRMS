import React, { useState, useEffect } from "react";
import {
  AuthProvider, ToastProvider, ModalProvider, useAuth,
  Sidebar, NotifBell, BrandMark, CursorGlow, CardSpotlight,
  GlobalSearch,
  Breadcrumbs,
} from "./components.jsx";
import { LoginScreen, ForcedResetScreen, PAGES } from "./pages.jsx";

function AppShell() {
  const { user, mustReset, checking } = useAuth();
  const resolveLocation = () => {
    const p = window.location.pathname.replace(/^\/+|\/+$/g, "");
    const routes = {
      "home":"dashboard","inbox":"inbox","me/profile":"worker-profile","me/onboarding":"my-onboarding","me/documents":"my-documents","me/performance/goals":"performance-goals","me/performance/reviews":"my-reviews","team/onboarding":"team-onboarding","team/performance/reviews":"team-performance-reviews","people/org-chart":"org-chart","me/offboarding":"offboarding","people/background-checks":"background-checks","talent/performance-depth":"performance-depth","team/leave-calendar":"workforce-experience","me/tax":"tax-experience","talent/recruitment-depth":"recruitment-depth","talent/learning-depth":"learning-benefits","services/delegations":"workflow-delegation","team/onboarding-plan":"onboarding-journey","services/document-templates":"document-templates","reports/experience":"p2-reports","workspace-approvals":"inbox","document-center":"my-documents","lifecycle-admin":"team-onboarding"
    };
    if (p.startsWith("people/workers/")) return { view:"worker-profile", params:{id:p.split("/")[2]} };
    if (p.startsWith("team/performance/reviews/")) return { view:"team-performance-reviews", params:{reviewId:p.split("/")[3]} };
    return { view: routes[p] || p || "dashboard", params:{} };
  };
  const initial = resolveLocation();
  const [view, setView] = useState(initial.view);
  const [routeParams, setRouteParams] = useState(initial.params);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = (next, params = {}) => {
    const legacy = { "workspace-approvals":"inbox", "document-center":"my-documents", "lifecycle-admin":"team-onboarding" };
    next = legacy[next] || next;
    const map = { dashboard:"/home", inbox:"/inbox", "worker-profile":"/me/profile", "my-onboarding":"/me/onboarding", "my-documents":"/me/documents", "performance-goals":"/me/performance/goals","my-reviews":"/me/performance/reviews", "team-onboarding":"/team/onboarding", "team-performance-reviews":"/team/performance/reviews","org-chart":"/people/org-chart","offboarding":"/me/offboarding","background-checks":"/people/background-checks","performance-depth":"/talent/performance-depth","workforce-experience":"/team/leave-calendar","tax-experience":"/me/tax","recruitment-depth":"/talent/recruitment-depth","learning-benefits":"/talent/learning-depth","workflow-delegation":"/services/delegations","onboarding-journey":"/team/onboarding-plan","document-templates":"/services/document-templates","p2-reports":"/reports/experience","workspace-approvals":"/inbox","document-center":"/me/documents","lifecycle-admin":"/team/onboarding" };
    let path = map[next] || next;
    if (next === "worker-profile" && params.id) path = `/people/workers/${params.id}`;
    if (next === "team-performance-reviews" && params.reviewId) path = `/team/performance/reviews/${params.reviewId}`;
    window.history.pushState({}, "", path);
    setView(next); setRouteParams(params); setSidebarOpen(false);
  };
  useEffect(() => { const onPop = () => { const x=resolveLocation(); setView(x.view); setRouteParams(x.params); }; window.addEventListener("popstate", onPop); return () => window.removeEventListener("popstate", onPop); }, []);

  if (checking) {
    return <div style={{ display: "flex", minHeight: "100vh", alignItems: "center", justifyContent: "center", color: "var(--text-dim)" }}>Loading…</div>;
  }

  if (!user) {
    return <LoginScreen onLoggedIn={() => {}} />;
  }

  if (mustReset) {
    return <ForcedResetScreen onDone={() => { navigate("dashboard"); }} />;
  }

  const Page = PAGES[view] || PAGES.dashboard;

  return (
    <div id="app-shell">
      <Sidebar view={view} setView={navigate} sidebarOpen={sidebarOpen} closeSidebar={() => setSidebarOpen(false)} />
      {sidebarOpen ? <div className="sidebar-scrim" onClick={() => setSidebarOpen(false)} /> : null}
      <div className="main-col">
        <header className="topbar">
          <button className="hamburger-btn" onClick={() => setSidebarOpen((o) => !o)}>☰</button>
          <div className="topbar-brand"><BrandMark /></div>
          <GlobalSearch view={view} setView={navigate} />
          <NotifBell />
        </header>
        <main className="content">
          <Breadcrumbs view={view} setView={navigate} />
          <div className="page-fade" key={view}>
            <Page navTo={navigate} {...routeParams} />
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <ModalProvider>
          <CursorGlow />
          <CardSpotlight />
          <AppShell />
        </ModalProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
