import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import * as api from "./api.js";

// ============================================================
// Small formatting / date helpers shared across pages
// ============================================================
export const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
export const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export function initials(name) {
  return (name || "").split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}
// RBAC check against the permission list the server attaches to the session user.
export function can(user, permission) {
  const ps = (user && user.permissions) || [];
  return ps.includes('*') || ps.includes(permission) || ps.includes(`${String(permission).split('.')[0]}.*`);
}
export function isApprover(user) { return can(user, 'manager.approve') || can(user, 'admin.configure'); }

export function fmtDate(d) {
  if (!d) return "—";
  // Date-only values (e.g. leave from/to, expense claim dates) come back
  // from the API as UTC-midnight ISO timestamps such as
  // "2026-09-25T00:00:00.000Z". Building a Date from that and calling
  // toLocaleDateString() converts to the *viewer's* local timezone, which
  // shifts the displayed calendar day back by one for anyone west of UTC.
  // Strip a midnight-UTC time component first so date-only values are
  // always treated as calendar dates, not as an instant in time.
  const dateOnlyMatch = d.length > 10 ? d.match(/^(\d{4}-\d{2}-\d{2})T00:00:00(\.000)?Z$/) : null;
  const dt = new Date(dateOnlyMatch ? `${dateOnlyMatch[1]}T00:00:00` : (d.length > 10 ? d : `${d}T00:00:00`));
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
export function fmtDateTime(d) {
  if (!d) return "—";
  return new Date(d.replace(" ", "T")).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
export function stampClass(status) {
  return { approved: "approved", verified: "approved", resolved: "approved", pending: "pending", submitted: "pending", open: "pending", in_progress: "pending", rejected: "rejected", draft: "draft", cancelled: "draft", closed: "draft" }[status] || "draft";
}
export function fmtMoney(v) {
  if (v === null || v === undefined) return "—";
  return "₹" + Number(v).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
export function fmtMoneyDec(v) {
  if (v === null || v === undefined) return "—";
  return "₹" + Number(v).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
export function mondayOf(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  const day = d.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  d.setDate(d.getDate() + diff);
  return d;
}
export function weekDates(mondayDate) {
  const out = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(mondayDate);
    d.setDate(d.getDate() + i);
    out.push(d);
  }
  return out;
}
export function toISODate(d) { return d.toISOString().slice(0, 10); }
export function addWeeks(dateObj, n) {
  const d = new Date(dateObj);
  d.setDate(d.getDate() + n * 7);
  return d;
}
export function leaveTypeName(id, types) {
  const t = (types || []).find((x) => x.id === id || x.id === parseInt(id, 10));
  return t ? t.name : "—";
}
export function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ============================================================
// Toast
// ============================================================
const ToastContext = createContext(() => {});
export function useToast() { return useContext(ToastContext); }

export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null); // { msg, isError }
  const timerRef = useRef(null);

  const showToast = useCallback((msg, isError = false) => {
    setToast({ msg, isError });
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setToast(null), 3200);
  }, []);

  const showError = useCallback((err) => {
    console.error(err);
    showToast(err?.message || "Something went wrong", true);
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, showError }}>
      {children}
      <div className={`toast${toast ? " show" : ""}${toast?.isError ? " error" : ""}`}>
        <span className="dot" />
        <span>{toast?.msg || ""}</span>
      </div>
    </ToastContext.Provider>
  );
}

// ============================================================
// Modal
// ============================================================
const ModalContext = createContext(null);
export function useModal() { return useContext(ModalContext); }

export function ModalProvider({ children }) {
  const [modal, setModal] = useState(null); // { title, body, footer }

  const openModal = useCallback((title, body, footer) => setModal({ title, body, footer }), []);
  const closeModal = useCallback(() => setModal(null), []);

  /** Promise-based comment prompt, replacing the old promptComment() helper. */
  const promptComment = useCallback((actionLabel, required = false) => {
    return new Promise((resolve) => {
      let value = "";
      let error = "";
      const renderBody = () => (
        <div className="field">
          <label>Comment {required ? "(required — the employee will see this)" : "(optional)"}</label>
          <textarea
            autoFocus
            placeholder={required ? "Explain what needs to change..." : "Add a note for the employee..."}
            defaultValue={value}
            onChange={(e) => { value = e.target.value; }}
          />
          {error ? <div className="inline-error">{error}</div> : null}
        </div>
      );
      const submit = () => {
        const v = value.trim();
        if (required && !v) {
          error = "A comment is required when rejecting.";
          setModal((m) => (m ? { ...m, body: renderBody() } : m));
          return;
        }
        setModal(null);
        resolve(v || "");
      };
      const cancel = () => { setModal(null); resolve(null); };
      setModal({
        title: actionLabel,
        body: renderBody(),
        footer: (
          <>
            <button className="btn btn-ghost" onClick={cancel}>Cancel</button>
            <button className="btn btn-primary" onClick={submit}>Confirm</button>
          </>
        ),
      });
    });
  }, []);

  return (
    <ModalContext.Provider value={{ openModal, closeModal, promptComment }}>
      {children}
      <div className={`modal-overlay${modal ? " open" : ""}`} onClick={(e) => { if (e.target === e.currentTarget) closeModal(); }}>
        <div className="modal">
          <div className="modal-header">
            <h3>{modal?.title || ""}</h3>
            <button className="modal-close" onClick={closeModal}>✕</button>
          </div>
          <div className="modal-body">{modal?.body}</div>
          <div className="modal-footer">{modal?.footer}</div>
        </div>
      </div>
    </ModalContext.Provider>
  );
}

// ============================================================
// Auth context — user, csrf token, session bootstrap
// ============================================================
const AuthContext = createContext(null);
export function useAuth() { return useContext(AuthContext); }

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [mustReset, setMustReset] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { user: u, csrfToken: tok } = await api.me();
        api.setCsrfToken(tok);
        setUser(u);
      } catch (e) {
        /* not logged in */
      } finally {
        setChecking(false);
      }
    })();
  }, []);

  const doLogin = useCallback(async (email, password) => {
    const { user: u, csrfToken: tok, mustReset: mr } = await api.login(email, password);
    api.setCsrfToken(tok);
    setUser(u);
    if (mr) setMustReset(true);
    return { mustReset: !!mr };
  }, []);

  const completeForcedReset = useCallback(async (currentPassword, newPassword) => {
    await api.changePassword(currentPassword, newPassword);
    setMustReset(false);
  }, []);

  const doLogout = useCallback(async () => {
    try { await api.logout(); } catch (e) { /* ignore */ }
    api.setCsrfToken(null);
    setUser(null);
    setMustReset(false);
  }, []);

  const refreshUser = useCallback(async () => {
    const { user: u } = await api.me();
    setUser(u);
    return u;
  }, []);

  return (
    <AuthContext.Provider value={{ user, setUser, mustReset, checking, doLogin, completeForcedReset, doLogout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

// ============================================================
// Nav structure — identical grouping/labels/roles to the original app
// ============================================================
// Small glyph per nav destination — purely decorative, keyed by the same
// route ids already used everywhere else, so it never touches routing.
export const NAV_ICONS = {
  "dashboard": "◈", "inbox":"✉", "worker-profile":"◐", "my-onboarding":"✓", "my-documents":"▧", "performance-goals":"★", "team-onboarding":"◎", "team-performance-reviews":"★", "my-reviews":"★", "document-verification":"▧", "calendar": "▦", "timesheet-entry": "◷", "timesheet-history": "☰",
  "leave-application": "✎", "leave-history": "▤",
  "my-salary": "₹", "my-tax-declaration": "§", "my-payslips": "▧", "my-benefits": "☂",
  "approvals": "✓", "team-timesheets": "▥", "reports": "▲", "team": "◎",
  "payroll-dashboard": "◈", "payroll-run": "⟳", "salary-admin": "₹",
  "payroll-benefits-admin": "☂", "payroll-reports": "△",
  "my-attendance": "⏱", "attendance-admin": "⏱",
  "my-tax-statement": "§", "compliance-admin": "§", "fnf-admin": "⏏",
  "my-comp-off": "☯", "leave-calendar": "▤", "leave-admin": "▤", "lifecycle-admin": "◐",
  "admin": "⚙", "profile": "◐",
  "document-center": "▧", "workflow-admin": "✓", "organization-admin": "◎", "payroll-controls": "₹", "compliance-rules": "§", "security-admin": "⚙",
  recruitment: "♙", performance: "★", learning: "⌘", benefits: "☂", expenses: "₹", assets: "▣", helpdesk: "?", "integration-hub": "⇄", "enterprise-analytics": "◉", mobile: "▣", "ai-assistant": "✦", "ai-payroll": "⌁", "ai-documents": "✧", "saved-reports": "▤",
};

export const DOMAIN_NAV = [
  { id: "home", label: "Home", icon: "⌂", workspace: "workspace-home", items: [{ id: "dashboard", label: "Dashboard", roles: ["employee", "manager", "admin"] }, { id: "inbox", label: "Inbox", roles: ["manager", "admin"] }, { id: "worker-profile", label: "My Profile" }, { id: "my-onboarding", label: "My Onboarding" }, { id: "my-documents", label: "My Documents", permission: "document.read" }, { id: "performance-goals", label: "My Goals", permission: "performance.read" }, { id: "my-reviews", label: "My Reviews", permission: "performance.read" }, { id: "offboarding", label: "My Offboarding" }, { id: "tax-experience", label: "Tax & Annual Statements" }] },
  { id: "my-work", label: "My Work", icon: "◷", workspace: "workspace-my-work", items: [
    { id: "calendar", label: "Calendar" }, { id: "timesheet-entry", label: "Submit Timesheet" }, { id: "timesheet-history", label: "Timesheet History" },
    { id: "my-attendance", label: "My Attendance" }, { id: "my-comp-off", label: "My Comp-Off" }, { id: "leave-calendar", label: "Leave Calendar" },
  ] },
  { id: "approvals", label: "Approvals", icon: "✓", workspace: "workspace-approvals", items: [{ id: "approvals", label: "Approval Center", roles: ["manager", "admin"] }, { id: "team-timesheets", label: "Team Timesheets", roles: ["manager", "admin"] }] },
  { id: "leave", label: "Leave", icon: "▤", workspace: "workspace-leave", items: [
    { id: "leave-application", label: "Apply for Leave" }, { id: "leave-history", label: "Leave History" }, { id: "leave-admin", label: "Leave Policies", roles: ["admin"] },
  ] },
  { id: "payroll", label: "Payroll", icon: "₹", workspace: "workspace-payroll", items: [
    { id: "my-salary", label: "My Salary" }, { id: "my-tax-declaration", label: "Tax Declaration" }, { id: "my-tax-statement", label: "My Tax Statement" },
    { id: "my-payslips", label: "My Payslips" }, { id: "my-benefits", label: "My Benefits" },
    { id: "payroll-dashboard", label: "Payroll Dashboard", roles: ["admin"] }, { id: "payroll-run", label: "Payroll Runs", roles: ["admin"] },
    { id: "salary-admin", label: "Salary Setup", roles: ["admin"] }, { id: "payroll-benefits-admin", label: "Loans, Advances & Encashment", roles: ["admin"] },
    { id: "payroll-reports", label: "Payroll Reports", roles: ["admin"] }, { id: "payroll-controls", label: "Payroll Controls", roles: ["admin"] },
    { id: "compliance-admin", label: "Tax & Statutory Compliance", roles: ["admin"] }, { id: "fnf-admin", label: "Full & Final Settlement", roles: ["admin"] },
  ] },
  { id: "people", label: "People", icon: "◎", workspace: "workspace-people", items: [
    { id: "team", label: "My Team", roles: ["manager", "admin"] }, { id: "team-onboarding", label: "New Hires", permission: "manager.approve" }, { id: "team-performance-reviews", label: "Team Reviews", permission: "performance.read" }, { id: "org-chart", label: "Reporting Line", permission: "employee.read" }, { id: "background-checks", label: "Background Verification", permission: "employee.read" }, { id: "document-verification", label: "Document Verification", permission: "document.verify" }, { id: "organization-admin", label: "Organization & Positions", roles: ["admin"] }, { id: "lifecycle-admin", label: "Employee Lifecycle", roles: ["admin"] },
  ] },
  { id: "talent", label: "Talent", icon: "★", workspace: "workspace-talent", items: [
    { id: "recruitment", label: "Recruitment", permission: "recruitment.read" }, { id: "performance", label: "Performance", permission: "performance.read" }, { id: "performance-depth", label: "Performance Depth", permission: "performance.read" }, { id: "learning", label: "Learning", permission: "learning.read" }, { id: "learning-benefits", label: "Learning & Development", permission: "learning.read" }, { id: "benefits", label: "Benefits", permission: "benefits.read" }, { id: "recruitment-depth", label: "Recruitment Depth", permission: "recruitment.read" },
  ] },
  { id: "services", label: "Services", icon: "▣", workspace: "workspace-services", items: [
    { id: "expenses", label: "Expenses" }, { id: "assets", label: "Assets" }, { id: "workforce-experience", label: "Workforce Experience" }, { id: "workflow-delegation", label: "Approval Delegation" }, { id: "document-templates", label: "Document Templates" }, { id: "helpdesk", label: "HR Service Desk" }, { id: "document-center", label: "Documents", permission: "document.read" },
  ] },
  { id: "reports", label: "Reports & Analytics", icon: "▲", workspace: "workspace-reports", items: [
    { id: "reports", label: "Reports", roles: ["manager", "admin"] }, { id: "p2-reports", label: "HR Experience Overview", roles: ["manager", "admin"] }, { id: "payroll-reports", label: "Payroll Reports", roles: ["admin"] }, { id: "enterprise-analytics", label: "Enterprise Analytics", roles: ["admin", "manager"] }, { id: "saved-reports", label: "Saved Reports", roles: ["admin"] },
  ] },
  { id: "administration", label: "Administration", icon: "⚙", workspace: "workspace-admin", items: [
    { id: "admin", label: "User & System Admin", roles: ["admin"] }, { id: "security-admin", label: "Security & Access", roles: ["admin"] }, { id: "workflow-admin", label: "Workflow & Notifications", roles: ["admin", "manager"] },
    { id: "attendance-admin", label: "Attendance Management", roles: ["admin"] }, { id: "compliance-rules", label: "Compliance Rules", roles: ["admin"] }, { id: "integration-hub", label: "Integration Hub", roles: ["admin"] }, { id: "mobile", label: "Mobile Workspace", roles: ["admin", "manager"] },
  ] },
  { id: "ai", label: "AI", icon: "✦", workspace: "workspace-ai", items: [
    { id: "ai-assistant", label: "AI Assistant" }, { id: "ai-payroll", label: "Payroll Intelligence", roles: ["admin"] }, { id: "ai-documents", label: "Document Intelligence", roles: ["admin"] },
  ] },
];

export function visibleDomains(userOrRole) {
  const user = typeof userOrRole === "object" ? userOrRole : { role: userOrRole, permissions: [] };
  const allowed = (item) => {
    if (item.permission && !can(user, item.permission)) return false;
    return !item.roles || item.roles.includes(user.role);
  };
  return DOMAIN_NAV.map((domain) => ({ ...domain, items: domain.items.filter(allowed) }))
    .filter((domain) => domain.id === "home" || domain.items.length > 0);
}

// ============================================================
// Brand mark (sidebar + login screen)
// ============================================================
export function BrandMark() {
  return (
    <div className="brand-mark">
      <div className="vasjo-mark">
        <span className="pix p1" /><span className="pix p2" /><span className="pix p3" />
        <span className="pix p4" /><span className="pix p5" /><span className="pix p6" />
        <div className="stroke-a" /><div className="stroke-b" /><div className="arrowhead" />
        <span className="node n1" /><span className="node n2" /><span className="node n3" />
      </div>
      <div className="vasjo-word">
        <span className="word-main"><span className="vas">VAS</span><span className="jo">JO</span></span>
        <span className="word-sub">TECHNOLOGIES</span>
      </div>
    </div>
  );
}

export function EmployeePicker({ value, onChange, disabled=false, placeholder="Search employee…" }) {
  const [items,setItems]=useState([]), [q,setQ]=useState(""), [open,setOpen]=useState(false), [loading,setLoading]=useState(false);
  useEffect(()=>{ let alive=true; if(q.trim().length<2){setItems([]);return;} setLoading(true); api.getUsersFlat().then(r=>{ if(!alive)return; const all=r.users||[]; const x=q.toLowerCase(); setItems(all.filter(u=>`${u.name} ${u.id} ${u.email||''} ${u.dept||''} ${u.title||''}`.toLowerCase().includes(x)).slice(0,12)); }).catch(()=>setItems([])).finally(()=>alive&&setLoading(false)); return()=>{alive=false}; },[q]);
  const selected=items.find(x=>String(x.id)===String(value));
  return <div style={{position:'relative',minWidth:260}}><input className="input-sm" disabled={disabled} placeholder={placeholder} value={selected?.name||q} onFocus={()=>setOpen(true)} onChange={e=>{setQ(e.target.value);setOpen(true);if(!e.target.value)onChange?.('')}} onKeyDown={e=>{if(e.key==='Escape')setOpen(false);if(e.key==='ArrowDown'&&items[0]){e.preventDefault();onChange?.(items[0].id);setQ(items[0].name)}}}/>{open&&!disabled?<div className="global-search-results" style={{position:'absolute',zIndex:30,left:0,right:0,top:'calc(100% + 4px)',maxHeight:300,overflow:'auto'}}>{loading?<div className="global-search-empty">Searching…</div>:items.map(u=><button key={u.id} onMouseDown={e=>e.preventDefault()} onClick={()=>{onChange?.(u.id);setQ('');setOpen(false)}}><span>{initials(u.name)}</span><span><strong>{u.name}</strong><small>{u.employee_code||u.email||u.dept||'Employee'}</small></span></button>)}{!loading&&q.length>=2&&!items.length?<div className="global-search-empty">No employee found.</div>:null}</div>:null}{value?<button type="button" className="btn btn-ghost btn-sm" style={{marginTop:4}} onClick={()=>{onChange?.('');setQ('')}}>Clear</button>:null}</div>;
}

// ============================================================
// Sidebar
// ============================================================
export function Sidebar({ view, setView, sidebarOpen, closeSidebar }) {
  const { user, doLogout } = useAuth();
  const [expanded, setExpanded] = useState(() => {
    try { return JSON.parse(localStorage.getItem("vasjo-nav-expanded") || "{}"); } catch { return {}; }
  });
  const domains = user ? visibleDomains(user) : [];
  const activeDomain = domains.find((domain) => domain.workspace === view || domain.items.some((item) => item.id === view))?.id || "home";
  useEffect(() => {
    setExpanded((current) => ({ ...current, [activeDomain]: true }));
  }, [activeDomain]);
  function toggleDomain(id) {
    setExpanded((current) => {
      const next = { ...current, [id]: !current[id] };
      localStorage.setItem("vasjo-nav-expanded", JSON.stringify(next));
      return next;
    });
  }

  if (!user) return null;
  return (
    <aside className={`sidebar${sidebarOpen ? " open" : ""}`} id="app-sidebar">
      <BrandMark />
      <nav>
        {domains.map((domain) => (
          <div className="nav-group domain-group" key={domain.id}>
            {domain.id === "home" ? (
              <button className={`nav-item domain-item${activeDomain === domain.id ? " active" : ""}`} onClick={() => setView(domain.workspace)}>
                <span className="nav-icon" aria-hidden="true">{domain.icon}</span><span className="nav-label-text">{domain.label}</span>
              </button>
            ) : (
              <button
                className={`nav-item domain-item${activeDomain === domain.id ? " active" : ""}`}
                onClick={() => { toggleDomain(domain.id); setView(domain.workspace); }}
              >
                <span className="nav-icon" aria-hidden="true">{domain.icon}</span><span className="nav-label-text">{domain.label}</span>
                <span className="domain-chevron">{expanded[domain.id] ? "⌃" : "⌄"}</span>
              </button>
            )}
            {domain.id !== "home" && expanded[domain.id] ? <div className="nav-children">
              <button className={`nav-item nav-workspace${view === domain.workspace ? " active" : ""}`} onClick={() => { setView(domain.workspace); closeSidebar(); }}>
                <span className="nav-icon">◆</span><span className="nav-label-text">{domain.label} Workspace</span>
              </button>
              {domain.items.map((item) => (
                <button key={`${domain.id}-${item.id}`} className={`nav-item nav-child${view === item.id ? " active" : ""}`} onClick={() => { setView(item.id); closeSidebar(); }}>
                  <span className="nav-icon">{NAV_ICONS[item.id] || "•"}</span><span className="nav-label-text">{item.label}</span>
                </button>
              ))}
            </div> : null}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="user-chip">
          <div className="user-avatar" style={{ background: user.avatar_color || "var(--amber)" }}>{initials(user.name)}</div>
          <div className="who">
            <div className="name">{user.name}</div>
            <div className="role">{user.role}</div>
          </div>
        </div>
        <button className="logout-btn" onClick={() => { closeSidebar(); doLogout(); }}>↩ Sign out</button>
      </div>
    </aside>
  );
}

export function GlobalSearch({ view, setView }) {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const domains = visibleDomains(user);
  const options = domains.flatMap((domain) => [
    { id: domain.workspace, label: `${domain.label} workspace`, domain: domain.label },
    ...domain.items.map((item) => ({ ...item, domain: domain.label })),
  ]);
  useEffect(() => {
    const onKeyDown = (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); setOpen(true); } };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);
  const results = options.filter((item) => `${item.label} ${item.domain}`.toLowerCase().includes(query.toLowerCase())).slice(0, 8);
  function choose(id) { setView(id); setQuery(""); setOpen(false); }
  return <div className="global-search">
    <button className="global-search-trigger" onClick={() => setOpen(true)} aria-label="Search navigation"><span>⌕</span><span>Search workspace</span><kbd>Ctrl K</kbd></button>
    {open ? <div className="global-search-overlay" onClick={(e) => { if (e.target === e.currentTarget) setOpen(false); }}>
      <div className="global-search-dialog">
        <input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Escape") setOpen(false); if (e.key === "Enter" && results[0]) choose(results[0].id); }} placeholder="Search Payroll, Leave, Payslips..." />
        <div className="global-search-results">{results.map((item) => <button key={item.id} onClick={() => choose(item.id)}><span>{NAV_ICONS[item.id] || "◆"}</span><span><strong>{item.label}</strong><small>{item.domain}</small></span></button>)}{!results.length ? <div className="global-search-empty">No workspace or page found.</div> : null}</div>
      </div>
    </div> : null}
  </div>;
}

export function Breadcrumbs({ view, setView }) {
  const { user } = useAuth();
  const domains = visibleDomains(user);
  const domain = domains.find((item) => item.workspace === view || item.items.some((child) => child.id === view));
  if (!domain || view === "workspace-home") return null;
  const current = domain.items.find((item) => item.id === view);
  return <div className="global-breadcrumb"><button onClick={() => setView("workspace-home")}>Home</button><span>/</span><button onClick={() => setView(domain.workspace)}>{domain.label}</button>{current ? <><span>/</span><strong>{current.label}</strong></> : null}</div>;
}

// ============================================================
// Notification bell + dropdown
// ============================================================
export function NotifBell() {
  const [items, setItems] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);

  const refresh = useCallback(async () => {
    try {
      const { items: it, unreadCount: uc } = await api.getNotifications();
      setItems(it);
      setUnreadCount(uc);
    } catch (e) { /* silent — notifications are non-critical */ }
  }, []);

  useEffect(() => {
    refresh();
    const handle = setInterval(refresh, 30000);
    return () => clearInterval(handle);
  }, [refresh]);

  useEffect(() => {
    function onDocClick(e) {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  async function onItemClick(id) {
    await api.markNotificationRead(id);
    refresh();
  }
  async function markAll(e) {
    e.stopPropagation();
    await api.markAllNotificationsRead();
    refresh();
  }

  return (
    <div style={{ position: "relative", marginLeft: "auto" }} ref={rootRef}>
      <button className={`notif-bell${unreadCount > 0 ? " has-unread" : ""}`} title="Notifications" onClick={() => setOpen((o) => !o)}>
        🔔<span className="notif-dot" />
      </button>
      <div className={`notif-dropdown${open ? " open" : ""}`}>
        <div className="notif-dropdown-head">
          <span>Notifications</span>
          <button onClick={markAll}>Mark all read</button>
        </div>
        <div>
          {items.length === 0 ? (
            <div className="notif-empty">You're all caught up.</div>
          ) : items.map((n) => (
            <div key={n.id} className={`notif-item${n.read ? "" : " unread"}`} onClick={() => onItemClick(n.id)}>
              <span className="n-dot" />
              <div>
                <div className="n-msg">{n.message}</div>
                <div className="n-time">{fmtDateTime(n.created_at)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Generic building blocks
// ============================================================
export function PageHead({ eyebrow, title, sub, actions }) {
  return (
    <div className="page-head">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        {sub ? <div className="sub">{sub}</div> : null}
      </div>
      {actions ? <div style={{ display: "flex", gap: "0.5rem" }}>{actions}</div> : null}
    </div>
  );
}

export function Card({ title, children, style, right }) {
  return (
    <div className="card" style={style}>
      {title ? (
        <div className="card-title" style={right ? { display: "flex", justifyContent: "space-between", alignItems: "center" } : undefined}>
          {title}{right}
        </div>
      ) : null}
      {children}
    </div>
  );
}

export function StatCard({ label, value, foot, tone }) {
  return (
    <div className={`stat-card${tone ? ` ${tone}` : ""}`}>
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {foot ? <div className="foot">{foot}</div> : null}
    </div>
  );
}

export function Stamp({ status, label }) {
  return <span className={`stamp ${stampClass(status)}`}>{label || status}</span>;
}

export function EmptyRow({ colSpan, children }) {
  return (
    <tr className="empty-row">
      <td colSpan={colSpan}>{children}</td>
    </tr>
  );
}

// Shared full-width loading state — replaces the old plain "Loading…" text
// with a skeleton shimmer, matching the page-head + stat-grid shape most
// pages load into. Purely presentational; callers still gate on their own
// data becoming non-null exactly as before.
export function PageLoading() {
  return (
    <div aria-busy="true" aria-label="Loading">
      <div className="skeleton" style={{ width: "8rem", height: "0.7rem", marginBottom: "0.7rem" }} />
      <div className="skeleton" style={{ width: "16rem", height: "1.6rem", marginBottom: "2rem" }} />
      <div className="stat-grid">
        {[0, 1, 2, 3].map((i) => (
          <div className="stat-card" key={i}>
            <div className="skeleton" style={{ width: "60%", height: "0.6rem", marginBottom: "0.8rem" }} />
            <div className="skeleton" style={{ width: "45%", height: "1.6rem" }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// Payroll workflow stepper — visualizes DRAFT → CALCULATED → REVIEWED →
// APPROVED → LOCKED for a run's existing `status` string. Read-only,
// decorative: it never changes what actions are shown, only how the
// current stage reads. `compact` renders a thin inline version for use
// inside a table cell.
const PAYROLL_STAGES = ["draft", "calculated", "reviewed", "approved", "locked"];
export function PayrollStagePath({ status, compact }) {
  const idx = PAYROLL_STAGES.indexOf(status);
  return (
    <div className={compact ? "stage-path stage-path-compact" : "stage-path"}>
      {PAYROLL_STAGES.map((stage, i) => {
        const state = idx < 0 ? "" : i < idx ? "done" : i === idx ? "current" : "";
        return (
          <React.Fragment key={stage}>
            <div className={`stage-node ${state}`}>
              <span className="stage-dot" />
              {!compact ? <span className="stage-name">{stage}</span> : null}
            </div>
            {i < PAYROLL_STAGES.length - 1 ? <span className={`stage-link${state === "done" ? " done" : ""}`} /> : null}
          </React.Fragment>
        );
      })}
    </div>
  );
}

export function BarChart({ rows, labelKey, valueKey, unit }) {
  const max = Math.max(1, ...rows.map((r) => r[valueKey] || 0));
  if (!rows.length) return <div style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>No data yet.</div>;
  return (
    <div className="bar-chart">
      {rows.map((r, i) => (
        <div className="bar-row" key={i}>
          <div className="bar-label">{r[labelKey]}</div>
          <div className="bar-track"><div className="bar-fill" style={{ width: `${Math.round(((r[valueKey] || 0) / max) * 100)}%` }} /></div>
          <div className="bar-value">{r[valueKey]}{unit || ""}</div>
        </div>
      ))}
    </div>
  );
}

export function Field({ label, children }) {
  return (
    <div className="field">
      <label>{label}</label>
      {children}
    </div>
  );
}

/** Expandable "View history" widget backed by /api/audit-log. */
export function AuditToggle({ entityType, entityId }) {
  const [open, setOpen] = useState(false);
  const [log, setLog] = useState(null);
  const { showError } = useToast();

  async function toggle(e) {
    e.preventDefault();
    if (open) { setOpen(false); return; }
    try {
      if (!log) {
        const { log: l } = await api.getAuditLog(entityType, entityId);
        setLog(l);
      }
      setOpen(true);
    } catch (err) { showError(err); }
  }

  return (
    <>
      <a href="#" className="audit-toggle" onClick={toggle}>{open ? "Hide history" : "View history"}</a>
      <div className={`audit-panel${open ? " open" : ""}`}>
        {open && log ? (
          log.length ? log.map((l, i) => (
            <div className="audit-item" key={i}>
              <span className="a-actor">{l.actor_name}</span> {l.action} — <span className="a-time">{fmtDateTime(l.acted_at)}</span>
              {l.notes ? <div className="a-notes">"{l.notes}"</div> : null}
            </div>
          )) : <div style={{ color: "var(--text-dim)", fontSize: "0.78rem" }}>No history yet.</div>
        ) : null}
      </div>
    </>
  );
}

/** Shared "reset a user's password" button + result modal, used by Admin and My Team. */
export function ResetPasswordButton({ userId, userName }) {
  const { openModal, closeModal } = useModal();
  const { showError } = useToast();

  async function onClick() {
    if (!window.confirm(`Reset the password for ${userName}? Their current password will stop working immediately.`)) return;
    try {
      const { tempPassword, userName: uName, userEmail } = await api.resetUserPassword(userId);
      openModal(
        `Password reset — ${uName}`,
        <>
          <p className="subtle-note" style={{ marginTop: 0 }}>
            Share this temporary password with {uName} ({userEmail}) through your normal channel — Slack, in person, etc.
            They'll be asked to set their own password the next time they sign in.
          </p>
          <Field label="Temporary password">
            <input type="text" defaultValue={tempPassword} readOnly style={{ fontFamily: "var(--font-mono)", fontSize: "1rem", textAlign: "center" }} />
          </Field>
        </>,
        <>
          <button className="btn btn-ghost" onClick={() => { navigator.clipboard?.writeText(tempPassword).catch(() => {}); }}>Copy</button>
          <button className="btn btn-primary" onClick={closeModal}>Done</button>
        </>
      );
    } catch (err) { showError(err); }
  }

  return <button className="btn btn-ghost btn-sm" onClick={onClick}>Reset Password</button>;
}

// ============================================================
// VISUAL-ONLY ADDITIONS (motion/VFX layer)
// These are purely decorative, isolated, and additive: no existing
// export above is modified. Both are opt-in — CursorGlow is mounted
// once in App.jsx and renders nothing that intercepts pointer events.
// ============================================================

/** True when the user has requested reduced motion at the OS/browser level. */
export function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(() =>
    typeof window !== "undefined" && window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)").matches : false
  );
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener ? mq.addEventListener("change", onChange) : mq.addListener(onChange);
    return () => {
      mq.removeEventListener ? mq.removeEventListener("change", onChange) : mq.removeListener(onChange);
    };
  }, []);
  return reduced;
}

/**
 * A soft radial-gradient glow that follows the pointer on desktop.
 * - Renders nothing on touch devices (no `(pointer: fine)` match).
 * - Renders nothing when prefers-reduced-motion is set.
 * - `pointer-events: none` (see styles.css) so it can never intercept clicks.
 * - Listener is passive and removed on unmount.
 */
export function CursorGlow() {
  const dotRef = useRef(null);
  const reducedMotion = usePrefersReducedMotion();
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    setEnabled(window.matchMedia("(pointer: fine)").matches);
  }, []);

  useEffect(() => {
    if (!enabled || reducedMotion) return;
    function onMove(e) {
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX - 210}px, ${e.clientY - 210}px)`;
      }
    }
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, [enabled, reducedMotion]);

  if (!enabled || reducedMotion) return null;
  return <div className="cursor-glow" ref={dotRef} aria-hidden="true" />;
}

/**
 * Powers the subtle mouse-follow spotlight on .card / .stat-card (see
 * styles.css `.card::after`). Uses a single delegated pointermove listener
 * and only ever writes CSS custom properties — never touches layout,
 * never intercepts events. No-op on touch devices or reduced motion.
 */
export function CardSpotlight() {
  const reducedMotion = usePrefersReducedMotion();
  useEffect(() => {
    if (reducedMotion || typeof window === "undefined" || !window.matchMedia) return;
    if (!window.matchMedia("(pointer: fine)").matches) return;
    let raf = null;
    function onMove(e) {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = null;
        const el = e.target.closest && e.target.closest(".card, .stat-card");
        if (el) {
          const r = el.getBoundingClientRect();
          el.style.setProperty("--mx", `${e.clientX - r.left}px`);
          el.style.setProperty("--my", `${e.clientY - r.top}px`);
        }
      });
    }
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => { window.removeEventListener("pointermove", onMove); if (raf) cancelAnimationFrame(raf); };
  }, [reducedMotion]);
  return null;
}
