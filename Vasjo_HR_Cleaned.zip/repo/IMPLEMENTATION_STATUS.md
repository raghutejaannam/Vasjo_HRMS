# Vasjo HR Platform P0/P1/P2 Updated Code

This package contains the cumulative P0 + P1 implementation plus the P2 UI/backend extension.

## P0/P1 UI coverage upgraded
- My onboarding with document upload and task completion
- My Documents canonical document experience
- Permission-aware HR document verification
- Goals with historical check-ins
- Self-review workflow
- Manager review detail workflow
- Performance feedback / PIP / calibration workspace
- Worker profile and reporting line
- Unified inbox and existing P0/P1 routes

## P2 backend/UI
See `backend/docs/P2_IMPLEMENTATION.md` and `P2_RELEASE_NOTES.md`.

## Migration
`backend/prisma/migrations/0007_p2_experience_depth/migration.sql`

## Runtime setup
Dependencies are intentionally not included in this source release.

Backend:
1. `cd backend`
2. `npm install`
3. `npx prisma generate`
4. configure `DATABASE_URL`
5. `npx prisma migrate deploy`
6. `npm test`

Frontend:
1. `cd frontend`
2. `npm install`
3. `npm run build`
